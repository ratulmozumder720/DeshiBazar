import express from 'express';
import type { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import { generateEcommerceThemeZip } from './src/utils/themeZipGenerator.ts';
import { apiRouter } from './server/apiRouter.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = process.env.PORT || 3000;

  app.use(express.json());

  // CORS middleware for API routes
  app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
    if (req.method === 'OPTIONS') {
      res.sendStatus(200);
      return;
    }
    next();
  });

  // Mount modular backend REST APIs
  app.use('/api', apiRouter);

  // ==========================================
  // 1. LIVE INTERNET CONNECTIVITY STATUS CHECK
  // ==========================================
  app.get('/api/internet/status', async (_req: Request, res: Response) => {
    const startTime = Date.now();
    try {
      // Ping public internet endpoint with timeout
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 4000);

      const response = await fetch('https://dns.google/resolve?name=google.com', {
        method: 'GET',
        headers: { 'User-Agent': 'DeshiBazar-LiveSync/1.0' },
        signal: controller.signal
      });

      clearTimeout(timeoutId);
      const latencyMs = Date.now() - startTime;

      if (response.ok) {
        res.json({
          online: true,
          status: 'connected',
          latencyMs,
          timestamp: new Date().toISOString(),
          gateway: 'Public Web Gateway',
          details: {
            httpStatus: response.status,
            protocol: 'HTTPS',
            nodeVersion: process.version
          }
        });
      } else {
        // Still has internet connectivity even if status was non-200
        res.json({
          online: true,
          status: 'degraded',
          latencyMs,
          timestamp: new Date().toISOString(),
          gateway: 'Public Web Gateway'
        });
      }
    } catch (error: any) {
      const latencyMs = Date.now() - startTime;
      res.json({
        online: false,
        status: 'offline',
        latencyMs,
        error: error.message || 'Network unreachable',
        timestamp: new Date().toISOString()
      });
    }
  });

  // ==========================================
  // 2. BACKEND DOWNLOAD E-COMMERCE HTML ZIP
  // ==========================================
  const handleZipDownload = async (req: Request, res: Response) => {
    try {
      const options = req.method === 'POST' ? req.body : req.query;
      const zip = await generateEcommerceThemeZip(options || {});
      const buffer = await zip.generateAsync({ 
        type: 'nodebuffer',
        compression: 'DEFLATE',
        compressionOptions: { level: 9 }
      });

      const safeName = ((options?.themeName as string) || 'deshibazar-ecommerce-theme')
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '');

      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', `attachment; filename="${safeName || 'ecommerce-theme'}.zip"`);
      res.setHeader('Content-Length', buffer.length);
      res.send(buffer);
    } catch (err: any) {
      console.error('Theme ZIP generation error:', err);
      res.status(500).json({ success: false, message: err?.message || 'Failed to generate theme ZIP' });
    }
  };

  app.post('/api/theme/download-zip', handleZipDownload);
  app.get('/api/theme/download-zip', handleZipDownload);

  // Return JSON 404 for unknown /api/* routes before SPA fallback
  app.use('/api', (_req: Request, res: Response) => {
    res.status(404).json({ success: false, error: 'API endpoint not found' });
  });

  // ==========================================
  // VITE MIDDLEWARE (DEV) OR STATIC SPA (PROD)
  // ==========================================
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`DeshiBazar Full-Stack Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
