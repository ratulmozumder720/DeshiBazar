import { Router } from 'express';
import type { Request, Response } from 'express';
import { backendStore } from './backendStore.ts';
import { ALL_THEMES, THEME_CATEGORIES } from '../src/data/themesData.ts';

export const apiRouter = Router();

// ==========================================
// 1. SYSTEM HEALTH & DIAGNOSTICS
// ==========================================
apiRouter.get('/health', (_req: Request, res: Response) => {
  const health = backendStore.getSystemHealth();
  res.json({ success: true, ...health });
});

// ==========================================
// 2. PRODUCTS REST API
// ==========================================
apiRouter.get('/products', (req: Request, res: Response) => {
  try {
    const {
      search,
      category,
      minPrice,
      maxPrice,
      isDeshi,
      isFlashSale,
      sortBy,
      page,
      limit
    } = req.query;

    const result = backendStore.getProducts({
      search: search as string,
      category: category as string,
      minPrice: minPrice ? Number(minPrice) : undefined,
      maxPrice: maxPrice ? Number(maxPrice) : undefined,
      isDeshi: isDeshi !== undefined ? isDeshi === 'true' : undefined,
      isFlashSale: isFlashSale !== undefined ? isFlashSale === 'true' : undefined,
      sortBy: sortBy as any,
      page: page ? Number(page) : undefined,
      limit: limit ? Number(limit) : undefined
    });

    res.json({
      success: true,
      ...result
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Failed to fetch products' });
  }
});

apiRouter.get('/products/:id', (req: Request, res: Response) => {
  const product = backendStore.getProductById(req.params.id);
  if (!product) {
    res.status(404).json({ success: false, error: 'Product not found' });
    return;
  }
  const reviews = backendStore.getReviews(req.params.id);
  res.json({ success: true, product, reviews });
});

apiRouter.post('/products', (req: Request, res: Response) => {
  try {
    const data = req.body;
    if (!data.name || !data.category) {
      res.status(400).json({ success: false, error: 'Product name and category are required' });
      return;
    }
    const created = backendStore.createProduct(data);
    res.status(201).json({
      success: true,
      message: 'Product created successfully',
      product: created
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Failed to create product' });
  }
});

apiRouter.put('/products/:id', (req: Request, res: Response) => {
  try {
    const updated = backendStore.updateProduct(req.params.id, req.body);
    if (!updated) {
      res.status(404).json({ success: false, error: 'Product not found' });
      return;
    }
    res.json({
      success: true,
      message: 'Product updated successfully',
      product: updated
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Failed to update product' });
  }
});

apiRouter.delete('/products/:id', (req: Request, res: Response) => {
  const deleted = backendStore.deleteProduct(req.params.id);
  if (!deleted) {
    res.status(404).json({ success: false, error: 'Product not found' });
    return;
  }
  res.json({ success: true, message: 'Product deleted successfully' });
});

// ==========================================
// 3. CATEGORIES REST API
// ==========================================
apiRouter.get('/categories', (_req: Request, res: Response) => {
  const categories = backendStore.getCategories();
  res.json({ success: true, total: categories.length, categories });
});

apiRouter.get('/categories/:id', (req: Request, res: Response) => {
  const cat = backendStore.getCategoryById(req.params.id);
  if (!cat) {
    res.status(404).json({ success: false, error: 'Category not found' });
    return;
  }
  res.json({ success: true, category: cat });
});

apiRouter.post('/categories', (req: Request, res: Response) => {
  try {
    const data = req.body;
    if (!data.name) {
      res.status(400).json({ success: false, error: 'Category name is required' });
      return;
    }
    const created = backendStore.createCategory(data);
    res.status(201).json({
      success: true,
      message: 'Category created successfully',
      category: created
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Failed to create category' });
  }
});

apiRouter.put('/categories/:id', (req: Request, res: Response) => {
  try {
    const updated = backendStore.updateCategory(req.params.id, req.body);
    if (!updated) {
      res.status(404).json({ success: false, error: 'Category not found' });
      return;
    }
    res.json({
      success: true,
      message: 'Category updated successfully',
      category: updated
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Failed to update category' });
  }
});

apiRouter.delete('/categories/:id', (req: Request, res: Response) => {
  const deleted = backendStore.deleteCategory(req.params.id);
  if (!deleted) {
    res.status(404).json({ success: false, error: 'Category not found' });
    return;
  }
  res.json({ success: true, message: 'Category deleted successfully' });
});

apiRouter.post('/categories/reset', (_req: Request, res: Response) => {
  const resetCats = backendStore.resetCategories();
  res.json({
    success: true,
    message: 'Categories reset to default configuration',
    categories: resetCats
  });
});

// ==========================================
// 4. ORDERS & CHECKOUT REST API
// ==========================================
apiRouter.get('/orders', (req: Request, res: Response) => {
  const userId = req.query.userId as string;
  const orders = backendStore.getOrders(userId);
  res.json({ success: true, total: orders.length, orders });
});

apiRouter.get('/orders/:id', (req: Request, res: Response) => {
  const order = backendStore.getOrderByNumberOrId(req.params.id);
  if (!order) {
    res.status(404).json({ success: false, error: 'Order not found' });
    return;
  }
  res.json({ success: true, order });
});

apiRouter.post('/orders', (req: Request, res: Response) => {
  try {
    const data = req.body;
    if (!data.customerName || !data.customerPhone) {
      res.status(400).json({ success: false, error: 'Customer name and phone number are required' });
      return;
    }
    if (!Array.isArray(data.items) || data.items.length === 0) {
      res.status(400).json({ success: false, error: 'Order must contain at least one item' });
      return;
    }

    const createdOrder = backendStore.createOrder(data);
    res.status(201).json({
      success: true,
      message: 'Order placed successfully',
      order: createdOrder
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Failed to place order' });
  }
});

apiRouter.patch('/orders/:id/status', (req: Request, res: Response) => {
  const { status } = req.body;
  if (!status) {
    res.status(400).json({ success: false, error: 'Status is required' });
    return;
  }
  const updated = backendStore.updateOrderStatus(req.params.id, status);
  if (!updated) {
    res.status(404).json({ success: false, error: 'Order not found' });
    return;
  }
  res.json({ success: true, message: `Order status updated to ${status}`, order: updated });
});

apiRouter.patch('/orders/:id/cancel', (req: Request, res: Response) => {
  const { reason } = req.body;
  const cancelled = backendStore.cancelOrder(req.params.id, reason);
  if (!cancelled) {
    res.status(404).json({ success: false, error: 'Order not found' });
    return;
  }
  res.json({ success: true, message: 'Order cancelled successfully', order: cancelled });
});

apiRouter.patch('/orders/:id/courier', (req: Request, res: Response) => {
  const { courierId, trackingCode } = req.body;
  if (!courierId) {
    res.status(400).json({ success: false, error: 'courierId is required' });
    return;
  }
  const updated = backendStore.assignCourier(req.params.id, courierId, trackingCode);
  if (!updated) {
    res.status(404).json({ success: false, error: 'Order not found' });
    return;
  }
  res.json({ success: true, message: 'Courier assigned successfully', order: updated });
});

// ==========================================
// 5. BANGLADESHI COURIERS & LIVE TRACKING API
// ==========================================
apiRouter.get('/couriers', (_req: Request, res: Response) => {
  const couriers = backendStore.getCouriers();
  res.json({ success: true, total: couriers.length, couriers });
});

apiRouter.get('/couriers/:courierId/tracking/:trackingCode', (req: Request, res: Response) => {
  const { courierId, trackingCode } = req.params;
  const orderNumber = req.query.orderNumber as string;
  const trackingData = backendStore.getLiveCourierTracking(trackingCode, orderNumber, courierId);
  res.json({ success: true, tracking: trackingData });
});

// ==========================================
// 6. COUPONS REST API
// ==========================================
apiRouter.get('/coupons', (_req: Request, res: Response) => {
  const coupons = backendStore.getCoupons();
  res.json({ success: true, total: coupons.length, coupons });
});

apiRouter.post('/coupons/validate', (req: Request, res: Response) => {
  const { code, subtotal } = req.body;
  if (!code) {
    res.status(400).json({ success: false, error: 'Coupon code is required' });
    return;
  }
  const result = backendStore.validateCoupon(code, Number(subtotal) || 0);
  res.json({ success: result.valid, ...result });
});

// ==========================================
// 7. REVIEWS REST API
// ==========================================
apiRouter.get('/reviews', (req: Request, res: Response) => {
  const productId = req.query.productId as string;
  const reviews = backendStore.getReviews(productId);
  res.json({ success: true, total: reviews.length, reviews });
});

apiRouter.post('/reviews', (req: Request, res: Response) => {
  try {
    const { productId, comment } = req.body;
    if (!productId || !comment) {
      res.status(400).json({ success: false, error: 'productId and comment are required' });
      return;
    }
    const created = backendStore.addReview(req.body);
    res.status(201).json({ success: true, message: 'Review added', review: created });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Failed to add review' });
  }
});

// ==========================================
// 8. STORE SETTINGS & CUSTOMER UI CONFIG API
// ==========================================
apiRouter.get('/settings/ui', (_req: Request, res: Response) => {
  const settings = backendStore.getSettings();
  res.json({ success: true, settings });
});

apiRouter.post('/settings/ui', (req: Request, res: Response) => {
  const updated = backendStore.updateSettings(req.body);
  res.json({ success: true, message: 'Settings updated successfully', settings: updated });
});

// ==========================================
// 9. THEMES REST API
// ==========================================
apiRouter.get('/themes', (_req: Request, res: Response) => {
  res.json({
    success: true,
    total: ALL_THEMES.length,
    categories: THEME_CATEGORIES,
    themes: ALL_THEMES
  });
});

// ==========================================
// 10. NEWSLETTER API
// ==========================================
apiRouter.post('/newsletter', (req: Request, res: Response) => {
  const { email } = req.body;
  const ok = backendStore.subscribeNewsletter(email);
  if (!ok) {
    res.status(400).json({ success: false, error: 'Valid email is required' });
    return;
  }
  res.json({ success: true, message: 'Subscribed to DeshiBazar newsletter successfully' });
});

// ==========================================
// 11. BANGLADESHI BANK PAYMENT GATEWAYS REST API
// ==========================================
apiRouter.get('/payment/banks', (_req: Request, res: Response) => {
  const banks = backendStore.getBangladeshiBanks();
  res.json({
    success: true,
    total: banks.length,
    banks
  });
});

apiRouter.get('/payment/banks/:id', (req: Request, res: Response) => {
  const bank = backendStore.getBangladeshiBankById(req.params.id);
  if (!bank) {
    res.status(404).json({ success: false, error: 'Bank not found' });
    return;
  }
  res.json({ success: true, bank });
});

apiRouter.patch('/payment/banks/:id/status', (req: Request, res: Response) => {
  const { active } = req.body;
  const updated = backendStore.toggleBankStatus(req.params.id, !!active);
  if (!updated) {
    res.status(404).json({ success: false, error: 'Bank not found' });
    return;
  }
  res.json({
    success: true,
    message: `Bank status updated to ${active ? 'Active' : 'Inactive'}`,
    bank: updated
  });
});

apiRouter.put('/payment/banks/:id', (req: Request, res: Response) => {
  const updated = backendStore.updateBankDetails(req.params.id, req.body);
  if (!updated) {
    res.status(404).json({ success: false, error: 'Bank not found' });
    return;
  }
  res.json({
    success: true,
    message: 'Bank details updated successfully',
    bank: updated
  });
});

apiRouter.get('/payment/gateways', (_req: Request, res: Response) => {
  const config = backendStore.getPaymentGatewayConfig();
  res.json({ success: true, config });
});

apiRouter.post('/payment/gateways', (req: Request, res: Response) => {
  const updated = backendStore.updatePaymentGatewayConfig(req.body);
  res.json({
    success: true,
    message: 'Payment gateway configuration saved successfully',
    config: updated
  });
});

apiRouter.post('/payment/verify-bank-transfer', (req: Request, res: Response) => {
  const { orderNumber, bankId, transactionRef } = req.body;
  if (!orderNumber || !transactionRef) {
    res.status(400).json({ success: false, error: 'orderNumber and transactionRef are required' });
    return;
  }
  const result = backendStore.verifyBankTransfer(orderNumber, bankId, transactionRef);
  res.json({
    success: true,
    message: 'Bank transfer verified and order confirmed',
    result
  });
});

// ==========================================
// 12. BULK SMS, RECEIPT NOTIFICATIONS & BAKI PAYMENT API
// ==========================================
apiRouter.get('/sms/data', (_req: Request, res: Response) => {
  const data = backendStore.getSmsData();
  res.json({ success: true, ...data });
});

apiRouter.post('/sms/settings', (req: Request, res: Response) => {
  const updated = backendStore.updateSmsSettings(req.body);
  res.json({ success: true, message: 'SMS gateway settings updated', settings: updated });
});

apiRouter.post('/sms/send-bulk', (req: Request, res: Response) => {
  try {
    const { recipients, type, title, titleBn, message, messageBn } = req.body;
    if (!Array.isArray(recipients) || recipients.length === 0) {
      res.status(400).json({ success: false, error: 'At least one recipient is required' });
      return;
    }
    const created = backendStore.sendBulkSms({
      recipients,
      type: type || 'baki_due',
      title: title || 'DeshiBazar Notification',
      titleBn: titleBn || 'দেশিবাজার নোটিফিকেশন',
      message: message || '',
      messageBn: messageBn || message || ''
    });
    res.status(201).json({
      success: true,
      message: `Sent ${created.length} SMS notification(s) successfully`,
      notifications: created
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Failed to send bulk SMS' });
  }
});

apiRouter.post('/baki/add', (req: Request, res: Response) => {
  try {
    const account = backendStore.addOrUpdateBaki(req.body);
    res.status(201).json({ success: true, account });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Failed to save baki account' });
  }
});

apiRouter.post('/baki/pay', (req: Request, res: Response) => {
  try {
    const { bakiId, amount, paymentMethod, transactionRef } = req.body;
    if (!bakiId || !amount || Number(amount) <= 0) {
      res.status(400).json({ success: false, error: 'bakiId and positive amount are required' });
      return;
    }
    const result = backendStore.payBakiAmount(bakiId, Number(amount), paymentMethod || 'bkash', transactionRef);
    if (!result) {
      res.status(404).json({ success: false, error: 'Baki account not found' });
      return;
    }
    res.json({
      success: true,
      message: 'Baki payment processed & receipt SMS issued',
      ...result
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Failed to process baki payment' });
  }
});

