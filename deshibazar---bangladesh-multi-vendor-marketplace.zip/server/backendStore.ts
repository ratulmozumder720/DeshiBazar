import type { Product, Category, Order, Coupon, Review, BangladeshiCourier, CustomerUIConfig, BangladeshiBank, SmsNotification, BakiAccount, SmsGatewaySettings, SmsNotificationType } from '../src/types.ts';
import { PRODUCTS, CATEGORIES, COUPONS } from '../src/data/mockData.ts';
import { BANGLADESHI_COURIERS, generateLiveCourierTrackingInfo } from '../src/data/courierData.ts';
import { DEFAULT_CUSTOMER_UI_CONFIG } from '../src/data/defaultCustomerUIConfig.ts';
import { BANGLADESHI_BANKS, DEFAULT_PAYMENT_GATEWAY_CONFIG } from '../src/data/bangladeshiBanks.ts';
import type { PaymentGatewayConfig } from '../src/data/bangladeshiBanks.ts';

// In-Memory & Persistent State for DeshiBazar Backend
class BackendStore {
  private products: Product[] = [];
  private categories: Category[] = [];
  private orders: Order[] = [];
  private coupons: Coupon[] = [];
  private couriers: BangladeshiCourier[] = [];
  private reviews: Review[] = [];
  private banks: BangladeshiBank[] = [];
  private gatewayConfig: PaymentGatewayConfig = { ...DEFAULT_PAYMENT_GATEWAY_CONFIG };
  private settings: CustomerUIConfig = { ...DEFAULT_CUSTOMER_UI_CONFIG };
  private newsletterSubscribers: string[] = [];
  private smsNotifications: SmsNotification[] = [];
  private bakiAccounts: BakiAccount[] = [];
  private smsGatewaySettings: SmsGatewaySettings = {
    provider: 'bulksmsbd',
    senderId: 'DESHIBAZAR',
    apiKeyMasked: 'BD-SMS-LIVE-••••••••9421',
    enableAutoOrderReceiptSms: true,
    enableAutoBakiReminderSms: true,
    enableAutoBakiPaymentReceiptSms: true,
    customerReceiveReceiptSms: true,
    customerReceiveBakiAlertSms: true,
    customerReceiveBulkPromoSms: true,
    smsLanguage: 'bilingual'
  };
  private startTime: number = Date.now();

  constructor() {
    this.initDefaultData();
  }

  public initDefaultData() {
    this.products = JSON.parse(JSON.stringify(PRODUCTS));
    this.categories = JSON.parse(JSON.stringify(CATEGORIES));
    this.coupons = JSON.parse(JSON.stringify(COUPONS));
    this.couriers = JSON.parse(JSON.stringify(BANGLADESHI_COURIERS));
    this.banks = JSON.parse(JSON.stringify(BANGLADESHI_BANKS));
    this.gatewayConfig = JSON.parse(JSON.stringify(DEFAULT_PAYMENT_GATEWAY_CONFIG));
    this.settings = JSON.parse(JSON.stringify(DEFAULT_CUSTOMER_UI_CONFIG));
    this.reviews = [
      {
        id: 'rev-1',
        productId: 'prod-1',
        userName: 'Tanvir Ahmed (তানভীর আহমেদ)',
        rating: 5,
        comment: 'খাঁটি সুন্দরবনের মধু! স্বাদ ও ঘ্রাণ অতুলনীয়। প্যাকেজিং অনেক মজবুত ছিল।',
        date: '2026-03-12',
        verifiedPurchase: true,
        location: 'Dhaka'
      },
      {
        id: 'rev-2',
        productId: 'prod-2',
        userName: 'Sadia Rahman (সাদিয়া রহমান)',
        rating: 5,
        comment: 'টাঙ্গাইল শাড়ির ফেব্রিক কোয়ালিটি চমৎকার, একদম অরিজিনাল দেশি হস্তশিল্প!',
        date: '2026-03-15',
        verifiedPurchase: true,
        location: 'Chittagong'
      }
    ];

    // Seed realistic sample orders
    this.orders = [
      {
        id: 'ord-seed-1',
        orderNumber: 'DB-260315-8921',
        customerName: 'Ashraful Islam (আশরাফুল ইসলাম)',
        customerPhone: '+8801712-984512',
        customerEmail: 'ashraf@example.com',
        division: 'Dhaka',
        district: 'Dhaka',
        upazila: 'Mirpur',
        address: 'House 42, Road 7, Block B, Mirpur-12, Dhaka',
        paymentMethod: 'cod',
        paymentStatus: 'pending',
        deliveryType: 'regular',
        deliveryFee: 60,
        subtotal: 1350,
        discount: 0,
        total: 1410,
        status: 'out_for_delivery',
        courierId: 'steadfast',
        courierName: 'Steadfast Courier',
        courierTrackingCode: 'ST-892144',
        createdAt: new Date(Date.now() - 36 * 3600 * 1000).toISOString(),
        estimatedDelivery: 'Today by 06:30 PM',
        items: [
          {
            product: this.products[0],
            quantity: 1
          }
        ],
        trackingSteps: [
          { status: 'placed', label: 'Order Placed', labelBn: 'অর্ডার গ্রহণ', completed: true, timestamp: '36 hours ago' },
          { status: 'confirmed', label: 'Order Confirmed', labelBn: 'অর্ডার নিশ্চিতকরণ', completed: true, timestamp: '34 hours ago' },
          { status: 'processing', label: 'Processing at Hub', labelBn: 'প্রক্রিয়াকরণ চলছে', completed: true, timestamp: '24 hours ago' },
          { status: 'packed', label: 'Package Ready', labelBn: 'প্যাকিং সম্পন্ন', completed: true, timestamp: '18 hours ago' },
          { status: 'shipped', label: 'Handed to Courier', labelBn: 'কুরিয়ারে হস্তান্তর', completed: true, timestamp: '12 hours ago' },
          { status: 'out_for_delivery', label: 'Out for Delivery', labelBn: 'ডেলিভারির পথে', completed: true, timestamp: '1 hour ago' },
          { status: 'delivered', label: 'Delivered', labelBn: 'ডেলিভারি সম্পন্ন', completed: false }
        ]
      }
    ];

    this.bakiAccounts = [
      {
        id: 'baki-1',
        customerName: 'Tanvir Hossain',
        customerNameBn: 'তানভীর হোসেন',
        customerPhone: '01819234567',
        customerEmail: 'tanvir@example.com',
        orderNumber: 'DB-260315-8921',
        description: 'Sundarban Honey & Premium Deshi Grocery Credit',
        descriptionBn: 'সুন্দরবনের মধু ও দেশি গ্রোসারি বাকি খাতা',
        totalBill: 2500,
        paidAmount: 1000,
        bakiAmount: 1500,
        dueDate: '2026-04-25',
        lastPaymentAt: new Date(Date.now() - 48 * 3600 * 1000).toISOString(),
        lastPaymentMethod: 'bkash',
        lastTransactionRef: 'BK984210',
        status: 'partial',
        updatedAt: new Date(Date.now() - 12 * 3600 * 1000).toISOString()
      },
      {
        id: 'baki-2',
        customerName: 'Nusrat Jahan',
        customerNameBn: 'নুসরাত জাহান',
        customerPhone: '01711987654',
        customerEmail: 'nusrat@example.com',
        orderNumber: 'DB-260318-4410',
        description: 'Tangail Tant Saree Wholesale Balance',
        descriptionBn: 'টাঙ্গাইল তাঁতের শাড়ি আংশিক বাকি',
        totalBill: 4800,
        paidAmount: 2000,
        bakiAmount: 2800,
        dueDate: '2026-04-28',
        status: 'partial',
        updatedAt: new Date(Date.now() - 24 * 3600 * 1000).toISOString()
      },
      {
        id: 'baki-3',
        customerName: 'Dr. Shahana Akhter',
        customerNameBn: 'ডা. শাহানা আখতার',
        customerPhone: '01912341234',
        customerEmail: 'shahana@example.com',
        orderNumber: 'DB-260319-7721',
        description: 'Organic Rajshahi Mango & Mustard Oil Box',
        descriptionBn: 'রাজশাহীর আম ও খাঁটি সরিষার তেল বাকি',
        totalBill: 1850,
        paidAmount: 0,
        bakiAmount: 1850,
        dueDate: '2026-04-30',
        status: 'due',
        updatedAt: new Date(Date.now() - 6 * 3600 * 1000).toISOString()
      }
    ];

    this.smsNotifications = [
      {
        id: 'sms-seed-1',
        recipientPhone: '01819234567',
        recipientName: 'Tanvir Hossain',
        recipientNameBn: 'তানভীর হোসেন',
        senderName: 'DeshiBazar Admin',
        senderRole: 'admin',
        type: 'baki_due',
        title: 'Baki Payment & Cash Memo Receipt Reminder',
        titleBn: 'বাকি টাকা পরিশোধ ও ক্যাশ মেমো রসিদ নোটিফিকেশন',
        message: 'Dear Tanvir Hossain, your order DB-260315-8921 total bill is ৳2,500 (Paid: ৳1,000). Remaining Baki Due: ৳1,500. Pay via bKash/Nagad/Bangladeshi Bank.',
        messageBn: 'প্রিয় তানভীর হোসেন, আপনার অর্ডার DB-260315-8921 এর মোট বিল ৳২,৫০০ (জমা: ৳১,০০০)। অবশিষ্ট বাকি: ৳১,৫০০। সেটিংসের নিচে নোটিফিকেশন থেকে বাকি পরিশোধ করুন।',
        orderNumber: 'DB-260315-8921',
        bakiId: 'baki-1',
        totalBillAmount: 2500,
        paidAmount: 1000,
        bakiDueAmount: 1500,
        isRead: false,
        deliveryStatus: 'delivered',
        gatewayProvider: 'BulkSMSBD',
        createdAt: new Date(Date.now() - 2 * 3600 * 1000).toISOString()
      },
      {
        id: 'sms-seed-2',
        recipientPhone: '01711987654',
        recipientName: 'Nusrat Jahan',
        recipientNameBn: 'নুসরাত জাহান',
        senderName: 'DeshiBazar Admin',
        senderRole: 'admin',
        type: 'order_receipt',
        title: 'Official Order Receipt SMS — DB-260318-4410',
        titleBn: 'অফিসিয়াল অর্ডার ও রসিদ এসএমএস — DB-260318-4410',
        message: 'Thank you Nusrat Jahan! Receipt #DB-260318-4410 confirmed. Total: ৳4,800, Advance Paid: ৳2,000, Baki Due: ৳2,800.',
        messageBn: 'ধন্যবাদ নুসরাত জাহান! রসিদ #DB-260318-4410 নিশ্চিত হয়েছে। মোট: ৳৪,৮০০, অগ্রিম জমা: ৳২,০০০, বাকি: ৳২,৮০০।',
        orderNumber: 'DB-260318-4410',
        bakiId: 'baki-2',
        totalBillAmount: 4800,
        paidAmount: 2000,
        bakiDueAmount: 2800,
        isRead: false,
        deliveryStatus: 'delivered',
        gatewayProvider: 'BulkSMSBD',
        createdAt: new Date(Date.now() - 5 * 3600 * 1000).toISOString()
      }
    ];
  }

  // --- PRODUCTS ---
  public getProducts(params?: {
    search?: string;
    category?: string;
    minPrice?: number;
    maxPrice?: number;
    isDeshi?: boolean;
    isFlashSale?: boolean;
    sortBy?: 'price_asc' | 'price_desc' | 'rating' | 'popular' | 'newest';
    page?: number;
    limit?: number;
  }) {
    let list = [...this.products];

    if (params?.search) {
      const q = params.search.toLowerCase().trim();
      list = list.filter(p => 
        p.name.toLowerCase().includes(q) ||
        p.nameBn.includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.brand?.toLowerCase().includes(q) ||
        p.vendorName?.toLowerCase().includes(q)
      );
    }

    if (params?.category && params.category !== 'all') {
      list = list.filter(p => p.category === params.category);
    }

    if (params?.minPrice !== undefined) {
      list = list.filter(p => p.price >= Number(params.minPrice));
    }

    if (params?.maxPrice !== undefined) {
      list = list.filter(p => p.price <= Number(params.maxPrice));
    }

    if (params?.isDeshi !== undefined) {
      list = list.filter(p => !!p.isDeshi === params.isDeshi);
    }

    if (params?.isFlashSale !== undefined) {
      list = list.filter(p => !!p.isFlashSale === params.isFlashSale);
    }

    if (params?.sortBy) {
      if (params.sortBy === 'price_asc') {
        list.sort((a, b) => a.price - b.price);
      } else if (params.sortBy === 'price_desc') {
        list.sort((a, b) => b.price - a.price);
      } else if (params.sortBy === 'rating') {
        list.sort((a, b) => b.rating - a.rating);
      } else if (params.sortBy === 'newest') {
        list.reverse();
      }
    }

    const total = list.length;
    const page = Math.max(1, Number(params?.page) || 1);
    const limit = Math.max(1, Number(params?.limit) || 50);
    const startIndex = (page - 1) * limit;
    const paginated = list.slice(startIndex, startIndex + limit);

    return {
      products: paginated,
      total,
      page,
      totalPages: Math.ceil(total / limit)
    };
  }

  public getProductById(id: string): Product | undefined {
    return this.products.find(p => p.id === id);
  }

  public createProduct(data: Partial<Product>): Product {
    const id = data.id || `prod-${Date.now()}`;
    const categoryInfo = this.categories.find(c => c.id === data.category) || this.categories[0];
    
    const product: Product = {
      id,
      name: data.name || 'Deshi Product',
      nameBn: data.nameBn || data.name || 'দেশি পণ্য',
      category: data.category || 'deshi-products',
      categoryBn: data.categoryBn || categoryInfo?.nameBn || 'দেশি পণ্য',
      subCategory: data.subCategory || '',
      brand: data.brand || 'DeshiBazar Authentic',
      vendorId: data.vendorId || 'seller-1',
      vendorName: data.vendorName || 'Deshi Agro Artisan',
      vendorLocation: data.vendorLocation || 'Dhaka, Bangladesh',
      price: Number(data.price) || 100,
      originalPrice: Number(data.originalPrice) || Number(data.price) || 100,
      discountPercent: Number(data.discountPercent) || 0,
      unit: data.unit || '1 pc',
      unitBn: data.unitBn || '১ পিস',
      rating: Number(data.rating) || 5.0,
      reviewCount: Number(data.reviewCount) || 1,
      stock: Number(data.stock) || 50,
      isFlashSale: !!data.isFlashSale,
      isDeshi: data.isDeshi !== undefined ? !!data.isDeshi : true,
      isDailyDeal: !!data.isDailyDeal,
      isOrganic: !!data.isOrganic,
      isBestSeller: !!data.isBestSeller,
      isNewArrival: !!data.isNewArrival,
      image: data.image || 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80',
      gallery: Array.isArray(data.gallery) && data.gallery.length > 0 ? data.gallery : [data.image || 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80'],
      description: data.description || 'Premium authentic product proudly sourced across Bangladesh.',
      descriptionBn: data.descriptionBn || 'খাঁটি ও গুণগত মানসম্মত দেশি পণ্য, দেশজুড়ে দ্রুত ডেলিভারি।',
      specifications: data.specifications || { 'Origin (উৎস)': 'Bangladesh', 'Quality': '100% Authentic' },
      origin: data.origin || 'Bangladesh'
    };

    // Prepend new product
    this.products.unshift(product);
    return product;
  }

  public updateProduct(id: string, update: Partial<Product>): Product | null {
    const index = this.products.findIndex(p => p.id === id);
    if (index === -1) return null;
    this.products[index] = { ...this.products[index], ...update, id };
    return this.products[index];
  }

  public deleteProduct(id: string): boolean {
    const prevLen = this.products.length;
    this.products = this.products.filter(p => p.id !== id);
    return this.products.length < prevLen;
  }

  // --- CATEGORIES ---
  public getCategories(): Category[] {
    return this.categories;
  }

  public getCategoryById(id: string): Category | undefined {
    return this.categories.find(c => c.id === id);
  }

  public createCategory(data: Partial<Category>): Category {
    const id = data.id || data.name?.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') || `category-${Date.now()}`;
    const category: Category = {
      id,
      name: data.name?.trim() || 'New Category',
      nameBn: data.nameBn?.trim() || data.name?.trim() || 'নতুন ক্যাটাগরি',
      iconName: data.iconName || 'Package',
      itemCount: Number(data.itemCount) || 0,
      image: data.image || 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80',
      color: data.color || 'from-emerald-500/20 to-teal-500/10',
      popularItems: Array.isArray(data.popularItems) ? data.popularItems : [],
      commissionRate: Number(data.commissionRate) || 8.5,
      status: data.status || 'active',
      description: data.description || '',
      descriptionBn: data.descriptionBn || ''
    };

    const existsIndex = this.categories.findIndex(c => c.id === id);
    if (existsIndex >= 0) {
      this.categories[existsIndex] = category;
    } else {
      this.categories.push(category);
    }
    return category;
  }

  public updateCategory(id: string, update: Partial<Category>): Category | null {
    const index = this.categories.findIndex(c => c.id === id);
    if (index === -1) return null;
    this.categories[index] = { ...this.categories[index], ...update, id };
    return this.categories[index];
  }

  public deleteCategory(id: string): boolean {
    const prevLen = this.categories.length;
    this.categories = this.categories.filter(c => c.id !== id);
    return this.categories.length < prevLen;
  }

  public resetCategories(): Category[] {
    this.categories = JSON.parse(JSON.stringify(CATEGORIES));
    return this.categories;
  }

  // --- ORDERS ---
  public getOrders(userId?: string): Order[] {
    if (userId) {
      return this.orders.filter(o => o.userId === userId);
    }
    return this.orders;
  }

  public getOrderByNumberOrId(key: string): Order | undefined {
    return this.orders.find(o => o.orderNumber === key || o.id === key);
  }

  public createOrder(data: Partial<Order>): Order {
    const now = new Date();
    const dateCode = now.toISOString().slice(2, 10).replace(/-/g, '');
    const randPart = Math.floor(1000 + Math.random() * 9000);
    const orderNumber = data.orderNumber || `DB-${dateCode}-${randPart}`;
    const id = data.id || `ord-${Date.now()}`;

    // Delivery fee logic: Inside Dhaka = 60, Outside = 120, Express = +50
    const isDhaka = (data.division || '').toLowerCase().includes('dhaka');
    let calculatedDeliveryFee = isDhaka ? 60 : 120;
    if (data.deliveryType === 'express') {
      calculatedDeliveryFee += 50;
    }

    const items = data.items || [];
    const subtotal = data.subtotal || items.reduce((sum, item) => sum + (item.product?.price || 0) * item.quantity, 0);
    const discount = data.discount || 0;
    const total = data.total || (subtotal + calculatedDeliveryFee - discount);

    const defaultCourier = BANGLADESHI_COURIERS[0]; // Steadfast default

    const trackingSteps = [
      { status: 'placed' as const, label: 'Order Placed', labelBn: 'অর্ডার গ্রহণ', timestamp: now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), completed: true },
      { status: 'confirmed' as const, label: 'Order Confirmed', labelBn: 'অর্ডার নিশ্চিতকরণ', completed: false },
      { status: 'processing' as const, label: 'Processing at Hub', labelBn: 'প্রক্রিয়াকরণ চলছে', completed: false },
      { status: 'packed' as const, label: 'Package Ready', labelBn: 'প্যাকিং সম্পন্ন', completed: false },
      { status: 'shipped' as const, label: 'Handed to Courier', labelBn: 'কুরিয়ারে হস্তান্তর', completed: false },
      { status: 'out_for_delivery' as const, label: 'Out for Delivery', labelBn: 'ডেলিভারির পথে', completed: false },
      { status: 'delivered' as const, label: 'Delivered', labelBn: 'ডেলিভারি সম্পন্ন', completed: false }
    ];

    const estimatedDays = isDhaka ? 1 : 3;
    const estDate = new Date(now.getTime() + estimatedDays * 24 * 3600 * 1000);
    const estDelivery = estDate.toLocaleDateString('bn-BD', { weekday: 'short', month: 'short', day: 'numeric' });

    const order: Order = {
      id,
      orderNumber,
      userId: data.userId,
      customerName: data.customerName || 'Customer',
      customerPhone: data.customerPhone || '+8801700000000',
      customerEmail: data.customerEmail,
      division: data.division || 'Dhaka',
      district: data.district || 'Dhaka',
      upazila: data.upazila || 'Savar',
      address: data.address || 'Dhaka, Bangladesh',
      deliveryInstructions: data.deliveryInstructions,
      paymentMethod: data.paymentMethod || 'cod',
      paymentStatus: data.paymentStatus || (data.paymentMethod === 'cod' ? 'pending' : 'paid_online'),
      transactionId: data.transactionId || (data.paymentMethod === 'bank_transfer' ? `BANK-${randPart}${Math.floor(100 + Math.random() * 899)}` : undefined),
      bankPaymentDetails: data.bankPaymentDetails,
      deliveryType: data.deliveryType || 'regular',
      deliveryFee: data.deliveryFee ?? calculatedDeliveryFee,
      subtotal,
      discount,
      couponCode: data.couponCode,
      total,
      status: 'placed',
      items,
      createdAt: now.toISOString(),
      estimatedDelivery: estDelivery,
      trackingSteps,
      courierId: data.courierId || defaultCourier.id,
      courierName: data.courierName || defaultCourier.name,
      courierTrackingCode: `ST-${randPart}${Math.floor(10 + Math.random() * 89)}`
    };

    this.orders.unshift(order);
    return order;
  }

  public updateOrderStatus(orderId: string, status: Order['status']): Order | null {
    const order = this.orders.find(o => o.id === orderId || o.orderNumber === orderId);
    if (!order) return null;

    order.status = status;
    const statusOrder: Order['status'][] = ['placed', 'confirmed', 'processing', 'packed', 'shipped', 'out_for_delivery', 'delivered'];
    const targetIdx = statusOrder.indexOf(status);

    if (order.trackingSteps) {
      order.trackingSteps = order.trackingSteps.map(step => {
        const stepIdx = statusOrder.indexOf(step.status);
        if (stepIdx <= targetIdx && targetIdx !== -1) {
          return {
            ...step,
            completed: true,
            timestamp: step.timestamp || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          };
        }
        return step;
      });
    }

    if (status === 'cancelled') {
      order.cancelledAt = new Date().toISOString();
    }

    return order;
  }

  public cancelOrder(orderId: string, reason?: string): Order | null {
    const order = this.orders.find(o => o.id === orderId || o.orderNumber === orderId);
    if (!order) return null;
    order.status = 'cancelled';
    order.cancelledAt = new Date().toISOString();
    order.cancellationReason = reason || 'Cancelled by customer';
    return order;
  }

  public assignCourier(orderId: string, courierId: string, customTrackingCode?: string): Order | null {
    const order = this.orders.find(o => o.id === orderId || o.orderNumber === orderId);
    if (!order) return null;

    const courier = this.couriers.find(c => c.id === courierId) || this.couriers[0];
    const trackingCode = customTrackingCode || `${courierId.substring(0, 3).toUpperCase()}-${Math.floor(100000 + Math.random() * 900000)}`;

    order.courierId = courier.id;
    order.courierName = courier.name;
    order.courierTrackingCode = trackingCode;
    order.status = 'shipped';
    return order;
  }

  // --- COURIERS ---
  public getCouriers(): BangladeshiCourier[] {
    return this.couriers;
  }

  public getLiveCourierTracking(trackingCode: string, orderNumber?: string, courierId?: string) {
    return generateLiveCourierTrackingInfo(trackingCode, orderNumber, courierId);
  }

  // --- COUPONS ---
  public getCoupons(): Coupon[] {
    return this.coupons;
  }

  public validateCoupon(code: string, subtotal: number): { valid: boolean; coupon?: Coupon; discount: number; message: string; messageBn: string } {
    const trimmed = (code || '').trim().toUpperCase();
    const coupon = this.coupons.find(c => c.code.toUpperCase() === trimmed);

    if (!coupon) {
      return {
        valid: false,
        discount: 0,
        message: 'Invalid coupon code.',
        messageBn: 'কুপন কোডটি সঠিক নয়।'
      };
    }

    if (subtotal < coupon.minOrder) {
      return {
        valid: false,
        discount: 0,
        message: `Minimum order amount of ৳${coupon.minOrder} required for this coupon.`,
        messageBn: `এই কুপনের জন্য সর্বনিম্ন ৳${coupon.minOrder} টাকার অর্ডার প্রয়োজন।`
      };
    }

    const calculatedDiscount = Math.min(Math.round((subtotal * coupon.discountPercent) / 100), coupon.maxDiscount);

    return {
      valid: true,
      coupon,
      discount: calculatedDiscount,
      message: `Coupon "${coupon.code}" applied! You saved ৳${calculatedDiscount}.`,
      messageBn: `কুপন "${coupon.code}" সফলভাবে প্রয়োগ করা হয়েছে! ৳${calculatedDiscount} সাশ্রয় হলো।`
    };
  }

  // --- REVIEWS ---
  public getReviews(productId?: string): Review[] {
    if (productId) {
      return this.reviews.filter(r => r.productId === productId);
    }
    return this.reviews;
  }

  public addReview(reviewData: Partial<Review>): Review {
    const review: Review = {
      id: reviewData.id || `rev-${Date.now()}`,
      productId: reviewData.productId || 'prod-1',
      userName: reviewData.userName || 'Customer',
      rating: Math.max(1, Math.min(5, Number(reviewData.rating) || 5)),
      comment: reviewData.comment || 'Very good product!',
      date: new Date().toISOString().slice(0, 10),
      verifiedPurchase: true,
      location: reviewData.location || 'Dhaka'
    };
    this.reviews.unshift(review);
    return review;
  }

  // --- SETTINGS ---
  public getSettings(): CustomerUIConfig {
    return this.settings;
  }

  public updateSettings(update: Partial<CustomerUIConfig>): CustomerUIConfig {
    this.settings = { ...this.settings, ...update, lastUpdated: new Date().toISOString() };
    return this.settings;
  }

  // --- NEWSLETTER ---
  public subscribeNewsletter(email: string): boolean {
    if (!email || !email.includes('@')) return false;
    if (!this.newsletterSubscribers.includes(email)) {
      this.newsletterSubscribers.push(email);
    }
    return true;
  }

  // --- BANGLADESHI BANKS & PAYMENT GATEWAYS ---
  public getBangladeshiBanks(): BangladeshiBank[] {
    return this.banks;
  }

  public getBangladeshiBankById(id: string): BangladeshiBank | undefined {
    return this.banks.find(b => b.id === id);
  }

  public toggleBankStatus(id: string, active: boolean): BangladeshiBank | null {
    const bank = this.banks.find(b => b.id === id);
    if (!bank) return null;
    bank.isActive = active;
    return bank;
  }

  public updateBankDetails(id: string, details: Partial<BangladeshiBank>): BangladeshiBank | null {
    const index = this.banks.findIndex(b => b.id === id);
    if (index === -1) return null;
    this.banks[index] = { ...this.banks[index], ...details, id };
    return this.banks[index];
  }

  public getPaymentGatewayConfig(): PaymentGatewayConfig {
    return this.gatewayConfig;
  }

  public updatePaymentGatewayConfig(update: Partial<PaymentGatewayConfig>): PaymentGatewayConfig {
    this.gatewayConfig = {
      ...this.gatewayConfig,
      ...update,
      bangladeshiBankGateway: {
        ...this.gatewayConfig.bangladeshiBankGateway,
        ...(update.bangladeshiBankGateway || {})
      }
    };
    return this.gatewayConfig;
  }

  public verifyBankTransfer(orderNumber: string, bankId: string, txnRef: string) {
    const order = this.orders.find(o => o.orderNumber === orderNumber || o.id === orderNumber);
    const bank = this.banks.find(b => b.id === bankId) || this.banks[0];
    if (order) {
      order.paymentStatus = 'paid_online';
      order.transactionId = txnRef;
      if (!order.bankPaymentDetails) {
        order.bankPaymentDetails = {
          bankId: bank.id,
          bankName: bank.name,
          accountNumber: bank.accountNumber,
          bankTransactionRef: txnRef,
          paymentMethodType: 'internet_banking'
        };
      }
      this.updateOrderStatus(order.id, 'confirmed');
    }
    return {
      verified: true,
      orderNumber,
      bank: bank.name,
      transactionRef: txnRef,
      verifiedAt: new Date().toISOString(),
      amountFormatted: order ? `৳${order.total}` : 'N/A'
    };
  }

  // --- BULK SMS, RECEIPT NOTIFICATIONS & BAKI LEDGER ---
  public getSmsData() {
    return {
      notifications: this.smsNotifications,
      bakiAccounts: this.bakiAccounts,
      settings: this.smsGatewaySettings
    };
  }

  public updateSmsSettings(update: Partial<SmsGatewaySettings>): SmsGatewaySettings {
    this.smsGatewaySettings = { ...this.smsGatewaySettings, ...update };
    return this.smsGatewaySettings;
  }

  public sendBulkSms(payload: {
    recipients: Array<{ name: string; nameBn?: string; phone: string; bakiId?: string; orderNumber?: string; totalBillAmount?: number; paidAmount?: number; bakiDueAmount?: number }>;
    type: SmsNotificationType;
    title: string;
    titleBn: string;
    message: string;
    messageBn: string;
  }): SmsNotification[] {
    const created: SmsNotification[] = payload.recipients.map((rec, idx) => {
      const renderTemplate = (tpl: string) =>
        tpl
          .replace(/\{name\}/g, rec.nameBn || rec.name)
          .replace(/\{baki\}/g, String(rec.bakiDueAmount ?? 0))
          .replace(/\{paid\}/g, String(rec.paidAmount ?? 0))
          .replace(/\{total\}/g, String(rec.totalBillAmount ?? 0))
          .replace(/\{orderNo\}/g, rec.orderNumber || 'DB-RECEIPT');

      return {
        id: `sms-${Date.now()}-${idx}`,
        recipientPhone: rec.phone,
        recipientName: rec.name,
        recipientNameBn: rec.nameBn,
        senderName: 'DeshiBazar Admin',
        senderRole: 'admin',
        type: payload.type,
        title: renderTemplate(payload.title),
        titleBn: renderTemplate(payload.titleBn),
        message: renderTemplate(payload.message),
        messageBn: renderTemplate(payload.messageBn),
        orderNumber: rec.orderNumber,
        bakiId: rec.bakiId,
        totalBillAmount: rec.totalBillAmount,
        paidAmount: rec.paidAmount,
        bakiDueAmount: rec.bakiDueAmount,
        isRead: false,
        deliveryStatus: 'delivered',
        gatewayProvider: this.smsGatewaySettings.provider.toUpperCase(),
        createdAt: new Date().toISOString()
      };
    });

    this.smsNotifications = [...created, ...this.smsNotifications].slice(0, 100);
    return created;
  }

  public addOrUpdateBaki(data: Partial<BakiAccount>): BakiAccount {
    const existingIdx = data.id ? this.bakiAccounts.findIndex(b => b.id === data.id) : -1;
    const totalBill = Number(data.totalBill) || 0;
    const paidAmount = Number(data.paidAmount) || 0;
    const bakiAmount = Math.max(0, totalBill - paidAmount);
    const status: BakiAccount['status'] = bakiAmount <= 0 ? 'paid' : paidAmount > 0 ? 'partial' : 'due';

    if (existingIdx >= 0) {
      this.bakiAccounts[existingIdx] = {
        ...this.bakiAccounts[existingIdx],
        ...data,
        totalBill,
        paidAmount,
        bakiAmount,
        status,
        updatedAt: new Date().toISOString()
      };
      return this.bakiAccounts[existingIdx];
    }

    const created: BakiAccount = {
      id: `baki-${Date.now()}`,
      customerName: data.customerName || 'Customer',
      customerNameBn: data.customerNameBn || data.customerName || 'গ্রাহক',
      customerPhone: data.customerPhone || '01700000000',
      customerEmail: data.customerEmail,
      orderNumber: data.orderNumber || `DB-BAKI-${Math.floor(1000 + Math.random() * 9000)}`,
      description: data.description || 'Customer Baki Account',
      descriptionBn: data.descriptionBn || data.description || 'গ্রাহকের বাকি হিসাব',
      totalBill,
      paidAmount,
      bakiAmount,
      dueDate: data.dueDate || new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10),
      status,
      updatedAt: new Date().toISOString()
    };
    this.bakiAccounts.unshift(created);
    return created;
  }

  public payBakiAmount(bakiId: string, amount: number, paymentMethod: string, transactionRef?: string) {
    const idx = this.bakiAccounts.findIndex(b => b.id === bakiId);
    if (idx === -1) return null;

    const account = this.bakiAccounts[idx];
    const payAmt = Math.min(account.bakiAmount, Math.max(1, Number(amount) || 0));
    const newPaid = account.paidAmount + payAmt;
    const newBaki = Math.max(0, account.totalBill - newPaid);
    const txnRef = transactionRef?.trim() || `BK-PAY-${Math.floor(100000 + Math.random() * 900000)}`;
    const now = new Date().toISOString();

    const updatedAccount: BakiAccount = {
      ...account,
      paidAmount: newPaid,
      bakiAmount: newBaki,
      status: newBaki <= 0 ? 'paid' : 'partial',
      lastPaymentAt: now,
      lastPaymentMethod: paymentMethod,
      lastTransactionRef: txnRef,
      updatedAt: now
    };
    this.bakiAccounts[idx] = updatedAccount;

    const receiptSms: SmsNotification = {
      id: `sms-rec-${Date.now()}`,
      recipientPhone: updatedAccount.customerPhone,
      recipientName: updatedAccount.customerName,
      recipientNameBn: updatedAccount.customerNameBn,
      senderName: 'DeshiBazar Payment & Receipt Desk',
      senderRole: 'system',
      type: 'baki_payment_receipt',
      title: `Baki Payment Receipt (${paymentMethod.toUpperCase()}) — ৳${payAmt}`,
      titleBn: `বাকি টাকা পরিশোধের রসিদ (${paymentMethod.toUpperCase()}) — ৳${payAmt}`,
      message: `Payment Received! ৳${payAmt} paid via ${paymentMethod.toUpperCase()} (Ref: ${txnRef}) for ${updatedAccount.orderNumber || updatedAccount.id}. Remaining Baki Due: ৳${newBaki}.`,
      messageBn: `বাকি পরিশোধ সফল! ${updatedAccount.orderNumber || updatedAccount.id} বাবদ ৳${payAmt} (${paymentMethod.toUpperCase()}, Ref: ${txnRef}) জমা হয়েছে। অবশিষ্ট বাকি: ৳${newBaki}।`,
      orderNumber: updatedAccount.orderNumber,
      bakiId: updatedAccount.id,
      totalBillAmount: updatedAccount.totalBill,
      paidAmount: payAmt,
      bakiDueAmount: newBaki,
      paymentMethod,
      transactionRef: txnRef,
      isRead: false,
      deliveryStatus: 'delivered',
      gatewayProvider: this.smsGatewaySettings.provider.toUpperCase(),
      createdAt: now
    };
    this.smsNotifications.unshift(receiptSms);

    return { account: updatedAccount, receiptSms };
  }

  // --- HEALTH & STATUS ---
  public getSystemHealth() {
    const uptimeSec = Math.floor((Date.now() - this.startTime) / 1000);
    const memory = process.memoryUsage();
    return {
      status: 'healthy',
      server: 'DeshiBazar Full-Stack Engine',
      port: 3000,
      uptimeSec,
      uptimeHuman: `${Math.floor(uptimeSec / 60)}m ${uptimeSec % 60}s`,
      memoryMB: {
        rss: Math.round(memory.rss / 1024 / 1024),
        heapTotal: Math.round(memory.heapTotal / 1024 / 1024),
        heapUsed: Math.round(memory.heapUsed / 1024 / 1024)
      },
      nodeVersion: process.version,
      stats: {
        totalProducts: this.products.length,
        totalCategories: this.categories.length,
        totalOrders: this.orders.length,
        totalCouriers: this.couriers.length,
        totalCoupons: this.coupons.length
      },
      timestamp: new Date().toISOString()
    };
  }
}

export const backendStore = new BackendStore();
