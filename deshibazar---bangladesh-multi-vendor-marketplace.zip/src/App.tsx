import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { MobileBottomNav } from './components/MobileBottomNav';
import { CartDrawer } from './components/CartDrawer';
import { ProductQuickViewModal } from './components/ProductQuickViewModal';
import { AuthModal } from './components/AuthModal';
import { CourierDirectoryModal } from './components/CourierDirectoryModal';
import { AddProductModal } from './components/AddProductModal';
import { DownloadAppModal } from './components/DownloadAppModal';
import { ToastContainer } from './components/ToastContainer';
import { ThemeStudioModal } from './components/ThemeStudioModal';
import { ThemeFloatingWidget } from './components/ThemeFloatingWidget';
import { EcommerceThemeStudioModal } from './components/EcommerceThemeStudioModal';
import { CustomerFloatingSupport } from './components/CustomerFloatingSupport';
import { CategoryAdminModal } from './components/CategoryAdminModal';
import { CashMemoModal } from './components/CashMemoModal';
import { SmsNotificationModal } from './components/SmsNotificationModal';

// Views
import { HomeView } from './views/HomeView';
import { CategoriesView } from './views/CategoriesView';
import { ShopView } from './views/ShopView';
import { ProductDetailsView } from './views/ProductDetailsView';
import { CheckoutView } from './views/CheckoutView';
import { TrackOrderView } from './views/TrackOrderView';
import { UserDashboardView } from './views/UserDashboardView';
import { SellerDashboardView } from './views/SellerDashboardView';
import { AdminDashboardView } from './views/AdminDashboardView';

const MainContent: React.FC = () => {
  const { 
    currentView, 
    isEcommerceStudioOpen, 
    setIsEcommerceStudioOpen,
    isCategoryModalOpen,
    setIsCategoryModalOpen,
    selectedCategoryForEdit,
    categoryModalInitialTab,
    addCategory,
    updateCategory
  } = useApp();

  return (
    <main className="min-h-screen flex flex-col justify-between">
      <div>
        {currentView === 'home' && <HomeView />}
        {currentView === 'categories' && <CategoriesView />}
        {currentView === 'shop' && <ShopView />}
        {currentView === 'product-details' && <ProductDetailsView />}
        {currentView === 'checkout' && <CheckoutView />}
        {currentView === 'track-order' && <TrackOrderView />}
        {currentView === 'user-dashboard' && <UserDashboardView />}
        {currentView === 'seller-dashboard' && <SellerDashboardView />}
        {currentView === 'admin-dashboard' && <AdminDashboardView />}
      </div>

      <Footer />
      <MobileBottomNav />
      <CartDrawer />
      <ProductQuickViewModal />
      <AuthModal />
      <CourierDirectoryModal />
      <AddProductModal />
      <DownloadAppModal />
      <ThemeStudioModal />
      <CashMemoModal />
      <SmsNotificationModal />
      <EcommerceThemeStudioModal 
        isOpen={isEcommerceStudioOpen} 
        onClose={() => setIsEcommerceStudioOpen(false)} 
      />
      {currentView !== 'admin-dashboard' && (
        <CategoryAdminModal
          isOpen={isCategoryModalOpen}
          onClose={() => setIsCategoryModalOpen(false)}
          categoryToEdit={selectedCategoryForEdit}
          onSave={(catData) => {
            if (selectedCategoryForEdit) {
              updateCategory(selectedCategoryForEdit.id, catData);
            } else {
              addCategory(catData as any);
            }
            setIsCategoryModalOpen(false);
          }}
          initialTab={categoryModalInitialTab}
        />
      )}
      <CustomerFloatingSupport />
      <ThemeFloatingWidget />
      <ToastContainer />
    </main>
  );
};

export default function App() {
  return (
    <AppProvider>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 font-sans transition-colors">
        <Header />
        <MainContent />
      </div>
    </AppProvider>
  );
}
