import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  Plus, 
  Sparkles, 
  Layers, 
  CheckCircle2
} from 'lucide-react';
import { CATEGORIES } from '../data/mockData';

const SAMPLE_IMAGE_PRESETS: { [category: string]: string[] } = {
  'fruits-vegetables': [
    'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80',
    'https://images.unsplash.com/photo-1568584711075-3d021a7c3ca3?auto=format&fit=crop&w=600&q=80',
    'https://images.unsplash.com/photo-1582979512210-99b6a53386f9?auto=format&fit=crop&w=600&q=80'
  ],
  'fish-meat': [
    'https://images.unsplash.com/photo-1544943910-4c1dc44a0551?auto=format&fit=crop&w=600&q=80',
    'https://images.unsplash.com/photo-1587593810167-a84920ea0781?auto=format&fit=crop&w=600&q=80',
    'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?auto=format&fit=crop&w=600&q=80'
  ],
  'rice-dal-grocery': [
    'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80',
    'https://images.unsplash.com/photo-1515543237350-b3eea1ec8082?auto=format&fit=crop&w=600&q=80',
    'https://images.unsplash.com/photo-1536304993881-ff6e9eefa2a6?auto=format&fit=crop&w=600&q=80'
  ],
  'dairy-eggs': [
    'https://images.unsplash.com/photo-1550583724-b2692b85b150?auto=format&fit=crop&w=600&q=80',
    'https://images.unsplash.com/photo-1631451095765-2c91616fc9e6?auto=format&fit=crop&w=600&q=80',
    'https://images.unsplash.com/photo-1506976785307-8732e854ad03?auto=format&fit=crop&w=600&q=80'
  ],
  'sports-fitness': [
    'https://images.unsplash.com/photo-1517649763962-0c623266ddc0?auto=format&fit=crop&w=600&q=80',
    'https://images.unsplash.com/photo-1531415074968-036ba1b575da?auto=format&fit=crop&w=600&q=80',
    'https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?auto=format&fit=crop&w=600&q=80'
  ],
  'pet-supplies': [
    'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?auto=format&fit=crop&w=600&q=80',
    'https://images.unsplash.com/photo-1548767797-d8c844163c4c?auto=format&fit=crop&w=600&q=80'
  ],
  'fashion': [
    'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=600&q=80',
    'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=600&q=80'
  ],
  'electronics': [
    'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80',
    'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=600&q=80'
  ],
  'beauty-personal-care': [
    'https://images.unsplash.com/photo-1608248597359-59828551737e?auto=format&fit=crop&w=600&q=80',
    'https://images.unsplash.com/photo-1607006311894-39c28892f336?auto=format&fit=crop&w=600&q=80'
  ],
  'home-kitchen': [
    'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?auto=format&fit=crop&w=600&q=80',
    'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=600&q=80'
  ],
  'handmade-products': [
    'https://images.unsplash.com/photo-1606744824163-985d376605aa?auto=format&fit=crop&w=600&q=80',
    'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=600&q=80',
    'https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?auto=format&fit=crop&w=600&q=80'
  ],
  'madicen': [
    'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=600&q=80',
    'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=600&q=80'
  ],
  'masala': [
    'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=600&q=80',
    'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=600&q=80'
  ],
  'hardware-accessories': [
    'https://images.unsplash.com/photo-1581783898377-1c85bf937427?auto=format&fit=crop&w=600&q=80',
    'https://images.unsplash.com/photo-1558002038-1055907df827?auto=format&fit=crop&w=600&q=80',
    'https://images.unsplash.com/photo-1504148455328-c376907d081c?auto=format&fit=crop&w=600&q=80'
  ]
};

export const AddProductModal: React.FC = () => {
  const { 
    t, 
    isAddProductModalOpen, 
    setIsAddProductModalOpen, 
    addProduct, 
    sellers,
    categories,
    addCategory,
    openAddCategoryModal
  } = useApp();

  const [category, setCategory] = useState<string>('deshi-products');
  const [name, setName] = useState<string>('');
  const [nameBn, setNameBn] = useState<string>('');
  const [brand, setBrand] = useState<string>('DeshiBazar');
  const [vendorId, setVendorId] = useState<string>(sellers[0]?.id || 'seller-kawran-fresh');
  const [price, setPrice] = useState<number>(250);
  const [originalPrice, setOriginalPrice] = useState<number>(320);
  const [unit, setUnit] = useState<string>('1 kg');
  const [unitBn] = useState<string>('১ কেজি');
  const [stock, setStock] = useState<number>(50);
  const [origin, setOrigin] = useState<string>('Dhaka');
  const [image, setImage] = useState<string>(
    'https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=600&q=80'
  );
  const [description, setDescription] = useState<string>('');
  const [descriptionBn, setDescriptionBn] = useState<string>('');
  const [isDeshi, setIsDeshi] = useState<boolean>(true);
  const [isOrganic, setIsOrganic] = useState<boolean>(false);
  const [isBestSeller, setIsBestSeller] = useState<boolean>(false);
  const [isDailyDeal, setIsDailyDeal] = useState<boolean>(false);
  const [isFlashSale, setIsFlashSale] = useState<boolean>(false);

  // Quick Add Category State
  const [isQuickAddCategoryOpen, setIsQuickAddCategoryOpen] = useState<boolean>(false);
  const [newCatName, setNewCatName] = useState<string>('');
  const [newCatNameBn, setNewCatNameBn] = useState<string>('');
  const [newCatIcon, setNewCatIcon] = useState<string>('Package');
  const [newCatImage, setNewCatImage] = useState<string>('');

  if (!isAddProductModalOpen) return null;

  const selectedCategoryObj = categories.find(c => c.id === category) || categories[0] || CATEGORIES[0];
  const presets = SAMPLE_IMAGE_PRESETS[category] || [selectedCategoryObj?.image || 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80'];

  const handleCreateQuickCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;

    const created = addCategory({
      name: newCatName.trim(),
      nameBn: newCatNameBn.trim() || newCatName.trim(),
      iconName: newCatIcon,
      itemCount: 0,
      image: newCatImage.trim() || 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80',
      color: 'from-emerald-500/20 to-teal-500/10',
      popularItems: []
    });

    setCategory(created.id);
    if (newCatImage.trim()) {
      setImage(newCatImage.trim());
    }
    setNewCatName('');
    setNewCatNameBn('');
    setNewCatImage('');
    setIsQuickAddCategoryOpen(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const selectedVendor = sellers.find(s => s.id === vendorId) || sellers[0];
    const discount = originalPrice > price 
      ? Math.round(((originalPrice - price) / originalPrice) * 100) 
      : 0;

    addProduct({
      name: name.trim(),
      nameBn: nameBn.trim() || name.trim(),
      category,
      categoryBn: selectedCategoryObj.nameBn,
      brand: brand.trim() || 'DeshiBazar',
      vendorId: selectedVendor?.id || 'seller-kawran-fresh',
      vendorName: selectedVendor?.name || 'Kawran Agro Fresh',
      vendorLocation: selectedVendor?.location || 'Dhaka',
      price: Number(price) || 100,
      originalPrice: Number(originalPrice) || Number(price),
      discountPercent: discount,
      unit: unit.trim() || '1 Unit',
      unitBn: unitBn.trim() || '১ টি',
      stock: Number(stock) || 50,
      image: image.trim() || selectedCategoryObj.image,
      gallery: [image.trim() || selectedCategoryObj.image],
      origin: origin.trim() || 'Bangladesh',
      description: description.trim() || `Authentic ${name} from ${origin}. Premium quality.`,
      descriptionBn: descriptionBn.trim() || `খাঁটি ও তাজা ${nameBn || name}। নির্ভরযোগ্য মান।`,
      isDeshi,
      isOrganic,
      isBestSeller,
      isDailyDeal,
      isFlashSale
    });

    setIsAddProductModalOpen(false);
    // Reset form
    setName('');
    setNameBn('');
    setDescription('');
    setDescriptionBn('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto animate-fade-in">
      <div className="relative w-full max-w-2xl bg-white dark:bg-gray-800 rounded-3xl shadow-2xl border border-gray-100 dark:border-gray-700 overflow-hidden my-8">
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-emerald-600 to-teal-700 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center backdrop-blur-xs">
              <Plus className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-black">{t('নতুন পণ্য যোগ করুন', 'Add New Product')}</h2>
              <p className="text-xs text-emerald-100">{t('১৭টি ক্যাটাগরির যেকোনোটিতে পণ্য তালিকাভুক্ত করুন', 'List authentic products in any of 17 categories')}</p>
            </div>
          </div>
          <button 
            onClick={() => setIsAddProductModalOpen(false)}
            className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          {/* 1. Category Selection */}
          <div className="bg-emerald-50/50 dark:bg-emerald-950/20 p-4 rounded-2xl border border-emerald-100 dark:border-emerald-800/50 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-gray-700 dark:text-gray-300 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-emerald-600" />
                <span>{t(`ক্যাটাগরি নির্বাচন করুন * (মোট ${categories.length}টি ক্যাটাগরি)`, `Select Category * (All ${categories.length} Categories)`)}</span>
              </label>

              <button
                type="button"
                onClick={() => setIsQuickAddCategoryOpen(!isQuickAddCategoryOpen)}
                className="text-[11px] font-bold text-emerald-700 dark:text-emerald-300 hover:text-emerald-800 dark:hover:text-emerald-200 flex items-center gap-1 bg-white dark:bg-gray-800 px-2.5 py-1 rounded-xl border border-emerald-300 dark:border-emerald-700 shadow-xs hover:shadow-sm transition-all"
              >
                <Plus className="w-3 h-3 text-emerald-600" />
                <span>{isQuickAddCategoryOpen ? t('ফর্ম বন্ধ করুন', 'Close') : t('+ নতুন ক্যাটাগরি যোগ করুন', '+ Add Category')}</span>
              </button>
            </div>

            {/* Inline Quick Add Category Form */}
            {isQuickAddCategoryOpen && (
              <div className="p-4 bg-white dark:bg-gray-800 rounded-2xl border border-emerald-200 dark:border-emerald-700/80 shadow-md space-y-3 animate-fade-in">
                <div className="flex items-center justify-between border-b border-gray-100 dark:border-gray-700 pb-2">
                  <h4 className="text-xs font-black text-gray-900 dark:text-white flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                    <span>{t('নতুন ক্যাটাগরি যোগ করুন (Quick Add Category)', 'Create New Product Category')}</span>
                  </h4>
                  <button
                    type="button"
                    onClick={() => setIsQuickAddCategoryOpen(false)}
                    className="text-gray-400 hover:text-gray-600 text-xs"
                  >
                    ✕
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-gray-600 dark:text-gray-400 mb-1">
                      {t('ক্যাটাগরির নাম (English) *', 'Category Name (English) *')}
                    </label>
                    <input
                      type="text"
                      value={newCatName}
                      onChange={(e) => setNewCatName(e.target.value)}
                      placeholder="e.g. Sports & Fitness"
                      className="w-full bg-gray-50 dark:bg-gray-750 border border-gray-200 dark:border-gray-650 rounded-xl px-3 py-1.5 text-xs text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-gray-600 dark:text-gray-400 mb-1">
                      {t('ক্যাটাগরির নাম (বাংলা)', 'Category Name (Bangla)')}
                    </label>
                    <input
                      type="text"
                      value={newCatNameBn}
                      onChange={(e) => setNewCatNameBn(e.target.value)}
                      placeholder="যেমন: খেলাধুলা ও ফিটনেস"
                      className="w-full bg-gray-50 dark:bg-gray-750 border border-gray-200 dark:border-gray-650 rounded-xl px-3 py-1.5 text-xs text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-gray-600 dark:text-gray-400 mb-1">
                    {t('আইকন নির্বাচন করুন', 'Select Icon')}
                  </label>
                  <div className="flex flex-wrap gap-1.5">
                    {[
                      { name: 'Trophy', label: 'Sports' },
                      { name: 'Heart', label: 'Pets/Care' },
                      { name: 'Package', label: 'Box' },
                      { name: 'Sparkles', label: 'Special' },
                      { name: 'Shirt', label: 'Wear' },
                      { name: 'Smartphone', label: 'Gadget' },
                      { name: 'Home', label: 'Home' },
                      { name: 'BookOpen', label: 'Books' },
                      { name: 'Flame', label: 'Spices' },
                      { name: 'Wrench', label: 'Tools' }
                    ].map(iconObj => (
                      <button
                        key={iconObj.name}
                        type="button"
                        onClick={() => setNewCatIcon(iconObj.name)}
                        className={`px-2.5 py-1 rounded-lg text-[10px] font-bold flex items-center gap-1 border transition-all ${
                          newCatIcon === iconObj.name
                            ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                            : 'bg-gray-50 dark:bg-gray-700 text-gray-600 dark:text-gray-300 border-gray-200 dark:border-gray-600 hover:border-emerald-400'
                        }`}
                      >
                        {iconObj.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-gray-600 dark:text-gray-400 mb-1">
                    {t('ছবির লিংক (Image URL)', 'Category Image URL')}
                  </label>
                  <input
                    type="url"
                    value={newCatImage}
                    onChange={(e) => setNewCatImage(e.target.value)}
                    placeholder="https://images.unsplash.com/photo-..."
                    className="w-full bg-gray-50 dark:bg-gray-750 border border-gray-200 dark:border-gray-650 rounded-xl px-3 py-1.5 text-xs text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div className="flex items-center justify-between pt-1">
                  <button
                    type="button"
                    onClick={openAddCategoryModal}
                    className="text-[11px] text-emerald-600 dark:text-emerald-400 font-bold hover:underline"
                  >
                    {t('বিস্তারিত ক্যাটাগরি স্টুডিও খুলুন →', 'Open Advanced Category Studio →')}
                  </button>

                  <button
                    type="button"
                    onClick={handleCreateQuickCategory}
                    disabled={!newCatName.trim()}
                    className="px-4 py-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl shadow-xs flex items-center gap-1.5"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{t('ক্যাটাগরি যুক্ত করুন ও সিলেক্ট করুন', 'Save & Select Category')}</span>
                  </button>
                </div>
              </div>
            )}

            <select
              value={category}
              onChange={(e) => {
                const newCat = e.target.value;
                setCategory(newCat);
                if (SAMPLE_IMAGE_PRESETS[newCat]?.length) {
                  setImage(SAMPLE_IMAGE_PRESETS[newCat][0]);
                }
              }}
              className="w-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-650 rounded-2xl px-4 py-2.5 text-xs text-gray-900 dark:text-white font-medium focus:ring-2 focus:ring-emerald-500 shadow-xs"
            >
              {categories.map((cat) => (
                <option key={cat.id} value={cat.id}>
                  {cat.name} ({cat.nameBn})
                </option>
              ))}
            </select>
          </div>

          {/* 2. Names */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5">
                {t('পণ্যের ইংরেজি নাম *', 'Product Name (English) *')}
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Organic Pure Mustard Honey"
                className="w-full bg-gray-50 dark:bg-gray-700/60 border border-gray-200 dark:border-gray-650 rounded-2xl px-4 py-2.5 text-xs text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5">
                {t('পণ্যের বাংলা নাম *', 'Product Name (Bangla) *')}
              </label>
              <input
                type="text"
                value={nameBn}
                onChange={(e) => setNameBn(e.target.value)}
                placeholder="যেমন: খাঁটি সরিষা ফুলের মধু"
                className="w-full bg-gray-50 dark:bg-gray-700/60 border border-gray-200 dark:border-gray-650 rounded-2xl px-4 py-2.5 text-xs text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* 3. Pricing & Stock */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">
                {t('বিক্রয় মূল্য (৳) *', 'Sale Price (৳) *')}
              </label>
              <input
                type="number"
                required
                min="1"
                value={price}
                onChange={(e) => setPrice(Number(e.target.value))}
                className="w-full bg-gray-50 dark:bg-gray-700/60 border border-gray-200 dark:border-gray-650 rounded-xl px-3 py-2 text-xs text-gray-900 dark:text-white font-bold"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">
                {t('আসল মূল্য (৳)', 'Original Price (৳)')}
              </label>
              <input
                type="number"
                min="1"
                value={originalPrice}
                onChange={(e) => setOriginalPrice(Number(e.target.value))}
                className="w-full bg-gray-50 dark:bg-gray-700/60 border border-gray-200 dark:border-gray-650 rounded-xl px-3 py-2 text-xs text-gray-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">
                {t('একক / Unit', 'Unit')}
              </label>
              <input
                type="text"
                value={unit}
                onChange={(e) => setUnit(e.target.value)}
                placeholder="1 kg / 500 gm / 1 Pc"
                className="w-full bg-gray-50 dark:bg-gray-700/60 border border-gray-200 dark:border-gray-650 rounded-xl px-3 py-2 text-xs text-gray-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">
                {t('স্টক সংখ্যা', 'Stock Qty')}
              </label>
              <input
                type="number"
                min="0"
                value={stock}
                onChange={(e) => setStock(Number(e.target.value))}
                className="w-full bg-gray-50 dark:bg-gray-700/60 border border-gray-200 dark:border-gray-650 rounded-xl px-3 py-2 text-xs text-gray-900 dark:text-white"
              />
            </div>
          </div>

          {/* 4. Image URL with Presets */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-gray-700 dark:text-gray-300">
                {t('পণ্যের ছবির লিঙ্ক (Image URL) *', 'Product Image URL *')}
              </label>
              <span className="text-[10px] text-gray-400 font-semibold">{t('প্রিসেট ছবি ক্লিক করে বেছে নিন', 'Or pick a preset')}</span>
            </div>
            
            <input
              type="url"
              required
              value={image}
              onChange={(e) => setImage(e.target.value)}
              className="w-full bg-gray-50 dark:bg-gray-700/60 border border-gray-200 dark:border-gray-650 rounded-2xl px-4 py-2 text-xs text-gray-900 dark:text-white font-mono"
            />

            {/* Quick Image Presets */}
            {presets && presets.length > 0 && (
              <div className="flex items-center gap-2 mt-2 overflow-x-auto pb-1">
                {presets.map((pUrl, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => setImage(pUrl)}
                    className={`relative w-12 h-12 rounded-xl overflow-hidden border-2 shrink-0 transition-all ${
                      image === pUrl ? 'border-emerald-500 ring-2 ring-emerald-500/20 scale-105' : 'border-gray-200 dark:border-gray-700 opacity-60 hover:opacity-100'
                    }`}
                  >
                    <img src={pUrl} alt="Preset" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* 5. Origin & Brand */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">
                {t('ব্র্যান্ড / ব্র্যান্ড নাম', 'Brand')}
              </label>
              <input
                type="text"
                value={brand}
                onChange={(e) => setBrand(e.target.value)}
                className="w-full bg-gray-50 dark:bg-gray-700/60 border border-gray-200 dark:border-gray-650 rounded-xl px-3 py-2 text-xs text-gray-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">
                {t('উৎপত্তিস্থল / জেলা', 'Origin / District')}
              </label>
              <input
                type="text"
                value={origin}
                onChange={(e) => setOrigin(e.target.value)}
                placeholder="e.g. Rajshahi, Tangail"
                className="w-full bg-gray-50 dark:bg-gray-700/60 border border-gray-200 dark:border-gray-650 rounded-xl px-3 py-2 text-xs text-gray-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">
                {t('বিক্রেতা / Seller', 'Seller')}
              </label>
              <select
                value={vendorId}
                onChange={(e) => setVendorId(e.target.value)}
                className="w-full bg-gray-50 dark:bg-gray-700/60 border border-gray-200 dark:border-gray-650 rounded-xl px-3 py-2 text-xs text-gray-900 dark:text-white"
              >
                {sellers.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.location})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* 6. Badges & Tags */}
          <div>
            <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-2">
              {t('বিশেষ বৈশিষ্ট্য ও ব্যাজ (Badges)', 'Special Badges')}
            </label>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => setIsDeshi(!isDeshi)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all flex items-center gap-1.5 ${
                  isDeshi ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-500 text-emerald-700 dark:text-emerald-300' : 'bg-gray-50 dark:bg-gray-750 border-gray-200 dark:border-gray-650 text-gray-500'
                }`}
              >
                <CheckCircle2 className={`w-3.5 h-3.5 ${isDeshi ? 'text-emerald-600' : 'text-gray-400'}`} />
                <span>{t('🇧🇩 খাঁটি দেশি পণ্য', '🇧🇩 Authentic Deshi')}</span>
              </button>

              <button
                type="button"
                onClick={() => setIsOrganic(!isOrganic)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all flex items-center gap-1.5 ${
                  isOrganic ? 'bg-lime-50 dark:bg-lime-950/60 border-lime-500 text-lime-700 dark:text-lime-300' : 'bg-gray-50 dark:bg-gray-750 border-gray-200 dark:border-gray-650 text-gray-500'
                }`}
              >
                <CheckCircle2 className={`w-3.5 h-3.5 ${isOrganic ? 'text-lime-600' : 'text-gray-400'}`} />
                <span>{t('🌿 ১০০% অর্গানিক', '🌿 100% Organic')}</span>
              </button>

              <button
                type="button"
                onClick={() => setIsDailyDeal(!isDailyDeal)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all flex items-center gap-1.5 ${
                  isDailyDeal ? 'bg-amber-50 dark:bg-amber-950/60 border-amber-500 text-amber-700 dark:text-amber-300' : 'bg-gray-50 dark:bg-gray-750 border-gray-200 dark:border-gray-650 text-gray-500'
                }`}
              >
                <CheckCircle2 className={`w-3.5 h-3.5 ${isDailyDeal ? 'text-amber-600' : 'text-gray-400'}`} />
                <span>{t('⚡ ডেইলি ডিল', '⚡ Daily Deal')}</span>
              </button>

              <button
                type="button"
                onClick={() => setIsFlashSale(!isFlashSale)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all flex items-center gap-1.5 ${
                  isFlashSale ? 'bg-rose-50 dark:bg-rose-950/60 border-rose-500 text-rose-700 dark:text-rose-300' : 'bg-gray-50 dark:bg-gray-750 border-gray-200 dark:border-gray-650 text-gray-500'
                }`}
              >
                <CheckCircle2 className={`w-3.5 h-3.5 ${isFlashSale ? 'text-rose-600' : 'text-gray-400'}`} />
                <span>{t('🔥 ফ্ল্যাশ সেল', '🔥 Flash Sale')}</span>
              </button>

              <button
                type="button"
                onClick={() => setIsBestSeller(!isBestSeller)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all flex items-center gap-1.5 ${
                  isBestSeller ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-500 text-indigo-700 dark:text-indigo-300' : 'bg-gray-50 dark:bg-gray-750 border-gray-200 dark:border-gray-650 text-gray-500'
                }`}
              >
                <CheckCircle2 className={`w-3.5 h-3.5 ${isBestSeller ? 'text-indigo-600' : 'text-gray-400'}`} />
                <span>{t('⭐ সেরা বিক্রিত', '⭐ Best Seller')}</span>
              </button>
            </div>
          </div>

          {/* 7. Description */}
          <div>
            <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5">
              {t('পণ্যের বিবরণ ও বৈশিষ্ট্য', 'Product Description')}
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Brief details about the product quality, harvesting, or origin..."
              className="w-full bg-gray-50 dark:bg-gray-700/60 border border-gray-200 dark:border-gray-650 rounded-2xl p-3 text-xs text-gray-900 dark:text-white"
            />
          </div>

          {/* Actions */}
          <div className="pt-2 flex items-center justify-end gap-3 border-t border-gray-100 dark:border-gray-700">
            <button
              type="button"
              onClick={() => setIsAddProductModalOpen(false)}
              className="px-5 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 text-xs font-bold hover:bg-gray-50 dark:hover:bg-gray-700"
            >
              {t('বাতিল', 'Cancel')}
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md shadow-emerald-600/20 active:scale-95 transition-all flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              <span>{t('পণ্যটি যুক্ত করুন', 'Add Product Now')}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
