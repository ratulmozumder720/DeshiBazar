import React, { useMemo, useState } from 'react';
import {
  Bell,
  MessageSquare,
  Send,
  Users,
  Wallet,
  Settings,
  Plus,
  CheckCircle2,
  Receipt,
  Smartphone,
  Building2,
  History,
  Sparkles,
  ExternalLink
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { BakiAccount, SmsNotificationType } from '../types';

interface AdminCustomerRow {
  id: string;
  name: string;
  nameBn?: string;
  phone: string;
  email?: string;
}

interface AdminBulkSmsPanelProps {
  customers?: AdminCustomerRow[];
}

export const AdminBulkSmsPanel: React.FC<AdminBulkSmsPanelProps> = ({ customers = [] }) => {
  const {
    t,
    language,
    orders,
    smsNotifications,
    bakiAccounts,
    smsGatewaySettings,
    unreadSmsCount,
    totalCustomerBakiDue,
    sendBulkSmsNotifications,
    updateSmsGatewaySettings,
    addOrUpdateBakiAccount,
    payBakiAmount,
    openSmsNotificationModal
  } = useApp();

  const [subTab, setSubTab] = useState<'compose' | 'baki-ledger' | 'gateway' | 'logs'>('compose');

  // Merge Baki ledger customers + Admin customer directory + Order customers
  const directoryContacts = useMemo(() => {
    const map = new Map<
      string,
      {
        key: string;
        name: string;
        nameBn?: string;
        phone: string;
        bakiId?: string;
        orderNumber?: string;
        totalBillAmount: number;
        paidAmount: number;
        bakiDueAmount: number;
      }
    >();

    bakiAccounts.forEach(acc => {
      map.set(acc.customerPhone, {
        key: acc.customerPhone,
        name: acc.customerName,
        nameBn: acc.customerNameBn,
        phone: acc.customerPhone,
        bakiId: acc.id,
        orderNumber: acc.orderNumber,
        totalBillAmount: acc.totalBill,
        paidAmount: acc.paidAmount,
        bakiDueAmount: acc.bakiAmount
      });
    });

    customers.forEach(c => {
      if (!c.phone) return;
      if (!map.has(c.phone)) {
        map.set(c.phone, {
          key: c.phone,
          name: c.name,
          nameBn: c.nameBn,
          phone: c.phone,
          totalBillAmount: 0,
          paidAmount: 0,
          bakiDueAmount: 0
        });
      }
    });

    orders.forEach(o => {
      if (!o.customerPhone) return;
      if (!map.has(o.customerPhone)) {
        const isPaid = o.paymentStatus === 'completed' || o.paymentStatus === 'paid_online';
        map.set(o.customerPhone, {
          key: o.customerPhone,
          name: o.customerName,
          phone: o.customerPhone,
          orderNumber: o.orderNumber,
          totalBillAmount: o.total,
          paidAmount: isPaid ? o.total : 0,
          bakiDueAmount: isPaid ? 0 : o.total
        });
      }
    });

    return Array.from(map.values());
  }, [bakiAccounts, customers, orders]);

  // Compose Bulk SMS state
  const [recipientMode, setRecipientMode] = useState<'baki_due' | 'all' | 'selected' | 'manual'>('baki_due');
  const [selectedPhones, setSelectedPhones] = useState<string[]>(() =>
    bakiAccounts.filter(b => b.bakiAmount > 0).map(b => b.customerPhone)
  );
  const [manualPhones, setManualPhones] = useState<string>('01819234567, 01711987654');
  const [smsType, setSmsType] = useState<SmsNotificationType>('baki_due');
  const [titleBn, setTitleBn] = useState<string>('বাকি টাকা পরিশোধ ও ক্যাশ মেমো রসিদ নোটিফিকেশন');
  const [titleEn, setTitleEn] = useState<string>('Baki Payment & Cash Memo Receipt Notification');
  const [messageBn, setMessageBn] = useState<string>(
    'প্রিয় {name}, আপনার অর্ডার {orderNo} এর মোট বিল ৳{total} (জমা: ৳{paid})। অবশিষ্ট বাকি: ৳{baki}। সেটিংসের নোটিফিকেশন আইকন থেকে বাকি পরিশোধ করুন।'
  );
  const [messageEn, setMessageEn] = useState<string>(
    'Dear {name}, receipt for {orderNo}: Total ৳{total}, Paid ৳{paid}, Remaining Baki Due ৳{baki}. Open Receipt Notification under Settings to pay.'
  );
  const [sending, setSending] = useState<boolean>(false);

  // Add Baki Form State
  const [newBakiName, setNewBakiName] = useState<string>('');
  const [newBakiPhone, setNewBakiPhone] = useState<string>('');
  const [newBakiOrder, setNewBakiOrder] = useState<string>('');
  const [newBakiDesc, setNewBakiDesc] = useState<string>('');
  const [newBakiTotal, setNewBakiTotal] = useState<string>('');
  const [newBakiPaid, setNewBakiPaid] = useState<string>('0');

  // Inline Admin Collect Payment state
  const [collectingBakiId, setCollectingBakiId] = useState<string | null>(null);
  const [collectAmount, setCollectAmount] = useState<string>('');
  const [collectMethod, setCollectMethod] = useState<string>('bkash');

  const applyTemplate = (tpl: SmsNotificationType) => {
    setSmsType(tpl);
    if (tpl === 'baki_due') {
      setTitleBn('বাকি টাকা পরিশোধ ও ক্যাশ মেমো রসিদ নোটিফিকেশন');
      setTitleEn('Baki Payment & Cash Memo Receipt Reminder');
      setMessageBn(
        'প্রিয় {name}, আপনার অর্ডার {orderNo} এর মোট বিল ৳{total} (জমা: ৳{paid})। অবশিষ্ট বাকি: ৳{baki}। সেটিংসের নোটিফিকেশন আইকন থেকে বাকি পরিশোধ করুন।'
      );
      setMessageEn(
        'Dear {name}, your order {orderNo} total is ৳{total} (Paid: ৳{paid}). Baki Due: ৳{baki}. Pay easily via bKash/Nagad/Bangladeshi Bank.'
      );
    } else if (tpl === 'order_receipt') {
      setTitleBn('অফিসিয়াল অর্ডার ও ক্যাশ মেমো রসিদ SMS — {orderNo}');
      setTitleEn('Official Order & Cash Memo Receipt SMS — {orderNo}');
      setMessageBn(
        'ধন্যবাদ {name}! আপনার ক্যাশ মেমো রসিদ #{orderNo} তৈরি হয়েছে। মোট বিল: ৳{total}, পরিশোধিত: ৳{paid}, বাকি: ৳{baki}।'
      );
      setMessageEn(
        'Thank you {name}! Official Receipt #{orderNo} issued. Total: ৳{total}, Paid: ৳{paid}, Due: ৳{baki}.'
      );
    } else if (tpl === 'baki_payment_receipt') {
      setTitleBn('বাকি টাকা পরিশোধের কনফার্মেশন রসিদ SMS');
      setTitleEn('Baki Payment Confirmation Receipt SMS');
      setMessageBn(
        'প্রিয় {name}, আপনার বাকি হিসাব ({orderNo}) বাবদ পেমেন্ট রসিদ আপডেট হয়েছে। মোট: ৳{total}, পরিশোধিত: ৳{paid}, অবশিষ্ট বাকি: ৳{baki}।'
      );
      setMessageEn(
        'Dear {name}, your Baki payment receipt for {orderNo} is updated. Total: ৳{total}, Paid: ৳{paid}, Remaining Baki: ৳{baki}.'
      );
    } else {
      setTitleBn('দেশিবাজার স্পেশাল বাল্ক এসএমএস ও অফার');
      setTitleEn('DeshiBazar Special Bulk SMS Offer');
      setMessageBn(
        'প্রিয় {name}, দেশিবাজারে চলছে বিশেষ ছাড়! বাংলা ও দেশি পণ্যে ১৫% পর্যন্ত ডিসকাউন্ট পেতে ভিজিট করুন DeshiBazar।'
      );
      setMessageEn(
        'Dear {name}, enjoy up to 15% discount on authentic Bangladeshi products at DeshiBazar today!'
      );
    }
  };

  const toggleCustomerSelection = (phone: string) => {
    setSelectedPhones(prev => (prev.includes(phone) ? prev.filter(p => p !== phone) : [...prev, phone]));
  };

  const targetRecipients = useMemo(() => {
    if (recipientMode === 'all') return directoryContacts;
    if (recipientMode === 'baki_due') return directoryContacts.filter(c => c.bakiDueAmount > 0);
    if (recipientMode === 'selected') return directoryContacts.filter(c => selectedPhones.includes(c.phone));
    return manualPhones
      .split(/[\n,;]+/)
      .map(s => s.trim())
      .filter(Boolean)
      .map((phone, i) => {
        const matched = directoryContacts.find(c => c.phone === phone);
        return (
          matched || {
            key: `${phone}-${i}`,
            name: 'Customer',
            nameBn: 'সম্মানিত গ্রাহক',
            phone,
            totalBillAmount: 0,
            paidAmount: 0,
            bakiDueAmount: 0
          }
        );
      });
  }, [recipientMode, directoryContacts, selectedPhones, manualPhones]);

  const handleSendBulkSms = async (e: React.FormEvent) => {
    e.preventDefault();
    if (targetRecipients.length === 0) return;
    setSending(true);
    try {
      await sendBulkSmsNotifications({
        recipients: targetRecipients.map(r => ({
          name: r.name,
          nameBn: r.nameBn,
          phone: r.phone,
          bakiId: r.bakiId,
          orderNumber: r.orderNumber,
          totalBillAmount: r.totalBillAmount,
          paidAmount: r.paidAmount,
          bakiDueAmount: r.bakiDueAmount
        })),
        type: smsType,
        title: titleEn,
        titleBn,
        message: messageEn,
        messageBn
      });
    } finally {
      setSending(false);
    }
  };

  const handleAddBaki = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBakiName.trim() || !newBakiPhone.trim() || !newBakiTotal) return;
    await addOrUpdateBakiAccount({
      customerName: newBakiName.trim(),
      customerNameBn: newBakiName.trim(),
      customerPhone: newBakiPhone.trim(),
      orderNumber: newBakiOrder.trim() || undefined,
      description: newBakiDesc.trim() || 'Store Credit / Baki Entry',
      descriptionBn: newBakiDesc.trim() || 'বাকি খাতা হিসাব',
      totalBill: Number(newBakiTotal),
      paidAmount: Number(newBakiPaid) || 0
    });
    setNewBakiName('');
    setNewBakiPhone('');
    setNewBakiOrder('');
    setNewBakiDesc('');
    setNewBakiTotal('');
    setNewBakiPaid('0');
  };

  const handleAdminCollectBaki = async (acc: BakiAccount) => {
    const amt = Number(collectAmount);
    if (!amt || amt <= 0) return;
    await payBakiAmount(acc.id, amt, collectMethod, `ADM-${Date.now().toString().slice(-6)}`);
    setCollectingBakiId(null);
    setCollectAmount('');
  };

  const handleQuickSendSingleBakiSms = async (acc: BakiAccount) => {
    await sendBulkSmsNotifications({
      recipients: [
        {
          name: acc.customerName,
          nameBn: acc.customerNameBn,
          phone: acc.customerPhone,
          bakiId: acc.id,
          orderNumber: acc.orderNumber,
          totalBillAmount: acc.totalBill,
          paidAmount: acc.paidAmount,
          bakiDueAmount: acc.bakiAmount
        }
      ],
      type: acc.bakiAmount > 0 ? 'baki_due' : 'baki_payment_receipt',
      title: 'Baki Ledger Receipt SMS — {orderNo}',
      titleBn: 'বাকি খাতা ও রসিদ SMS — {orderNo}',
      message: 'Dear {name}, Ledger {orderNo}: Total ৳{total}, Paid ৳{paid}, Remaining Baki Due: ৳{baki}.',
      messageBn: 'প্রিয় {name}, হিসাব {orderNo}: মোট বিল ৳{total}, জমা ৳{paid}, অবশিষ্ট বাকি: ৳{baki}। নোটিফিকেশন থেকে পরিশোধ করুন।'
    });
  };

  const previewTarget = targetRecipients[0] || {
    name: 'Tanvir Hossain',
    nameBn: 'তানভীর হোসেন',
    phone: '01819234567',
    orderNumber: 'DB-260315-8921',
    totalBillAmount: 2500,
    paidAmount: 1000,
    bakiDueAmount: 1500
  };

  const renderedPreviewBn = messageBn
    .replace(/\{name\}/g, previewTarget.nameBn || previewTarget.name)
    .replace(/\{orderNo\}/g, previewTarget.orderNumber || 'DB-RECEIPT')
    .replace(/\{total\}/g, String(previewTarget.totalBillAmount))
    .replace(/\{paid\}/g, String(previewTarget.paidAmount))
    .replace(/\{baki\}/g, String(previewTarget.bakiDueAmount));

  return (
    <div className="space-y-6">
      {/* Top KPI Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-teal-900 text-white rounded-2xl p-5 shadow-lg border border-emerald-800/60">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center">
              <Bell className="w-6 h-6 text-amber-300" />
            </div>
            <div>
              <h3 className="text-lg font-bold flex items-center gap-2">
                {t('অ্যাডমিন বাল্ক এসএমএস, রসিদ নোটিফিকেশন ও বাকি পেমেন্ট সিস্টেম', 'Admin Bulk SMS, Receipt Notification & Baki Payment Hub')}
              </h3>
              <p className="text-xs text-emerald-200 mt-0.5">
                {t(
                  'সেটিংসের অধীনে এখান থেকে কাস্টমারদের রসিদ SMS ও বাকি তাগাদা পাঠান এবং কাস্টমারদের বাকি টাকা গ্রহণ করুন।',
                  'Send Admin-to-Customer Bulk/Receipt SMS & manage Baki collections directly under Settings.'
                )}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => openSmsNotificationModal('notifications')}
            className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs flex items-center gap-2 shadow"
          >
            <Bell className="w-4 h-4" />
            <span>{t('কাস্টমার নোটিফিকেশন প্রিভিউ', 'Open Customer Receipt Inbox')}</span>
            {unreadSmsCount > 0 && (
              <span className="px-1.5 py-0.5 rounded-full bg-rose-600 text-white text-[10px]">
                {unreadSmsCount}
              </span>
            )}
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4">
          <div className="bg-white/10 rounded-xl p-3 border border-white/10">
            <span className="text-[11px] text-emerald-200 block">{t('প্রেরিত মোট SMS', 'Total Sent SMS')}</span>
            <span className="text-xl font-black">{smsNotifications.length}</span>
          </div>
          <div className="bg-white/10 rounded-xl p-3 border border-white/10">
            <span className="text-[11px] text-emerald-200 block">{t('অপঠিত রসিদ SMS', 'Unread Receipts')}</span>
            <span className="text-xl font-black text-amber-300">{unreadSmsCount}</span>
          </div>
          <div className="bg-white/10 rounded-xl p-3 border border-white/10">
            <span className="text-[11px] text-emerald-200 block">{t('মোট কাস্টমার বাকি', 'Total Baki Due')}</span>
            <span className="text-xl font-black text-rose-300">৳{totalCustomerBakiDue.toLocaleString()}</span>
          </div>
          <div className="bg-white/10 rounded-xl p-3 border border-white/10">
            <span className="text-[11px] text-emerald-200 block">{t('সক্রিয় BD গেটওয়ে', 'Active SMS Gateway')}</span>
            <span className="text-sm font-extrabold uppercase text-emerald-300 mt-1 block">
              {smsGatewaySettings.provider} ({smsGatewaySettings.senderId})
            </span>
          </div>
        </div>
      </div>

      {/* Sub-navigation tabs */}
      <div className="flex flex-wrap gap-2">
        {[
          { id: 'compose', icon: Send, bn: 'বাল্ক ও রসিদ SMS পাঠান', en: 'Send Bulk & Receipt SMS' },
          { id: 'baki-ledger', icon: Wallet, bn: `বাকি খাতা ও কালেকশন (${bakiAccounts.length})`, en: `Baki Ledger (${bakiAccounts.length})` },
          { id: 'gateway', icon: Settings, bn: 'BD SMS গেটওয়ে সেটিংস', en: 'BD SMS Gateway Settings' },
          { id: 'logs', icon: History, bn: `প্রেরিত SMS লগ (${smsNotifications.length})`, en: `Sent SMS Logs (${smsNotifications.length})` }
        ].map(tab => {
          const IconComp = tab.icon;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setSubTab(tab.id as any)}
              className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-all ${
                subTab === tab.id
                  ? 'bg-emerald-600 text-white shadow'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-700 hover:bg-gray-50'
              }`}
            >
              <IconComp className="w-4 h-4" />
              <span>{t(tab.bn, tab.en)}</span>
            </button>
          );
        })}
      </div>

      {/* SUB-TAB 1: COMPOSE BULK & RECEIPT SMS */}
      {subTab === 'compose' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <form
            onSubmit={handleSendBulkSms}
            className="lg:col-span-8 bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 p-5 space-y-5 shadow-sm"
          >
            {/* Recipient Target Group */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-2">
                {t('১. গ্রাহক গ্রুপ নির্বাচন করুন (Admin → Customer)', '1. Select Target Customers')}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { id: 'baki_due', bn: 'বাকি থাকা গ্রাহক', en: 'Due/Baki Only' },
                  { id: 'all', bn: 'সকল কাস্টমার', en: 'All Customers' },
                  { id: 'selected', bn: 'বাছাইকৃত গ্রাহক', en: 'Pick Customers' },
                  { id: 'manual', bn: 'ম্যানুয়াল নম্বর', en: 'Manual Numbers' }
                ].map(mode => (
                  <button
                    key={mode.id}
                    type="button"
                    onClick={() => setRecipientMode(mode.id as any)}
                    className={`p-2.5 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                      recipientMode === mode.id
                        ? 'bg-emerald-50 dark:bg-emerald-900/30 border-emerald-600 text-emerald-700 dark:text-emerald-300'
                        : 'border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300'
                    }`}
                  >
                    <Users className="w-3.5 h-3.5" />
                    <span>{t(mode.bn, mode.en)}</span>
                  </button>
                ))}
              </div>
            </div>

            {recipientMode === 'selected' && (
              <div className="p-3 rounded-xl bg-gray-50 dark:bg-gray-900/60 border border-gray-200 dark:border-gray-700 max-h-44 overflow-y-auto space-y-1.5">
                {directoryContacts.map(c => (
                  <label
                    key={c.key}
                    className="flex items-center justify-between p-2 rounded-lg bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 cursor-pointer text-xs"
                  >
                    <span className="flex items-center gap-2 font-semibold">
                      <input
                        type="checkbox"
                        checked={selectedPhones.includes(c.phone)}
                        onChange={() => toggleCustomerSelection(c.phone)}
                        className="accent-emerald-600"
                      />
                      <span>{c.nameBn || c.name}</span>
                      <span className="text-gray-500 font-mono">({c.phone})</span>
                    </span>
                    {c.bakiDueAmount > 0 && (
                      <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-800 font-bold">
                        {t(`বাকি: ৳${c.bakiDueAmount}`, `Due: ৳${c.bakiDueAmount}`)}
                      </span>
                    )}
                  </label>
                ))}
              </div>
            )}

            {recipientMode === 'manual' && (
              <div>
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                  {t('মোবাইল নম্বর লিখুন (কমা দিয়ে আলাদা করুন)', 'Enter Mobile Numbers (comma separated)')}
                </label>
                <input
                  type="text"
                  value={manualPhones}
                  onChange={e => setManualPhones(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-900 text-sm font-mono"
                  placeholder="017XXXXXXXX, 018XXXXXXXX"
                />
              </div>
            )}

            {/* Template Selector */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-2">
                {t('২. রসিদ ও SMS টেমপ্লেট বাছাই করুন', '2. Select SMS / Receipt Template')}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { id: 'baki_due', bn: 'বাকি টাকা তাগাদা', en: 'Baki Due Alert' },
                  { id: 'order_receipt', bn: 'অর্ডার রসিদ SMS', en: 'Order Receipt SMS' },
                  { id: 'baki_payment_receipt', bn: 'বাকি পরিশোধ রসিদ', en: 'Baki Paid Receipt' },
                  { id: 'bulk_promo', bn: 'অফার বাল্ক SMS', en: 'Bulk Offer SMS' }
                ].map(tpl => (
                  <button
                    key={tpl.id}
                    type="button"
                    onClick={() => applyTemplate(tpl.id as SmsNotificationType)}
                    className={`px-3 py-2 rounded-xl border text-xs font-bold transition-all ${
                      smsType === tpl.id
                        ? 'bg-amber-50 dark:bg-amber-900/30 border-amber-500 text-amber-800 dark:text-amber-300'
                        : 'border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300'
                    }`}
                  >
                    {t(tpl.bn, tpl.en)}
                  </button>
                ))}
              </div>
              <p className="text-[11px] text-gray-500 dark:text-gray-400 mt-1.5">
                {t('ডাইনামিক কোড:', 'Smart variables:')}{' '}
                <code className="px-1 bg-gray-100 dark:bg-gray-700 rounded">{'{name}'}</code>{' '}
                <code className="px-1 bg-gray-100 dark:bg-gray-700 rounded">{'{orderNo}'}</code>{' '}
                <code className="px-1 bg-gray-100 dark:bg-gray-700 rounded">{'{total}'}</code>{' '}
                <code className="px-1 bg-gray-100 dark:bg-gray-700 rounded">{'{paid}'}</code>{' '}
                <code className="px-1 bg-gray-100 dark:bg-gray-700 rounded">{'{baki}'}</code>
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                  {t('নোটিফিকেশন শিরোনাম (বাংলা)', 'Notification Title (Bangla)')}
                </label>
                <input
                  type="text"
                  value={titleBn}
                  onChange={e => setTitleBn(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-900 text-sm"
                  required
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                  {t('শিরোনাম (English)', 'Notification Title (English)')}
                </label>
                <input
                  type="text"
                  value={titleEn}
                  onChange={e => setTitleEn(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-900 text-sm"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                  {t('রসিদ ও SMS বার্তা (বাংলা)', 'SMS Message Body (Bangla)')}
                </label>
                <textarea
                  rows={4}
                  value={messageBn}
                  onChange={e => setMessageBn(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-900 text-sm"
                  required
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                  {t('রসিদ ও SMS বার্তা (English)', 'SMS Message Body (English)')}
                </label>
                <textarea
                  rows={4}
                  value={messageEn}
                  onChange={e => setMessageEn(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-900 text-sm"
                  required
                />
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-gray-200 dark:border-gray-700">
              <div className="text-xs font-semibold text-gray-600 dark:text-gray-300">
                {t(
                  `টার্গেট গ্রাহক সংখ্যা: ${targetRecipients.length} জন`,
                  `Target Recipients: ${targetRecipients.length} customer(s)`
                )}
              </div>
              <button
                type="submit"
                disabled={sending || targetRecipients.length === 0}
                className="px-5 py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold text-sm shadow-lg flex items-center gap-2 disabled:opacity-60"
              >
                <Send className="w-4 h-4" />
                <span>
                  {sending
                    ? t('পাঠানো হচ্ছে...', 'Sending SMS...')
                    : t(
                        `${targetRecipients.length} জনকে বাল্ক ও রসিদ SMS পাঠান`,
                        `Send Bulk & Receipt SMS (${targetRecipients.length})`
                      )}
                </span>
              </button>
            </div>
          </form>

          {/* Live Customer Phone SMS & Notification Preview */}
          <div className="lg:col-span-4 space-y-4">
            <div className="bg-slate-900 text-white rounded-3xl p-4 border-4 border-slate-800 shadow-xl space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-400 border-b border-slate-800 pb-2">
                <span className="flex items-center gap-1.5 font-bold text-emerald-400">
                  <Smartphone className="w-4 h-4" /> {smsGatewaySettings.senderId}
                </span>
                <span>{previewTarget.phone}</span>
              </div>

              <div className="bg-emerald-950/80 border border-emerald-700/50 rounded-2xl p-3.5 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-amber-400 text-slate-950">
                    {t('রসিদ SMS প্রিভিউ', 'Live Receipt SMS')}
                  </span>
                  <Bell className="w-4 h-4 text-amber-300" />
                </div>
                <p className="text-xs font-bold text-white">{titleBn}</p>
                <p className="text-xs text-emerald-100 leading-relaxed">{renderedPreviewBn}</p>
                {previewTarget.bakiDueAmount > 0 && (
                  <div className="pt-2 border-t border-emerald-800 flex items-center justify-between text-[11px]">
                    <span className="text-amber-300 font-bold">
                      {t(`বাকি: ৳${previewTarget.bakiDueAmount}`, `Baki Due: ৳${previewTarget.bakiDueAmount}`)}
                    </span>
                    <span className="px-2 py-0.5 rounded bg-amber-500 text-slate-950 font-bold">
                      {t('বাকি পরিশোধ', 'Pay Baki')}
                    </span>
                  </div>
                )}
              </div>

              <p className="text-[11px] text-slate-400 text-center">
                {t(
                  'গ্রাহক সেটিংসের নিচে থাকা বেল আইকনে ক্লিক করেই রসিদ দেখে বাকি টাকা পরিশোধ করতে পারবেন।',
                  'Customers will receive this in their Receipt Notification icon under Settings with 1-click Baki payment.'
                )}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 2: BAKI KHATA & COLLECTION */}
      {subTab === 'baki-ledger' && (
        <div className="space-y-5">
          {/* Add New Baki Form */}
          <form
            onSubmit={handleAddBaki}
            className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 p-4 sm:p-5 space-y-3 shadow-sm"
          >
            <h4 className="text-sm font-bold text-gray-900 dark:text-white flex items-center gap-2">
              <Plus className="w-4 h-4 text-emerald-600" />
              {t('নতুন কাস্টমার বাকি খাতা / ইনভয়েস যোগ করুন', 'Add New Customer Baki / Credit Entry')}
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
              <input
                type="text"
                placeholder={t('কাস্টমারের নাম', 'Customer Name')}
                value={newBakiName}
                onChange={e => setNewBakiName(e.target.value)}
                required
                className="px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-900 text-xs sm:text-sm"
              />
              <input
                type="text"
                placeholder={t('মোবাইল নম্বর', 'Phone (017...)')}
                value={newBakiPhone}
                onChange={e => setNewBakiPhone(e.target.value)}
                required
                className="px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-900 text-xs sm:text-sm"
              />
              <input
                type="text"
                placeholder={t('অর্ডার নং (ঐচ্ছিক)', 'Order # (optional)')}
                value={newBakiOrder}
                onChange={e => setNewBakiOrder(e.target.value)}
                className="px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-900 text-xs sm:text-sm"
              />
              <input
                type="text"
                placeholder={t('বিবরণ (যেমন: মধু/শাড়ি)', 'Item Description')}
                value={newBakiDesc}
                onChange={e => setNewBakiDesc(e.target.value)}
                className="px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-900 text-xs sm:text-sm"
              />
              <input
                type="number"
                min={1}
                placeholder={t('মোট বিল ৳', 'Total Bill ৳')}
                value={newBakiTotal}
                onChange={e => setNewBakiTotal(e.target.value)}
                required
                className="px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-900 text-xs sm:text-sm"
              />
              <div className="flex gap-2">
                <input
                  type="number"
                  min={0}
                  placeholder={t('জমা ৳', 'Paid ৳')}
                  value={newBakiPaid}
                  onChange={e => setNewBakiPaid(e.target.value)}
                  className="w-24 px-2.5 py-2 rounded-xl border border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-900 text-xs sm:text-sm"
                />
                <button
                  type="submit"
                  className="flex-1 px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold"
                >
                  {t('যোগ করুন', 'Add')}
                </button>
              </div>
            </div>
          </form>

          {/* Baki Ledger Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {bakiAccounts.map(acc => (
              <div
                key={acc.id}
                className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 p-4 space-y-3 shadow-sm"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h4 className="font-bold text-gray-900 dark:text-white text-sm sm:text-base">
                      {language === 'bn' ? acc.customerNameBn || acc.customerName : acc.customerName}
                    </h4>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {acc.customerPhone} • <span className="font-mono">{acc.orderNumber}</span>
                    </p>
                  </div>
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                      acc.status === 'paid'
                        ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300'
                        : acc.status === 'partial'
                        ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300'
                        : 'bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300'
                    }`}
                  >
                    {acc.status === 'paid' ? t('পরিশোধিত', 'Paid') : acc.status === 'partial' ? t('আংশিক', 'Partial') : t('বাকি', 'Due')}
                  </span>
                </div>

                <p className="text-xs text-gray-600 dark:text-gray-300">
                  {language === 'bn' ? acc.descriptionBn : acc.description}
                </p>

                <div className="grid grid-cols-3 gap-2 text-center bg-gray-50 dark:bg-gray-900/70 rounded-xl p-2.5">
                  <div>
                    <span className="text-[10px] text-gray-500 block">{t('মোট বিল', 'Total Bill')}</span>
                    <span className="text-sm font-bold text-gray-900 dark:text-white">৳{acc.totalBill.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-gray-500 block">{t('জমা হয়েছে', 'Paid')}</span>
                    <span className="text-sm font-bold text-emerald-600">৳{acc.paidAmount.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-gray-500 block">{t('বাকি আছে', 'Baki Due')}</span>
                    <span className="text-sm font-black text-rose-600 dark:text-rose-400">৳{acc.bakiAmount.toLocaleString()}</span>
                  </div>
                </div>

                {collectingBakiId === acc.id && acc.bakiAmount > 0 ? (
                  <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 space-y-2">
                    <div className="flex flex-wrap gap-2">
                      <input
                        type="number"
                        min={1}
                        max={acc.bakiAmount}
                        value={collectAmount}
                        onChange={e => setCollectAmount(e.target.value)}
                        placeholder={t('পরিমাণ ৳', 'Amount')}
                        className="flex-1 min-w-[100px] px-2.5 py-1.5 rounded-lg border border-amber-300 bg-white dark:bg-gray-900 text-xs font-bold"
                      />
                      <select
                        value={collectMethod}
                        onChange={e => setCollectMethod(e.target.value)}
                        className="px-2.5 py-1.5 rounded-lg border border-amber-300 bg-white dark:bg-gray-900 text-xs font-bold"
                      >
                        <option value="bkash">bKash</option>
                        <option value="nagad">Nagad</option>
                        <option value="rocket">Rocket</option>
                        <option value="bank_transfer">Bangladeshi Bank</option>
                        <option value="cash">Cash Counter</option>
                      </select>
                    </div>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => handleAdminCollectBaki(acc)}
                        className="flex-1 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-bold hover:bg-emerald-700"
                      >
                        {t('জমা নিন ও রসিদ SMS দিন', 'Confirm & Issue Receipt SMS')}
                      </button>
                      <button
                        type="button"
                        onClick={() => setCollectingBakiId(null)}
                        className="px-3 py-1.5 rounded-lg bg-gray-200 dark:bg-gray-700 text-xs font-bold"
                      >
                        {t('বাতিল', 'Cancel')}
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() => handleQuickSendSingleBakiSms(acc)}
                      className="flex-1 px-3 py-2 rounded-xl bg-blue-50 hover:bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 text-xs font-bold flex items-center justify-center gap-1.5"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>{t('রসিদ/বাকি SMS পাঠান', 'Send Receipt SMS')}</span>
                    </button>
                    {acc.bakiAmount > 0 && (
                      <button
                        type="button"
                        onClick={() => {
                          setCollectingBakiId(acc.id);
                          setCollectAmount(String(acc.bakiAmount));
                        }}
                        className="flex-1 px-3 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold flex items-center justify-center gap-1.5"
                      >
                        <Wallet className="w-3.5 h-3.5" />
                        <span>{t('বাকি টাকা সংগ্রহ করুন', 'Collect Baki')}</span>
                      </button>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUB-TAB 3: BD SMS GATEWAY SETTINGS */}
      {subTab === 'gateway' && (
        <div className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 p-5 space-y-4 shadow-sm max-w-3xl">
          <h4 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
            <Building2 className="w-5 h-5 text-emerald-600" />
            {t('বাংলাদেশি বাল্ক এসএমএস গেটওয়ে কনফিগারেশন', 'Bangladeshi Bulk SMS Gateway Configuration')}
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-600 dark:text-gray-300 mb-1">
                {t('এসএমএস প্রোভাইডার', 'SMS Gateway Provider')}
              </label>
              <select
                value={smsGatewaySettings.provider}
                onChange={e => updateSmsGatewaySettings({ provider: e.target.value as any })}
                className="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-900 text-sm font-semibold"
              >
                <option value="bulksmsbd">BulkSMSBD (BD Live)</option>
                <option value="ssl_wireless">SSL Wireless SMS</option>
                <option value="greenweb_bd">GreenWeb Bangladesh</option>
                <option value="elitbuzz">Elitbuzz SMS BD</option>
                <option value="mimsms">MimSMS Bangladesh</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-600 dark:text-gray-300 mb-1">
                {t('সেন্ডার আইডি (Masking)', 'Sender ID (Masking)')}
              </label>
              <input
                type="text"
                value={smsGatewaySettings.senderId}
                onChange={e => updateSmsGatewaySettings({ senderId: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-900 text-sm font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-600 dark:text-gray-300 mb-1">
                {t('এপিআই কী', 'API Token / Key')}
              </label>
              <input
                type="text"
                value={smsGatewaySettings.apiKeyMasked}
                onChange={e => updateSmsGatewaySettings({ apiKeyMasked: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-900 text-sm font-mono"
              />
            </div>
          </div>

          <div className="space-y-2.5 pt-2">
            {[
              {
                key: 'enableAutoOrderReceiptSms' as const,
                bn: 'প্রতিটি নতুন অর্ডারে স্বয়ংক্রিয়ভাবে রসিদ SMS পাঠান',
                en: 'Auto-send Cash Memo Receipt SMS on every new order'
              },
              {
                key: 'enableAutoBakiReminderSms' as const,
                bn: 'বাকি থাকা কাস্টমারদের রসিদ ও তাগাদা নোটিফিকেশন সক্রিয় রাখুন',
                en: 'Enable Baki Due alert notifications under Customer Settings'
              },
              {
                key: 'enableAutoBakiPaymentReceiptSms' as const,
                bn: 'বাকি টাকা পরিশোধের সাথে সাথে কনফার্মেশন রসিদ SMS পাঠান',
                en: 'Auto-issue Verified Payment Receipt SMS when Baki is paid'
              }
            ].map(item => (
              <label
                key={item.key}
                className="flex items-center justify-between p-3 rounded-xl bg-gray-50 dark:bg-gray-900/60 border border-gray-200 dark:border-gray-700 cursor-pointer"
              >
                <span className="text-xs sm:text-sm font-semibold text-gray-800 dark:text-gray-200">
                  {t(item.bn, item.en)}
                </span>
                <input
                  type="checkbox"
                  checked={!!smsGatewaySettings[item.key]}
                  onChange={e => updateSmsGatewaySettings({ [item.key]: e.target.checked })}
                  className="w-4 h-4 accent-emerald-600"
                />
              </label>
            ))}
          </div>
        </div>
      )}

      {/* SUB-TAB 4: SENT SMS & RECEIPT LOGS */}
      {subTab === 'logs' && (
        <div className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 overflow-hidden shadow-sm">
          <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
            <h4 className="font-bold text-sm text-gray-900 dark:text-white flex items-center gap-2">
              <Receipt className="w-4 h-4 text-emerald-600" />
              {t('প্রেরিত বাল্ক SMS ও রসিদ ডেলিভারি লগ', 'Sent Bulk SMS & Receipt Delivery Logs')}
            </h4>
            <button
              type="button"
              onClick={() => openSmsNotificationModal('notifications')}
              className="text-xs font-bold text-emerald-600 hover:underline flex items-center gap-1"
            >
              <Sparkles className="w-3.5 h-3.5" />
              {t('কাস্টমার ইনবক্স দেখুন', 'Preview Customer Inbox')}
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-gray-50 dark:bg-gray-900/70 text-gray-600 dark:text-gray-300 font-bold">
                <tr>
                  <th className="p-3">{t('গ্রাহক ও ফোন', 'Customer & Phone')}</th>
                  <th className="p-3">{t('ধরন', 'Type')}</th>
                  <th className="p-3">{t('রসিদ / বার্তা', 'Message')}</th>
                  <th className="p-3">{t('বাকি / পরিশোধ', 'Baki / Paid')}</th>
                  <th className="p-3">{t('স্ট্যাটাস', 'Status')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
                {smsNotifications.map(n => (
                  <tr key={n.id} className="hover:bg-gray-50/70 dark:hover:bg-gray-900/40">
                    <td className="p-3 whitespace-nowrap">
                      <div className="font-bold text-gray-900 dark:text-white">{n.recipientNameBn || n.recipientName}</div>
                      <div className="text-[11px] font-mono text-gray-500">{n.recipientPhone}</div>
                    </td>
                    <td className="p-3 whitespace-nowrap">
                      <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300 font-bold text-[10px]">
                        {n.type}
                      </span>
                    </td>
                    <td className="p-3 max-w-xs">
                      <div className="font-bold text-gray-800 dark:text-gray-200 truncate">
                        {language === 'bn' ? n.titleBn : n.title}
                      </div>
                      <div className="text-[11px] text-gray-500 line-clamp-2">
                        {language === 'bn' ? n.messageBn : n.message}
                      </div>
                    </td>
                    <td className="p-3 whitespace-nowrap">
                      {n.bakiDueAmount !== undefined && (
                        <div className="font-bold text-amber-600">
                          {t(`বাকি: ৳${n.bakiDueAmount}`, `Due: ৳${n.bakiDueAmount}`)}
                        </div>
                      )}
                      {n.paidAmount !== undefined && (
                        <div className="text-[11px] text-emerald-600">
                          {t(`জমা: ৳${n.paidAmount}`, `Paid: ৳${n.paidAmount}`)}
                        </div>
                      )}
                    </td>
                    <td className="p-3 whitespace-nowrap">
                      <span className="inline-flex items-center gap-1 text-emerald-600 font-bold">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        {n.deliveryStatus}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
