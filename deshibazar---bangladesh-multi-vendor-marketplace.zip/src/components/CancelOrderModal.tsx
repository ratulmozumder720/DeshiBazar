import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { AlertCircle, X, Check, ShieldAlert } from 'lucide-react';
import { Order } from '../types';

interface CancelOrderModalProps {
  order: Order | null;
  isOpen: boolean;
  onClose: () => void;
  onCancelled?: () => void;
}

export const CancelOrderModal: React.FC<CancelOrderModalProps> = ({
  order,
  isOpen,
  onClose,
  onCancelled
}) => {
  const { t, cancelOrder } = useApp();

  const [selectedReason, setSelectedReason] = useState<string>('Selected wrong product or quantity');
  const [customNote, setCustomNote] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  if (!isOpen || !order) return null;

  const REASONS = [
    {
      en: 'Selected wrong product or quantity',
      bn: 'ভুল পণ্য বা পরিমাণ নির্বাচন করেছি'
    },
    {
      en: 'Need to change delivery address or phone',
      bn: 'ডেলিভারি ঠিকানা বা মোবাইল নম্বর পরিবর্তন করতে চাই'
    },
    {
      en: 'Found better price or deal elsewhere',
      bn: 'অন্য কোথাও কম দামে বা ভালো অফার পেয়েছি'
    },
    {
      en: 'Delivery time is longer than expected',
      bn: 'সম্ভাব্য ডেলিভারি তারিখ অনেক বেশি সময় নিচ্ছে'
    },
    {
      en: 'Placed order by mistake',
      bn: 'ভুলবশত অর্ডার কনফার্ম করে ফেলেছি'
    },
    {
      en: 'Other reasons',
      bn: 'অন্যান্য ব্যক্তিগত কারণ'
    }
  ];

  const handleConfirmCancel = async () => {
    setIsSubmitting(true);
    const finalReason = customNote.trim() 
      ? `${selectedReason}: ${customNote.trim()}`
      : selectedReason;

    const success = await cancelOrder(order.id, finalReason);
    setIsSubmitting(false);

    if (success) {
      if (onCancelled) onCancelled();
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto p-4 flex items-center justify-center">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
      />

      <div className="relative bg-white dark:bg-gray-800 rounded-3xl max-w-md w-full p-6 shadow-2xl border border-gray-100 dark:border-gray-700 z-10 animate-in fade-in zoom-in-95 duration-150">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Icon */}
        <div className="w-12 h-12 rounded-2xl bg-rose-100 dark:bg-rose-950/80 text-rose-600 flex items-center justify-center mb-4 mx-auto">
          <AlertCircle className="w-6 h-6" />
        </div>

        <div className="text-center mb-5">
          <h3 className="text-lg font-black text-gray-900 dark:text-white">
            {t('অর্ডার বাতিল নিশ্চিত করুন', 'Cancel Order Confirmation')}
          </h3>
          <p className="text-xs text-gray-500 mt-1">
            {t('অর্ডার নং:', 'Order ID:')}{' '}
            <span className="font-mono font-bold text-gray-900 dark:text-white">{order.orderNumber}</span>
            {' • '}
            <span>৳{order.total}</span>
          </p>
        </div>

        {/* Reason Selector */}
        <div className="space-y-3 mb-5">
          <label className="text-xs font-bold text-gray-700 dark:text-gray-300 block">
            {t('বাতিল করার কারণ নির্বাচন করুন:', 'Select reason for cancellation:')}
          </label>

          <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
            {REASONS.map((r, i) => (
              <label
                key={i}
                className={`p-3 rounded-xl border text-xs font-medium flex items-center justify-between cursor-pointer transition-colors ${
                  selectedReason === r.en
                    ? 'border-rose-500 bg-rose-50/50 dark:bg-rose-950/30 text-rose-900 dark:text-rose-200 font-bold'
                    : 'border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-750'
                }`}
              >
                <div className="flex items-center gap-2">
                  <input
                    type="radio"
                    name="cancel_reason"
                    checked={selectedReason === r.en}
                    onChange={() => setSelectedReason(r.en)}
                    className="accent-rose-500"
                  />
                  <span>{t(r.bn, r.en)}</span>
                </div>
                {selectedReason === r.en && <Check className="w-4 h-4 text-rose-500 shrink-0" />}
              </label>
            ))}
          </div>

          <div>
            <label className="text-[11px] text-gray-400 block mb-1">
              {t('অতিরিক্ত মন্তব্য (ঐচ্ছিক):', 'Additional remarks (optional):')}
            </label>
            <input
              type="text"
              value={customNote}
              onChange={(e) => setCustomNote(e.target.value)}
              placeholder={t('বিস্তারিত লিখুন...', 'Add more details if needed...')}
              className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl px-3 py-2 text-xs focus:ring-1 focus:ring-rose-500 focus:outline-none"
            />
          </div>
        </div>

        {/* Warning Note */}
        <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-xl flex items-start gap-2 mb-5 text-[11px] text-amber-800 dark:text-amber-200">
          <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
          <span>
            {t(
              'অর্ডার বাতিল করলে প্যাকেজিং বন্ধ হয়ে যাবে। অনলাইন পেমেন্ট করে থাকলে স্বয়ংক্রিয়ভাবে রিফান্ড সম্পন্ন হবে।',
              'Cancelling will stop packing and dispatch. Any online payment will be refunded to your source account.'
            )}
          </span>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={onClose}
            disabled={isSubmitting}
            className="py-3 px-4 rounded-xl border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 font-bold text-xs hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
          >
            {t('অর্ডার রাখবেন', 'Keep Order')}
          </button>

          <button
            type="button"
            onClick={handleConfirmCancel}
            disabled={isSubmitting}
            className="py-3 px-4 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md shadow-rose-600/20 active:scale-95 transition-all disabled:opacity-50"
          >
            {isSubmitting ? t('বাতিল হচ্ছে...', 'Cancelling...') : t('হ্যাঁ, অর্ডার বাতিল করুন', 'Yes, Cancel Order')}
          </button>
        </div>
      </div>
    </div>
  );
};
