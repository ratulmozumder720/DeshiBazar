import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useApp } from '../context/AppContext';
import type { CartItem, Order } from '../types';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import {
  X,
  Printer,
  FileDown,
  Image as ImageIcon,
  CheckCircle2,
  ShieldCheck,
  Receipt,
  Layers,
  SlidersHorizontal,
  Plus,
  Minus,
  Trash2
} from 'lucide-react';

interface CashMemoModalProps {
  order?: Order | null;
  isOpen?: boolean;
  onClose?: () => void;
}

export const CashMemoModal: React.FC<CashMemoModalProps> = ({
  order: propOrder,
  isOpen: propIsOpen,
  onClose: propOnClose
}) => {
  const {
    isCashMemoModalOpen,
    setIsCashMemoModalOpen,
    selectedCashMemoOrder,
    cashMemoInitialCategory,
    cashMemoIsBuilder,
    closeCashMemoModal,
    categories,
    products,
    orders,
    t,
    language,
    showToast
  } = useApp();

  const memoRef = useRef<HTMLDivElement>(null);
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const [isExportingImage, setIsExportingImage] = useState(false);
  const [memoStyle, setMemoStyle] = useState<'traditional' | 'modern' | 'category'>('category');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('all');
  const [isCustomizerOpen, setIsCustomizerOpen] = useState<boolean>(false);

  // Editable invoice override state (used when customizing or building category cash memos)
  const [customCustomerName, setCustomCustomerName] = useState<string>('');
  const [customCustomerPhone, setCustomCustomerPhone] = useState<string>('');
  const [customAddress, setCustomAddress] = useState<string>('');
  const [customPaymentMethod, setCustomPaymentMethod] = useState<Order['paymentMethod']>('cod');
  const [customDeliveryFee, setCustomDeliveryFee] = useState<number>(60);
  const [customDiscount, setCustomDiscount] = useState<number>(0);
  const [editableItems, setEditableItems] = useState<CartItem[] | null>(null);
  const [dataSource, setDataSource] = useState<'current' | 'catalog' | 'orders'>('current');

  // Determine active order & open state (support either props or context)
  const baseOrder = propOrder !== undefined ? propOrder : selectedCashMemoOrder;
  const isOpen = propIsOpen !== undefined ? propIsOpen : isCashMemoModalOpen;

  // Sync defaults whenever modal opens with a new order / category
  useEffect(() => {
    if (!isOpen || !baseOrder) return;
    setMemoStyle(cashMemoIsBuilder ? 'category' : 'category');
    setSelectedCategoryFilter(cashMemoInitialCategory || 'all');
    setIsCustomizerOpen(Boolean(cashMemoIsBuilder));
    setCustomCustomerName(baseOrder.customerName || '');
    setCustomCustomerPhone(baseOrder.customerPhone || '');
    setCustomAddress(baseOrder.address || '');
    setCustomPaymentMethod(baseOrder.paymentMethod || 'cod');
    setCustomDeliveryFee(baseOrder.deliveryFee ?? 60);
    setCustomDiscount(baseOrder.discount ?? 0);
    setEditableItems(baseOrder.items.map(it => ({ ...it })));
    setDataSource(cashMemoIsBuilder ? 'catalog' : 'current');
  }, [isOpen, baseOrder, cashMemoInitialCategory, cashMemoIsBuilder]);

  const handleClose = () => {
    if (propOnClose) {
      propOnClose();
    } else {
      closeCashMemoModal();
      setIsCashMemoModalOpen(false);
    }
  };

  // Switch item data source inside Customizer
  const handleSwitchDataSource = (source: 'current' | 'catalog' | 'orders') => {
    setDataSource(source);
    if (source === 'current' && baseOrder) {
      setEditableItems(baseOrder.items.map(it => ({ ...it })));
      setSelectedCategoryFilter('all');
    } else if (source === 'catalog') {
      const activeCats = new Set(categories.filter(c => c.status !== 'inactive').map(c => c.id));
      const catalogItems: CartItem[] = products
        .filter(p => activeCats.has(p.category) || Boolean(p.category))
        .map(p => ({ product: p, quantity: 1 }));
      setEditableItems(catalogItems);
    } else if (source === 'orders') {
      const mergedMap = new Map<string, CartItem>();
      orders.forEach(ord => {
        ord.items.forEach(it => {
          const existing = mergedMap.get(it.product.id);
          if (existing) {
            mergedMap.set(it.product.id, { product: it.product, quantity: existing.quantity + it.quantity });
          } else {
            mergedMap.set(it.product.id, { product: it.product, quantity: it.quantity });
          }
        });
      });
      const aggregated = Array.from(mergedMap.values());
      if (aggregated.length === 0) {
        showToast(t('কোনো অর্ডার আইটেম পাওয়া যায়নি, ক্যাটালগ দেখানো হচ্ছে', 'No customer orders found; keeping current items'), 'info');
      } else {
        setEditableItems(aggregated);
        setSelectedCategoryFilter('all');
      }
    }
  };

  const activeItems = useMemo(() => {
    if (!baseOrder) return [];
    const sourceItems = editableItems ?? baseOrder.items;
    if (selectedCategoryFilter === 'all') return sourceItems;
    return sourceItems.filter(it => it.product.category === selectedCategoryFilter);
  }, [baseOrder, editableItems, selectedCategoryFilter]);

  // Group items by Category for Category-Wise Cash Memo & Category Breakdown
  const categoryGroups = useMemo(() => {
    const groupMap = new Map<string, {
      categoryId: string;
      name: string;
      nameBn: string;
      items: CartItem[];
      subtotal: number;
      totalQty: number;
    }>();

    // Pre-order groups following the marketplace's category directory order
    const categoryOrderIndex = new Map<string, number>();
    categories.forEach((c, idx) => categoryOrderIndex.set(c.id, idx));

    activeItems.forEach((it) => {
      const catId = it.product.category || 'other';
      const catMeta = categories.find(c => c.id === catId);
      const existing = groupMap.get(catId);
      if (existing) {
        existing.items.push(it);
        existing.subtotal += it.product.price * it.quantity;
        existing.totalQty += it.quantity;
      } else {
        groupMap.set(catId, {
          categoryId: catId,
          name: catMeta?.name || catId.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
          nameBn: catMeta?.nameBn || it.product.categoryBn || catId,
          items: [it],
          subtotal: it.product.price * it.quantity,
          totalQty: it.quantity
        });
      }
    });

    return Array.from(groupMap.values()).sort((a, b) => {
      const idxA = categoryOrderIndex.get(a.categoryId) ?? 999;
      const idxB = categoryOrderIndex.get(b.categoryId) ?? 999;
      return idxA - idxB;
    });
  }, [activeItems, categories]);

  // Available categories present in the underlying editable items (plus all active categories if builder)
  const availableCategoriesForDropdown = useMemo(() => {
    const sourceItems = editableItems ?? baseOrder?.items ?? [];
    const presentIds = new Set(sourceItems.map(it => it.product.category));
    return categories.filter(c => c.status !== 'inactive' && (cashMemoIsBuilder || dataSource === 'catalog' || presentIds.has(c.id)));
  }, [categories, editableItems, baseOrder, cashMemoIsBuilder, dataSource]);

  const computedSubtotal = useMemo(
    () => activeItems.reduce((sum, it) => sum + it.product.price * it.quantity, 0),
    [activeItems]
  );

  const effectiveDeliveryFee = activeItems.length > 0 ? customDeliveryFee : 0;
  const effectiveDiscount = Math.min(customDiscount, computedSubtotal);
  const computedTotal = Math.max(0, computedSubtotal + effectiveDeliveryFee - effectiveDiscount);

  const updateItemQty = (productId: string, delta: number) => {
    setEditableItems(prev => {
      if (!prev) return prev;
      return prev
        .map(it => it.product.id === productId ? { ...it, quantity: Math.max(1, it.quantity + delta) } : it);
    });
  };

  const removeItemFromMemo = (productId: string) => {
    setEditableItems(prev => (prev ? prev.filter(it => it.product.id !== productId) : prev));
  };

  if (!isOpen || !baseOrder) return null;

  const order: Order = {
    ...baseOrder,
    customerName: customCustomerName || baseOrder.customerName,
    customerPhone: customCustomerPhone || baseOrder.customerPhone,
    address: customAddress || baseOrder.address,
    paymentMethod: customPaymentMethod,
    deliveryFee: effectiveDeliveryFee,
    discount: effectiveDiscount,
    subtotal: computedSubtotal,
    total: computedTotal,
    items: activeItems
  };

  const selectedCatMeta = selectedCategoryFilter !== 'all'
    ? categories.find(c => c.id === selectedCategoryFilter)
    : null;

  // Format Date in Bengali or English
  const orderDate = new Date(order.createdAt || Date.now());
  const formattedDate = orderDate.toLocaleDateString(language === 'bn' ? 'bn-BD' : 'en-US', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });
  const formattedTime = orderDate.toLocaleTimeString(language === 'bn' ? 'bn-BD' : 'en-US', {
    hour: '2-digit',
    minute: '2-digit'
  });

  const fileSuffix = selectedCategoryFilter === 'all'
    ? (memoStyle === 'category' ? `AllCategories_${order.orderNumber}` : order.orderNumber)
    : `${selectedCategoryFilter}_${order.orderNumber}`;

  // Export as PDF
  const handleDownloadPdf = async () => {
    if (!memoRef.current) return;
    setIsExportingPdf(true);
    showToast(t('ক্যাশ মেমো PDF তৈরি হচ্ছে...', 'Generating PDF cash memo...'), 'info');

    try {
      const element = memoRef.current;
      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff'
      });

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      const imgWidth = 210; // A4 width mm
      const pageHeight = 297; // A4 height mm
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;
      let position = 0;

      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      while (heightLeft > 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }

      pdf.save(`DeshiBazar_CashMemo_${fileSuffix}.pdf`);
      showToast(t('ক্যাশ মেমো PDF ফাইল সফলভাবে ডাউনলোড হয়েছে!', 'Cash Memo PDF downloaded successfully!'), 'success');
    } catch (error) {
      console.error('PDF Export Error:', error);
      showToast(t('PDF তৈরিতে সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।', 'Failed to generate PDF. Please try again.'), 'error');
    } finally {
      setIsExportingPdf(false);
    }
  };

  // Export as Image (PNG / JPG)
  const handleDownloadImage = async (format: 'png' | 'jpeg' = 'png') => {
    if (!memoRef.current) return;
    setIsExportingImage(true);
    showToast(t('ক্যাশ মেমো ইমেজ তৈরি হচ্ছে...', 'Generating Cash Memo image...'), 'info');

    try {
      const element = memoRef.current;
      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff'
      });

      const imageURI = canvas.toDataURL(format === 'png' ? 'image/png' : 'image/jpeg', 0.95);
      const link = document.createElement('a');
      link.download = `DeshiBazar_CashMemo_${fileSuffix}.${format === 'png' ? 'png' : 'jpg'}`;
      link.href = imageURI;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      showToast(t(`ক্যাশ মেমো ${format.toUpperCase()} ইমেজ সফলভাবে ডাউনলোড হয়েছে!`, `Cash Memo ${format.toUpperCase()} image downloaded successfully!`), 'success');
    } catch (error) {
      console.error('Image Export Error:', error);
      showToast(t('ইমেজ তৈরিতে ত্রুটি দেখা দিয়েছে', 'Failed to generate image'), 'error');
    } finally {
      setIsExportingImage(false);
    }
  };

  // Direct Print
  const handlePrint = () => {
    window.print();
  };

  const isPaid = order.paymentStatus === 'completed' || order.paymentStatus === 'paid_online';

  const getPaymentMethodLabel = () => {
    switch (order.paymentMethod) {
      case 'bkash': return t('বিকাশ ইনস্ট্যান্ট পেমেন্ট (bKash)', 'bKash Instant Gateway');
      case 'nagad': return t('নগদ ডিজিটাল পেমেন্ট (Nagad)', 'Nagad Gateway');
      case 'rocket': return t('রকেট / নেক্সাসপে (Rocket)', 'DBBL Rocket / NexusPay');
      case 'bank_transfer': return t(
        order.bankPaymentDetails ? `বাংলাদেশি ব্যাংক (${order.bankPaymentDetails.bankName})` : 'বাংলাদেশি ব্যাংক ট্রান্সফার',
        order.bankPaymentDetails ? `Bangladeshi Bank (${order.bankPaymentDetails.bankName})` : 'Bangladeshi Bank Transfer'
      );
      case 'card': return t('ক্রেডিট / ডেবিট কার্ড (Visa/Mastercard)', 'Debit / Credit Card');
      case 'cod':
      default:
        return t('ক্যাশ অন ডেলিভারি (Cash on Delivery - COD)', 'Cash on Delivery (COD)');
    }
  };

  // Compute running sequential index across category groups
  let runningSerial = 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/75 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div
        className="w-full max-w-5xl max-h-[96vh] flex flex-col bg-white dark:bg-gray-900 rounded-3xl shadow-2xl border border-gray-100 dark:border-gray-800 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Action Bar (Controls & Download Buttons) */}
        <div className="px-5 py-3.5 border-b border-gray-100 dark:border-gray-800 flex flex-wrap items-center justify-between gap-3 bg-gradient-to-r from-emerald-50 via-white to-teal-50 dark:from-gray-900 dark:via-gray-850 dark:to-gray-900">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-600 text-white flex items-center justify-center shadow-md shadow-emerald-600/20">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-sm sm:text-base font-black text-gray-900 dark:text-white">
                  {t('ক্যাটাগরি অনুযায়ী ক্যাশ মেমো ও ইনভয়েস', 'Category-Wise Cash Memo & Invoice')}
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                  {order.orderNumber}
                </span>
              </div>
              <p className="text-xs text-gray-500 dark:text-gray-400">
                {t('সকল ক্যাটাগরি বা একক ক্যাটাগরি বেছে নিয়ে PDF, ইমেজ ও প্রিন্ট করুন', 'Filter by all or any category, customize quantities, and export PDF/Image')}
              </p>
            </div>
          </div>

          {/* Action Buttons Toolbar */}
          <div className="flex items-center flex-wrap gap-2">
            {/* Style switcher */}
            <div className="flex items-center bg-gray-100 dark:bg-gray-800 p-0.5 rounded-xl text-[11px] font-bold border border-gray-200 dark:border-gray-700">
              <button
                type="button"
                onClick={() => setMemoStyle('category')}
                className={`px-2.5 py-1 rounded-lg transition-all flex items-center gap-1 ${
                  memoStyle === 'category'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-gray-500 dark:text-gray-400'
                }`}
              >
                <Layers className="w-3 h-3" />
                <span>{t('ক্যাটাগরি মেমো', 'Category-Wise')}</span>
              </button>
              <button
                type="button"
                onClick={() => setMemoStyle('traditional')}
                className={`px-2.5 py-1 rounded-lg transition-all ${
                  memoStyle === 'traditional'
                    ? 'bg-white dark:bg-gray-700 text-emerald-700 dark:text-emerald-300 shadow-xs'
                    : 'text-gray-500 dark:text-gray-400'
                }`}
              >
                {t('প্রমিত মেমো', 'Cash Memo')}
              </button>
              <button
                type="button"
                onClick={() => setMemoStyle('modern')}
                className={`px-2.5 py-1 rounded-lg transition-all ${
                  memoStyle === 'modern'
                    ? 'bg-white dark:bg-gray-700 text-emerald-700 dark:text-emerald-300 shadow-xs'
                    : 'text-gray-500 dark:text-gray-400'
                }`}
              >
                {t('ট্যাক্স ইনভয়েস', 'Tax Invoice')}
              </button>
            </div>

            {/* Category Filter Selector */}
            <select
              value={selectedCategoryFilter}
              onChange={(e) => setSelectedCategoryFilter(e.target.value)}
              className="bg-white dark:bg-gray-800 border border-emerald-300 dark:border-emerald-700 text-gray-800 dark:text-gray-100 rounded-xl px-2.5 py-1.5 text-xs font-bold focus:outline-none focus:ring-2 focus:ring-emerald-500"
              title={t('ক্যাটাগরি নির্বাচন করুন', 'Select Category Filter')}
            >
              <option value="all">
                {t(`সকল ক্যাটাগরি (${categoryGroups.length})`, `All Categories (${categoryGroups.length})`)}
              </option>
              {availableCategoriesForDropdown.map(cat => (
                <option key={cat.id} value={cat.id}>
                  {language === 'bn' ? `${cat.nameBn} (${cat.name})` : cat.name}
                </option>
              ))}
            </select>

            {/* Customizer Toggle */}
            <button
              type="button"
              onClick={() => setIsCustomizerOpen(!isCustomizerOpen)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold border flex items-center gap-1.5 transition-all ${
                isCustomizerOpen
                  ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border-amber-300 dark:border-amber-700'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border-gray-200 dark:border-gray-700 hover:border-emerald-400'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>{t('কাস্টমাইজ', 'Customize')}</span>
            </button>

            {/* Download PDF Button */}
            <button
              type="button"
              onClick={handleDownloadPdf}
              disabled={isExportingPdf || activeItems.length === 0}
              className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-600/20 flex items-center gap-1.5 transition-all active:scale-95 disabled:opacity-50"
              title={t('PDF ফাইল হিসেবে ডাউনলোড করুন', 'Download Cash Memo as PDF Document')}
            >
              <FileDown className="w-4 h-4 text-emerald-100" />
              <span>{isExportingPdf ? t('PDF তৈরি হচ্ছে...', 'PDF...') : t('PDF ডাউনলোড', 'PDF File')}</span>
            </button>

            {/* Download Image Button */}
            <button
              type="button"
              onClick={() => handleDownloadImage('png')}
              disabled={isExportingImage || activeItems.length === 0}
              className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-600/20 flex items-center gap-1.5 transition-all active:scale-95 disabled:opacity-50"
              title={t('PNG ছবি হিসেবে ডাউনলোড করুন', 'Download Cash Memo as PNG Image File')}
            >
              <ImageIcon className="w-4 h-4 text-indigo-100" />
              <span>{isExportingImage ? t('ইমেজ হচ্ছে...', 'Image...') : t('ইমেজ (PNG)', 'Image File')}</span>
            </button>

            {/* Print Button */}
            <button
              type="button"
              onClick={handlePrint}
              disabled={activeItems.length === 0}
              className="p-2 sm:px-3 sm:py-2 bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-650 text-gray-800 dark:text-gray-200 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 disabled:opacity-50"
              title={t('ক্যাশ মেমো প্রিন্ট করুন', 'Print Cash Memo')}
            >
              <Printer className="w-4 h-4 text-gray-600 dark:text-gray-300" />
              <span className="hidden sm:inline">{t('প্রিন্ট', 'Print')}</span>
            </button>

            {/* Close Modal Button */}
            <button
              type="button"
              onClick={handleClose}
              className="w-9 h-9 rounded-xl flex items-center justify-center text-gray-400 hover:text-gray-700 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Interactive Category Cash Memo Customizer Panel */}
        {isCustomizerOpen && (
          <div className="px-5 py-3.5 bg-amber-50/60 dark:bg-gray-850 border-b border-amber-200/70 dark:border-gray-800 space-y-3 text-xs">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-emerald-600" />
                <span className="font-black text-gray-900 dark:text-white">
                  {t('ক্যাটাগরি মেমো ও তথ্য সেটআপ', 'Category Memo Builder & Controls')}
                </span>
              </div>

              {/* Data Source Switcher */}
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-[11px] font-bold text-gray-500">{t('উৎস:', 'Source:')}</span>
                <button
                  type="button"
                  onClick={() => handleSwitchDataSource('catalog')}
                  className={`px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-all ${
                    dataSource === 'catalog'
                      ? 'bg-emerald-600 text-white border-emerald-600'
                      : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border-gray-200 dark:border-gray-700'
                  }`}
                >
                  {t('সকল ক্যাটাগরি ক্যাটালগ', 'All Categories Catalog')}
                </button>
                <button
                  type="button"
                  onClick={() => handleSwitchDataSource('orders')}
                  className={`px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-all ${
                    dataSource === 'orders'
                      ? 'bg-emerald-600 text-white border-emerald-600'
                      : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border-gray-200 dark:border-gray-700'
                  }`}
                >
                  {t(`সব অর্ডার (${orders.length})`, `All Orders (${orders.length})`)}
                </button>
                {!cashMemoIsBuilder && (
                  <button
                    type="button"
                    onClick={() => handleSwitchDataSource('current')}
                    className={`px-2.5 py-1 rounded-lg font-bold text-[11px] border transition-all ${
                      dataSource === 'current'
                        ? 'bg-emerald-600 text-white border-emerald-600'
                        : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border-gray-200 dark:border-gray-700'
                    }`}
                  >
                    {t('বর্তমান অর্ডার', 'Current Order')}
                  </button>
                )}
              </div>
            </div>

            {/* Quick Category Pills Bar */}
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
              <button
                type="button"
                onClick={() => setSelectedCategoryFilter('all')}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-bold whitespace-nowrap border transition-all ${
                  selectedCategoryFilter === 'all'
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                    : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border-gray-200 dark:border-gray-700 hover:border-emerald-400'
                }`}
              >
                {t('সব ক্যাটাগরি', 'All Categories')} ({(editableItems ?? baseOrder.items).length})
              </button>
              {availableCategoriesForDropdown.map(cat => {
                const count = (editableItems ?? baseOrder.items).filter(it => it.product.category === cat.id).length;
                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setSelectedCategoryFilter(cat.id)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold whitespace-nowrap border transition-all ${
                      selectedCategoryFilter === cat.id
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                        : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border-gray-200 dark:border-gray-700 hover:border-emerald-400'
                    }`}
                  >
                    {t(cat.nameBn, cat.name)} ({count})
                  </button>
                );
              })}
            </div>

            {/* Editable Customer / Fees Inputs */}
            <div className="grid grid-cols-2 sm:grid-cols-6 gap-2">
              <input
                type="text"
                value={customCustomerName}
                onChange={(e) => setCustomCustomerName(e.target.value)}
                placeholder={t('গ্রাহকের নাম', 'Customer Name')}
                className="sm:col-span-1 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg px-2.5 py-1.5 text-xs text-gray-900 dark:text-white"
              />
              <input
                type="text"
                value={customCustomerPhone}
                onChange={(e) => setCustomCustomerPhone(e.target.value)}
                placeholder={t('মোবাইল নম্বর', 'Phone Number')}
                className="sm:col-span-1 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg px-2.5 py-1.5 text-xs text-gray-900 dark:text-white"
              />
              <input
                type="text"
                value={customAddress}
                onChange={(e) => setCustomAddress(e.target.value)}
                placeholder={t('ঠিকানা', 'Address')}
                className="sm:col-span-1 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg px-2.5 py-1.5 text-xs text-gray-900 dark:text-white"
              />
              <select
                value={customPaymentMethod}
                onChange={(e) => setCustomPaymentMethod(e.target.value as Order['paymentMethod'])}
                className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg px-2 py-1.5 text-xs text-gray-900 dark:text-white font-semibold"
              >
                <option value="cod">COD</option>
                <option value="bkash">bKash</option>
                <option value="nagad">Nagad</option>
                <option value="rocket">Rocket</option>
                <option value="bank_transfer">BD Bank</option>
                <option value="card">Card</option>
              </select>
              <div className="flex items-center gap-1 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg px-2 py-1">
                <span className="text-[10px] text-gray-400 shrink-0">{t('ডেলিভারি:', 'Ship:')}</span>
                <input
                  type="number"
                  min={0}
                  value={customDeliveryFee}
                  onChange={(e) => setCustomDeliveryFee(Math.max(0, Number(e.target.value) || 0))}
                  className="w-full bg-transparent text-xs font-bold text-gray-900 dark:text-white focus:outline-none"
                />
              </div>
              <div className="flex items-center gap-1 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg px-2 py-1">
                <span className="text-[10px] text-gray-400 shrink-0">{t('ছাড়:', 'Disc:')}</span>
                <input
                  type="number"
                  min={0}
                  value={customDiscount}
                  onChange={(e) => setCustomDiscount(Math.max(0, Number(e.target.value) || 0))}
                  className="w-full bg-transparent text-xs font-bold text-gray-900 dark:text-white focus:outline-none"
                />
              </div>
            </div>
          </div>
        )}

        {/* Scrollable Printable Document Container */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-gray-100/70 dark:bg-gray-950 flex justify-center">
          {/* THE ACTUAL CASH MEMO ELEMENT (Captured by html2canvas & printed) */}
          <div
            ref={memoRef}
            className="w-full max-w-[780px] bg-white text-gray-900 rounded-2xl shadow-xl p-6 sm:p-9 border border-gray-200 print:shadow-none print:border-none print:p-4 text-xs font-sans relative select-text h-fit"
            style={{ backgroundColor: '#ffffff', color: '#111827' }}
          >
            {/* Top Security & Watermark Stamp */}
            <div className="absolute right-8 top-28 opacity-10 pointer-events-none select-none rotate-[-15deg] border-4 border-emerald-900 rounded-3xl p-4 text-center">
              <span className="text-3xl font-black uppercase tracking-widest text-emerald-950">
                {isPaid ? 'PAID VERIFIED' : 'CASH ON DELIVERY'}
              </span>
              <p className="text-[10px] font-mono mt-1">DESHIBAZAR BANGLADESH</p>
            </div>

            {/* Header: Brand, Trade License, Hotline */}
            <div className="border-b-2 border-emerald-800 pb-4 mb-5">
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                {/* Left: Marketplace Identity */}
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <div className="w-9 h-9 rounded-xl bg-emerald-700 text-white flex items-center justify-center font-black text-xl shadow-xs">
                      দ
                    </div>
                    <div>
                      <h1 className="text-xl font-black text-emerald-800 tracking-tight leading-none">
                        দেশিবাজার <span className="text-sm font-bold text-gray-700">| DeshiBazar</span>
                      </h1>
                      <p className="text-[10px] font-semibold text-emerald-700 mt-0.5">
                        খাঁটি দেশি ও ঐতিহ্যবাহী পণ্যের বিশ্বস্ত মার্কেটপ্লেস
                      </p>
                    </div>
                  </div>
                  <div className="text-[10px] text-gray-600 pt-1 space-y-0.5">
                    <p>🏛️ সরকারি ট্রেড লাইসেন্স নং: <strong>TR-DHK-2026-98412</strong> | ই-টিআইএন: <strong>849201948219</strong></p>
                    <p>📍 প্রধান কার্যালয়: লেভেল ৪, গ্রিন টাওয়ার, সোনারগাঁও রোড, বাংলামোটর, ঢাকা-১০০০</p>
                    <p>📞 কাস্টমার কেয়ার হেল্পলাইন: <strong>+৮৮০১৭১২-০০৯৯৮৮</strong> | ✉️ support@deshibazar.com</p>
                  </div>
                </div>

                {/* Right: Memo Title & Document Serial */}
                <div className="sm:text-right space-y-1 shrink-0">
                  <div className="inline-block px-3 py-1 bg-emerald-800 text-white rounded-lg text-xs font-black uppercase tracking-wider shadow-xs">
                    {memoStyle === 'category'
                      ? 'ক্যাটাগরি ক্যাশ মেমো (CATEGORY CASH MEMO)'
                      : memoStyle === 'traditional'
                        ? 'ক্যাশ মেমো (CASH MEMO)'
                        : 'ট্যাক্স ইনভয়েস (TAX INVOICE)'}
                  </div>
                  {selectedCatMeta ? (
                    <p className="text-[11px] font-bold text-emerald-700">
                      বিভাগ: {selectedCatMeta.nameBn} ({selectedCatMeta.name})
                    </p>
                  ) : (
                    <p className="text-[11px] font-bold text-emerald-700">
                      মোট ক্যাটাগরি: {categoryGroups.length}টি বিভাগ • {activeItems.length}টি পণ্য
                    </p>
                  )}
                  <p className="text-[11px] font-mono font-bold text-gray-900 block">
                    মেমো নং: <span className="text-emerald-800">MEMO-{order.orderNumber}</span>
                  </p>
                  <p className="text-[10px] text-gray-500 font-mono">
                    অর্ডার আইডি: #{order.id}
                  </p>
                  <p className="text-[10px] text-gray-700">
                    তারিখ: <strong>{formattedDate}</strong>, {formattedTime}
                  </p>
                </div>
              </div>
            </div>

            {/* Customer & Delivery Information Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-5 p-3.5 bg-gray-50 rounded-xl border border-gray-200 text-xs">
              {/* Left Column: Customer Details */}
              <div className="space-y-1">
                <span className="text-[10px] font-black uppercase tracking-wider text-emerald-800 flex items-center gap-1">
                  <span>গ্রাহকের বিবরণ (CUSTOMER DETAILS)</span>
                </span>
                <p className="font-bold text-gray-900 text-sm">
                  {order.customerName}
                </p>
                <p className="text-gray-700">
                  মোবাইল: <strong className="font-mono text-gray-900">{order.customerPhone}</strong>
                </p>
                {order.customerEmail && (
                  <p className="text-gray-600 text-[11px]">
                    ইমেইল: {order.customerEmail}
                  </p>
                )}
                <p className="text-gray-700 text-[11px] leading-relaxed pt-0.5">
                  ডেলিভারি ঠিকানা: <strong>{order.address}</strong>, {order.upazila}, {order.district}, {order.division}
                </p>
              </div>

              {/* Right Column: Payment & Courier Details */}
              <div className="space-y-1 sm:border-l sm:border-gray-200 sm:pl-4">
                <span className="text-[10px] font-black uppercase tracking-wider text-emerald-800 flex items-center gap-1">
                  <span>পেমেন্ট ও কুরিয়ার বিবরণ (PAYMENT & DISPATCH)</span>
                </span>
                <p className="text-gray-700">
                  পেমেন্ট মাধ্যম: <strong className="text-gray-900">{getPaymentMethodLabel()}</strong>
                </p>
                {order.transactionId && (
                  <p className="text-gray-700 font-mono text-[11px]">
                    ট্রানজেকশন আইডি: <strong className="text-emerald-800">{order.transactionId}</strong>
                  </p>
                )}
                {order.bankPaymentDetails && (
                  <p className="text-gray-700 text-[11px]">
                    ব্যাংক শাখা/হিসাব: <strong>{order.bankPaymentDetails.bankName}</strong> ({order.bankPaymentDetails.accountNumber})
                  </p>
                )}
                <p className="text-gray-700">
                  ডেলিভারি কুরিয়ার: <strong>{order.courierName || 'Steadfast BD Courier'}</strong>
                </p>
                <p className="text-gray-700 font-mono text-[11px]">
                  কন্সায়নমেন্ট ট্র্যাকিং: <strong>{order.courierTrackingCode || 'ST-BD-982401'}</strong>
                </p>
                <div className="pt-1">
                  <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                    isPaid ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' : 'bg-amber-100 text-amber-800 border border-amber-300'
                  }`}>
                    {isPaid ? '✓ পরিশোধিত (PAID ONLINE)' : '⏳ ক্যাশ অন ডেলিভারি (DUE ON DELIVERY)'}
                  </span>
                </div>
              </div>
            </div>

            {/* Category-Wise or Flat Products Table */}
            {activeItems.length === 0 ? (
              <div className="mb-5 p-8 border border-dashed border-gray-300 rounded-xl text-center text-gray-500">
                {t('নির্বাচিত ক্যাটাগরিতে কোনো পণ্য পাওয়া যায়নি। অন্য ক্যাটাগরি নির্বাচন করুন।', 'No items found in the selected category filter.')}
              </div>
            ) : memoStyle === 'category' ? (
              <div className="mb-5 space-y-4">
                {categoryGroups.map((group, gIdx) => (
                  <div key={group.categoryId} className="border border-emerald-200 rounded-xl overflow-hidden">
                    {/* Category Group Header */}
                    <div className="bg-emerald-800 text-white px-3.5 py-2 flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="w-5 h-5 rounded-md bg-amber-400 text-emerald-950 font-black text-[11px] flex items-center justify-center">
                          {gIdx + 1}
                        </span>
                        <span className="font-black text-xs">
                          {group.nameBn} <span className="font-medium text-emerald-200">({group.name})</span>
                        </span>
                      </div>
                      <div className="flex items-center gap-3 text-[11px] font-bold">
                        <span className="bg-emerald-900/70 px-2 py-0.5 rounded">
                          পণ্য: {group.items.length}টি | পরিমাণ: {group.totalQty}
                        </span>
                        <span className="text-amber-300 font-mono font-black">
                          উপ-মোট: ৳{group.subtotal.toLocaleString()}
                        </span>
                      </div>
                    </div>

                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-emerald-50 text-emerald-900 text-[10px] font-extrabold border-b border-emerald-200">
                          <th className="py-1.5 px-3 text-center w-10">ক্রম</th>
                          <th className="py-1.5 px-3">পণ্যের বিবরণ (Item)</th>
                          <th className="py-1.5 px-3 text-center">উৎস / জেলা</th>
                          <th className="py-1.5 px-3 text-right">একক মূল্য</th>
                          <th className="py-1.5 px-3 text-center w-24">পরিমাণ</th>
                          <th className="py-1.5 px-3 text-right w-24">মোট টাকা</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200 text-xs text-gray-800">
                        {group.items.map((it, idx) => {
                          runningSerial += 1;
                          return (
                            <tr key={it.product.id} className={idx % 2 === 0 ? 'bg-white' : 'bg-gray-50/70'}>
                              <td className="py-2 px-3 text-center font-mono text-gray-500 font-bold">
                                {runningSerial}
                              </td>
                              <td className="py-2 px-3">
                                <span className="font-bold text-gray-900 block">
                                  {language === 'bn' ? (it.product.nameBn || it.product.name) : it.product.name}
                                </span>
                                <span className="text-[10px] text-gray-500 block">
                                  বিক্রেতা: {it.product.vendorName} • ইউনিট: {language === 'bn' ? it.product.unitBn : it.product.unit}
                                </span>
                              </td>
                              <td className="py-2 px-3 text-center text-[11px] text-gray-600">
                                {it.product.origin || it.product.vendorLocation || 'বাংলাদেশ'}
                              </td>
                              <td className="py-2 px-3 text-right font-mono font-medium">
                                ৳{it.product.price.toLocaleString()}
                              </td>
                              <td className="py-2 px-3 text-center font-mono font-bold">
                                {isCustomizerOpen ? (
                                  <div className="inline-flex items-center gap-1">
                                    <button
                                      type="button"
                                      onClick={() => updateItemQty(it.product.id, -1)}
                                      className="w-4 h-4 rounded bg-gray-200 hover:bg-gray-300 flex items-center justify-center"
                                    >
                                      <Minus className="w-2.5 h-2.5" />
                                    </button>
                                    <span className="px-1">{it.quantity}</span>
                                    <button
                                      type="button"
                                      onClick={() => updateItemQty(it.product.id, 1)}
                                      className="w-4 h-4 rounded bg-gray-200 hover:bg-gray-300 flex items-center justify-center"
                                    >
                                      <Plus className="w-2.5 h-2.5" />
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => removeItemFromMemo(it.product.id)}
                                      className="w-4 h-4 rounded text-rose-500 hover:bg-rose-50 flex items-center justify-center ml-0.5"
                                      title="Remove"
                                    >
                                      <Trash2 className="w-2.5 h-2.5" />
                                    </button>
                                  </div>
                                ) : (
                                  <span>{it.quantity}</span>
                                )}
                              </td>
                              <td className="py-2 px-3 text-right font-mono font-bold text-gray-900">
                                ৳{(it.product.price * it.quantity).toLocaleString()}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                ))}
              </div>
            ) : (
              <div className="mb-5 border border-gray-200 rounded-xl overflow-hidden">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-emerald-800 text-white text-[11px] font-bold">
                      <th className="py-2.5 px-3 text-center w-10">ক্রম</th>
                      <th className="py-2.5 px-3">পণ্যের বিবরণ ও ক্যাটাগরি (Item & Category)</th>
                      <th className="py-2.5 px-3 text-center">উৎস / জেলা</th>
                      <th className="py-2.5 px-3 text-right">একক মূল্য</th>
                      <th className="py-2.5 px-3 text-center w-16">পরিমাণ</th>
                      <th className="py-2.5 px-3 text-right w-24">মোট টাকা</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200 text-xs text-gray-800">
                    {order.items.map((it, idx) => {
                      const catMeta = categories.find(c => c.id === it.product.category);
                      return (
                        <tr key={idx} className={idx % 2 === 0 ? 'bg-white' : 'bg-gray-50/70'}>
                          <td className="py-2.5 px-3 text-center font-mono text-gray-500 font-bold">
                            {idx + 1}
                          </td>
                          <td className="py-2.5 px-3">
                            <span className="font-bold text-gray-900 block">
                              {language === 'bn' ? (it.product.nameBn || it.product.name) : it.product.name}
                            </span>
                            <span className="text-[10px] text-gray-500 block">
                              <strong className="text-emerald-700">{catMeta?.nameBn || it.product.category}</strong> • বিক্রেতা: {it.product.vendorName}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-center text-[11px] text-gray-600">
                            {it.product.origin || 'বাংলাদেশ'}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono font-medium">
                            ৳{it.product.price.toLocaleString()}
                          </td>
                          <td className="py-2.5 px-3 text-center font-mono font-bold">
                            {it.quantity}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono font-bold text-gray-900">
                            ৳{(it.product.price * it.quantity).toLocaleString()}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}

            {/* Category-Wise Financial Summary Matrix (Shown when 1+ categories present) */}
            {categoryGroups.length > 0 && (
              <div className="mb-5 p-3.5 bg-emerald-50/60 rounded-xl border border-emerald-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-black uppercase tracking-wider text-emerald-900">
                    📊 সকল ক্যাটাগরি অনুযায়ী হিসাবের সারসংক্ষেপ (Category Summary Breakdown)
                  </span>
                  <span className="text-[10px] font-bold text-emerald-700">
                    মোট {categoryGroups.length}টি ক্যাটাগরি
                  </span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px]">
                  {categoryGroups.map((g, idx) => (
                    <div
                      key={g.categoryId}
                      className="bg-white rounded-lg px-2.5 py-1.5 border border-emerald-100 flex items-center justify-between gap-2"
                    >
                      <div className="min-w-0">
                        <span className="font-bold text-gray-900 truncate block">
                          {idx + 1}. {g.nameBn}
                        </span>
                        <span className="text-[9px] text-gray-500">
                          {g.items.length} আইটেম ({g.totalQty} পিস)
                        </span>
                      </div>
                      <span className="font-mono font-black text-emerald-800 shrink-0">
                        ৳{g.subtotal.toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Calculations & Totals Summary */}
            <div className="flex flex-col sm:flex-row justify-between gap-6 mb-6">
              {/* Left Side: QR Code, Official Seal & Barcode */}
              <div className="sm:max-w-xs space-y-2.5">
                <div className="flex items-center gap-3 p-2.5 bg-gray-50 rounded-xl border border-gray-200">
                  <div className="w-16 h-16 bg-white border border-gray-300 rounded-lg p-1 flex items-center justify-center shrink-0">
                    <svg viewBox="0 0 100 100" className="w-full h-full text-gray-900">
                      <rect width="100" height="100" fill="#ffffff" />
                      <rect x="10" y="10" width="25" height="25" fill="#065f46" />
                      <rect x="15" y="15" width="15" height="15" fill="#ffffff" />
                      <rect x="18" y="18" width="9" height="9" fill="#065f46" />
                      <rect x="65" y="10" width="25" height="25" fill="#065f46" />
                      <rect x="70" y="15" width="15" height="15" fill="#ffffff" />
                      <rect x="73" y="18" width="9" height="9" fill="#065f46" />
                      <rect x="10" y="65" width="25" height="25" fill="#065f46" />
                      <rect x="15" y="70" width="15" height="15" fill="#ffffff" />
                      <rect x="18" y="73" width="9" height="9" fill="#065f46" />
                      <rect x="42" y="15" width="6" height="6" fill="#065f46" />
                      <rect x="52" y="25" width="6" height="6" fill="#065f46" />
                      <rect x="42" y="42" width="16" height="16" fill="#065f46" />
                      <rect x="65" y="55" width="8" height="8" fill="#065f46" />
                      <rect x="75" y="75" width="15" height="15" fill="#065f46" />
                    </svg>
                  </div>
                  <div className="text-[10px] text-gray-600 leading-tight">
                    <p className="font-bold text-emerald-800">অফিসিয়াল ডিজিটাল ভেরিফিকেশন</p>
                    <p className="mt-0.5">ক্যামেরা বা কিউআর স্ক্যানার দিয়ে স্ক্যান করে এই অর্ডারের সত্যতা নিশ্চিত করুন।</p>
                    <p className="font-mono text-gray-400 mt-0.5">SECURE-BD-AUTH-OK</p>
                  </div>
                </div>

                {/* SVG Barcode */}
                <div className="bg-white p-2 rounded-xl border border-gray-200 text-center">
                  <svg className="w-full h-8" viewBox="0 0 200 40">
                    <rect x="10" y="0" width="3" height="30" fill="#111" />
                    <rect x="16" y="0" width="2" height="30" fill="#111" />
                    <rect x="22" y="0" width="4" height="30" fill="#111" />
                    <rect x="30" y="0" width="2" height="30" fill="#111" />
                    <rect x="36" y="0" width="5" height="30" fill="#111" />
                    <rect x="45" y="0" width="2" height="30" fill="#111" />
                    <rect x="52" y="0" width="4" height="30" fill="#111" />
                    <rect x="60" y="0" width="3" height="30" fill="#111" />
                    <rect x="68" y="0" width="2" height="30" fill="#111" />
                    <rect x="74" y="0" width="4" height="30" fill="#111" />
                    <rect x="82" y="0" width="6" height="30" fill="#111" />
                    <rect x="92" y="0" width="2" height="30" fill="#111" />
                    <rect x="98" y="0" width="3" height="30" fill="#111" />
                    <rect x="105" y="0" width="5" height="30" fill="#111" />
                    <rect x="114" y="0" width="3" height="30" fill="#111" />
                    <rect x="122" y="0" width="2" height="30" fill="#111" />
                    <rect x="130" y="0" width="4" height="30" fill="#111" />
                    <rect x="138" y="0" width="5" height="30" fill="#111" />
                    <rect x="148" y="0" width="2" height="30" fill="#111" />
                    <rect x="155" y="0" width="4" height="30" fill="#111" />
                    <rect x="164" y="0" width="3" height="30" fill="#111" />
                    <rect x="172" y="0" width="2" height="30" fill="#111" />
                    <rect x="180" y="0" width="4" height="30" fill="#111" />
                    <rect x="188" y="0" width="3" height="30" fill="#111" />
                  </svg>
                  <span className="font-mono text-[9px] text-gray-500 tracking-widest block -mt-1">
                    *{order.orderNumber}*
                  </span>
                </div>
              </div>

              {/* Right Side: Totals Calculation Table */}
              <div className="sm:w-72 bg-gray-50 p-3.5 rounded-xl border border-gray-200 space-y-2 text-xs">
                <div className="flex justify-between text-gray-700">
                  <span>পণ্যের মোট মূল্য (Subtotal):</span>
                  <span className="font-mono font-bold text-gray-900">৳{order.subtotal.toLocaleString()}</span>
                </div>

                <div className="flex justify-between text-gray-700">
                  <span>ডেলিভারি চার্জ (Delivery Fee):</span>
                  <span className="font-mono font-bold text-gray-900">৳{order.deliveryFee.toLocaleString()}</span>
                </div>

                {order.discount > 0 && (
                  <div className="flex justify-between text-emerald-700">
                    <span>বিশেষ ছাড় / কুপন ({order.couponCode || 'PROMO'}):</span>
                    <span className="font-mono font-bold">-৳{order.discount.toLocaleString()}</span>
                  </div>
                )}

                <div className="border-t-2 border-emerald-800 pt-2 flex justify-between items-center text-sm">
                  <span className="font-black text-emerald-900">সর্বমোট প্রদেয় (Net Total):</span>
                  <span className="font-black font-mono text-base text-emerald-800">
                    ৳{order.total.toLocaleString()}
                  </span>
                </div>

                <div className="pt-1 text-[10px] text-gray-500 italic text-right">
                  (ভ্যাট ও সকল সরকারি ট্যাক্স অন্তর্ভুক্ত)
                </div>
              </div>
            </div>

            {/* Terms, Conditions & Return Policy */}
            <div className="p-3 bg-emerald-50/50 rounded-xl border border-emerald-200 text-[10px] text-gray-700 mb-6 space-y-1">
              <span className="font-bold text-emerald-800 block uppercase">
                শর্তাবলী ও রিটার্ন নির্দেশিকা (TERMS & RETURN POLICY):
              </span>
              <p>১. ডেলিভারি রাইডারের উপস্থিতিতে পার্সেল চেক করে গ্রহণ করুন। কোনো ক্ষতি বা অমিল থাকলে তাৎক্ষণিক জানান।</p>
              <p>২. পণ্য সংক্রান্ত যেকোনো অভিযোগ পণ্য প্রাপ্তির ৩ দিনের (৭২ ঘণ্টা) মধ্যে আমাদের হেল্পলাইনে রেকর্ড করাতে হবে।</p>
              <p>৩. ক্যাশ অন ডেলিভারির ক্ষেত্রে রাইডারকে নির্ধারিত পূর্ণ অর্থ পরিশোধ সাপেক্ষে পার্সেল হস্তান্তর করা হবে।</p>
            </div>

            {/* Signatures & Seal Section */}
            <div className="border-t border-gray-300 pt-6 mt-4 flex items-end justify-between text-xs text-gray-600">
              <div className="text-center w-40">
                <div className="border-b border-gray-400 pb-1 mb-1 font-signature text-gray-800 italic">
                  {order.customerName}
                </div>
                <span className="text-[10px] block font-semibold text-gray-500">
                  গ্রাহকের স্বাক্ষর (Customer)
                </span>
              </div>

              <div className="text-center">
                <div className="w-20 h-20 rounded-full border-2 border-dashed border-emerald-700 p-1 flex flex-col items-center justify-center text-emerald-800 text-[8px] font-black uppercase tracking-tighter leading-none shadow-xs rotate-[-8deg] mx-auto bg-emerald-50/40">
                  <ShieldCheck className="w-5 h-5 text-emerald-700 mb-0.5" />
                  <span>DESHI BAZAR</span>
                  <span className="text-[7px] text-emerald-600">AUTHENTIC BD</span>
                  <span className="mt-0.5 font-mono text-[7px]">VERIFIED 2026</span>
                </div>
                <span className="text-[9px] text-emerald-700 font-bold block mt-1">
                  ডিজিটাল মার্কেটপ্লেস সিল
                </span>
              </div>

              <div className="text-center w-44">
                <div className="border-b border-gray-400 pb-1 mb-1">
                  <span className="font-serif italic text-emerald-900 font-bold text-sm block">
                    Farhan Chowdhury
                  </span>
                </div>
                <span className="text-[10px] block font-semibold text-gray-500">
                  অনুমোদিত কর্মকর্তা (Accounts Officer)
                </span>
              </div>
            </div>

            {/* Bottom Disclaimer */}
            <div className="mt-6 pt-3 border-t border-gray-200 text-center text-[9px] text-gray-400">
              এটি একটি কম্পিউটার জেনারেটেড ডিজিটাল ক্যাশ মেমো ও ক্যাটাগরি-ভিত্তিক ট্যাক্স চালান। দেশিবাজার ই-কমার্স লিমিটেড কর্তৃক অনুমোদিত।
            </div>
          </div>
        </div>

        {/* Modal Bottom Footer Actions */}
        <div className="px-5 py-3 border-t border-gray-100 dark:border-gray-800 flex items-center justify-between bg-gray-50 dark:bg-gray-850 text-xs">
          <div className="flex items-center gap-2 text-gray-500 dark:text-gray-400">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{t('সকল ক্যাটাগরি অনুযায়ী PDF এবং ইমেজ ফাইল উভয় ফরম্যাটেই সম্পূর্ণ সাপোর্ট রয়েছে', 'Category-wise Cash Memo ready for PDF & Image export')}</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => handleDownloadImage('jpeg')}
              disabled={isExportingImage || activeItems.length === 0}
              className="px-3 py-1.5 rounded-xl border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 font-bold text-xs disabled:opacity-50"
            >
              JPG ইমেজ
            </button>
            <button
              type="button"
              onClick={handleClose}
              className="px-4 py-1.5 bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-650 text-gray-800 dark:text-gray-200 rounded-xl font-bold text-xs"
            >
              {t('বন্ধ করুন', 'Close')}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
