import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Upload, 
  Sparkles, 
  Check, 
  Image as ImageIcon, 
  Palette, 
  Layers, 
  Tag, 
  AlertCircle,
  Plus,
  Percent,
  Carrot, 
  Fish, 
  Wheat, 
  Egg, 
  Coffee, 
  Shirt, 
  Smartphone, 
  HeartHandshake, 
  Home, 
  Baby, 
  BookOpen, 
  Sprout, 
  Pill, 
  Flame, 
  Wrench, 
  Package, 
  Utensils, 
  Apple, 
  ShoppingBasket, 
  Gift, 
  Watch, 
  Scissors, 
  Shield, 
  Truck, 
  Zap, 
  Compass,
  Trophy,
  Heart
} from 'lucide-react';
import { Category } from '../types';
import { useApp } from '../context/AppContext';

export interface CategoryAdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  categoryToEdit?: Category | null;
  onSave: (categoryData: Partial<Category>) => void;
  initialTab?: 'general' | 'image' | 'style' | 'tags';
}

export const AVAILABLE_ICONS = [
  { name: 'Carrot', icon: Carrot, label: 'Vegetables' },
  { name: 'Fish', icon: Fish, label: 'Fish & Meat' },
  { name: 'Wheat', icon: Wheat, label: 'Rice & Grocery' },
  { name: 'Egg', icon: Egg, label: 'Dairy & Eggs' },
  { name: 'Coffee', icon: Coffee, label: 'Tea & Snacks' },
  { name: 'Sparkles', icon: Sparkles, label: 'Deshi Heritage' },
  { name: 'Shirt', icon: Shirt, label: 'Fashion & Wear' },
  { name: 'Smartphone', icon: Smartphone, label: 'Electronics' },
  { name: 'HeartHandshake', icon: HeartHandshake, label: 'Beauty & Care' },
  { name: 'Home', icon: Home, label: 'Home & Kitchen' },
  { name: 'Baby', icon: Baby, label: 'Baby Products' },
  { name: 'BookOpen', icon: BookOpen, label: 'Books & Stationery' },
  { name: 'Sprout', icon: Sprout, label: 'Agriculture' },
  { name: 'Palette', icon: Palette, label: 'Handicrafts' },
  { name: 'Pill', icon: Pill, label: 'Medicine & Health' },
  { name: 'Flame', icon: Flame, label: 'Pure Spices' },
  { name: 'Wrench', icon: Wrench, label: 'Hardware & Tools' },
  { name: 'Package', icon: Package, label: 'General Box' },
  { name: 'Utensils', icon: Utensils, label: 'Cookware' },
  { name: 'Apple', icon: Apple, label: 'Fresh Fruits' },
  { name: 'ShoppingBasket', icon: ShoppingBasket, label: 'Groceries' },
  { name: 'Gift', icon: Gift, label: 'Special Gifts' },
  { name: 'Watch', icon: Watch, label: 'Accessories' },
  { name: 'Scissors', icon: Scissors, label: 'Tailoring' },
  { name: 'Shield', icon: Shield, label: 'Safety & Security' },
  { name: 'Truck', icon: Truck, label: 'Fast Delivery' },
  { name: 'Zap', icon: Zap, label: 'Gadgets & Power' },
  { name: 'Tag', icon: Tag, label: 'Offers & Deals' },
  { name: 'Compass', icon: Compass, label: 'Outdoor' },
  { name: 'Trophy', icon: Trophy, label: 'Sports & Fitness' },
  { name: 'Heart', icon: Heart, label: 'Pets & Animals' }
];

export const AVAILABLE_GRADIENTS = [
  { value: 'from-emerald-500/20 to-green-500/10', label: 'Emerald Green', bgClass: 'bg-gradient-to-r from-emerald-500 to-green-500' },
  { value: 'from-blue-500/20 to-cyan-500/10', label: 'River Cyan', bgClass: 'bg-gradient-to-r from-blue-500 to-cyan-500' },
  { value: 'from-amber-500/20 to-yellow-500/10', label: 'Golden Amber', bgClass: 'bg-gradient-to-r from-amber-500 to-yellow-500' },
  { value: 'from-orange-500/20 to-amber-500/10', label: 'Warm Orange', bgClass: 'bg-gradient-to-r from-orange-500 to-amber-500' },
  { value: 'from-rose-500/20 to-red-500/10', label: 'Rose Red', bgClass: 'bg-gradient-to-r from-rose-500 to-red-500' },
  { value: 'from-emerald-600/20 to-teal-500/10', label: 'Forest Teal', bgClass: 'bg-gradient-to-r from-emerald-600 to-teal-500' },
  { value: 'from-purple-500/20 to-pink-500/10', label: 'Royal Purple', bgClass: 'bg-gradient-to-r from-purple-500 to-pink-500' },
  { value: 'from-blue-600/20 to-indigo-500/10', label: 'Deep Indigo', bgClass: 'bg-gradient-to-r from-blue-600 to-indigo-500' },
  { value: 'from-pink-500/20 to-rose-500/10', label: 'Blush Pink', bgClass: 'bg-gradient-to-r from-pink-500 to-rose-500' },
  { value: 'from-teal-500/20 to-cyan-500/10', label: 'Aqua Marine', bgClass: 'bg-gradient-to-r from-teal-500 to-cyan-500' },
  { value: 'from-sky-500/20 to-blue-500/10', label: 'Sky Blue', bgClass: 'bg-gradient-to-r from-sky-500 to-blue-500' },
  { value: 'from-indigo-500/20 to-violet-500/10', label: 'Violet Glow', bgClass: 'bg-gradient-to-r from-indigo-500 to-violet-500' },
  { value: 'from-emerald-700/20 to-lime-600/10', label: 'Lime Agriculture', bgClass: 'bg-gradient-to-r from-emerald-700 to-lime-600' },
  { value: 'from-amber-600/20 to-orange-500/10', label: 'Artisan Clay', bgClass: 'bg-gradient-to-r from-amber-600 to-orange-500' },
  { value: 'from-red-500/20 to-rose-500/10', label: 'Medical Red', bgClass: 'bg-gradient-to-r from-red-500 to-rose-500' },
  { value: 'from-orange-600/20 to-amber-600/10', label: 'Deshi Spices', bgClass: 'bg-gradient-to-r from-orange-600 to-amber-600' },
  { value: 'from-slate-600/20 to-zinc-500/10', label: 'Steel Hardware', bgClass: 'bg-gradient-to-r from-slate-600 to-zinc-500' },
  { value: 'from-fuchsia-600/20 to-purple-500/10', label: 'Magenta Silk', bgClass: 'bg-gradient-to-r from-fuchsia-600 to-purple-500' }
];

export const CURATED_IMAGE_PRESETS = [
  {
    title: 'Fresh Vegetables & Greens',
    titleBn: 'শাকসবজি ও শাক',
    url: 'https://images.unsplash.com/photo-1610832958506-aa56368176cf?auto=format&fit=crop&w=600&q=80'
  },
  {
    title: 'Fresh River Catch & Hilsa',
    titleBn: 'নদীর তাজা মাছ ও ইলিশ',
    url: 'https://images.unsplash.com/photo-1544943910-4c1dc44a0551?auto=format&fit=crop&w=600&q=80'
  },
  {
    title: 'Miniket Rice & Deshi Dal',
    titleBn: 'মিনিকেট চাল ও দেশি ডাল',
    url: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80'
  },
  {
    title: 'Pure Cow Milk & Bogura Doi',
    titleBn: 'খাঁটি গরুর দুধ ও বগুড়ার দই',
    url: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?auto=format&fit=crop&w=600&q=80'
  },
  {
    title: 'Sylhet Tea & Tea Garden',
    titleBn: 'সিলেটের চা ও চা বাগান',
    url: 'https://images.unsplash.com/photo-1579954115545-a95591f28bfc?auto=format&fit=crop&w=600&q=80'
  },
  {
    title: 'Sundarbans Natural Honey',
    titleBn: 'সুন্দরবনের প্রাকৃতিক মধু',
    url: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=600&q=80'
  },
  {
    title: 'Jamdani Saree & Handloom',
    titleBn: 'জামদানি শাড়ি ও তাঁতের পোশাক',
    url: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=600&q=80'
  },
  {
    title: 'Smart Gadgets & Electronics',
    titleBn: 'স্মার্ট ইলেকট্রনিক্স ও গ্যাজেটস',
    url: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80'
  },
  {
    title: 'Natural Herbal Cosmetics',
    titleBn: 'হার্বাল ও ন্যাচারাল কসমেটিক্স',
    url: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=600&q=80'
  },
  {
    title: 'Deshi Clay Pots & Kitchen',
    titleBn: 'মাটির তৈজসপত্র ও কিচেনওয়্যার',
    url: 'https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?auto=format&fit=crop&w=600&q=80'
  },
  {
    title: 'Baby Care & Soft Cotton',
    titleBn: 'শিশুর যত্ন ও বেবি কেয়ার',
    url: 'https://images.unsplash.com/photo-1515488042361-ee00e0ddd4e4?auto=format&fit=crop&w=600&q=80'
  },
  {
    title: 'Handmade Journals & Stationery',
    titleBn: 'হাতে তৈরি খাতা ও স্টেশনারি',
    url: 'https://images.unsplash.com/photo-1456735190827-d1262f71b8a3?auto=format&fit=crop&w=600&q=80'
  },
  {
    title: 'Organic Seeds & Farming Tools',
    titleBn: 'কৃষি বীজ ও চাষাবাদ সরঞ্জাম',
    url: 'https://images.unsplash.com/photo-1592417817098-8f3d6910985c?auto=format&fit=crop&w=600&q=80'
  },
  {
    title: 'Nakshi Kantha & Jute Crafts',
    titleBn: 'নকশী কাঁথা ও পাটের হস্তশিল্প',
    url: 'https://images.unsplash.com/photo-1606744824163-985d376605aa?auto=format&fit=crop&w=600&q=80'
  },
  {
    title: 'First Aid & Health Pharmacy',
    titleBn: 'ফার্মেসি ও ফার্স্ট এইড ওষুধ',
    url: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=600&q=80'
  },
  {
    title: 'Pure Ground Chili & Turmeric',
    titleBn: 'খাঁটি গুঁড়া মরিচ ও হলুদ মসলা',
    url: 'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=600&q=80'
  },
  {
    title: 'Heavy Duty Hardware Tools',
    titleBn: 'হার্ডওয়্যার যন্ত্রপাতি ও সামগ্রী',
    url: 'https://images.unsplash.com/photo-1581783898377-1c85bf937427?auto=format&fit=crop&w=600&q=80'
  },
  {
    title: 'Traditional Deshi Sweets',
    titleBn: 'ঐতিহ্যবাহী রসগোল্লা ও মিষ্টি',
    url: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=600&q=80'
  }
];

export const CategoryAdminModal: React.FC<CategoryAdminModalProps> = ({
  isOpen,
  onClose,
  categoryToEdit,
  onSave,
  initialTab = 'general'
}) => {
  const { t, showToast } = useApp();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [activeTab, setActiveTab] = useState<'general' | 'image' | 'style' | 'tags'>(initialTab);

  // Form State
  const [name, setName] = useState('');
  const [nameBn, setNameBn] = useState('');
  const [slug, setSlug] = useState('');
  const [image, setImage] = useState('');
  const [iconName, setIconName] = useState('Carrot');
  const [color, setColor] = useState('from-emerald-500/20 to-green-500/10');
  const [commissionRate, setCommissionRate] = useState<number>(8.5);
  const [itemCount, setItemCount] = useState<number>(0);
  const [status, setStatus] = useState<'active' | 'inactive'>('active');
  const [description, setDescription] = useState('');
  const [descriptionBn, setDescriptionBn] = useState('');
  const [popularItems, setPopularItems] = useState<string[]>([]);
  const [newTagInput, setNewTagInput] = useState('');

  // Image load error indicator
  const [imageError, setImageError] = useState(false);

  useEffect(() => {
    if (categoryToEdit) {
      setName(categoryToEdit.name || '');
      setNameBn(categoryToEdit.nameBn || '');
      setSlug(categoryToEdit.id || '');
      setImage(categoryToEdit.image || '');
      setIconName(categoryToEdit.iconName || 'Package');
      setColor(categoryToEdit.color || 'from-emerald-500/20 to-green-500/10');
      setCommissionRate(categoryToEdit.commissionRate ?? 8.5);
      setItemCount(categoryToEdit.itemCount ?? 0);
      setStatus(categoryToEdit.status || 'active');
      setDescription(categoryToEdit.description || '');
      setDescriptionBn(categoryToEdit.descriptionBn || '');
      setPopularItems(categoryToEdit.popularItems ? [...categoryToEdit.popularItems] : []);
    } else {
      // Defaults for new category
      setName('');
      setNameBn('');
      setSlug('');
      setImage(CURATED_IMAGE_PRESETS[0].url);
      setIconName('Package');
      setColor(AVAILABLE_GRADIENTS[0].value);
      setCommissionRate(8.5);
      setItemCount(0);
      setStatus('active');
      setDescription('');
      setDescriptionBn('');
      setPopularItems(['Organic', 'Fresh', 'Special']);
    }
    setActiveTab(initialTab);
    setImageError(false);
  }, [categoryToEdit, isOpen, initialTab]);

  if (!isOpen) return null;

  // Auto generate slug from English name if empty or editing new
  const handleNameChange = (val: string) => {
    setName(val);
    if (!categoryToEdit) {
      const generatedSlug = val
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '');
      setSlug(generatedSlug);
    }
  };

  // Handle local image file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      showToast(t('ছবির সাইজ সর্বোচ্চ ৫ মেগাবাইট হতে পারবে', 'Image size must be less than 5MB'), 'error');
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === 'string') {
        setImage(reader.result);
        setImageError(false);
        showToast(t('ছবি সফলভাবে নির্বাচন করা হয়েছে!', 'Image loaded successfully!'), 'success');
      }
    };
    reader.readAsDataURL(file);
  };

  // Add popular item tag
  const handleAddTag = () => {
    const trimmed = newTagInput.trim();
    if (!trimmed) return;
    if (popularItems.includes(trimmed)) {
      showToast(t('এই ট্যাগটি ইতিমধ্যে রয়েছে', 'Tag already exists'), 'info');
      return;
    }
    setPopularItems([...popularItems, trimmed]);
    setNewTagInput('');
  };

  // Remove tag
  const handleRemoveTag = (indexToRemove: number) => {
    setPopularItems(popularItems.filter((_, idx) => idx !== indexToRemove));
  };

  // Submit Handler
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!name.trim()) {
      showToast(t('দয়া করে ক্যাটাগরির ইংরেজি নাম দিন', 'Please enter Category English name'), 'error');
      setActiveTab('general');
      return;
    }

    if (!image.trim()) {
      showToast(t('দয়া করে ক্যাটাগরির জন্য একটি ছবি দিন বা সিলেক্ট করুন', 'Please provide or select an image for this category'), 'error');
      setActiveTab('image');
      return;
    }

    const categoryData: Partial<Category> = {
      name: name.trim(),
      nameBn: nameBn.trim() || name.trim(),
      id: slug.trim() || name.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
      image: image.trim(),
      iconName: iconName || 'Package',
      color: color || 'from-emerald-500/20 to-green-500/10',
      commissionRate: Number(commissionRate) || 8.5,
      itemCount: Number(itemCount) || 0,
      status,
      description: description.trim(),
      descriptionBn: descriptionBn.trim(),
      popularItems
    };

    onSave(categoryData);
    onClose();
  };

  // Icon preview component
  const CurrentSelectedIcon = AVAILABLE_ICONS.find(i => i.name === iconName)?.icon || Package;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-sm animate-fadeIn overflow-y-auto">
      <div 
        className="bg-white dark:bg-gray-800 rounded-3xl w-full max-w-3xl shadow-2xl border border-gray-100 dark:border-gray-700 overflow-hidden flex flex-col max-h-[92vh] my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/15 backdrop-blur-md flex items-center justify-center border border-white/20">
              <CurrentSelectedIcon className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black tracking-tight">
                {categoryToEdit 
                  ? t(`ক্যাটাগরি সম্পাদনা: ${categoryToEdit.nameBn || categoryToEdit.name}`, `Edit Category: ${categoryToEdit.name}`)
                  : t('নতুন পণ্য ক্যাটাগরি তৈরি করুন', 'Create New Product Category')
                }
              </h2>
              <p className="text-xs text-emerald-100 font-medium">
                {t('ছবি, কালার প্যালেট, আইকন এবং কমিশন রেট কাস্টমাইজ করুন', 'Customize category image, styling, icon, and commission')}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-gray-200 dark:border-gray-700 px-6 bg-gray-50/70 dark:bg-gray-800/70 shrink-0 overflow-x-auto gap-2 py-2">
          <button
            type="button"
            onClick={() => setActiveTab('general')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'general'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>{t('১. সাধারণ তথ্য', '1. General Info')}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('image')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'image'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
            }`}
          >
            <ImageIcon className="w-3.5 h-3.5" />
            <span>{t('২. ছবি ও ব্যানার', '2. Image & Cover')}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('style')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'style'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
            }`}
          >
            <Palette className="w-3.5 h-3.5" />
            <span>{t('৩. কালার ও আইকন', '3. Color & Icon')}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('tags')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'tags'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
            }`}
          >
            <Tag className="w-3.5 h-3.5" />
            <span>{t('৪. জনপ্রিয় ট্যাগ', '4. Popular Items')}</span>
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* TAB 1: GENERAL INFO */}
          {activeTab === 'general' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                    {t('ক্যাটাগরির নাম (English) *', 'Category Name (English) *')}
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => handleNameChange(e.target.value)}
                    placeholder="e.g. Traditional Handloom"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white text-xs font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                    {t('ক্যাটাগরির নাম (বাংলা) *', 'Category Name (Bengali) *')}
                  </label>
                  <input
                    type="text"
                    required
                    value={nameBn}
                    onChange={(e) => setNameBn(e.target.value)}
                    placeholder="যেমন: ঐতিহ্যবাহী তাঁতের পোশাক"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white text-xs font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                    {t('ইউনিক স্ল্যাগ / আইডি (ID)', 'Unique Slug / ID')}
                  </label>
                  <input
                    type="text"
                    value={slug}
                    onChange={(e) => setSlug(e.target.value.toLowerCase().replace(/[^a-z0-9_-]/g, ''))}
                    placeholder="e.g. traditional-handloom"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white text-xs font-mono font-bold focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                  <span className="text-[10px] text-gray-400 mt-1 block">URL: /category/{slug || '...'}</span>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                    {t('মার্কেটপ্লেস কমিশন রেট (%)', 'Commission Rate (%)')}
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      step="0.1"
                      min="0"
                      max="50"
                      value={commissionRate}
                      onChange={(e) => setCommissionRate(parseFloat(e.target.value) || 0)}
                      className="w-full pl-3.5 pr-8 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white text-xs font-bold focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    />
                    <Percent className="w-3.5 h-3.5 text-gray-400 absolute right-3 top-3" />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                    {t('স্ট্যাটাস (Status)', 'Status')}
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as 'active' | 'inactive')}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white text-xs font-bold focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  >
                    <option value="active">🟢 {t('অ্যাক্টিভ (সক্রিয়)', 'Active (Visible)')}</option>
                    <option value="inactive">🔴 {t('ইনঅ্যাক্টিভ (লুকানো)', 'Inactive (Hidden)')}</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                  {t('সংক্ষিপ্ত বিবরণ (Description)', 'Description')}
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <textarea
                    rows={2}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Short summary in English..."
                    className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white text-xs font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                  <textarea
                    rows={2}
                    value={descriptionBn}
                    onChange={(e) => setDescriptionBn(e.target.value)}
                    placeholder="বাংলায় সংক্ষিপ্ত বিবরণ..."
                    className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white text-xs font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Live Preview Card */}
              <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-900/60 border border-gray-100 dark:border-gray-800">
                <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider block mb-2">
                  {t('লাইভ প্রিভিউ (Live Card Preview)', 'Live Card Preview')}
                </span>
                <div className="flex items-center gap-3.5 p-3 rounded-xl bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 shadow-xs max-w-md">
                  <div className="relative w-14 h-14 rounded-xl overflow-hidden bg-gray-100 dark:bg-gray-700 shrink-0">
                    <img 
                      src={image || 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80'} 
                      alt="Preview" 
                      className="w-full h-full object-cover" 
                    />
                    <div className="absolute top-1 left-1 w-6 h-6 rounded-md bg-white/90 dark:bg-gray-800/90 flex items-center justify-center shadow-xs">
                      <CurrentSelectedIcon className="w-3.5 h-3.5 text-emerald-600" />
                    </div>
                  </div>
                  <div className="min-w-0 flex-1">
                    <h4 className="text-xs font-bold text-gray-900 dark:text-white truncate">
                      {name || 'Category Name'}
                    </h4>
                    <p className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 truncate">
                      {nameBn || 'ক্যাটাগরির নাম'}
                    </p>
                    <span className="text-[10px] text-gray-400 block mt-0.5">
                      {itemCount} {t('পণ্য', 'items')} • {commissionRate}% {t('কমিশন', 'Comm.')}
                    </span>
                  </div>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    status === 'active' 
                      ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300' 
                      : 'bg-red-100 dark:bg-red-950 text-red-700 dark:text-red-300'
                  }`}>
                    {status === 'active' ? 'Active' : 'Inactive'}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: IMAGE EDIT & SELECTION */}
          {activeTab === 'image' && (
            <div className="space-y-5">
              <div className="flex flex-col md:flex-row gap-5">
                {/* Image Preview Box */}
                <div className="w-full md:w-56 shrink-0 flex flex-col items-center">
                  <div className="relative w-full aspect-square rounded-2xl overflow-hidden bg-gray-100 dark:bg-gray-900 border-2 border-dashed border-gray-200 dark:border-gray-700 shadow-inner group">
                    <img
                      src={image || 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80'}
                      alt="Category Preview"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      onError={() => setImageError(true)}
                    />
                    {imageError && (
                      <div className="absolute inset-0 bg-red-900/80 text-white flex flex-col items-center justify-center p-3 text-center text-xs">
                        <AlertCircle className="w-6 h-6 mb-1 text-red-300" />
                        <span>{t('ছবি লোড করা যায়নি', 'Image URL failed to load')}</span>
                      </div>
                    )}
                    <div className="absolute bottom-2 right-2 px-2 py-1 rounded-lg bg-black/60 backdrop-blur-xs text-white text-[10px] font-bold flex items-center gap-1">
                      <ImageIcon className="w-3 h-3" />
                      <span>{t('প্রিভিউ', 'Preview')}</span>
                    </div>
                  </div>

                  <input
                    type="file"
                    ref={fileInputRef}
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="mt-3 w-full py-2.5 px-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 text-emerald-700 dark:text-emerald-300 text-xs font-bold flex items-center justify-center gap-2 border border-emerald-200 dark:border-emerald-800 transition-colors"
                  >
                    <Upload className="w-4 h-4" />
                    <span>{t('ডিভাইস থেকে আপলোড', 'Upload from Device')}</span>
                  </button>
                </div>

                {/* Image URL & Quick Actions */}
                <div className="flex-1 space-y-3.5">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                      {t('ছবির ওয়েব লিংক (Image URL)', 'Image Web URL')}
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="url"
                        value={image}
                        onChange={(e) => {
                          setImage(e.target.value);
                          setImageError(false);
                        }}
                        placeholder="https://images.unsplash.com/..."
                        className="flex-1 px-3.5 py-2 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white text-xs font-mono focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                      />
                      <button
                        type="button"
                        onClick={() => setImage('')}
                        className="px-3 py-2 rounded-xl bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 text-gray-600 dark:text-gray-300 text-xs font-bold"
                      >
                        {t('ক্লিয়ার', 'Clear')}
                      </button>
                    </div>
                    <span className="text-[11px] text-gray-400 mt-1 block">
                      {t('সরাসরি যেকোনো ইমেজ লিংক পেস্ট করতে পারেন অথবা নিচের প্রি-সেট থেকে বেছে নিন।', 'Paste any direct high-res image URL or select from our curated presets below.')}
                    </span>
                  </div>

                  {/* Curated Presets Header */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-gray-700 dark:text-gray-300 flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                        <span>{t('দেশি পণ্যের নির্বাচিত ছবির গ্যালারি (Curated Bangladeshi Presets)', 'Curated High-Res Deshi Presets')}</span>
                      </span>
                    </div>

                    {/* Presets Grid */}
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-h-56 overflow-y-auto pr-1">
                      {CURATED_IMAGE_PRESETS.map((preset, idx) => {
                        const isSelected = image === preset.url;
                        return (
                          <div
                            key={idx}
                            onClick={() => {
                              setImage(preset.url);
                              setImageError(false);
                            }}
                            className={`group relative rounded-xl overflow-hidden cursor-pointer border-2 transition-all p-1 bg-gray-50 dark:bg-gray-900 ${
                              isSelected 
                                ? 'border-emerald-500 ring-2 ring-emerald-500/20 shadow-sm' 
                                : 'border-transparent hover:border-gray-300 dark:hover:border-gray-600'
                            }`}
                          >
                            <div className="w-full h-16 rounded-lg overflow-hidden bg-gray-200 dark:bg-gray-800">
                              <img src={preset.url} alt={preset.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                            </div>
                            <span className="block text-[10px] font-bold text-gray-800 dark:text-gray-200 mt-1 truncate">
                              {preset.titleBn}
                            </span>
                            {isSelected && (
                              <div className="absolute top-2 right-2 w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center shadow-xs">
                                <Check className="w-3 h-3" />
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: COLOR & ICON */}
          {activeTab === 'style' && (
            <div className="space-y-6">
              {/* Icon Picker */}
              <div>
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-2">
                  {t('ক্যাটাগরির আইকন নির্বাচন করুন (Choose Category Icon)', 'Choose Category Icon')}
                </label>
                <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-6 gap-2 max-h-56 overflow-y-auto pr-1">
                  {AVAILABLE_ICONS.map((item) => {
                    const IconComp = item.icon;
                    const isSelected = iconName === item.name;
                    return (
                      <button
                        key={item.name}
                        type="button"
                        onClick={() => setIconName(item.name)}
                        className={`p-2.5 rounded-xl border flex flex-col items-center gap-1.5 transition-all ${
                          isSelected
                            ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-500 text-emerald-700 dark:text-emerald-300 shadow-xs ring-1 ring-emerald-500'
                            : 'bg-white dark:bg-gray-800/80 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:border-emerald-300'
                        }`}
                      >
                        <IconComp className="w-5 h-5" />
                        <span className="text-[10px] font-semibold truncate max-w-full">{item.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Color Gradient Picker */}
              <div>
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-2">
                  {t('থিম কালার গ্রেডিয়েন্ট (Theme Gradient & Accent)', 'Theme Gradient & Accent')}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-h-52 overflow-y-auto pr-1">
                  {AVAILABLE_GRADIENTS.map((grad) => {
                    const isSelected = color === grad.value;
                    return (
                      <button
                        key={grad.value}
                        type="button"
                        onClick={() => setColor(grad.value)}
                        className={`p-2 rounded-xl border flex items-center gap-2.5 transition-all text-left ${
                          isSelected
                            ? 'border-emerald-500 ring-2 ring-emerald-500/20 bg-gray-50 dark:bg-gray-800'
                            : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 bg-white dark:bg-gray-900'
                        }`}
                      >
                        <div className={`w-6 h-6 rounded-lg ${grad.bgClass} shrink-0 shadow-inner`} />
                        <span className="text-xs font-bold text-gray-800 dark:text-gray-200 truncate flex-1">
                          {grad.label}
                        </span>
                        {isSelected && <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: POPULAR ITEMS & TAGS */}
          {activeTab === 'tags' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                  {t('নতুন জনপ্রিয় পণ্য / ট্যাগ যোগ করুন', 'Add Popular Item Tag')}
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newTagInput}
                    onChange={(e) => setNewTagInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddTag();
                      }
                    }}
                    placeholder="যেমন: পদ্মা ইলিশ, খাঁটি ঘি, বাসমতী চাল..."
                    className="flex-1 px-3.5 py-2 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white text-xs font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={handleAddTag}
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 transition-colors shadow-xs"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{t('যোগ করুন', 'Add Tag')}</span>
                  </button>
                </div>
                <span className="text-[11px] text-gray-400 mt-1 block">
                  {t('এই ট্যাগগুলো ক্যাটাগরি কার্ড এবং সার্চ বারে সাজেশনে প্রদর্শিত হবে।', 'These search tags appear as quick suggestions on category cards and the search bar.')}
                </span>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-2">
                  {t(`বর্তমান ট্যাগসমূহ (${popularItems.length}টি)`, `Current Tags (${popularItems.length})`)}
                </label>
                {popularItems.length === 0 ? (
                  <p className="text-xs text-gray-400 italic">
                    {t('কোনো ট্যাগ নেই। উপরে ইনপুট দিয়ে যোগ করুন।', 'No tags added yet. Type above to add tags.')}
                  </p>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {popularItems.map((tagItem, idx) => (
                      <span
                        key={idx}
                        className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 text-xs font-bold"
                      >
                        <span>{tagItem}</span>
                        <button
                          type="button"
                          onClick={() => handleRemoveTag(idx)}
                          className="hover:text-red-500 rounded-full transition-colors"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Form Actions Footer */}
          <div className="pt-4 border-t border-gray-200 dark:border-gray-700 flex items-center justify-between gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 text-xs font-bold transition-colors"
            >
              {t('বাতিল', 'Cancel')}
            </button>

            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white text-xs font-bold shadow-md shadow-emerald-600/20 flex items-center gap-2 transition-all"
            >
              <Check className="w-4 h-4" />
              <span>
                {categoryToEdit 
                  ? t('পরিবর্তন সংরক্ষণ করুন', 'Save Category Changes')
                  : t('নতুন ক্যাটাগরি তৈরি করুন', 'Create Category')
                }
              </span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
