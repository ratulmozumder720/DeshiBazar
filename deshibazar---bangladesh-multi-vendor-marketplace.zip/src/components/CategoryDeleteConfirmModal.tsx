import React from 'react';
import { AlertTriangle, Trash2, X, Package } from 'lucide-react';
import { Category } from '../types';
import { useApp } from '../context/AppContext';

interface CategoryDeleteConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  category: Category | null;
  onConfirmDelete: (categoryId: string) => void;
  associatedProductsCount: number;
}

export const CategoryDeleteConfirmModal: React.FC<CategoryDeleteConfirmModalProps> = ({
  isOpen,
  onClose,
  category,
  onConfirmDelete,
  associatedProductsCount
}) => {
  const { t } = useApp();

  if (!isOpen || !category) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
      <div 
        className="bg-white dark:bg-gray-800 rounded-3xl max-w-md w-full p-6 border border-gray-100 dark:border-gray-700 shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-red-100 dark:bg-red-950/60 text-red-600 dark:text-red-400 flex items-center justify-center shrink-0">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-500 hover:text-gray-900 dark:hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <h3 className="text-lg font-black text-gray-900 dark:text-white mb-2">
          {t('ক্যাটাগরি মুছে ফেলতে চান?', 'Delete this Category?')}
        </h3>

        <p className="text-xs text-gray-500 dark:text-gray-400 mb-4 leading-relaxed">
          {t(
            `আপনি "${category.nameBn || category.name}" (${category.name}) ক্যাটাগরিটি মুছে ফেলতে যাচ্ছেন।`,
            `You are about to delete the category "${category.name}" (${category.nameBn}).`
          )}
        </p>

        {/* Category Card Preview */}
        <div className="flex items-center gap-3 p-3 rounded-2xl bg-gray-50 dark:bg-gray-750 border border-gray-100 dark:border-gray-700 mb-4">
          <img 
            src={category.image} 
            alt={category.name} 
            className="w-12 h-12 rounded-xl object-cover shrink-0" 
          />
          <div className="min-w-0 flex-1">
            <h4 className="text-xs font-bold text-gray-900 dark:text-white truncate">{category.name}</h4>
            <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold block">{category.nameBn}</span>
            <span className="text-[10px] text-gray-400 font-mono">ID: {category.id}</span>
          </div>
        </div>

        {/* Warning if products exist */}
        {associatedProductsCount > 0 ? (
          <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-200 text-xs mb-5 flex items-start gap-2.5">
            <Package className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold block">
                {t(`সতর্কতা: ${associatedProductsCount}টি পণ্য এই ক্যাটাগরিতে তালিকাভুক্ত আছে!`, `Warning: ${associatedProductsCount} items are linked to this category!`)}
              </span>
              <span className="text-[11px] mt-0.5 block opacity-90">
                {t('ক্যাটাগরি মুছে ফেললেও পণ্যগুলো মার্কেটপ্লেস ডাটাবেজে সংরক্ষিত থাকবে।', 'Deleting this category will un-categorize these items, but they will remain in the database.')}
              </span>
            </div>
          </div>
        ) : (
          <p className="text-[11px] text-gray-400 mb-5">
            {t('এই ক্যাটাগরিতে কোনো পণ্য নেই, নিরাপদে মুছে ফেলা যাবে।', 'No products currently catalogued under this category. Safe to delete.')}
          </p>
        )}

        <div className="flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 text-xs font-bold transition-colors"
          >
            {t('না, বাতিল', 'No, Cancel')}
          </button>
          <button
            type="button"
            onClick={() => {
              onConfirmDelete(category.id);
              onClose();
            }}
            className="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold flex items-center gap-1.5 transition-colors shadow-md shadow-red-600/20"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>{t('হ্যাঁ, মুছে ফেলুন', 'Yes, Delete Category')}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
