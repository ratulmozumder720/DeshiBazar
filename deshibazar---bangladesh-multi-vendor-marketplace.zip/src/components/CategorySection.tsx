import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  ChevronRight, 
  ArrowRight, 
  Carrot, 
  Fish, 
  Wheat, 
  Egg, 
  Coffee, 
  Sparkles, 
  Shirt, 
  Smartphone, 
  HeartHandshake, 
  Home, 
  Baby, 
  BookOpen, 
  Sprout, 
  Palette, 
  Pill, 
  Flame,
  Wrench,
  Layers,
  ShoppingBag,
  Trophy,
  Heart,
  Receipt
} from 'lucide-react';
import { Category } from '../types';

export const CategorySection: React.FC = () => {
  const { t, categories, setSelectedCategory, setSelectedSellerId, setCurrentView, openCategoryCashMemo } = useApp();
  const [activeFilter, setActiveFilter] = useState<'all' | 'food' | 'lifestyle' | 'essentials'>('all');

  const handleCategoryClick = (catId: string) => {
    setSelectedCategory(catId);
    setSelectedSellerId(null);
    setCurrentView('shop');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Helper to render distinct icons with matching palette
  const getCategoryIcon = (id: string, iconName?: string) => {
    const key = (iconName || id).toLowerCase();
    if (key.includes('trophy') || key.includes('sport') || id === 'sports-fitness') return <Trophy className="w-5 h-5 text-teal-600 dark:text-teal-400" />;
    if (key.includes('heart') || key.includes('pet') || id === 'pet-supplies') return <Heart className="w-5 h-5 text-amber-600 dark:text-amber-400" />;
    if (key.includes('carrot') || id === 'fruits-vegetables') return <Carrot className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />;
    if (key.includes('fish') || id === 'fish-meat') return <Fish className="w-5 h-5 text-blue-600 dark:text-blue-400" />;
    if (key.includes('wheat') || id === 'rice-dal-grocery') return <Wheat className="w-5 h-5 text-amber-600 dark:text-amber-400" />;
    if (key.includes('egg') || id === 'dairy-eggs') return <Egg className="w-5 h-5 text-orange-600 dark:text-orange-400" />;
    if (key.includes('coffee') || id === 'snacks-beverages') return <Coffee className="w-5 h-5 text-rose-600 dark:text-rose-400" />;
    if (key.includes('sparkle') || id === 'deshi-products') return <Sparkles className="w-5 h-5 text-amber-500 dark:text-amber-300" />;
    if (key.includes('shirt') || id === 'fashion') return <Shirt className="w-5 h-5 text-purple-600 dark:text-purple-400" />;
    if (key.includes('phone') || id === 'electronics') return <Smartphone className="w-5 h-5 text-cyan-600 dark:text-cyan-400" />;
    if (key.includes('heart') || id === 'beauty-personal-care') return <HeartHandshake className="w-5 h-5 text-pink-600 dark:text-pink-400" />;
    if (key.includes('home') || id === 'home-kitchen') return <Home className="w-5 h-5 text-teal-600 dark:text-teal-400" />;
    if (key.includes('baby') || id === 'baby-products') return <Baby className="w-5 h-5 text-sky-600 dark:text-sky-400" />;
    if (key.includes('book') || id === 'stationery') return <BookOpen className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />;
    if (key.includes('sprout') || id === 'agriculture-products') return <Sprout className="w-5 h-5 text-emerald-700 dark:text-emerald-300" />;
    if (key.includes('palette') || id === 'handmade-products') return <Palette className="w-5 h-5 text-amber-700 dark:text-amber-400" />;
    if (key.includes('pill') || id === 'madicen') return <Pill className="w-5 h-5 text-red-600 dark:text-red-400" />;
    if (key.includes('flame') || id === 'masala') return <Flame className="w-5 h-5 text-orange-600 dark:text-amber-500" />;
    if (key.includes('wrench') || id === 'hardware-accessories') return <Wrench className="w-5 h-5 text-slate-700 dark:text-slate-300" />;
    return <ShoppingBag className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />;
  };

  const getCategoryColor = (id: string) => {
    switch (id) {
      case 'fruits-vegetables':
      case 'agriculture-products':
        return 'from-emerald-500/10 to-green-500/5 group-hover:border-emerald-500/60';
      case 'sports-fitness':
        return 'from-teal-500/10 to-blue-500/5 group-hover:border-teal-500/60';
      case 'pet-supplies':
        return 'from-amber-500/10 to-orange-500/5 group-hover:border-amber-500/60';
      case 'fish-meat':
      case 'electronics':
        return 'from-blue-500/10 to-cyan-500/5 group-hover:border-blue-500/60';
      case 'rice-dal-grocery':
      case 'handmade-products':
      case 'deshi-products':
        return 'from-amber-500/10 to-yellow-500/5 group-hover:border-amber-500/60';
      case 'masala':
      case 'dairy-eggs':
        return 'from-orange-500/10 to-amber-500/5 group-hover:border-orange-500/60';
      case 'fashion':
      case 'stationery':
        return 'from-purple-500/10 to-indigo-500/5 group-hover:border-purple-500/60';
      case 'beauty-personal-care':
      case 'snacks-beverages':
        return 'from-rose-500/10 to-pink-500/5 group-hover:border-rose-500/60';
      case 'madicen':
        return 'from-red-500/10 to-rose-500/5 group-hover:border-red-500/60';
      case 'hardware-accessories':
        return 'from-slate-500/10 to-zinc-500/5 group-hover:border-slate-500/60';
      default:
        return 'from-emerald-500/10 to-teal-500/5 group-hover:border-emerald-500/60';
    }
  };

  // Filter groups
  const filteredCategories = categories.filter((cat) => {
    if (cat.status === 'inactive') return false;
    if (activeFilter === 'all') return true;
    if (activeFilter === 'food') {
      return ['fruits-vegetables', 'fish-meat', 'rice-dal-grocery', 'dairy-eggs', 'snacks-beverages', 'masala'].includes(cat.id);
    }
    if (activeFilter === 'lifestyle') {
      return ['deshi-products', 'sports-fitness', 'pet-supplies', 'fashion', 'electronics', 'beauty-personal-care', 'handmade-products', 'hardware-accessories'].includes(cat.id);
    }
    if (activeFilter === 'essentials') {
      return ['home-kitchen', 'baby-products', 'stationery', 'agriculture-products', 'madicen', 'hardware-accessories'].includes(cat.id);
    }
    return true;
  });

  const activeCategoriesCount = categories.filter(c => c.status !== 'inactive').length;

  return (
    <section className="py-14 bg-gradient-to-b from-white via-emerald-50/20 to-white dark:from-gray-900 dark:via-gray-900 dark:to-gray-900 border-b border-gray-100 dark:border-gray-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100/80 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 text-xs font-black uppercase tracking-wider mb-2 border border-emerald-200 dark:border-emerald-800/60">
              <Layers className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>{t('দেশিবাজার প্রধান বিভাগসমূহ', 'Shop By Category')}</span>
            </div>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-gray-900 dark:text-white tracking-tight">
              {t('সকল ক্যাটাগরি এক্সপ্লোর করুন', `Explore All ${activeCategoriesCount} Categories`)}
            </h2>
            <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400 mt-1 max-w-xl">
              {t(
                'তাজা শাকসবজি, মাছ-মাংস, দেশি পণ্য, হস্তশিল্প, মসলা থেকে শুরু করে ওষুধ ও কৃষি সামগ্রী—সব পাবেন এক ঠিকানায়।',
                'Fresh produce, river fish, authentic local heritage crafts, pure spices, health essentials, and agricultural supplies.'
              )}
            </p>
          </div>

          {/* Filter Pills */}
          <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 self-start md:self-end">
            <button
              onClick={() => setActiveFilter('all')}
              className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all ${
                activeFilter === 'all'
                  ? 'bg-emerald-600 text-white shadow-sm shadow-emerald-600/30'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              {t(`সকল ${activeCategoriesCount}টি বিভাগ`, `All ${activeCategoriesCount}`)}
            </button>
            <button
              onClick={() => setActiveFilter('food')}
              className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all ${
                activeFilter === 'food'
                  ? 'bg-emerald-600 text-white shadow-sm shadow-emerald-600/30'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              {t('খাদ্য ও মুদি', 'Food & Grocery')}
            </button>
            <button
              onClick={() => setActiveFilter('lifestyle')}
              className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all ${
                activeFilter === 'lifestyle'
                  ? 'bg-emerald-600 text-white shadow-sm shadow-emerald-600/30'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              {t('দেশি ফ্যাশন ও কারুশিল্প', 'Deshi & Crafts')}
            </button>
            <button
              onClick={() => setActiveFilter('essentials')}
              className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all ${
                activeFilter === 'essentials'
                  ? 'bg-emerald-600 text-white shadow-sm shadow-emerald-600/30'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              {t('স্বাস্থ্য ও প্রয়োজনীয়', 'Health & Essentials')}
            </button>

            <button
              type="button"
              onClick={() => openCategoryCashMemo('all')}
              className="px-3.5 py-1.5 rounded-full text-xs font-bold bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white shadow-sm flex items-center gap-1.5 transition-all active:scale-95"
              title={t('সকল ক্যাটাগরি অনুযায়ী ক্যাশ মেমো বা ইনভয়েজ তৈরি করুন', 'Create All-Category Cash Memo / Invoice (PDF & Image)')}
            >
              <Receipt className="w-3.5 h-3.5" />
              <span>{t('ক্যাটাগরি ক্যাশ মেমো', 'Category Cash Memo')}</span>
            </button>
          </div>
        </div>

        {/* Categories Grid: 16 visually attractive cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-4 gap-4 sm:gap-5">
          {filteredCategories.map((cat: Category) => (
            <div
              key={cat.id}
              onClick={() => handleCategoryClick(cat.id)}
              className={`group relative bg-white dark:bg-gray-800/90 rounded-3xl p-4 border border-gray-150 dark:border-gray-700/70 shadow-xs hover:shadow-xl transition-all duration-300 cursor-pointer flex flex-col justify-between overflow-hidden bg-gradient-to-br ${getCategoryColor(
                cat.id
              )}`}
            >
              {/* Image & Floating Icon */}
              <div className="relative w-full h-36 sm:h-40 rounded-2xl overflow-hidden mb-3 bg-gray-100 dark:bg-gray-700 shadow-inner">
                <img
                  src={cat.image}
                  alt={cat.name}
                  loading="lazy"
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                
                {/* Soft gradient overlay on image */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent" />

                {/* Floating category icon pill */}
                <div className="absolute top-2.5 left-2.5 w-9 h-9 rounded-xl bg-white/95 dark:bg-gray-800/95 backdrop-blur-md shadow-md flex items-center justify-center group-hover:rotate-6 transition-transform">
                  {getCategoryIcon(cat.id, cat.iconName)}
                </div>

                {/* Item Count Badge */}
                <span className="absolute bottom-2.5 left-2.5 px-2.5 py-0.5 rounded-lg bg-emerald-600/90 text-white font-mono text-[10px] font-bold tracking-wider backdrop-blur-xs shadow-xs">
                  {cat.itemCount}+ {t('পণ্য', 'Items')}
                </span>
              </div>

              {/* Title & Bangla Subtitle */}
              <div className="space-y-1">
                <h3 className="text-sm sm:text-base font-black text-gray-900 dark:text-white group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors line-clamp-1">
                  {t(cat.nameBn, cat.name)}
                </h3>
                <p className="text-[11px] text-gray-500 dark:text-gray-400 line-clamp-1 font-medium">
                  {cat.name}
                </p>
              </div>

              {/* Popular Tags Preview & Quick Category Memo */}
              <div className="mt-2.5 pt-2.5 border-t border-gray-100 dark:border-gray-700/60 flex items-center justify-between gap-1.5 text-[11px] text-gray-400">
                <span className="truncate pr-1 text-gray-500 dark:text-gray-400 font-medium">
                  {cat.popularItems && cat.popularItems.length > 0 ? cat.popularItems.slice(0, 2).join(' • ') : cat.name}
                </span>
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      openCategoryCashMemo(cat.id);
                    }}
                    className="px-2 py-1 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-300 hover:bg-indigo-600 hover:text-white text-[10px] font-bold flex items-center gap-1 transition-all"
                    title={t(`${cat.nameBn} - ক্যাশ মেমো / ইনভয়েজ`, `${cat.name} Cash Memo / Invoice`)}
                  >
                    <Receipt className="w-3 h-3" />
                    <span className="hidden sm:inline">{t('মেমো', 'Memo')}</span>
                  </button>
                  <div className="w-6 h-6 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0 group-hover:bg-emerald-600 group-hover:text-white group-hover:translate-x-0.5 transition-all">
                    <ChevronRight className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* View All Categories Directory Banner */}
        <div className="mt-10 p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-900 text-white flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl relative overflow-hidden">
          <div className="relative z-10 text-center md:text-left space-y-1">
            <span className="text-xs font-bold text-amber-300 uppercase tracking-widest block">
              {t('সবার জন্য দেশি পণ্য', 'Authentic Local Heritage')}
            </span>
            <h4 className="text-xl sm:text-2xl font-black">
              {t('সবগুলো ক্যাটাগরি ও পণ্য দেখতে চান?', 'Looking for a specific Bangladeshi product?')}
            </h4>
            <p className="text-xs sm:text-sm text-emerald-100 max-w-xl">
              {t(
                '১৭টি সুনির্দিষ্ট ক্যাটাগরি, ১০০০+ দেশি পণ্য এবং সারা বাংলাদেশে হোম ডেলিভারি সুবিধা।',
                'Explore all 17 specialized categories, trusted local vendors, and fast doorstep delivery.'
              )}
            </p>
          </div>

          <div className="relative z-10 flex flex-wrap items-center gap-3 shrink-0">
            <button
              onClick={() => {
                setSelectedCategory(null);
                setSelectedSellerId(null);
                setCurrentView('shop');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="px-5 py-3 bg-white hover:bg-gray-100 text-emerald-950 font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all active:scale-95"
            >
              {t('সব পণ্য ব্রাউজ করুন', 'Browse All Products')}
            </button>

            <button
              onClick={() => {
                setCurrentView('categories');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="px-5 py-3 bg-amber-400 hover:bg-amber-300 text-emerald-950 font-bold text-xs sm:text-sm rounded-xl shadow-md flex items-center gap-2 transition-all active:scale-95"
            >
              <span>{t('ক্যাটাগরি ডিরেক্টরি', 'Category Directory')}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Decorative ambient backdrop circles */}
          <div className="absolute -right-10 -bottom-10 w-48 h-48 bg-emerald-700/30 rounded-full blur-2xl pointer-events-none" />
          <div className="absolute -left-10 -top-10 w-48 h-48 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />
        </div>
      </div>
    </section>
  );
};
