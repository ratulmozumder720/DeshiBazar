import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Truck, 
  X, 
  Phone, 
  ExternalLink, 
  CheckCircle2, 
  MapPin, 
  ArrowRight
} from 'lucide-react';
import { BANGLADESH_COURIERS } from '../data/courierData';
import { BangladeshiCourier } from '../types';

export const CourierDirectoryModal: React.FC = () => {
  const { t, isCourierModalOpen, setIsCourierModalOpen, setCurrentView } = useApp();
  const [selectedCourierId, setSelectedCourierId] = useState<string>('steadfast');

  if (!isCourierModalOpen) return null;

  const selectedCourier = BANGLADESH_COURIERS.find((c: BangladeshiCourier) => c.id === selectedCourierId) || BANGLADESH_COURIERS[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="bg-white dark:bg-gray-800 w-full max-w-4xl rounded-3xl shadow-2xl border border-gray-100 dark:border-gray-700 overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-emerald-700 via-teal-800 to-cyan-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-white shrink-0">
              <Truck className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg sm:text-xl font-black">
                  {t('বাংলাদেশের সকল কুরিয়ার সেবা ও হাব', 'All Bangladeshi Courier Logistics')}
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-amber-400 text-emerald-950 text-[10px] font-black uppercase">
                  {BANGLADESH_COURIERS.length} Partners
                </span>
              </div>
              <p className="text-xs text-teal-100 mt-0.5">
                {t('দেশব্যাপি ৬৪ জেলা ও ৪৯৫+ উপজেলায় নির্ভরযোগ্য ডেলিভারি পার্টনার্স', 'Nationwide 64 districts & 495+ upazilas doorstep delivery network')}
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsCourierModalOpen(false)}
            className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body: Left Courier Selector, Right Details */}
        <div className="flex-1 overflow-y-auto grid grid-cols-1 md:grid-cols-12 divide-y md:divide-y-0 md:divide-x divide-gray-100 dark:divide-gray-700">
          {/* Left: List of all 8 Bangladeshi Couriers */}
          <div className="md:col-span-5 p-4 space-y-2 bg-gray-50/60 dark:bg-gray-900/40 overflow-y-auto max-h-[60vh]">
            <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider block px-2 mb-1">
              {t('কুরিয়ার নির্বাচন করুন', 'Select Courier Partner')}
            </span>

            {BANGLADESH_COURIERS.map((courier: BangladeshiCourier) => {
              const isSelected = courier.id === selectedCourierId;
              return (
                <button
                  key={courier.id}
                  onClick={() => setSelectedCourierId(courier.id)}
                  className={`w-full text-left p-3 rounded-2xl transition-all flex items-center gap-3 border ${
                    isSelected
                      ? 'bg-white dark:bg-gray-800 border-emerald-500 shadow-md shadow-emerald-500/10'
                      : 'bg-white/70 dark:bg-gray-800/70 border-gray-100 dark:border-gray-700/80 hover:bg-white dark:hover:bg-gray-800'
                  }`}
                >
                  <img
                    src={courier.logo}
                    alt={courier.name}
                    className="w-11 h-11 rounded-xl object-cover border border-gray-200 dark:border-gray-700 shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black text-gray-900 dark:text-white truncate">
                        {t(courier.nameBn, courier.name)}
                      </span>
                      {courier.isPopular && (
                        <span className="text-[9px] font-extrabold px-1.5 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 shrink-0">
                          POPULAR
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] text-gray-500 block truncate">
                      {courier.deliveryTimeInsideDhaka} (Dhaka) • {courier.deliveryTimeOutsideDhaka} (BD)
                    </span>
                    <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400">
                      ৳{courier.baseRateInsideDhaka} / ৳{courier.baseRateOutsideDhaka}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Right: Selected Courier Full Details */}
          <div className="md:col-span-7 p-6 space-y-6">
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-3">
                <img
                  src={selectedCourier.logo}
                  alt={selectedCourier.name}
                  className="w-14 h-14 rounded-2xl object-cover border-2 border-emerald-500 shadow-md"
                />
                <div>
                  <h4 className="text-base sm:text-lg font-black text-gray-900 dark:text-white">
                    {t(selectedCourier.nameBn, selectedCourier.name)}
                  </h4>
                  <p className="text-xs text-gray-500">
                    {t(selectedCourier.taglineBn, selectedCourier.tagline)}
                  </p>
                </div>
              </div>

              <a
                href={selectedCourier.trackingUrlTemplate.replace('{tracking}', '')}
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-xl bg-gray-100 dark:bg-gray-700 hover:bg-emerald-50 text-gray-600 hover:text-emerald-600 transition-colors"
                title="Official Website"
              >
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>

            {/* Rates & Speed Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div className="p-3 rounded-2xl bg-gray-50 dark:bg-gray-700/60 border border-gray-100 dark:border-gray-700">
                <span className="text-[10px] font-bold text-gray-400 uppercase block mb-1">
                  {t('ঢাকা সিটি ডেলিভারি', 'Inside Dhaka')}
                </span>
                <span className="text-xs font-black text-emerald-600 block">
                  ৳{selectedCourier.baseRateInsideDhaka} / {selectedCourier.deliveryTimeInsideDhaka}
                </span>
              </div>

              <div className="p-3 rounded-2xl bg-gray-50 dark:bg-gray-700/60 border border-gray-100 dark:border-gray-700">
                <span className="text-[10px] font-bold text-gray-400 uppercase block mb-1">
                  {t('ঢাকার বাইরে ডেলিভারি', 'Outside Dhaka')}
                </span>
                <span className="text-xs font-black text-blue-600 block">
                  ৳{selectedCourier.baseRateOutsideDhaka} / {selectedCourier.deliveryTimeOutsideDhaka}
                </span>
              </div>

              <div className="p-3 rounded-2xl bg-gray-50 dark:bg-gray-700/60 border border-gray-100 dark:border-gray-700 col-span-2 sm:col-span-1">
                <span className="text-[10px] font-bold text-gray-400 uppercase block mb-1">
                  {t('সিওডি চার্জ (COD)', 'COD Charge')}
                </span>
                <span className="text-xs font-black text-gray-900 dark:text-white block">
                  {selectedCourier.codChargePercent}% Only
                </span>
              </div>
            </div>

            {/* Coverage & Features */}
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-xs text-gray-600 dark:text-gray-300 font-semibold">
                <MapPin className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{selectedCourier.coverage}</span>
              </div>

              <div className="space-y-2 pt-1">
                <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider block">
                  {t('প্রধান সুবিধাসমূহ', 'Key Services & Highlights')}
                </span>
                {selectedCourier.featuresBn.map((feature: string, idx: number) => (
                  <div key={idx} className="flex items-center gap-2 text-xs text-gray-700 dark:text-gray-200">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>{feature}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Hotline & Live Tracking Box */}
            <div className="p-4 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
                  <Phone className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] text-gray-500 uppercase font-bold block">
                    {t('কুরিয়ার হেল্পলাইন / হটলাইন', 'Courier Hotline Call')}
                  </span>
                  <a href={`tel:${selectedCourier.hotline}`} className="text-xs font-black text-emerald-700 dark:text-emerald-300 hover:underline">
                    {selectedCourier.hotline}
                  </a>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  setIsCourierModalOpen(false);
                  setCurrentView('track-order');
                }}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shrink-0"
              >
                <span>{t('লাইভ পার্সেল ট্র্যাক করুন', 'Live Track Parcel')}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-gray-50 dark:bg-gray-800/80 border-t border-gray-100 dark:border-gray-700 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-gray-500">
          <span>
            {t(
              'দেশিবাজার থেকে সকল পণ্য এই ভেরিফাইড কুরিয়ার পার্টনারদের মাধ্যমে সুরক্ষিতভাবে পাঠানো হয়।',
              'All DeshiBazar orders are dispatched through these verified Bangladeshi courier services.'
            )}
          </span>
          <button
            onClick={() => setIsCourierModalOpen(false)}
            className="px-4 py-1.5 rounded-xl bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-200 font-bold hover:bg-gray-300"
          >
            {t('বন্ধ করুন', 'Close')}
          </button>
        </div>
      </div>
    </div>
  );
};
