import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Phone, MessageCircle, X, Headphones } from 'lucide-react';
import { DESHIBAZAR_CONTACT } from '../data/contactConfig';

export const CustomerFloatingSupport: React.FC = () => {
  const { customerUIConfig, t } = useApp();
  const [isOpen, setIsOpen] = useState(false);

  if (!customerUIConfig?.mobileShowFloatingSupport) return null;

  const phone = customerUIConfig.mobileSupportNumber || DESHIBAZAR_CONTACT.hotlineDisplay;
  const telLink = `tel:${phone.replace(/[^0-9+]/g, '')}`;
  const whatsappLink = `https://wa.me/${phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent('Hello DeshiBazar Support, I would like to inquire about products and delivery.')}`;

  return (
    <div className="fixed bottom-24 md:bottom-20 left-4 z-40 flex flex-col items-start">
      {/* Quick Menu Popup */}
      {isOpen && (
        <div className="mb-2 p-3 bg-white dark:bg-gray-800 rounded-2xl shadow-2xl border border-gray-100 dark:border-gray-700 w-56 animate-in slide-in-from-bottom-2 text-xs">
          <div className="flex items-center justify-between pb-2 border-b border-gray-100 dark:border-gray-700 mb-2">
            <span className="font-bold text-gray-900 dark:text-white flex items-center gap-1.5">
              <Headphones className="w-3.5 h-3.5 text-emerald-600" />
              <span>{t('গ্রাহক সহায়তা সেবা', 'Customer Support')}</span>
            </span>
            <button 
              onClick={() => setIsOpen(false)}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-1.5">
            {(customerUIConfig.mobileSupportType === 'both' || customerUIConfig.mobileSupportType === 'whatsapp') && (
              <a
                href={whatsappLink}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2 px-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 font-bold flex items-center gap-2 hover:bg-emerald-100 transition-colors"
              >
                <MessageCircle className="w-4 h-4 text-emerald-600" />
                <span>{t('হোয়াটসঅ্যাপ চ্যাট', 'WhatsApp Chat')}</span>
              </a>
            )}

            {(customerUIConfig.mobileSupportType === 'both' || customerUIConfig.mobileSupportType === 'call') && (
              <a
                href={telLink}
                className="w-full py-2 px-3 rounded-xl bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 font-bold flex items-center gap-2 hover:bg-blue-100 transition-colors"
              >
                <Phone className="w-4 h-4 text-blue-600" />
                <span>{t('সরাসরি ফোন কল', 'Direct Hotline Call')}</span>
              </a>
            )}
          </div>
        </div>
      )}

      {/* Floating Trigger Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="group relative flex items-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-700 text-white p-3 rounded-full shadow-lg shadow-emerald-900/20 hover:scale-105 active:scale-95 transition-all"
        title="24/7 Customer Help"
      >
        <Headphones className="w-5 h-5" />
        <span className="hidden sm:inline text-xs font-bold pr-1">
          {t('সহায়তা', 'Help')}
        </span>
        <span className="w-2.5 h-2.5 rounded-full bg-amber-400 border-2 border-white dark:border-gray-900 absolute top-0 right-0 animate-pulse" />
      </button>
    </div>
  );
};
