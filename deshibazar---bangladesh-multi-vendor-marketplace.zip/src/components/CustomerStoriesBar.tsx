import React from 'react';
import { useApp } from '../context/AppContext';
import { CustomerStoryItem } from '../types';

export const CustomerStoriesBar: React.FC = () => {
  const { t, customerUIConfig, setSelectedCategory, setCurrentView } = useApp();

  if (!customerUIConfig?.showCustomerStories) return null;

  const stories: CustomerStoryItem[] = customerUIConfig.stories || [];
  if (stories.length === 0) return null;

  const handleStoryClick = (story: CustomerStoryItem) => {
    if (story.linkCategory) {
      if (story.linkCategory === 'flash-sale') {
        setCurrentView('shop');
      } else {
        setSelectedCategory(story.linkCategory);
        setCurrentView('shop');
      }
    } else {
      setCurrentView('shop');
    }
  };

  return (
    <section className="py-3 px-4 bg-white/80 dark:bg-gray-850/80 backdrop-blur-xs border-b border-gray-100 dark:border-gray-800/80 transition-colors">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-4 overflow-x-auto pb-1 scrollbar-none py-1">
          {stories.map((story) => (
            <button
              key={story.id}
              onClick={() => handleStoryClick(story)}
              className="flex flex-col items-center gap-1.5 shrink-0 group focus:outline-hidden transition-transform active:scale-95"
            >
              {/* Circular Avatar with Gradient Ring */}
              <div className="relative p-0.5 rounded-full bg-gradient-to-tr from-amber-400 via-emerald-500 to-teal-600 group-hover:from-rose-500 group-hover:to-amber-500 transition-all shadow-xs">
                <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full overflow-hidden border-2 border-white dark:border-gray-900 bg-gray-100 dark:bg-gray-800">
                  <img
                    src={story.image}
                    alt={story.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    loading="lazy"
                  />
                </div>

                {/* Badge if any */}
                {story.badge && (
                  <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 bg-red-600 text-white text-[9px] font-black px-1.5 py-0.2 rounded-full shadow-xs whitespace-nowrap">
                    {story.badge}
                  </span>
                )}

                {/* Live Pulse Dot if isLive */}
                {story.isLive && (
                  <span className="absolute top-0 right-0 w-3 h-3 rounded-full bg-emerald-500 border-2 border-white dark:border-gray-900 animate-pulse" />
                )}
              </div>

              {/* Story Title */}
              <span className="text-[11px] font-bold text-gray-700 dark:text-gray-300 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 max-w-[70px] truncate text-center">
                {t(story.titleBn, story.title)}
              </span>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
};
