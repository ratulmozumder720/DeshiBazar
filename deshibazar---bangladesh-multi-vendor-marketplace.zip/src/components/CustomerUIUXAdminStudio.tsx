import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { CustomerUIConfig, CustomerStoryItem } from '../types';
import { DEFAULT_CUSTOMER_UI_CONFIG, CUSTOMER_UI_PRESETS } from '../data/defaultCustomerUIConfig';
import {
  Smartphone,
  Monitor,
  Sparkles,
  Layers,
  Palette,
  Eye,
  Check,
  Save,
  RotateCcw,
  Plus,
  Trash2,
  Sliders,
  ShoppingBag,
  Flame,
  Tag,
  Store,
  MessageCircle,
  Award,
  Zap,
  CheckCircle2,
  Layout
} from 'lucide-react';
import { doc, setDoc } from 'firebase/firestore';
import { db } from '../firebase';

export const CustomerUIUXAdminStudio: React.FC = () => {
  const { t, customerUIConfig, updateCustomerUIConfig, showToast } = useApp();

  // Local draft state initialized with current config
  const [draftConfig, setDraftConfig] = useState<CustomerUIConfig>(() => ({
    ...DEFAULT_CUSTOMER_UI_CONFIG,
    ...customerUIConfig
  }));

  const [activeSubTab, setActiveSubTab] = useState<'presets' | 'layout' | 'cards' | 'mobile' | 'stories' | 'brand'>('layout');
  const [previewDevice, setPreviewDevice] = useState<'mobile' | 'desktop'>('mobile');
  const [isSaving, setIsSaving] = useState(false);

  // New Story Form State
  const [newStoryTitle, setNewStoryTitle] = useState('');
  const [newStoryTitleBn, setNewStoryTitleBn] = useState('');
  const [newStoryImage, setNewStoryImage] = useState('');
  const [newStoryBadge, setNewStoryBadge] = useState('');
  const [newStoryCategory] = useState('fruits-vegetables');

  // Handle Preset Selection
  const handleApplyPreset = (presetId: string) => {
    const preset = CUSTOMER_UI_PRESETS.find(p => p.id === presetId);
    if (!preset) return;
    setDraftConfig(prev => ({
      ...prev,
      ...preset.config,
      lastUpdated: new Date().toISOString()
    }));
    showToast(t(`থিম প্রিসেট "${preset.nameBn}" প্রিভিউতে লোড হয়েছে!`, `Loaded preset "${preset.name}" into preview!`), 'info');
  };

  // Add New Story
  const handleAddStory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStoryTitle.trim()) return;

    const newStory: CustomerStoryItem = {
      id: `story-${Date.now()}`,
      title: newStoryTitle.trim(),
      titleBn: newStoryTitleBn.trim() || newStoryTitle.trim(),
      image: newStoryImage.trim() || 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=300&q=80',
      badge: newStoryBadge.trim() || undefined,
      linkCategory: newStoryCategory,
      isLive: true
    };

    setDraftConfig(prev => ({
      ...prev,
      stories: [newStory, ...(prev.stories || [])]
    }));

    setNewStoryTitle('');
    setNewStoryTitleBn('');
    setNewStoryImage('');
    setNewStoryBadge('');
    showToast(t('নতুন কাস্টমার স্টোরি যোগ করা হয়েছে!', 'Added new customer story bubble!'), 'success');
  };

  // Remove Story
  const handleRemoveStory = (storyId: string) => {
    setDraftConfig(prev => ({
      ...prev,
      stories: prev.stories.filter(s => s.id !== storyId)
    }));
    showToast(t('স্টোরি মুছে ফেলা হয়েছে', 'Story removed'), 'info');
  };

  // Save & Publish to Live Customer Web and Mobile Apps
  const handleSaveAndPublish = async () => {
    setIsSaving(true);
    try {
      const finalConfig: CustomerUIConfig = {
        ...draftConfig,
        lastUpdated: new Date().toISOString()
      };

      // 1. Update React Context state and localStorage
      updateCustomerUIConfig(finalConfig);

      // 2. Sync to Firestore settings/customer_ui for shared multi-device experience
      try {
        await setDoc(doc(db, 'settings', 'customer_ui'), finalConfig);
      } catch (err) {
        console.warn('Firestore settings sync fallback:', err);
      }

      showToast(
        t('গ্রাহক ওয়েব ও মোবাইল অ্যাপসের নতুন UI/UX ডিজাইন সফলভাবে প্রকাশিত হয়েছে!', 'Successfully published new Customer Web & App UI/UX design!'),
        'success'
      );
    } catch (err: any) {
      console.error(err);
      showToast(t('সংরক্ষণে সমস্যা হয়েছে। আবার চেষ্টা করুন।', 'Failed to publish UI settings.'), 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const handleResetDefaults = () => {
    setDraftConfig(DEFAULT_CUSTOMER_UI_CONFIG);
    showToast(t('ডিফল্ট UI/UX কনফিগারেশন সেট করা হয়েছে। সংরক্ষণের জন্য "পাবলিশ" চাপুন।', 'Defaults restored. Click Publish to save.'), 'info');
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-600 via-teal-700 to-indigo-800 rounded-3xl p-6 sm:p-8 text-white shadow-lg relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-2">
            <span className="px-3 py-1 rounded-full bg-amber-400 text-gray-950 text-xs font-black uppercase tracking-wider shadow-sm flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-gray-950" />
              <span>Customer Experience Studio</span>
            </span>
            <span className="text-xs bg-white/20 px-2.5 py-0.5 rounded-full backdrop-blur-xs font-bold">
              Web & App UI/UX
            </span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
            {t('কাস্টমার ওয়েব ও অ্যাপস আকর্ষণীয় UI/UX ডিজাইন কন্ট্রোল', 'Customer Web & Apps Attractive UI/UX Studio')}
          </h2>
          <p className="text-xs sm:text-sm text-emerald-100 mt-2 max-w-2xl leading-relaxed">
            {t(
              'গ্রাহকদের জন্য হোমপেজ সেকশন, ব্যানার, প্রোডাক্ট কার্ড স্টাইল, ইনস্টাগ্রাম স্টাইল স্টোরি ও মোবাইল অ্যাপস বটম বার কাস্টমাইজ করুন এবং লাইভ পাবলিশ করুন।',
              'Configure customer-facing homepage sections, banners, product card aesthetics, circular story highlights, and mobile bottom navigation with live real-time simulation.'
            )}
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0 relative z-10">
          <button
            onClick={handleResetDefaults}
            className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 backdrop-blur-xs"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{t('ডিফল্ট রিসেট', 'Reset')}</span>
          </button>

          <button
            onClick={handleSaveAndPublish}
            disabled={isSaving}
            className="px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-gray-950 rounded-xl text-xs font-black shadow-lg transition-all active:scale-95 flex items-center gap-2 disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            <span>{isSaving ? t('পাবলিশ হচ্ছে...', 'Publishing...') : t('লাইভ পাবলিশ করুন', 'Publish to Customer Store')}</span>
          </button>
        </div>
      </div>

      {/* Main Studio Grid: Left Controls (7 cols) + Right Live Multi-Device Simulator (5 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* LEFT COLUMN: Controls & Appearance Tabs */}
        <div className="lg:col-span-7 bg-white dark:bg-gray-800 rounded-3xl p-6 border border-gray-100 dark:border-gray-700 shadow-xs space-y-6">
          
          {/* Sub Navigation Bar */}
          <div className="flex items-center gap-1.5 p-1.5 bg-gray-100 dark:bg-gray-750 rounded-2xl overflow-x-auto scrollbar-none text-xs font-bold">
            <button
              onClick={() => setActiveSubTab('layout')}
              className={`px-3.5 py-2 rounded-xl transition-all shrink-0 flex items-center gap-1.5 ${
                activeSubTab === 'layout'
                  ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-xs'
                  : 'text-gray-600 dark:text-gray-400 hover:text-gray-900'
              }`}
            >
              <Layout className="w-4 h-4 text-emerald-600" />
              <span>{t('হোমপেজ সেকশনসমূহ', 'Sections & Order')}</span>
            </button>

            <button
              onClick={() => setActiveSubTab('cards')}
              className={`px-3.5 py-2 rounded-xl transition-all shrink-0 flex items-center gap-1.5 ${
                activeSubTab === 'cards'
                  ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-xs'
                  : 'text-gray-600 dark:text-gray-400 hover:text-gray-900'
              }`}
            >
              <ShoppingBag className="w-4 h-4 text-blue-600" />
              <span>{t('প্রোডাক্ট কার্ড স্টাইল', 'Product Cards')}</span>
            </button>

            <button
              onClick={() => setActiveSubTab('mobile')}
              className={`px-3.5 py-2 rounded-xl transition-all shrink-0 flex items-center gap-1.5 ${
                activeSubTab === 'mobile'
                  ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-xs'
                  : 'text-gray-600 dark:text-gray-400 hover:text-gray-900'
              }`}
            >
              <Smartphone className="w-4 h-4 text-purple-600" />
              <span>{t('মোবাইল ও অ্যাপস UX', 'Mobile App UX')}</span>
            </button>

            <button
              onClick={() => setActiveSubTab('stories')}
              className={`px-3.5 py-2 rounded-xl transition-all shrink-0 flex items-center gap-1.5 ${
                activeSubTab === 'stories'
                  ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-xs'
                  : 'text-gray-600 dark:text-gray-400 hover:text-gray-900'
              }`}
            >
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>{t('ইনস্টাগ্রাম স্টোরিজ', 'App Stories')}</span>
            </button>

            <button
              onClick={() => setActiveSubTab('presets')}
              className={`px-3.5 py-2 rounded-xl transition-all shrink-0 flex items-center gap-1.5 ${
                activeSubTab === 'presets'
                  ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-xs'
                  : 'text-gray-600 dark:text-gray-400 hover:text-gray-900'
              }`}
            >
              <Palette className="w-4 h-4 text-rose-600" />
              <span>{t('ডিজাইন প্রিসেট', 'Presets')}</span>
            </button>

            <button
              onClick={() => setActiveSubTab('brand')}
              className={`px-3.5 py-2 rounded-xl transition-all shrink-0 flex items-center gap-1.5 ${
                activeSubTab === 'brand'
                  ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-xs'
                  : 'text-gray-600 dark:text-gray-400 hover:text-gray-900'
              }`}
            >
              <Sliders className="w-4 h-4 text-indigo-600" />
              <span>{t('কালার ও ব্র্যান্ডিং', 'Brand & Colors')}</span>
            </button>
          </div>

          {/* TAB 1: HOMEPAGE SECTIONS & LAYOUT */}
          {activeSubTab === 'layout' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-sm font-black text-gray-900 dark:text-white flex items-center gap-2">
                  <Layout className="w-4 h-4 text-emerald-600" />
                  <span>{t('গ্রাহক হোমপেজ সেকশন টগল কন্ট্রোল', 'Customer Storefront Section Visibility')}</span>
                </h3>
                <p className="text-xs text-gray-400 mt-0.5">
                  {t('কোন কোন সেকশন গ্রাহকরা হোমপেজে দেখতে পাবেন তা নির্বাচন করুন:', 'Toggle which modules are visible to visiting customers:')}
                </p>
              </div>

              {/* Toggles Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {[
                  { key: 'showFlashSale', label: t('আজকের ফ্ল্যাশ সেল অফার', 'Flash Sale Deals'), desc: t('১২ ঘণ্টার কাউন্টডাউন টাইমার ও বিশাল ছাড়', '12-hour limited countdown & discounts'), icon: Flame, color: 'text-rose-500' },
                  { key: 'showCustomerStories', label: t('স্টোরি বাবলস স্ট্রিপ', 'Stories Highlight Bar'), desc: t('মোবাইল স্ক্রিনে গোল স্টোরি হাইলাইটস', 'Circular highlights like Instagram/Daraz'), icon: Sparkles, color: 'text-amber-500' },
                  { key: 'showDeshiSpotlight', label: t('বাংলার সেরা দেশি পণ্য স্পটলাইট', 'Deshi Heritage Spotlight'), desc: t('পদ্মার ইলিশ, সুন্দরবনের মধু ও তাঁত শাড়ি', 'Authentic regional handmade treasures'), icon: Award, color: 'text-emerald-500' },
                  { key: 'showCategoryPills', label: t('১৭টি ক্যাটাগরি পিলস স্ক্রল', 'Category Navigation Pills'), desc: t('দ্রুত স্পর্শে ক্যাটাগরি ব্রাউজ করুন', 'Touch-friendly category selector'), icon: Layers, color: 'text-blue-500' },
                  { key: 'showDailyDeals', label: t('প্রতিদিনের সেরা ডিল', 'Daily Deals'), desc: t('দৈনন্দিন বাজারের বিশেষ সাশ্রয়ী ডিল', 'Everyday grocery & household values'), icon: Tag, color: 'text-orange-500' },
                  { key: 'showLocalSellers', label: t('ভেরিফাইড আঞ্চলিক বিক্রেতা', 'Local Verified Sellers'), desc: t('কাওরান বাজার, কুমিল্লা ও টাঙ্গাইলের মার্চেন্ট', 'Top rated sellers & artisan stores'), icon: Store, color: 'text-indigo-500' },
                  { key: 'showAppDownloadBanner', label: t('অ্যাপ ও পিসি সফটওয়্যার ব্যানার', 'Mobile App Download Banner'), desc: t('Play Store, App Store ও Windows সফটওয়্যার', 'Promotes native APK, PWA & EXE downloads'), icon: Smartphone, color: 'text-purple-500' },
                  { key: 'showNewsletter', label: t('অফার এসএমএস ও নিউজলেটার', 'Newsletter & SMS Alerts'), desc: t('গ্রাহক সাবস্ক্রিপশন ও বিশেষ প্রচার', 'Special seasonal discount announcements'), icon: Zap, color: 'text-teal-500' }
                ].map((item) => {
                  const Icon = item.icon;
                  const isChecked = (draftConfig as any)[item.key];
                  return (
                    <div 
                      key={item.key}
                      onClick={() => setDraftConfig(prev => ({ ...prev, [item.key]: !isChecked }))}
                      className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                        isChecked
                          ? 'bg-emerald-50/70 dark:bg-emerald-950/30 border-emerald-300 dark:border-emerald-800'
                          : 'bg-gray-50/50 dark:bg-gray-750/30 border-gray-200 dark:border-gray-700 opacity-60'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className={`w-9 h-9 rounded-xl bg-white dark:bg-gray-800 shadow-xs flex items-center justify-center shrink-0 ${item.color}`}>
                          <Icon className="w-4 h-4" />
                        </div>
                        <div className="min-w-0">
                          <h4 className="text-xs font-bold text-gray-900 dark:text-white truncate">
                            {item.label}
                          </h4>
                          <p className="text-[10px] text-gray-500 dark:text-gray-400 truncate">
                            {item.desc}
                          </p>
                        </div>
                      </div>

                      <div className={`w-5 h-5 rounded-md flex items-center justify-center shrink-0 transition-colors ${
                        isChecked ? 'bg-emerald-600 text-white' : 'border border-gray-300 dark:border-gray-600'
                      }`}>
                        {isChecked && <Check className="w-3.5 h-3.5" />}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Announcement Bar Settings */}
              <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-750 border border-gray-200 dark:border-gray-700 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-amber-500" />
                    <span className="text-xs font-black text-gray-900 dark:text-white">
                      {t('টপ অ্যানাউন্সমেন্ট ব্যানার বার', 'Top Announcement Bar')}
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={draftConfig.showAnnouncementTicker}
                    onChange={(e) => setDraftConfig(prev => ({ ...prev, showAnnouncementTicker: e.target.checked }))}
                    className="w-4 h-4 accent-emerald-600 rounded cursor-pointer"
                  />
                </div>

                {draftConfig.showAnnouncementTicker && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    <div>
                      <label className="text-[11px] font-bold text-gray-600 dark:text-gray-400 block mb-1">
                        {t('ব্যানার বার্তা (বাংলা)', 'Ticker Message (Bangla)')}
                      </label>
                      <input
                        type="text"
                        value={draftConfig.announcementTextBn}
                        onChange={(e) => setDraftConfig(prev => ({ ...prev, announcementTextBn: e.target.value }))}
                        className="w-full px-3 py-1.5 text-xs rounded-xl border border-gray-200 dark:border-gray-650 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-bold text-gray-600 dark:text-gray-400 block mb-1">
                        {t('ব্যানার বার্তা (English)', 'Ticker Message (English)')}
                      </label>
                      <input
                        type="text"
                        value={draftConfig.announcementText}
                        onChange={(e) => setDraftConfig(prev => ({ ...prev, announcementText: e.target.value }))}
                        className="w-full px-3 py-1.5 text-xs rounded-xl border border-gray-200 dark:border-gray-650 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: PRODUCT CARD UI/UX STYLING */}
          {activeSubTab === 'cards' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-sm font-black text-gray-900 dark:text-white flex items-center gap-2">
                  <ShoppingBag className="w-4 h-4 text-blue-600" />
                  <span>{t('প্রোডাক্ট কার্ড ডিজাইন ও বাটন কনফিগারেশন', 'Product Card Aesthetic & Action UX')}</span>
                </h3>
                <p className="text-xs text-gray-400 mt-0.5">
                  {t('গ্রাহকদের জন্য প্রোডাক্ট কার্ডের ডিজাইন ও ইন্টারঅ্যাকশন মোড নির্ধারণ করুন:', 'Choose card style, badge presentation, and purchase button behavior:')}
                </p>
              </div>

              {/* Card Style Selector */}
              <div>
                <label className="text-xs font-bold text-gray-700 dark:text-gray-300 block mb-2">
                  {t('কার্ড ডিজাইন স্টাইল', 'Card Visual Layout Style')}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {[
                    { id: 'modern', name: 'Modern Soft', desc: 'Rounded-2xl, soft shadow, clean border' },
                    { id: 'minimal-border', name: 'Minimal Razor', desc: 'Crisp 2px border, zero shadow' },
                    { id: 'elevated-glow', name: 'Elevated Glow', desc: 'Deep shadow with vibrant hover ring' },
                    { id: 'supermarket-compact', name: 'Compact Grid', desc: 'High density, supermarket layout' }
                  ].map((style) => {
                    const isSelected = draftConfig.productCardStyle === style.id;
                    return (
                      <button
                        key={style.id}
                        type="button"
                        onClick={() => setDraftConfig(prev => ({ ...prev, productCardStyle: style.id as any }))}
                        className={`p-3 rounded-2xl border text-left transition-all ${
                          isSelected
                            ? 'bg-blue-50/80 dark:bg-blue-950/40 border-blue-500 ring-2 ring-blue-500/20'
                            : 'bg-gray-50/60 dark:bg-gray-750/40 border-gray-200 dark:border-gray-700 hover:border-gray-300'
                        }`}
                      >
                        <span className="text-xs font-black text-gray-900 dark:text-white block">{style.name}</span>
                        <span className="text-[10px] text-gray-500 dark:text-gray-400 block mt-0.5">{style.desc}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Card Action UX Selector */}
              <div>
                <label className="text-xs font-bold text-gray-700 dark:text-gray-300 block mb-2">
                  {t('কার্ড অ্যাকশন বাটন মোড', 'Action Button Layout')}
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  {[
                    { id: 'both-buttons', title: 'Buy Now + Add to Cart', desc: 'Highest conversion rate for Bangladeshi shoppers' },
                    { id: 'cart-only', title: 'Add to Cart Only', desc: 'Clean, standard e-commerce flow' },
                    { id: 'hover-reveal', title: 'Hover Reveal', desc: 'Buttons slide up gracefully on card hover' }
                  ].map((act) => {
                    const isSelected = draftConfig.cardActionStyle === act.id;
                    return (
                      <button
                        key={act.id}
                        type="button"
                        onClick={() => setDraftConfig(prev => ({ ...prev, cardActionStyle: act.id as any }))}
                        className={`p-3 rounded-2xl border text-left transition-all ${
                          isSelected
                            ? 'bg-emerald-50/80 dark:bg-emerald-950/40 border-emerald-500 ring-2 ring-emerald-500/20'
                            : 'bg-gray-50/60 dark:bg-gray-750/40 border-gray-200 dark:border-gray-700'
                        }`}
                      >
                        <span className="text-xs font-black text-gray-900 dark:text-white block">{act.title}</span>
                        <span className="text-[10px] text-gray-500 dark:text-gray-400 block mt-0.5">{act.desc}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Badges and Metadata Toggles */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                <label className="p-3 rounded-2xl border border-gray-200 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-750/30 flex items-center justify-between cursor-pointer">
                  <span className="text-xs font-bold text-gray-800 dark:text-gray-200">
                    {t('ছাড় পারসেন্টেজ ব্যাজ (%)', 'Discount Badge (%)')}
                  </span>
                  <input
                    type="checkbox"
                    checked={draftConfig.showDiscountPercent}
                    onChange={(e) => setDraftConfig(prev => ({ ...prev, showDiscountPercent: e.target.checked }))}
                    className="w-4 h-4 accent-emerald-600 rounded"
                  />
                </label>

                <label className="p-3 rounded-2xl border border-gray-200 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-750/30 flex items-center justify-between cursor-pointer">
                  <span className="text-xs font-bold text-gray-800 dark:text-gray-200">
                    {t('স্টার রেটিং ও রিভিউ সংখ্যা', 'Review Rating Stars')}
                  </span>
                  <input
                    type="checkbox"
                    checked={draftConfig.showRatingStars}
                    onChange={(e) => setDraftConfig(prev => ({ ...prev, showRatingStars: e.target.checked }))}
                    className="w-4 h-4 accent-emerald-600 rounded"
                  />
                </label>

                <label className="p-3 rounded-2xl border border-gray-200 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-750/30 flex items-center justify-between cursor-pointer">
                  <span className="text-xs font-bold text-gray-800 dark:text-gray-200">
                    {t('স্টক কাউন্ট ব্যাজ', 'Stock Left Count')}
                  </span>
                  <input
                    type="checkbox"
                    checked={draftConfig.showStockCount}
                    onChange={(e) => setDraftConfig(prev => ({ ...prev, showStockCount: e.target.checked }))}
                    className="w-4 h-4 accent-emerald-600 rounded"
                  />
                </label>
              </div>
            </div>
          )}

          {/* TAB 3: MOBILE APPS & PWA UX */}
          {activeSubTab === 'mobile' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-sm font-black text-gray-900 dark:text-white flex items-center gap-2">
                  <Smartphone className="w-4 h-4 text-purple-600" />
                  <span>{t('মোবাইল ও পিডব্লিউএ অ্যাপস UI/UX স্পেসিফিকেশন', 'Mobile Native & PWA UI/UX Customization')}</span>
                </h3>
                <p className="text-xs text-gray-400 mt-0.5">
                  {t('স্মার্টফোন স্ক্রিনের জন্য বটম বার ও কাস্টমার সাপোর্ট বাবল কাস্টমাইজ করুন:', 'Customize mobile bottom bar style, floating WhatsApp hotline, and location header:')}
                </p>
              </div>

              {/* Mobile Bottom Navigation Bar Style */}
              <div>
                <label className="text-xs font-bold text-gray-700 dark:text-gray-300 block mb-2">
                  {t('মোবাইল বটম বার স্টাইল', 'Mobile Bottom Bar Style')}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {[
                    { id: 'floating-pill', name: 'Floating Pill', desc: 'Detached pill floating above screen with blur' },
                    { id: 'classic-dock', name: 'Classic Dock', desc: 'Solid bottom dock with top border' },
                    { id: 'glassmorphism', name: 'Glass Blur', desc: 'Frosted transparent glass backdrop' },
                    { id: 'glow-active', name: 'Glow Accent', desc: 'Active icon glows with brand primary color' }
                  ].map((bStyle) => {
                    const isSelected = draftConfig.mobileBottomNavStyle === bStyle.id;
                    return (
                      <button
                        key={bStyle.id}
                        type="button"
                        onClick={() => setDraftConfig(prev => ({ ...prev, mobileBottomNavStyle: bStyle.id as any }))}
                        className={`p-3 rounded-2xl border text-left transition-all ${
                          isSelected
                            ? 'bg-purple-50/80 dark:bg-purple-950/40 border-purple-500 ring-2 ring-purple-500/20'
                            : 'bg-gray-50/60 dark:bg-gray-750/40 border-gray-200 dark:border-gray-700'
                        }`}
                      >
                        <span className="text-xs font-black text-gray-900 dark:text-white block">{bStyle.name}</span>
                        <span className="text-[10px] text-gray-500 dark:text-gray-400 block mt-0.5">{bStyle.desc}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Floating Customer WhatsApp / Hotline */}
              <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-750 border border-gray-200 dark:border-gray-700 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <MessageCircle className="w-4 h-4 text-emerald-600" />
                    <div>
                      <span className="text-xs font-black text-gray-900 dark:text-white block">
                        {t('মোবাইল ফ্লোটিং কাস্টমার সহায়তা বাটন', 'Floating Support Button (WhatsApp & Phone)')}
                      </span>
                      <span className="text-[10px] text-gray-400">
                        {t('গ্রাহকদের জন্য এক ক্লিকে সরাসরি যোগাযোগ উইজেট', 'Provides 1-tap WhatsApp and phone call for mobile buyers')}
                      </span>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={draftConfig.mobileShowFloatingSupport}
                    onChange={(e) => setDraftConfig(prev => ({ ...prev, mobileShowFloatingSupport: e.target.checked }))}
                    className="w-4 h-4 accent-emerald-600 rounded cursor-pointer"
                  />
                </div>

                {draftConfig.mobileShowFloatingSupport && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    <div>
                      <label className="text-[11px] font-bold text-gray-600 dark:text-gray-400 block mb-1">
                        {t('সাপোর্ট মাধ্যম', 'Contact Channels')}
                      </label>
                      <select
                        value={draftConfig.mobileSupportType}
                        onChange={(e) => setDraftConfig(prev => ({ ...prev, mobileSupportType: e.target.value as any }))}
                        className="w-full px-3 py-1.5 text-xs rounded-xl border border-gray-200 dark:border-gray-650 bg-white dark:bg-gray-800 text-gray-900 dark:text-white font-medium"
                      >
                        <option value="both">WhatsApp & Phone Hotline (Both)</option>
                        <option value="whatsapp">WhatsApp Chat Only</option>
                        <option value="call">Phone Call Only</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[11px] font-bold text-gray-600 dark:text-gray-400 block mb-1">
                        {t('সহায়তা নম্বর (WhatsApp/Hotline)', 'Support Phone Number')}
                      </label>
                      <input
                        type="text"
                        value={draftConfig.mobileSupportNumber}
                        onChange={(e) => setDraftConfig(prev => ({ ...prev, mobileSupportNumber: e.target.value }))}
                        className="w-full px-3 py-1.5 text-xs rounded-xl border border-gray-200 dark:border-gray-650 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                        placeholder="+8801700123456"
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 4: APP STORIES MANAGER */}
          {activeSubTab === 'stories' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-black text-gray-900 dark:text-white flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-amber-500" />
                    <span>{t('ইনস্টাগ্রাম স্টাইল কাস্টমার স্টোরিজ হাইলাইটস', 'Customer Stories & Flash Highlights')}</span>
                  </h3>
                  <p className="text-xs text-gray-400 mt-0.5">
                    {t('মোবাইলের শীর্ষে গোল স্টোরি বাবলস তৈরি করুন যা গ্রাহকদের নজর কাড়বে:', 'Circular highlight bubbles at the top of the mobile home feed:')}
                  </p>
                </div>
                
                <label className="flex items-center gap-2 text-xs font-bold text-gray-700 dark:text-gray-300">
                  <span>{t('স্টোরিজ সক্রিয়', 'Active')}</span>
                  <input
                    type="checkbox"
                    checked={draftConfig.showCustomerStories}
                    onChange={(e) => setDraftConfig(prev => ({ ...prev, showCustomerStories: e.target.checked }))}
                    className="w-4 h-4 accent-emerald-600 rounded"
                  />
                </label>
              </div>

              {/* Add Story Form */}
              <form onSubmit={handleAddStory} className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-750 border border-gray-200 dark:border-gray-700 space-y-3">
                <span className="text-xs font-black text-gray-900 dark:text-white block">
                  {t('+ নতুন স্টোরি হাইলাইট যোগ করুন', '+ Add New Story Bubble')}
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] font-bold text-gray-500 block mb-1">
                      {t('স্টোরি নাম (বাংলা)', 'Story Title (Bangla)')}
                    </label>
                    <input
                      type="text"
                      value={newStoryTitleBn}
                      onChange={(e) => setNewStoryTitleBn(e.target.value)}
                      placeholder="e.g. রূপালী ইলিশ"
                      className="w-full px-3 py-1.5 text-xs rounded-xl border border-gray-200 dark:border-gray-650 bg-white dark:bg-gray-800"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-gray-500 block mb-1">
                      {t('স্টোরি নাম (English)', 'Story Title (English)')}
                    </label>
                    <input
                      type="text"
                      value={newStoryTitle}
                      onChange={(e) => setNewStoryTitle(e.target.value)}
                      placeholder="e.g. Padma Hilsha"
                      required
                      className="w-full px-3 py-1.5 text-xs rounded-xl border border-gray-200 dark:border-gray-650 bg-white dark:bg-gray-800"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="sm:col-span-2">
                    <label className="text-[10px] font-bold text-gray-500 block mb-1">
                      {t('ছবি ইমেজ URL', 'Image URL')}
                    </label>
                    <input
                      type="url"
                      value={newStoryImage}
                      onChange={(e) => setNewStoryImage(e.target.value)}
                      placeholder="https://images.unsplash.com/..."
                      className="w-full px-3 py-1.5 text-xs rounded-xl border border-gray-200 dark:border-gray-650 bg-white dark:bg-gray-800"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-gray-500 block mb-1">
                      {t('ব্যাজ টেক্সট (ঐচ্ছিক)', 'Badge (Optional)')}
                    </label>
                    <input
                      type="text"
                      value={newStoryBadge}
                      onChange={(e) => setNewStoryBadge(e.target.value)}
                      placeholder="e.g. 50% OFF / Fresh"
                      className="w-full px-3 py-1.5 text-xs rounded-xl border border-gray-200 dark:border-gray-650 bg-white dark:bg-gray-800"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>{t('স্টোরি যুক্ত করুন', 'Add Story Bubble')}</span>
                </button>
              </form>

              {/* Current Stories List */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-gray-600 dark:text-gray-400 block">
                  {t(`বর্তমান স্টোরিসমূহ (${draftConfig.stories?.length || 0}টি):`, `Current Stories (${draftConfig.stories?.length || 0}):`)}
                </span>
                
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {(draftConfig.stories || []).map((story) => (
                    <div 
                      key={story.id}
                      className="p-2.5 rounded-2xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 flex items-center justify-between gap-2"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <img 
                          src={story.image} 
                          alt={story.title} 
                          className="w-8 h-8 rounded-full object-cover border border-emerald-500 shrink-0" 
                        />
                        <div className="min-w-0">
                          <span className="text-xs font-bold text-gray-900 dark:text-white block truncate">
                            {t(story.titleBn, story.title)}
                          </span>
                          {story.badge && (
                            <span className="text-[9px] px-1 py-0.2 bg-red-100 text-red-600 rounded font-black inline-block">
                              {story.badge}
                            </span>
                          )}
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleRemoveStory(story.id)}
                        className="text-gray-400 hover:text-red-500 p-1"
                        title="Remove Story"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: 1-CLICK PRESETS */}
          {activeSubTab === 'presets' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-black text-gray-900 dark:text-white flex items-center gap-2">
                  <Palette className="w-4 h-4 text-rose-600" />
                  <span>{t('রেডিমেড আকর্ষণীয় প্রিসেট প্যাকস (১ ক্লিকে প্রয়োগ)', 'Instant Curated Customer Experience Packs')}</span>
                </h3>
                <p className="text-xs text-gray-400 mt-0.5">
                  {t('যেকোনো একটি প্রিসেট নির্বাচন করে তাৎক্ষণিকভাবে গ্রাহক সাইটে প্রয়োগ করতে পারবেন:', 'Select any pre-tuned storefront pack designed for maximum conversion:')}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {CUSTOMER_UI_PRESETS.map((preset) => (
                  <div
                    key={preset.id}
                    onClick={() => handleApplyPreset(preset.id)}
                    className="p-4 rounded-2xl border border-gray-200 dark:border-gray-700 hover:border-emerald-500 bg-white dark:bg-gray-800 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-black text-gray-900 dark:text-white">
                          {t(preset.nameBn, preset.name)}
                        </span>
                        <div className="flex -space-x-1">
                          <span 
                            className="w-4 h-4 rounded-full border border-white"
                            style={{ backgroundColor: preset.config.primaryColor }} 
                          />
                          <span 
                            className="w-4 h-4 rounded-full border border-white"
                            style={{ backgroundColor: preset.config.accentColor }} 
                          />
                        </div>
                      </div>
                      <p className="text-[11px] text-gray-500 dark:text-gray-400">
                        {t(preset.descriptionBn, preset.description)}
                      </p>
                    </div>

                    <button
                      type="button"
                      className="mt-3 w-full py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 font-bold text-xs hover:bg-emerald-100 transition-colors"
                    >
                      {t('প্রিভিউতে লোড করুন →', 'Load into Preview →')}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 6: BRANDING, COLORS & TYPOGRAPHY */}
          {activeSubTab === 'brand' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-sm font-black text-gray-900 dark:text-white flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-indigo-600" />
                  <span>{t('ব্র্যান্ড আইডেন্টিটি, কালার ও টাইপোগ্রাফি', 'Brand Identity, Colors & Typography')}</span>
                </h3>
                <p className="text-xs text-gray-400 mt-0.5">
                  {t('গ্রাহকদের চোখে স্টোরের সার্বিক নান্দনিকতা, ফন্ট ও কালার প্যালেট নিয়ন্ত্রণ করুন:', 'Customize brand personality, color palettes, fonts and corner rounding:')}
                </p>
              </div>

              {/* Store Name & Tagline */}
              <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-750 border border-gray-200 dark:border-gray-700 space-y-3">
                <span className="text-xs font-black text-gray-900 dark:text-white block">
                  {t('স্টোরের নাম ও স্লোগান', 'Store Branding & Taglines')}
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-gray-600 dark:text-gray-400 block mb-1">
                      {t('দোকানের নাম (বাংলা)', 'Store Name (Bangla)')}
                    </label>
                    <input
                      type="text"
                      value={draftConfig.storeNameBn}
                      onChange={(e) => setDraftConfig(prev => ({ ...prev, storeNameBn: e.target.value }))}
                      className="w-full px-3 py-1.5 text-xs rounded-xl border border-gray-200 dark:border-gray-650 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                      placeholder="দেশিবাজার"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-bold text-gray-600 dark:text-gray-400 block mb-1">
                      {t('দোকানের নাম (English)', 'Store Name (English)')}
                    </label>
                    <input
                      type="text"
                      value={draftConfig.storeName}
                      onChange={(e) => setDraftConfig(prev => ({ ...prev, storeName: e.target.value }))}
                      className="w-full px-3 py-1.5 text-xs rounded-xl border border-gray-200 dark:border-gray-650 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                      placeholder="DeshiBazar"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-bold text-gray-600 dark:text-gray-400 block mb-1">
                      {t('স্লোগান (বাংলা)', 'Tagline (Bangla)')}
                    </label>
                    <input
                      type="text"
                      value={draftConfig.taglineBn}
                      onChange={(e) => setDraftConfig(prev => ({ ...prev, taglineBn: e.target.value }))}
                      className="w-full px-3 py-1.5 text-xs rounded-xl border border-gray-200 dark:border-gray-650 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                      placeholder="খাঁটি বাংলার বিশ্বস্ত হাট"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-bold text-gray-600 dark:text-gray-400 block mb-1">
                      {t('স্লোগান (English)', 'Tagline (English)')}
                    </label>
                    <input
                      type="text"
                      value={draftConfig.tagline}
                      onChange={(e) => setDraftConfig(prev => ({ ...prev, tagline: e.target.value }))}
                      className="w-full px-3 py-1.5 text-xs rounded-xl border border-gray-200 dark:border-gray-650 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                      placeholder="Authentic Bangladeshi Marketplace"
                    />
                  </div>
                </div>
              </div>

              {/* Color Swatches & Custom Pickers */}
              <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-750 border border-gray-200 dark:border-gray-700 space-y-4">
                <span className="text-xs font-black text-gray-900 dark:text-white block">
                  {t('থিম কালার প্যালেট', 'Theme Color Palettes')}
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {/* 1. Primary Brand Color */}
                  <div>
                    <label className="text-[11px] font-bold text-gray-600 dark:text-gray-400 block mb-1">
                      {t('মূল ব্র্যান্ড কালার (Primary)', 'Primary Brand Color')}
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={draftConfig.primaryColor}
                        onChange={(e) => setDraftConfig(prev => ({ ...prev, primaryColor: e.target.value }))}
                        className="w-9 h-9 rounded-xl border-0 cursor-pointer p-0.5 bg-transparent"
                      />
                      <input
                        type="text"
                        value={draftConfig.primaryColor}
                        onChange={(e) => setDraftConfig(prev => ({ ...prev, primaryColor: e.target.value }))}
                        className="w-full px-2.5 py-1 text-xs rounded-xl border border-gray-200 dark:border-gray-650 bg-white dark:bg-gray-800 text-gray-900 dark:text-white uppercase font-mono"
                      />
                    </div>
                  </div>

                  {/* 2. Accent Color */}
                  <div>
                    <label className="text-[11px] font-bold text-gray-600 dark:text-gray-400 block mb-1">
                      {t('অ্যাকসেন্ট কালার (Accent)', 'Accent Color')}
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={draftConfig.accentColor}
                        onChange={(e) => setDraftConfig(prev => ({ ...prev, accentColor: e.target.value }))}
                        className="w-9 h-9 rounded-xl border-0 cursor-pointer p-0.5 bg-transparent"
                      />
                      <input
                        type="text"
                        value={draftConfig.accentColor}
                        onChange={(e) => setDraftConfig(prev => ({ ...prev, accentColor: e.target.value }))}
                        className="w-full px-2.5 py-1 text-xs rounded-xl border border-gray-200 dark:border-gray-650 bg-white dark:bg-gray-800 text-gray-900 dark:text-white uppercase font-mono"
                      />
                    </div>
                  </div>

                  {/* 3. Badge Color */}
                  <div>
                    <label className="text-[11px] font-bold text-gray-600 dark:text-gray-400 block mb-1">
                      {t('ডিসকাউন্ট ব্যাজ কালার (Badge)', 'Discount Badge Color')}
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={draftConfig.badgeColor}
                        onChange={(e) => setDraftConfig(prev => ({ ...prev, badgeColor: e.target.value }))}
                        className="w-9 h-9 rounded-xl border-0 cursor-pointer p-0.5 bg-transparent"
                      />
                      <input
                        type="text"
                        value={draftConfig.badgeColor}
                        onChange={(e) => setDraftConfig(prev => ({ ...prev, badgeColor: e.target.value }))}
                        className="w-full px-2.5 py-1 text-xs rounded-xl border border-gray-200 dark:border-gray-650 bg-white dark:bg-gray-800 text-gray-900 dark:text-white uppercase font-mono"
                      />
                    </div>
                  </div>
                </div>

                {/* Quick Swatches */}
                <div className="pt-2">
                  <span className="text-[10px] font-bold text-gray-500 block mb-1.5">
                    {t('জনপ্রিয় কালার প্যালেট থেকে বাছাই করুন:', 'Pick from curated palettes:')}
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {[
                      { name: 'Heritage Emerald', primary: '#059669', accent: '#f59e0b', badge: '#e11d48' },
                      { name: 'Royal Indigo', primary: '#4f46e5', accent: '#06b6d4', badge: '#f43f5e' },
                      { name: 'Crimson Luxury', primary: '#be123c', accent: '#fbbf24', badge: '#9f1239' },
                      { name: 'Golden Amber', primary: '#d97706', accent: '#10b981', badge: '#ef4444' },
                      { name: 'Ocean Cyan', primary: '#0284c7', accent: '#f97316', badge: '#e11d48' },
                      { name: 'Deep Slate High-Tech', primary: '#1e293b', accent: '#3b82f6', badge: '#dc2626' }
                    ].map((palette) => (
                      <button
                        key={palette.name}
                        type="button"
                        onClick={() => setDraftConfig(prev => ({
                          ...prev,
                          primaryColor: palette.primary,
                          accentColor: palette.accent,
                          badgeColor: palette.badge
                        }))}
                        className="px-2.5 py-1 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:border-gray-400 text-[11px] font-bold flex items-center gap-1.5 shadow-2xs"
                      >
                        <span className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: palette.primary }} />
                        <span className="text-gray-800 dark:text-gray-200">{palette.name}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Typography & Border Radius */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Border Radius */}
                <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-750 border border-gray-200 dark:border-gray-700 space-y-2">
                  <span className="text-xs font-black text-gray-900 dark:text-white block">
                    {t('কার্ভ ও কোণা রাউন্ডিং (Corners)', 'Corner Rounding')}
                  </span>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { id: 'rounded-xl', name: 'Subtle Curve (12px)' },
                      { id: 'rounded-2xl', name: 'Modern Rounded (16px)' },
                      { id: 'rounded-3xl', name: 'Curved Pill (24px)' },
                      { id: 'rounded-none', name: 'Sharp Neo (0px)' }
                    ].map((rad) => {
                      const isSel = draftConfig.borderRadius === rad.id;
                      return (
                        <button
                          key={rad.id}
                          type="button"
                          onClick={() => setDraftConfig(prev => ({ ...prev, borderRadius: rad.id as any }))}
                          className={`p-2.5 rounded-xl border text-left text-xs font-bold transition-all ${
                            isSel
                              ? 'bg-indigo-50/80 dark:bg-indigo-950/40 border-indigo-500 ring-2 ring-indigo-500/20'
                              : 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700'
                          }`}
                        >
                          <span className="text-gray-900 dark:text-white">{rad.name}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Hero Layout */}
                <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-750 border border-gray-200 dark:border-gray-700 space-y-2">
                  <span className="text-xs font-black text-gray-900 dark:text-white block">
                    {t('হিরো ব্যানার লেআউট স্টাইল', 'Hero Banner Layout')}
                  </span>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { id: 'carousel', name: 'Full Carousel Slider' },
                      { id: 'bento', name: 'Bento Grid Cards' },
                      { id: 'split-banner', name: 'Split 2-Column Banner' },
                      { id: 'clean-minimal', name: 'Clean Minimal Banner' }
                    ].map((hl) => {
                      const isSel = draftConfig.heroLayout === hl.id;
                      return (
                        <button
                          key={hl.id}
                          type="button"
                          onClick={() => setDraftConfig(prev => ({ ...prev, heroLayout: hl.id as any }))}
                          className={`p-2.5 rounded-xl border text-left text-xs font-bold transition-all ${
                            isSel
                              ? 'bg-indigo-50/80 dark:bg-indigo-950/40 border-indigo-500 ring-2 ring-indigo-500/20'
                              : 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700'
                          }`}
                        >
                          <span className="text-gray-900 dark:text-white">{hl.name}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

            </div>
          )}

        </div>

        {/* RIGHT COLUMN: Live Multi-Device Interactive Simulator (5 cols) */}
        <div className="lg:col-span-5 bg-white dark:bg-gray-850 rounded-3xl p-5 border border-gray-100 dark:border-gray-700 shadow-xs flex flex-col space-y-4 sticky top-6">
          
          {/* Simulator Toolbar */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Eye className="w-4 h-4 text-emerald-600" />
              <span className="text-xs font-black text-gray-900 dark:text-white">
                {t('লাইভ কাস্টমার এক্সপেরিয়েন্স প্রিভিউ', 'Live Customer Experience Simulator')}
              </span>
            </div>

            <div className="flex items-center gap-1 bg-gray-100 dark:bg-gray-700 p-1 rounded-xl">
              <button
                onClick={() => setPreviewDevice('mobile')}
                className={`p-1.5 rounded-lg text-xs font-bold flex items-center gap-1 transition-all ${
                  previewDevice === 'mobile'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-gray-600 dark:text-gray-300'
                }`}
                title="Mobile App View"
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>App</span>
              </button>

              <button
                onClick={() => setPreviewDevice('desktop')}
                className={`p-1.5 rounded-lg text-xs font-bold flex items-center gap-1 transition-all ${
                  previewDevice === 'desktop'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-gray-600 dark:text-gray-300'
                }`}
                title="Desktop Web View"
              >
                <Monitor className="w-3.5 h-3.5" />
                <span>Web</span>
              </button>
            </div>
          </div>

          {/* Simulator Viewport Container */}
          <div className="flex justify-center items-center py-2 bg-gray-100 dark:bg-gray-900 rounded-2xl p-3 overflow-hidden">
            <div 
              className={`transition-all duration-300 overflow-hidden shadow-2xl border flex flex-col relative bg-white dark:bg-gray-900 ${
                previewDevice === 'mobile'
                  ? 'w-[330px] h-[580px] rounded-[36px] border-8 border-gray-800'
                  : 'w-full h-[580px] rounded-2xl border-2 border-gray-300 dark:border-gray-700'
              }`}
            >
              {/* Phone Speaker Notch */}
              {previewDevice === 'mobile' && (
                <div className="h-4 bg-gray-800 w-full flex items-center justify-center shrink-0">
                  <div className="w-12 h-2.5 bg-black rounded-full" />
                </div>
              )}

              {/* Simulated Customer Top Announcement */}
              {draftConfig.showAnnouncementTicker && (
                <div 
                  className="py-1 px-3 text-[9px] font-bold text-white text-center truncate shrink-0"
                  style={{ backgroundColor: draftConfig.primaryColor }}
                >
                  ⚡ {draftConfig.announcementTextBn || draftConfig.announcementText}
                </div>
              )}

              {/* Simulated Header */}
              <div className="p-3 border-b border-gray-100 dark:border-gray-800 flex items-center justify-between shrink-0 bg-white/95 dark:bg-gray-900/95">
                <div className="flex items-center gap-1.5">
                  <div 
                    className="w-6 h-6 rounded-lg text-white font-black text-[10px] flex items-center justify-center shadow-xs"
                    style={{ backgroundColor: draftConfig.primaryColor }}
                  >
                    দ
                  </div>
                  <span className="font-black text-xs text-gray-900 dark:text-white truncate max-w-[120px]">
                    {draftConfig.storeNameBn || draftConfig.storeName}
                  </span>
                </div>

                <div className="flex items-center gap-1.5">
                  <div className="w-6 h-6 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center text-[10px]">
                    🔍
                  </div>
                  <div className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center text-[10px] font-bold">
                    🛒 2
                  </div>
                </div>
              </div>

              {/* Scrollable Customer Viewport Feed */}
              <div className="flex-1 overflow-y-auto p-3 space-y-3.5 scrollbar-thin">
                
                {/* 1. Customer Stories Bubble Bar */}
                {draftConfig.showCustomerStories && (draftConfig.stories || []).length > 0 && (
                  <div className="flex gap-2.5 overflow-x-auto pb-1 scrollbar-none">
                    {(draftConfig.stories || []).slice(0, 5).map(s => (
                      <div key={s.id} className="flex flex-col items-center gap-1 shrink-0">
                        <div className="p-0.5 rounded-full bg-gradient-to-tr from-amber-400 via-emerald-500 to-teal-600">
                          <img 
                            src={s.image} 
                            alt={s.title} 
                            className="w-10 h-10 rounded-full object-cover border border-white"
                          />
                        </div>
                        <span className="text-[9px] font-bold text-gray-700 dark:text-gray-300 max-w-[50px] truncate text-center">
                          {t(s.titleBn, s.title)}
                        </span>
                      </div>
                    ))}
                  </div>
                )}

                {/* 2. Hero Promotional Banner */}
                <div 
                  className="p-3.5 rounded-2xl text-white relative overflow-hidden shadow-sm"
                  style={{
                    background: `linear-gradient(135deg, ${draftConfig.primaryColor} 0%, #064e3b 100%)`
                  }}
                >
                  <span 
                    className="text-[8px] font-black uppercase px-2 py-0.5 rounded-full inline-block mb-1 shadow-xs"
                    style={{ backgroundColor: draftConfig.accentColor, color: '#fff' }}
                  >
                    Mega Deshi Sale
                  </span>
                  <h4 className="text-xs font-black leading-tight">
                    {t('সুন্দরবনের খাঁটি মধু ও পদ্মার রূপালী ইলিশ', 'Sundarbans Raw Honey & Fresh Hilsha')}
                  </h4>
                  <span className="text-[9px] opacity-80 block mt-1">Free Delivery on ৳1,500+</span>
                </div>

                {/* 3. Category Pills */}
                {draftConfig.showCategoryPills && (
                  <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none text-[10px] font-bold">
                    <span 
                      className="px-2.5 py-0.5 rounded-full text-white shrink-0"
                      style={{ backgroundColor: draftConfig.primaryColor }}
                    >
                      সব পণ্য
                    </span>
                    <span className="px-2.5 py-0.5 rounded-full bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 shrink-0">
                      মুদি চাল-ডাল
                    </span>
                    <span className="px-2.5 py-0.5 rounded-full bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 shrink-0">
                      তাজা মাছ
                    </span>
                    <span className="px-2.5 py-0.5 rounded-full bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 shrink-0">
                      দেশি শাড়ি
                    </span>
                  </div>
                )}

                {/* 4. Flash Sale Strip */}
                {draftConfig.showFlashSale && (
                  <div className="p-2 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 flex items-center justify-between text-[10px]">
                    <div className="flex items-center gap-1 font-black text-rose-600">
                      <Flame className="w-3.5 h-3.5" />
                      <span>{t('ফ্ল্যাশ সেল', 'Flash Sale')}</span>
                    </div>
                    <span className="bg-rose-600 text-white font-mono px-1.5 py-0.2 rounded text-[9px] font-bold">
                      11:42:18
                    </span>
                  </div>
                )}

                {/* 5. Product Cards Grid (Simulating configured style) */}
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { name: 'সুন্দরবনের মধু', price: 450, oldPrice: 550, img: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=200&q=80', disc: 18 },
                    { name: 'পদ্মার তাজা ইলিশ', price: 1850, oldPrice: 2200, img: 'https://images.unsplash.com/photo-1544943910-4c1dc44a0551?auto=format&fit=crop&w=200&q=80', disc: 15 }
                  ].map((p, idx) => (
                    <div 
                      key={idx}
                      className={`overflow-hidden flex flex-col justify-between transition-all ${
                        draftConfig.productCardStyle === 'minimal-border'
                          ? 'border-2 border-gray-200 dark:border-gray-700 rounded-lg p-1.5'
                          : draftConfig.productCardStyle === 'elevated-glow'
                          ? 'rounded-3xl shadow-lg ring-1 ring-emerald-500/30 p-2 bg-white dark:bg-gray-800'
                          : 'rounded-2xl border border-gray-100 dark:border-gray-700 shadow-xs bg-white dark:bg-gray-800 p-2'
                      }`}
                    >
                      <div className="aspect-square rounded-xl bg-gray-100 relative overflow-hidden">
                        <img src={p.img} alt={p.name} className="w-full h-full object-cover" />
                        {draftConfig.showDiscountPercent && (
                          <span 
                            className={`absolute top-1 left-1 text-[8px] font-black text-white px-1.5 py-0.2 ${
                              draftConfig.badgeStyle === 'pill' ? 'rounded-full' : 'rounded-sm'
                            }`}
                            style={{ backgroundColor: draftConfig.badgeColor }}
                          >
                            -{p.disc}%
                          </span>
                        )}
                      </div>

                      <div className="pt-1.5 flex flex-col justify-between flex-1">
                        <span className="text-[10px] font-bold text-gray-900 dark:text-white truncate">{p.name}</span>
                        {draftConfig.showRatingStars && (
                          <span className="text-[9px] text-amber-500 font-bold">★ 4.9 (124)</span>
                        )}
                        <div className="flex items-baseline justify-between mt-1">
                          <span className="text-xs font-black text-emerald-600">৳{p.price}</span>
                          <span className="text-[9px] text-gray-400 line-through">৳{p.oldPrice}</span>
                        </div>

                        {draftConfig.cardActionStyle === 'both-buttons' ? (
                          <div className="grid grid-cols-2 gap-1 mt-1.5">
                            <button 
                              className="py-1 text-[8px] font-bold rounded-lg bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200"
                            >
                              Add
                            </button>
                            <button 
                              className="py-1 text-[8px] font-bold rounded-lg text-white"
                              style={{ backgroundColor: draftConfig.primaryColor }}
                            >
                              Buy
                            </button>
                          </div>
                        ) : (
                          <button 
                            className="w-full mt-1.5 py-1 text-[9px] font-bold text-white rounded-lg flex items-center justify-center gap-1"
                            style={{ backgroundColor: draftConfig.primaryColor }}
                          >
                            + Add to Cart
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

              </div>

              {/* Simulated Customer Bottom Nav Bar */}
              {previewDevice === 'mobile' && (
                <div 
                  className={`h-12 flex items-center justify-around text-[9px] font-bold shrink-0 ${
                    draftConfig.mobileBottomNavStyle === 'floating-pill'
                      ? 'm-2 rounded-full border border-gray-200 dark:border-gray-700 shadow-md bg-white/95 dark:bg-gray-850/95'
                      : 'border-t border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900'
                  }`}
                >
                  <span className="flex flex-col items-center" style={{ color: draftConfig.primaryColor }}>
                    <span>🏠</span>
                    <span>Home</span>
                  </span>
                  <span className="flex flex-col items-center text-gray-400">
                    <span>🛍️</span>
                    <span>Shop</span>
                  </span>
                  <span className="flex flex-col items-center text-gray-400">
                    <span>🛒</span>
                    <span>Cart</span>
                  </span>
                  <span className="flex flex-col items-center text-gray-400">
                    <span>👤</span>
                    <span>Me</span>
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Quick Publish Action inside Toolbar */}
          <button
            onClick={handleSaveAndPublish}
            disabled={isSaving}
            className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-2xl shadow-md flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{isSaving ? t('পাবলিশ হচ্ছে...', 'Publishing...') : t('গ্রাহক সাইটে এই ডিজাইন সক্রিয় করুন (Publish Live)', 'Publish This Design Live to Customer Store')}</span>
          </button>
        </div>

      </div>
    </div>
  );
};
