import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ProductCard } from './ProductCard';
import { Tag, Sparkles } from 'lucide-react';

export const DailyDealsSection: React.FC = () => {
  const { t, products } = useApp();
  const [selectedDiscountFilter, setSelectedDiscountFilter] = useState<number | 'all'>('all');

  const dealProducts = products.filter(p => {
    if (selectedDiscountFilter === 'all') return p.discountPercent > 10;
    if (selectedDiscountFilter === 20) return p.discountPercent >= 20 && p.discountPercent < 30;
    if (selectedDiscountFilter === 30) return p.discountPercent >= 30 && p.discountPercent < 40;
    if (selectedDiscountFilter === 40) return p.discountPercent >= 40 && p.discountPercent < 50;
    if (selectedDiscountFilter === 50) return p.discountPercent >= 50;
    return true;
  });

  return (
    <section className="py-12 bg-gray-50/60 dark:bg-gray-850/40 border-b border-gray-100 dark:border-gray-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header and Filter Pills */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-1.5 text-amber-600 dark:text-amber-400 text-xs font-black uppercase tracking-wider mb-1">
              <Tag className="w-4 h-4" />
              <span>{t('প্রতিদিনের দারুণ মূল্যছাড়', 'Mega Bargains')}</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white tracking-tight">
              {t('দৈনিক ধামাকা ডিলস', 'Daily Deals & Discounts')}
            </h2>
          </div>

          {/* Discount Percentage Selectors */}
          <div className="flex flex-wrap items-center gap-1.5 bg-white dark:bg-gray-800 p-1.5 rounded-2xl border border-gray-200 dark:border-gray-700 shadow-sm">
            <button
              onClick={() => setSelectedDiscountFilter('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                selectedDiscountFilter === 'all'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-gray-600 dark:text-gray-300 hover:text-emerald-600'
              }`}
            >
              {t('সব ডিল', 'All Deals')}
            </button>
            {[20, 30, 40, 50].map((pct) => (
              <button
                key={pct}
                onClick={() => setSelectedDiscountFilter(pct)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  selectedDiscountFilter === pct
                    ? 'bg-amber-500 text-emerald-950 shadow-sm'
                    : 'text-gray-600 dark:text-gray-300 hover:text-amber-600'
                }`}
              >
                {pct}% {t('ছাড়', 'OFF')}
              </button>
            ))}
          </div>
        </div>

        {/* Products Grid */}
        {dealProducts.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-6">
            {dealProducts.slice(0, 8).map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12 bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700">
            <Sparkles className="w-8 h-8 text-amber-500 mx-auto mb-2 opacity-60" />
            <p className="text-sm font-semibold text-gray-600 dark:text-gray-300">
              {t('এই ডিসকাউন্ট ক্যাটাগরিতে এই মুহূর্তে নতুন স্টক যোগ হচ্ছে।', 'New stock is being added for this discount level.')}
            </p>
          </div>
        )}
      </div>
    </section>
  );
};
