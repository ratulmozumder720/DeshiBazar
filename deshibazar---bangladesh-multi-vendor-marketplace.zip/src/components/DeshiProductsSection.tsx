import React from 'react';
import { useApp } from '../context/AppContext';
import { ProductCard } from './ProductCard';
import { Sparkles, Award, ArrowRight } from 'lucide-react';

export const DeshiProductsSection: React.FC = () => {
  const { t, products, setSelectedCategory, setCurrentView } = useApp();

  const deshiProducts = products.filter(p => p.isDeshi).slice(0, 6);

  const handleShopDeshi = () => {
    setSelectedCategory('deshi-products');
    setCurrentView('shop');
  };

  return (
    <section className="py-14 bg-gradient-to-b from-amber-50/50 via-white to-emerald-50/30 dark:from-gray-900 dark:via-gray-850 dark:to-gray-900 border-b border-gray-100 dark:border-gray-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100 dark:bg-amber-950/80 border border-amber-300 dark:border-amber-800 text-amber-900 dark:text-amber-300 text-xs font-black uppercase tracking-wider mb-2">
              <Sparkles className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
              <span>{t('ঐতিহ্য ও সংস্কৃতির ছোঁয়া', 'Roots of Bengal Heritage')}</span>
            </div>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-gray-900 dark:text-white tracking-tight">
              {t('বাংলার সেরা দেশি পণ্য', 'Best of Deshi Products')}
            </h2>
            <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400 mt-1 max-w-xl">
              {t(
                'সুন্দরবনের খাঁটি মধু, ঘানিভাঙা সরিষার তেল, যশোরের নকশিকাঁথা, ঢাকাই জামদানি এবং খাঁটি নদীর মাছ—আমাদের নিজস্ব ঐতিহ্য।',
                'Sundarbans raw honey, cold-pressed mustard oil, master-stitched Nakshi Kantha, Dhakai Jamdani and river catches—preserving Bengal craftsmanship.'
              )}
            </p>
          </div>

          <button
            onClick={handleShopDeshi}
            className="self-start md:self-auto px-6 py-3 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-700/20 flex items-center gap-2 transition-transform active:scale-95"
          >
            <Award className="w-4 h-4 text-amber-400" />
            <span>{t('দেশি পণ্য এক্সপ্লোর করুন', 'Shop Deshi Products')}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Highlight Banner Callouts */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <div className="bg-gradient-to-r from-amber-600 to-amber-700 rounded-2xl p-5 text-white shadow-md relative overflow-hidden flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider bg-white/20 px-2 py-0.5 rounded">
                {t('খাদ্য ও পুষ্টি', 'Pure Nutrition')}
              </span>
              <h3 className="text-base font-black mt-2">
                {t('সুন্দরবনের খাঁটি মধু ও কাঠের ঘানির তেল', 'Sundarbans Honey & Ghani Oil')}
              </h3>
              <p className="text-xs text-amber-100 mt-1">
                {t('কোনো রাসায়নিক ছাড়া শতভাগ প্রাকৃতিক', '100% pure without adulteration')}
              </p>
            </div>
            <span className="text-xs font-bold underline mt-3 cursor-pointer" onClick={handleShopDeshi}>
              {t('পণ্য দেখুন →', 'Explore Products →')}
            </span>
          </div>

          <div className="bg-gradient-to-r from-emerald-700 to-teal-800 rounded-2xl p-5 text-white shadow-md relative overflow-hidden flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider bg-white/20 px-2 py-0.5 rounded">
                {t('তাঁত ও ঐতিহ্য', 'Handloom Heritage')}
              </span>
              <h3 className="text-base font-black mt-2">
                {t('টাঙ্গাইলের জামদানি ও যশোরের নকশিকাঁথা', 'Jamdani Sarees & Nakshi Kantha')}
              </h3>
              <p className="text-xs text-emerald-100 mt-1">
                {t('প্রজন্মের কারিগরদের নিপুণ হাতের কাজ', 'Handmade by master artisans')}
              </p>
            </div>
            <span className="text-xs font-bold underline mt-3 cursor-pointer" onClick={handleShopDeshi}>
              {t('সংগ্রহ দেখুন →', 'View Collections →')}
            </span>
          </div>

          <div className="bg-gradient-to-r from-cyan-700 to-blue-800 rounded-2xl p-5 text-white shadow-md relative overflow-hidden flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider bg-white/20 px-2 py-0.5 rounded">
                {t('নদী ও উপকূল', 'Rivers & Coast')}
              </span>
              <h3 className="text-base font-black mt-2">
                {t('পদ্মার রূপালী ইলিশ ও কক্সবাজারের শুঁটকি', 'Padma Hilsha & Cox\'s Shutki')}
              </h3>
              <p className="text-xs text-blue-100 mt-1">
                {t('তাজা সংগৃহীত ও নিরাপদ প্যাকেজিং', 'Chilled ice-boxed transport')}
              </p>
            </div>
            <span className="text-xs font-bold underline mt-3 cursor-pointer" onClick={handleShopDeshi}>
              {t('অর্ডার করুন →', 'Order Fresh →')}
            </span>
          </div>
        </div>

        {/* Product Cards Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
          {deshiProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </section>
  );
};
