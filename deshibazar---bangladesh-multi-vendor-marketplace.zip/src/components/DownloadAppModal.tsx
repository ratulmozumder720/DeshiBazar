import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  Smartphone, 
  Download, 
  Check, 
  Send, 
  Sparkles, 
  ShieldCheck, 
  Star, 
  Copy, 
  ExternalLink,
  Laptop,
  Bell,
  Zap,
  Palette
} from 'lucide-react';

export const DownloadAppModal: React.FC = () => {
  const { 
    t, 
    isDownloadAppModalOpen, 
    setIsDownloadAppModalOpen,
    downloadAppInitialTab,
    showToast,
    openThemeStudio,
    currentTheme,
    allThemes,
    setThemeId 
  } = useApp();

  const [activeTab, setActiveTab] = useState<'android' | 'ios' | 'microsoft' | 'apk' | 'huawei' | 'pwa'>(downloadAppInitialTab || 'android');
  const [phoneForSms, setPhoneForSms] = useState('');
  const [copiedCoupon, setCopiedCoupon] = useState(false);
  const [isDownloadingApk, setIsDownloadingApk] = useState(false);
  const [isDownloadingMsix, setIsDownloadingMsix] = useState(false);

  useEffect(() => {
    if (downloadAppInitialTab) {
      setActiveTab(downloadAppInitialTab);
    }
  }, [downloadAppInitialTab, isDownloadAppModalOpen]);

  if (!isDownloadAppModalOpen) return null;

  const handleCopyCode = () => {
    navigator.clipboard.writeText('DESHIAPP');
    setCopiedCoupon(true);
    showToast(t('কুপন কোড DESHIAPP কপি করা হয়েছে!', 'Promo code DESHIAPP copied!'), 'success');
    setTimeout(() => setCopiedCoupon(false), 3000);
  };

  const handleSendSmsLink = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phoneForSms || phoneForSms.length < 11) {
      showToast(t('অনুগ্রহ করে সঠিক ১১ ডিজিটের মোবাইল নম্বর দিন', 'Please enter a valid 11-digit mobile number'), 'error');
      return;
    }
    showToast(
      t(`ডাউনলোড লিংক ${phoneForSms} নম্বরে এসএমএস ও হোয়াটসঅ্যাপে পাঠানো হয়েছে!`, 
        `Download link sent to ${phoneForSms} via SMS & WhatsApp!`),
      'success'
    );
    setPhoneForSms('');
  };

  const handleDirectApkDownload = () => {
    setIsDownloadingApk(true);
    // Simulate APK file generation/download
    const apkData = JSON.stringify({
      app: 'DeshiBazar Marketplace BD',
      version: '2.8.4',
      releaseDate: '2026-09-28',
      package: 'com.deshibazar.app',
      signature: 'SHA256:4f8a92b...verified',
      bdixOptimized: true,
      downloadSource: 'https://cdn.deshibazar.com.bd/releases/deshibazar-v2.8.4.apk'
    }, null, 2);

    const blob = new Blob([apkData], { type: 'application/vnd.android.package-archive' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'DeshiBazar-v2.8.4-BDIX-Fast.apk';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);

    setTimeout(() => {
      setIsDownloadingApk(false);
      showToast(t('দেশিবাজার APK ডাউনলোড শুরু হয়েছে (২৪.২ এমবি)', 'DeshiBazar APK download started (24.2 MB)'), 'success');
    }, 800);
  };

  const handleDirectMsixDownload = () => {
    setIsDownloadingMsix(true);
    const msixData = JSON.stringify({
      app: 'DeshiBazar Marketplace for Windows 11/10',
      version: '2.8.4',
      publisher: 'CN=DeshiBazar Bangladesh Ltd, O=DeshiBazar, C=BD',
      msixPackage: 'DeshiBazar-v2.8.4-x64-arm64.msixbundle',
      downloadSource: 'https://cdn.deshibazar.com.bd/releases/windows/deshibazar-v2.8.4.msixbundle',
      verifiedSignature: 'SHA256:88fa12c9b...verified'
    }, null, 2);

    const blob = new Blob([msixData], { type: 'application/msixbundle' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'DeshiBazar-v2.8.4-Windows.msixbundle';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);

    setTimeout(() => {
      setIsDownloadingMsix(false);
      showToast(t('দেশিবাজার Windows MSIX প্যাকেজ ডাউনলোড শুরু হয়েছে (২৮.৪ এমবি)', 'DeshiBazar Windows MSIX download started (28.4 MB)'), 'success');
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs overflow-y-auto animate-fade-in">
      <div className="relative w-full max-w-2xl bg-white dark:bg-gray-850 rounded-3xl shadow-2xl border border-gray-100 dark:border-gray-700 overflow-hidden my-6">
        
        {/* Modal Top Header Banner */}
        <div className="relative bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-800 text-white p-6 sm:p-7 overflow-hidden">
          {/* Subtle Decorative Elements */}
          <div className="absolute -right-10 -bottom-10 w-44 h-44 bg-white/10 rounded-full blur-2xl pointer-events-none" />
          <div className="absolute right-12 top-6 opacity-15 pointer-events-none hidden sm:block">
            <Smartphone className="w-32 h-32" />
          </div>

          <div className="relative z-10 flex items-start justify-between gap-4">
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-[11px] font-bold text-emerald-100 mb-2.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                <span>{t('অফিশিয়াল মোবাইল অ্যাপ ২০২৬', 'Official Mobile App 2026')}</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black tracking-tight">
                {t('দেশিবাজার অ্যাপ ডাউনলোড করুন', 'Download DeshiBazar App')}
              </h2>
              <p className="text-xs sm:text-sm text-emerald-100 mt-1 max-w-md">
                {t(
                  'গুগল প্লে, অ্যাপল অ্যাপ স্টোর, হুয়াওয়ে অ্যাপগ্যালারি কিংবা সরাসরি এপিকে—যেকোনো ডিভাইসে উপভোগ করুন সেরা দেশি কেনাকাটার অভিজ্ঞতা!',
                  'Available across Google Play, Apple App Store, Huawei AppGallery & Direct APK for all devices!'
                )}
              </p>
            </div>

            <button
              onClick={() => setIsDownloadAppModalOpen(false)}
              className="w-9 h-9 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center transition-all shrink-0"
              title={t('বন্ধ করুন', 'Close')}
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Exclusive App Promo Banner */}
          <div className="relative z-10 mt-4 p-3 rounded-2xl bg-white/15 backdrop-blur-md border border-white/20 flex flex-wrap items-center justify-between gap-2.5">
            <div className="flex items-center gap-2">
              <span className="text-xl">🎁</span>
              <div>
                <span className="text-xs font-black block text-amber-200">
                  {t('অ্যাপ এক্সক্লুসিভ অফার: ১০০ টাকা ছাড়!', 'App Exclusive Offer: Flat ৳100 OFF!')}
                </span>
                <span className="text-[11px] text-white/90">
                  {t('প্রথম অ্যাপ অর্ডারে কোড ব্যবহার করুন:', 'Use voucher on your first app purchase:')}
                </span>
              </div>
            </div>

            <button
              onClick={handleCopyCode}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-gray-900 font-black text-xs shadow-md transition-all active:scale-95"
            >
              <span className="tracking-wider">DESHIAPP</span>
              {copiedCoupon ? <Check className="w-3.5 h-3.5 text-emerald-900" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* Platform Selector Tabs */}
        <div className="p-4 bg-gray-50 dark:bg-gray-800/80 border-b border-gray-100 dark:border-gray-700 flex gap-2 overflow-x-auto scrollbar-none">
          {[
            { id: 'android', label: 'Google Play', icon: '🤖', sub: 'Android Phones' },
            { id: 'ios', label: 'App Store', icon: '🍎', sub: 'iPhone & iPad' },
            { id: 'microsoft', label: 'Microsoft Store', icon: '🪟', sub: 'Windows 11 & 10' },
            { id: 'apk', label: 'Direct APK', icon: '⚡', sub: 'Fast Download' },
            { id: 'huawei', label: 'Huawei / Samsung', icon: '📱', sub: 'AppGallery & Galaxy' },
            { id: 'pwa', label: 'Web PWA', icon: '💻', sub: 'Desktop Browser' }
          ].map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all shrink-0 ${
                  isActive
                    ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                    : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-650 border border-gray-200 dark:border-gray-600'
                }`}
              >
                <span className="text-base">{tab.icon}</span>
                <div className="text-left">
                  <span className="block leading-tight">{tab.label}</span>
                  <span className={`text-[9px] block font-normal ${isActive ? 'text-emerald-100' : 'text-gray-400'}`}>
                    {tab.sub}
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Tab Contents */}
        <div className="p-6 space-y-6 max-h-[60vh] overflow-y-auto">
          
          {/* TAB 1: GOOGLE PLAY */}
          {activeTab === 'android' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row items-center gap-6 p-4 rounded-2xl bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-800/40">
                {/* QR Code */}
                <div className="p-3 bg-white rounded-2xl shadow-sm border border-gray-100 shrink-0 text-center">
                  <img 
                    src="https://api.qrserver.com/v1/create-qr-code/?size=130x130&data=https://play.google.com/store/apps/details?id=com.deshibazar.app" 
                    alt="Play Store QR Code" 
                    className="w-28 h-28 mx-auto"
                  />
                  <span className="text-[10px] font-bold text-gray-500 mt-1 block">
                    {t('ক্যামেরা দিয়ে স্ক্যান করুন', 'Scan to Install')}
                  </span>
                </div>

                <div className="space-y-2 text-center sm:text-left">
                  <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-900 text-emerald-800 dark:text-emerald-200 text-[10px] font-black">
                      Official Android Release
                    </span>
                    <span className="text-[11px] text-gray-500 flex items-center gap-1 font-bold">
                      <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                      4.9 (42,000+ Reviews)
                    </span>
                  </div>

                  <h3 className="text-base font-black text-gray-900 dark:text-white">
                    DeshiBazar: Online Shopping Bangladesh
                  </h3>

                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {t(
                      'স্যামসাং, শাওমি, রিয়েলমি, অপ্পো, ভিভো ও সকল অ্যান্ড্রয়েড ফোনে সর্বোচ্চ মসৃণ অভিজ্ঞতা ও ১-ট্যাপ বিকাশ পেমেন্ট।',
                      'Ultra-fast shopping for Samsung, Xiaomi, Realme, Vivo, Oppo & all Android phones with instant bKash checkout.'
                    )}
                  </p>

                  <div className="pt-2 flex flex-wrap gap-2.5 justify-center sm:justify-start">
                    <a
                      href="https://play.google.com/store/apps/details?id=com.deshibazar.app"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gray-950 hover:bg-black text-white text-xs font-bold shadow-md transition-all active:scale-95"
                    >
                      <svg className="w-4 h-4 fill-current text-emerald-400" viewBox="0 0 24 24">
                        <path d="M3.609 1.814L13.792 12 3.61 22.186c-.198-.198-.323-.473-.323-.775V2.589c0-.302.125-.577.323-.775zM15.207 13.414l2.422 2.422-12.019 6.845 9.597-9.267zm2.422-5.25L15.207 10.586 5.61 1.319l12.019 6.845zm1.536 2.685l2.49 1.417c.725.412.725 1.084 0 1.497l-2.49 1.417-2.148-2.165 2.148-2.166z"/>
                      </svg>
                      <div className="text-left">
                        <span className="block text-[9px] uppercase tracking-wider text-gray-400">GET IT ON</span>
                        <span className="block text-xs font-black">Google Play</span>
                      </div>
                    </a>

                    <button
                      onClick={handleDirectApkDownload}
                      className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-650 text-gray-800 dark:text-gray-200 text-xs font-bold transition-all"
                    >
                      <Download className="w-4 h-4 text-emerald-600" />
                      <span>{t('সরাসরি APK (২৪.২ MB)', 'Direct APK (24.2 MB)')}</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Version & Compatibility specs */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                <div className="p-3 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700">
                  <span className="text-[10px] text-gray-400 block font-bold">সংস্করণ / Version</span>
                  <span className="font-black text-gray-800 dark:text-white">v2.8.4 Stable</span>
                </div>
                <div className="p-3 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700">
                  <span className="text-[10px] text-gray-400 block font-bold">ফাইল সাইজ / Size</span>
                  <span className="font-black text-gray-800 dark:text-white">24.2 MB</span>
                </div>
                <div className="p-3 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700">
                  <span className="text-[10px] text-gray-400 block font-bold">প্রয়োজনীয় ওএস / OS</span>
                  <span className="font-black text-gray-800 dark:text-white">Android 8.0+</span>
                </div>
                <div className="p-3 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700">
                  <span className="text-[10px] text-gray-400 block font-bold">নিরাপত্তা / Safety</span>
                  <span className="font-black text-emerald-600">100% Verified</span>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: APPLE APP STORE (iOS) */}
          {activeTab === 'ios' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row items-center gap-6 p-4 rounded-2xl bg-blue-50/50 dark:bg-blue-950/20 border border-blue-100 dark:border-blue-800/40">
                {/* QR Code */}
                <div className="p-3 bg-white rounded-2xl shadow-sm border border-gray-100 shrink-0 text-center">
                  <img 
                    src="https://api.qrserver.com/v1/create-qr-code/?size=130x130&data=https://apps.apple.com/app/deshibazar-bangladesh/id1689234850" 
                    alt="App Store QR Code" 
                    className="w-28 h-28 mx-auto"
                  />
                  <span className="text-[10px] font-bold text-gray-500 mt-1 block">
                    {t('আইফোন ক্যামেরা দিয়ে স্ক্যান করুন', 'Scan with iPhone')}
                  </span>
                </div>

                <div className="space-y-2 text-center sm:text-left">
                  <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                    <span className="px-2.5 py-0.5 rounded-full bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 text-[10px] font-black">
                      iOS & iPadOS Native
                    </span>
                    <span className="text-[11px] text-gray-500 flex items-center gap-1 font-bold">
                      <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                      4.9 (18,400+ Ratings)
                    </span>
                  </div>

                  <h3 className="text-base font-black text-gray-900 dark:text-white">
                    DeshiBazar: Pure Deshi Shopping
                  </h3>

                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {t(
                      'আইফোন ও আইপ্যাডের জন্য বিশেষভাবে নির্মিত। অ্যাপল পে ও লাইভ অ্যাক্টিভিটি দিয়ে সরাসরি লক স্ক্রিন থেকে কুরিয়ার রাইডার ট্র্যাক করুন।',
                      'Engineered for iPhone & iPad. Real-time Live Activities lock screen delivery tracking & fluid 120Hz ProMotion.'
                    )}
                  </p>

                  <div className="pt-2 flex justify-center sm:justify-start">
                    <a
                      href="https://apps.apple.com/app/deshibazar-bangladesh/id1689234850"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gray-950 hover:bg-black text-white text-xs font-bold shadow-md transition-all active:scale-95"
                    >
                      <svg className="w-4 h-4 fill-current text-white" viewBox="0 0 24 24">
                        <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 6.37c.62-.75 1.04-1.8 0.92-2.85-.9.04-2 0.6-2.65 1.35-.58.67-.09 1.74.05 2.77 1.01.08 2.05-.52 2.68-1.27z"/>
                      </svg>
                      <div className="text-left">
                        <span className="block text-[9px] uppercase tracking-wider text-gray-400">Download on the</span>
                        <span className="block text-xs font-black">App Store</span>
                      </div>
                    </a>
                  </div>
                </div>
              </div>

              {/* Version & Compatibility specs */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                <div className="p-3 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700">
                  <span className="text-[10px] text-gray-400 block font-bold">সংস্করণ / Version</span>
                  <span className="font-black text-gray-800 dark:text-white">v2.8.4</span>
                </div>
                <div className="p-3 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700">
                  <span className="text-[10px] text-gray-400 block font-bold">সাইজ / Size</span>
                  <span className="font-black text-gray-800 dark:text-white">32.6 MB</span>
                </div>
                <div className="p-3 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700">
                  <span className="text-[10px] text-gray-400 block font-bold">প্রয়োজনীয় ওএস / OS</span>
                  <span className="font-black text-gray-800 dark:text-white">iOS 14.0 or later</span>
                </div>
                <div className="p-3 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700">
                  <span className="text-[10px] text-gray-400 block font-bold">ডিভাইস / Devices</span>
                  <span className="font-black text-gray-800 dark:text-white">iPhone & iPad</span>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2.5: MICROSOFT STORE (WINDOWS 11 & WINDOWS 10) */}
          {activeTab === 'microsoft' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row items-center gap-6 p-4 rounded-2xl bg-sky-50/50 dark:bg-sky-950/20 border border-sky-100 dark:border-sky-800/40">
                {/* QR Code */}
                <div className="p-3 bg-white rounded-2xl shadow-sm border border-gray-100 shrink-0 text-center">
                  <img 
                    src="https://api.qrserver.com/v1/create-qr-code/?size=130x130&data=https://apps.microsoft.com/detail/deshibazar-bangladesh" 
                    alt="Microsoft Store QR Code" 
                    className="w-28 h-28 mx-auto"
                  />
                  <span className="text-[10px] font-bold text-gray-500 mt-1 block">
                    {t('উইন্ডোজ পিসির জন্য স্ক্যান', 'Scan for PC')}
                  </span>
                </div>

                <div className="space-y-2 text-center sm:text-left">
                  <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                    <span className="px-2.5 py-0.5 rounded-full bg-sky-100 dark:bg-sky-900 text-sky-800 dark:text-sky-200 text-[10px] font-black">
                      Official Windows 11 / 10 App
                    </span>
                    <span className="text-[11px] text-gray-500 flex items-center gap-1 font-bold">
                      <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                      4.9 (12,800+ Ratings)
                    </span>
                  </div>

                  <h3 className="text-base font-black text-gray-900 dark:text-white">
                    DeshiBazar Marketplace for Windows
                  </h3>

                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {t(
                      'উইন্ডোজ ১১ এবং উইন্ডোজ ১০ এর জন্য ফ্লুয়েন্ট ডিজাইন ও নেটিভ পারফরম্যান্স। টাস্কবারে লাইভ নোটিফিকেশন, কিবোর্ড শর্টকাট ও মাল্টি-উইন্ডো শপিং সাপোর্ট।',
                      'Fluent Design with native Windows push notifications, multi-window shopping, live order status on taskbar, and QR payment checkout.'
                    )}
                  </p>

                  <div className="pt-2 flex flex-wrap gap-2.5 justify-center sm:justify-start">
                    <a
                      href="https://apps.microsoft.com/detail/deshibazar-bangladesh"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2.5 px-5 py-2.5 rounded-xl bg-gray-950 hover:bg-black text-white text-xs font-bold shadow-md transition-all active:scale-95"
                    >
                      <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                        <rect x="2" y="2" width="9.5" height="9.5" fill="#F25022"/>
                        <rect x="12.5" y="2" width="9.5" height="9.5" fill="#7FBA00"/>
                        <rect x="2" y="12.5" width="9.5" height="9.5" fill="#00A4EF"/>
                        <rect x="12.5" y="12.5" width="9.5" height="9.5" fill="#FFB900"/>
                      </svg>
                      <div className="text-left">
                        <span className="block text-[9px] uppercase tracking-wider text-gray-400">Get it from</span>
                        <span className="block text-xs font-black">Microsoft Store</span>
                      </div>
                    </a>

                    <a
                      href="ms-windows-store://pdp/?productid=deshibazar"
                      className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold transition-all shadow-sm"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>{t('মাইক্রোসফট স্টোর অ্যাপে খুলুন', 'Open in Store App')}</span>
                    </a>

                    <button
                      onClick={handleDirectMsixDownload}
                      disabled={isDownloadingMsix}
                      className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-650 text-gray-800 dark:text-gray-200 text-xs font-bold transition-all"
                    >
                      <Download className={`w-3.5 h-3.5 text-sky-500 ${isDownloadingMsix ? 'animate-bounce' : ''}`} />
                      <span>{isDownloadingMsix ? t('ডাউনলোড হচ্ছে...', 'Downloading...') : t('অফলাইন MSIX (২৮.৪ MB)', 'Offline MSIX (28.4 MB)')}</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Version & Compatibility specs */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                <div className="p-3 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700">
                  <span className="text-[10px] text-gray-400 block font-bold">সংস্করণ / Version</span>
                  <span className="font-black text-gray-800 dark:text-white">v2.8.4 MSIX</span>
                </div>
                <div className="p-3 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700">
                  <span className="text-[10px] text-gray-400 block font-bold">প্যাকেজ সাইজ / Size</span>
                  <span className="font-black text-gray-800 dark:text-white">28.4 MB</span>
                </div>
                <div className="p-3 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700">
                  <span className="text-[10px] text-gray-400 block font-bold">অপারেটিং সিস্টেম / OS</span>
                  <span className="font-black text-gray-800 dark:text-white">Windows 11 / 10</span>
                </div>
                <div className="p-3 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700">
                  <span className="text-[10px] text-gray-400 block font-bold">আর্কিটেকচার / Arch</span>
                  <span className="font-black text-emerald-600">x64, ARM64</span>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: DIRECT APK DOWNLOAD */}
          {activeTab === 'apk' && (
            <div className="space-y-4">
              <div className="p-5 rounded-2xl bg-gradient-to-r from-emerald-500/10 to-teal-500/10 border border-emerald-200 dark:border-emerald-800/60 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold">
                      APK
                    </span>
                    <div>
                      <h4 className="text-sm font-black text-gray-950 dark:text-white">
                        {t('সরাসরি দেশিবাজার অফিশিয়াল APK ফাইল', 'Direct Official DeshiBazar APK')}
                      </h4>
                      <span className="text-[11px] text-emerald-600 font-bold">
                        ⚡ {t('বিডিআইএক্স (BDIX) সুপারফাস্ট ক্যাশড সার্ভার থেকে ডাউনলোড', 'BDIX Ultra-fast direct download server')}
                      </span>
                    </div>
                  </div>
                  <span className="text-xs font-black text-gray-500">v2.8.4</span>
                </div>

                <p className="text-xs text-gray-600 dark:text-gray-300 leading-relaxed">
                  {t(
                    'প্লে স্টোর অ্যাকাউন্ট ছাড়াই সরাসরি আপনার অ্যান্ড্রয়েড মোবাইলে অ্যাপ ইনস্টল করুন। কোনো জিমেইল বা গুগল প্লে সার্ভিস ছাড়াই চলবে নির্বিঘ্নে।',
                    'Install directly on any Android device without Google Play Store login or GMS dependencies.'
                  )}
                </p>

                <div className="pt-2 flex flex-col sm:flex-row gap-3">
                  <button
                    onClick={handleDirectApkDownload}
                    disabled={isDownloadingApk}
                    className="flex-1 py-3 px-5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-xs font-black shadow-lg shadow-emerald-600/20 flex items-center justify-center gap-2 transition-all"
                  >
                    <Download className={`w-4 h-4 ${isDownloadingApk ? 'animate-bounce' : ''}`} />
                    <span>
                      {isDownloadingApk ? t('ডাউনলোড হচ্ছে...', 'Downloading APK...') : t('APK ডাউনলোড করুন (২৪.২ MB)', 'Download APK File (24.2 MB)')}
                    </span>
                  </button>

                  <a
                    href="https://play.google.com/store/apps/details?id=com.deshibazar.app"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="py-3 px-4 rounded-xl border border-gray-300 dark:border-gray-650 hover:bg-gray-100 dark:hover:bg-gray-750 text-gray-700 dark:text-gray-200 text-xs font-bold text-center"
                  >
                    {t('অথবা গুগল প্লে ব্যবহার করুন', 'Or via Google Play')}
                  </a>
                </div>
              </div>

              {/* 3 Step Installation Guide */}
              <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700 space-y-2">
                <h5 className="text-xs font-black text-gray-900 dark:text-white uppercase tracking-wider">
                  {t('সহজ ৩ ধাপে APK ইনস্টল করার নিয়ম:', 'How to Install APK in 3 Easy Steps:')}
                </h5>
                <ol className="text-xs text-gray-600 dark:text-gray-300 space-y-1.5 list-decimal pl-4">
                  <li>
                    <strong className="text-gray-900 dark:text-white">Download APK:</strong> {t('উপরের বাটনে ক্লিক করে ফাইলটি ডাউনলোড করুন।', 'Click download above to save the .apk file.')}
                  </li>
                  <li>
                    <strong className="text-gray-900 dark:text-white">Allow Permission:</strong> {t('ফোনে "Install Unknown Apps" অথবা "Allow from this source" পারমিশন দিন।', 'Enable "Install Unknown Apps" permission in device settings if prompted.')}
                  </li>
                  <li>
                    <strong className="text-gray-900 dark:text-white">Open & Shop:</strong> {t('ইনস্টল সম্পন্ন হলে অ্যাপ ওপেন করুন এবং কুপন DESHIAPP ব্যবহার করুন!', 'Open the app, sign in and use code DESHIAPP for ৳100 discount!')}
                  </li>
                </ol>
              </div>
            </div>
          )}

          {/* TAB 4: HUAWEI APPGALLERY & SAMSUNG GALAXY STORE */}
          {activeTab === 'huawei' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Huawei Box */}
                <div className="p-4 rounded-2xl bg-red-50/50 dark:bg-red-950/20 border border-red-100 dark:border-red-900/40 space-y-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-red-600 text-white flex items-center justify-center font-bold text-xs">
                      H
                    </div>
                    <div>
                      <h4 className="text-xs font-black text-gray-900 dark:text-white">Huawei AppGallery</h4>
                      <span className="text-[10px] text-red-600 font-bold">HarmonyOS & EMUI Native</span>
                    </div>
                  </div>
                  <p className="text-xs text-gray-500">
                    {t('হুয়াওয়ে পি-সিরিজ, নোভা ও মেট সিরিজের সকল ডিভাইসের জন্য শতভাগ অপ্টিমাইজড।', 'Full HMS Core support for all Huawei smartphones and MatePads.')}
                  </p>
                  <a
                    href="https://appgallery.huawei.com/app/C108923485"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2.5 px-3 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-all"
                  >
                    <span>EXPLORE IT ON AppGallery</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>

                {/* Samsung Galaxy Store Box */}
                <div className="p-4 rounded-2xl bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-100 dark:border-indigo-900/40 space-y-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold text-xs">
                      S
                    </div>
                    <div>
                      <h4 className="text-xs font-black text-gray-900 dark:text-white">Samsung Galaxy Store</h4>
                      <span className="text-[10px] text-indigo-600 font-bold">One UI Optimized</span>
                    </div>
                  </div>
                  <p className="text-xs text-gray-500">
                    {t('স্যামসাং গ্যালাক্সি এস, এ ও এম সিরিজের গ্রাহকদের জন্য সরাসরি গ্যালাক্সি স্টোর লিংক।', 'One UI fluid animations & Samsung Knox verified security.')}
                  </p>
                  <a
                    href="https://galaxystore.samsung.com/detail/com.deshibazar.app"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2.5 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-all"
                  >
                    <span>Available on Galaxy Store</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: WEB PWA / DESKTOP */}
          {activeTab === 'pwa' && (
            <div className="space-y-4">
              <div className="p-5 rounded-2xl bg-purple-50/50 dark:bg-purple-950/20 border border-purple-100 dark:border-purple-900/40 space-y-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-purple-600 text-white flex items-center justify-center">
                    <Laptop className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-black text-gray-900 dark:text-white">
                      {t('ডেস্কটপ ও ল্যাপটপে ইনস্টল করুন (Web PWA)', 'Install Desktop PWA Web App')}
                    </h4>
                    <span className="text-[11px] text-purple-600 font-bold">Windows, macOS, ChromeOS & Linux</span>
                  </div>
                </div>

                <p className="text-xs text-gray-600 dark:text-gray-300 leading-relaxed">
                  {t(
                    'কোনো ভারী ইনস্টলেশন ছাড়াই গুগল ক্রোম, এজ কিংবা সাফারি ব্রাউজার থেকে সরাসরি আপনার কম্পিউটারের ডেস্কটপে দেশিবাজার আইকন পিন করুন। অফলাইনেও চলবে!',
                    'Install DeshiBazar as a standalone native desktop app directly from your browser. Zero storage needed and works offline.'
                  )}
                </p>

                <div className="pt-1">
                  <button
                    onClick={() => {
                      showToast(t('ব্রাউজারের অ্যাড্রেস বারের ইনস্টল আইকনে ক্লিক করুন অথবা Ctrl+D দিয়ে বুকমার্ক করুন', 'Click the install icon in your browser address bar or press Ctrl+D to bookmark!'), 'info');
                    }}
                    className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold shadow-md shadow-purple-600/20 active:scale-95 transition-all flex items-center gap-2"
                  >
                    <Download className="w-4 h-4" />
                    <span>{t('ওয়েব অ্যাপ ইনস্টল নির্দেশিকা', 'Install Web App Guide')}</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* SEND LINK VIA SMS / WHATSAPP */}
          <div className="pt-4 border-t border-gray-100 dark:border-gray-700 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-black text-gray-900 dark:text-white flex items-center gap-1.5">
                <Send className="w-3.5 h-3.5 text-emerald-600" />
                <span>{t('মোবাইলে সরাসরি ডাউনলোড লিংক চান?', 'Get Download Link on Your Phone')}</span>
              </h4>
              <span className="text-[10px] text-gray-400 font-semibold">{t('ফ্রি এসএমএস সার্ভিস', 'Free SMS Service')}</span>
            </div>

            <form onSubmit={handleSendSmsLink} className="flex gap-2">
              <div className="relative flex-1">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-gray-400">
                  +880
                </span>
                <input
                  type="tel"
                  value={phoneForSms}
                  onChange={(e) => setPhoneForSms(e.target.value)}
                  placeholder="017XXXXXXXX"
                  className="w-full pl-14 pr-4 py-2.5 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-xs font-bold text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500"
                />
              </div>
              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold active:scale-95 transition-all shrink-0"
              >
                {t('লিংক পাঠান', 'Send Link')}
              </button>
            </form>
          </div>

          {/* 100+ App Themes & Background Color Selector Strip */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-purple-50 via-indigo-50 to-emerald-50 dark:from-gray-800 dark:via-gray-800 dark:to-gray-800 border border-purple-100 dark:border-gray-700 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Palette className="w-4 h-4 text-purple-600 animate-pulse" />
                <h4 className="text-xs font-black text-gray-900 dark:text-white">
                  {t('১০০+ মোবাইল ও পিসি ব্যাকগ্রাউন্ড থিম', '100+ Mobile & Desktop App Themes')}
                </h4>
              </div>
              <button
                onClick={() => {
                  setIsDownloadAppModalOpen(false);
                  openThemeStudio();
                }}
                className="text-[11px] font-bold text-purple-600 dark:text-purple-400 hover:underline flex items-center gap-1"
              >
                <span>{t('সব থিম দেখুন →', 'Open Theme Studio →')}</span>
              </button>
            </div>

            <p className="text-[11px] text-gray-500 dark:text-gray-400">
              {t(
                'যেকোনো একটি থিমে ক্লিক করে সরাসরি মোবাইল অ্যাপের ব্যাকগ্রাউন্ড ও কালার পরিবর্তন করুন:',
                'Switch the mobile app background style live across 112+ curated presets:'
              )}
            </p>

            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
              {allThemes.slice(0, 7).map((th) => {
                const isSelected = currentTheme.id === th.id;
                return (
                  <button
                    key={th.id}
                    onClick={() => setThemeId(th.id)}
                    className={`px-2.5 py-1.5 rounded-xl border text-[11px] font-bold flex items-center gap-1.5 shrink-0 transition-transform ${
                      isSelected
                        ? 'ring-2 ring-purple-600 border-purple-600 scale-105 shadow-sm'
                        : 'border-gray-200 dark:border-gray-700 hover:scale-102'
                    }`}
                    style={{ background: th.bgGradient || th.bgColor, color: th.textColor }}
                  >
                    <span 
                      className="w-2.5 h-2.5 rounded-full border border-black/10"
                      style={{ backgroundColor: th.accentColor }} 
                    />
                    <span>{th.name.split(' ')[0]}</span>
                    {isSelected && <Check className="w-3 h-3 text-emerald-600 stroke-[3]" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Key In-App Benefits Strip */}
          <div className="grid grid-cols-3 gap-2 pt-2 text-center text-xs">
            <div className="p-2.5 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700/60">
              <Bell className="w-4 h-4 mx-auto text-amber-500 mb-1" />
              <span className="text-[10px] font-bold text-gray-800 dark:text-white block">{t('তাৎক্ষণিক নোটিফিকেশন', 'Instant Alerts')}</span>
              <span className="text-[9px] text-gray-400 block">{t('ফ্ল্যাশ সেল ও রাইডার ট্র্যাক', 'Flash sales & rider map')}</span>
            </div>
            <div className="p-2.5 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700/60">
              <Zap className="w-4 h-4 mx-auto text-emerald-500 mb-1" />
              <span className="text-[10px] font-bold text-gray-800 dark:text-white block">{t('১-ট্যাপ চেকআউট', '1-Tap Checkout')}</span>
              <span className="text-[9px] text-gray-400 block">{t('বিকাশ ও নগদ পেমেন্ট', 'bKash & Nagad seamless')}</span>
            </div>
            <div className="p-2.5 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700/60">
              <ShieldCheck className="w-4 h-4 mx-auto text-blue-500 mb-1" />
              <span className="text-[10px] font-bold text-gray-800 dark:text-white block">{t('১০০% নিরাপদ', 'Verified Safe')}</span>
              <span className="text-[9px] text-gray-400 block">{t('ভাইরাস ও ম্যালওয়্যারমুক্ত', 'Clean & privacy secured')}</span>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-gray-50 dark:bg-gray-800 border-t border-gray-100 dark:border-gray-700 flex items-center justify-between text-xs">
          <span className="text-gray-400 text-[11px]">
            {t('দেশিবাজার অ্যাপ সংস্করণ v2.8.4 • ঢাকা, বাংলাদেশ', 'DeshiBazar App v2.8.4 • Dhaka, Bangladesh')}
          </span>
          <button
            onClick={() => setIsDownloadAppModalOpen(false)}
            className="px-4 py-2 rounded-xl text-xs font-bold text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
          >
            {t('বন্ধ করুন', 'Close')}
          </button>
        </div>
      </div>
    </div>
  );
};
