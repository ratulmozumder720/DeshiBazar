import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Download, 
  Smartphone, 
  Tablet, 
  Monitor, 
  Sparkles, 
  Check, 
  X, 
  ShoppingBag, 
  Flame, 
  FileCode2,
  Info
} from 'lucide-react';
import { ThemeZipOptions, generateEcommerceThemeZip } from '../utils/themeZipGenerator';

export interface ThemePreset {
  id: string;
  name: string;
  nameBn: string;
  description: string;
  options: ThemeZipOptions;
}

export const THEME_PRESETS: ThemePreset[] = [
  {
    id: 'deshi-emerald',
    name: 'Deshi Heritage Emerald',
    nameBn: 'দেশি হেরিটেজ এমারেল্ড ও গোল্ড',
    description: 'Traditional Bangladeshi marketplace aesthetic with royal emerald, warm mustard, and crisp clean cards.',
    options: {
      themeName: 'Deshi Heritage Emerald',
      themeId: 'deshi-emerald',
      storeName: 'DeshiBazar Marketplace',
      storeTagline: 'দেশি পণ্য, সবার বাজার',
      primaryColor: '#059669',
      accentColor: '#f59e0b',
      bgColor: '#f8fafc',
      cardBg: '#ffffff',
      textColor: '#0f172a',
      textMuted: '#64748b',
      borderColor: '#e2e8f0',
      borderRadius: '16px',
      currencySymbol: '৳',
      isDarkMode: false
    }
  },
  {
    id: 'minimal-luxe',
    name: 'Modern Minimalist Luxe',
    nameBn: 'মডার্ন মিনিমালিস্ট লাক্স',
    description: 'Ultra-clean monochrome with razor-sharp typography, sleek slate accents, and subtle borders.',
    options: {
      themeName: 'Modern Minimalist Luxe',
      themeId: 'minimal-luxe',
      storeName: 'Luxe Commerce Studio',
      storeTagline: 'Pure & Minimal Retail',
      primaryColor: '#18181b',
      accentColor: '#3b82f6',
      bgColor: '#fafafa',
      cardBg: '#ffffff',
      textColor: '#09090b',
      textMuted: '#71717a',
      borderColor: '#e4e4e7',
      borderRadius: '12px',
      currencySymbol: '৳',
      isDarkMode: false
    }
  },
  {
    id: 'cyber-neon',
    name: 'Cyber Neon Pulse (OLED)',
    nameBn: 'সাইবার নিয়ন ডার্ক মোড',
    description: 'Immersive dark OLED aesthetic with vibrant cyan, electric violet, and glowing contrast buttons.',
    options: {
      themeName: 'Cyber Neon Pulse',
      themeId: 'cyber-neon',
      storeName: 'CyberTech BD Store',
      storeTagline: 'Next-Gen Electronics & Gear',
      primaryColor: '#06b6d4',
      accentColor: '#ec4899',
      bgColor: '#090d16',
      cardBg: '#111827',
      textColor: '#f9fafb',
      textMuted: '#9ca3af',
      borderColor: '#1f2937',
      borderRadius: '16px',
      currencySymbol: '৳',
      isDarkMode: true
    }
  },
  {
    id: 'pastel-boutique',
    name: 'Pastel Artisan Boutique',
    nameBn: 'প্যাস্টেল অর্গানিক বুটিক',
    description: 'Soft matcha green, gentle terracotta peach, and welcoming warm cream tones for artisanal organics.',
    options: {
      themeName: 'Pastel Artisan Boutique',
      themeId: 'pastel-boutique',
      storeName: 'Artisan Bengal Pantry',
      storeTagline: 'Naturally Grown, Lovingly Made',
      primaryColor: '#0d9488',
      accentColor: '#f97316',
      bgColor: '#fdfbf7',
      cardBg: '#ffffff',
      textColor: '#1c1917',
      textMuted: '#78716c',
      borderColor: '#f5efe6',
      borderRadius: '20px',
      currencySymbol: '৳',
      isDarkMode: false
    }
  },
  {
    id: 'hyper-sale',
    name: 'Supermarket Flash Mega',
    nameBn: 'সুপারমার্কেট মেগা ডিসকাউন্ট',
    description: 'High-conversion retail theme with punchy crimson red badges, gold discount flares, and prominent carts.',
    options: {
      themeName: 'Supermarket Flash Mega',
      themeId: 'hyper-sale',
      storeName: 'MegaBazar Superstore',
      storeTagline: 'Biggest Discounts Every Day',
      primaryColor: '#e11d48',
      accentColor: '#eab308',
      bgColor: '#f8fafc',
      cardBg: '#ffffff',
      textColor: '#0f172a',
      textMuted: '#64748b',
      borderColor: '#e2e8f0',
      borderRadius: '14px',
      currencySymbol: '৳',
      isDarkMode: false
    }
  },
  {
    id: 'royal-jamdani',
    name: 'Royal Velvet & Saffron',
    nameBn: 'রাজকীয় মখমল ও জাফরান',
    description: 'Regal crimson and warm gold luxury palette crafted for bridal sarees, gold ornaments, and silk.',
    options: {
      themeName: 'Royal Velvet & Saffron',
      themeId: 'royal-jamdani',
      storeName: 'Dhakai Heritage Saree',
      storeTagline: 'Centuries of Bengal Weaving',
      primaryColor: '#7c2d12',
      accentColor: '#eab308',
      bgColor: '#fffbeb',
      cardBg: '#ffffff',
      textColor: '#451a03',
      textMuted: '#78350f',
      borderColor: '#fde68a',
      borderRadius: '18px',
      currencySymbol: '৳',
      isDarkMode: false
    }
  }
];

interface EcommerceThemeStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const EcommerceThemeStudioModal: React.FC<EcommerceThemeStudioModalProps> = ({
  isOpen,
  onClose
}) => {
  const { t, showToast, setCustomTheme } = useApp();

  const [selectedPresetId, setSelectedPresetId] = useState<string>('deshi-emerald');
  const [devicePreview, setDevicePreview] = useState<'mobile' | 'tablet' | 'desktop'>('mobile');
  const [activeTab, setActiveTab] = useState<'presets' | 'customize' | 'export'>('presets');
  const [isDownloading, setIsDownloading] = useState<boolean>(false);

  // Active Theme Options State
  const [themeOptions, setThemeOptions] = useState<ThemeZipOptions>(THEME_PRESETS[0].options);

  // Simulated in-preview interactions
  const [simCartCount, setSimCartCount] = useState<number>(2);
  const [simFilterCat, setSimFilterCat] = useState<string>('All');
  const [simSearchQuery, setSimSearchQuery] = useState<string>('');

  if (!isOpen) return null;

  const handleSelectPreset = (preset: ThemePreset) => {
    setSelectedPresetId(preset.id);
    setThemeOptions({ ...preset.options });
  };

  const handleApplyToLiveSite = () => {
    setCustomTheme({
      name: themeOptions.themeName || 'Custom Theme',
      nameBn: themeOptions.themeName || 'কাস্টম থিম',
      bgColor: themeOptions.bgColor || '#f8fafc',
      surfaceColor: themeOptions.cardBg || '#ffffff',
      surfaceBorder: themeOptions.borderColor || '#e2e8f0',
      headerBg: themeOptions.cardBg || '#ffffff',
      textColor: themeOptions.textColor || '#0f172a',
      accentColor: themeOptions.primaryColor || '#059669',
      accentHover: (themeOptions.primaryColor || '#059669') + 'dd',
      accentText: '#ffffff',
      mode: themeOptions.isDarkMode ? 'dark' : 'light'
    });
    showToast(
      t(`থিম "${themeOptions.themeName}" সফলভাবে লাইভ সাইটে প্রযোজ্য হয়েছে!`, `Theme "${themeOptions.themeName}" applied to live site!`),
      'success'
    );
  };

  const handleDownloadZip = async () => {
    setIsDownloading(true);
    try {
      // 1. Try Backend Download Endpoint first
      const response = await fetch('/api/theme/download-zip', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(themeOptions)
      });

      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        const filename = (themeOptions.themeName || 'deshibazar-theme')
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, '-')
          .replace(/(^-|-$)/g, '') + '.zip';
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        a.remove();
        window.URL.revokeObjectURL(url);
        showToast(t('ই-কমার্স থিম জিপ ফাইল সফলভাবে ডাউনলোড হয়েছে!', 'E-Commerce Theme ZIP downloaded successfully from backend!'), 'success');
        return;
      }

      // 2. Client-side fallback via JSZip
      const zip = await generateEcommerceThemeZip(themeOptions);
      const content = await zip.generateAsync({ type: 'blob' });
      const url = window.URL.createObjectURL(content);
      const a = document.createElement('a');
      const filename = (themeOptions.themeName || 'deshibazar-theme')
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '') + '.zip';
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
      showToast(t('ই-কমার্স থিম জিপ ফাইল তৈরি ও ডাউনলোড হয়েছে!', 'E-Commerce Theme ZIP created and downloaded!'), 'success');
    } catch (err: any) {
      console.error(err);
      showToast(t('ডাউনলোড ব্যর্থ হয়েছে। আবার চেষ্টা করুন।', 'Failed to download theme ZIP.'), 'error');
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/70 backdrop-blur-xs overflow-y-auto animate-fade-in">
      <div className="relative w-full max-w-6xl bg-white dark:bg-gray-900 rounded-3xl shadow-2xl border border-gray-100 dark:border-gray-800 overflow-hidden my-4 flex flex-col max-h-[92vh]">
        
        {/* Modal Top Header */}
        <div className="p-4 sm:p-6 bg-gradient-to-r from-emerald-700 via-teal-800 to-cyan-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/15 flex items-center justify-center backdrop-blur-xs border border-white/20">
              <Sparkles className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black tracking-tight">
                  {t('ই-কমার্স থিম স্টুডিও ও মোবাইল রেসপনসিভ বিল্ডার', 'E-Commerce Theme Studio & Mobile Responsive Builder')}
                </h2>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-400 text-gray-900 uppercase">
                  HTML ZIP Ready
                </span>
              </div>
              <p className="text-xs text-emerald-100">
                {t('রেসপনসিভ ই-কমার্স থিম তৈরি করুন, মোবাইলে টেস্ট করুন এবং ব্যাকএন্ড থেকে জিপ ফাইল ডাউনলোড করুন।', 'Design mobile responsive themes, preview live, and download full backend HTML ZIP bundle.')}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadZip}
              disabled={isDownloading}
              className="hidden sm:inline-flex items-center gap-2 px-4 py-2 bg-amber-400 hover:bg-amber-300 text-gray-950 rounded-xl text-xs font-black shadow-md transition-all active:scale-95 disabled:opacity-50"
            >
              <Download className={`w-4 h-4 ${isDownloading ? 'animate-bounce' : ''}`} />
              <span>{isDownloading ? t('ডাউনলোড হচ্ছে...', 'Generating...') : t('ডাউনলোড HTML ZIP', 'Download HTML ZIP')}</span>
            </button>

            <button
              onClick={onClose}
              className="w-9 h-9 rounded-2xl bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Studio Content Layout: Left Controls + Right Live Preview */}
        <div className="grid grid-cols-1 lg:grid-cols-12 flex-1 overflow-hidden">
          
          {/* LEFT COLUMN: Controls & Settings */}
          <div className="lg:col-span-5 border-r border-gray-100 dark:border-gray-800 p-4 sm:p-6 overflow-y-auto flex flex-col gap-5 bg-gray-50/50 dark:bg-gray-900/50">
            
            {/* Tabs */}
            <div className="flex items-center gap-1 bg-gray-200/80 dark:bg-gray-800 p-1 rounded-2xl text-xs font-bold">
              <button
                onClick={() => setActiveTab('presets')}
                className={`flex-1 py-2 rounded-xl transition-all ${
                  activeTab === 'presets'
                    ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-xs'
                    : 'text-gray-600 dark:text-gray-400 hover:text-gray-900'
                }`}
              >
                <span>{t('রেডিমেড থিমস', 'Curated Themes')}</span>
              </button>
              <button
                onClick={() => setActiveTab('customize')}
                className={`flex-1 py-2 rounded-xl transition-all ${
                  activeTab === 'customize'
                    ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-xs'
                    : 'text-gray-600 dark:text-gray-400 hover:text-gray-900'
                }`}
              >
                <span>{t('কালার ও স্টাইল', 'Color Studio')}</span>
              </button>
              <button
                onClick={() => setActiveTab('export')}
                className={`flex-1 py-2 rounded-xl transition-all ${
                  activeTab === 'export'
                    ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-xs'
                    : 'text-gray-600 dark:text-gray-400 hover:text-gray-900'
                }`}
              >
                <span>{t('জিপ ডাউনলোড', 'ZIP Files')}</span>
              </button>
            </div>

            {/* TAB 1: CURATED PRESETS */}
            {activeTab === 'presets' && (
              <div className="space-y-3">
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  {t('যেকোনো রেডিমেড রেসপনসিভ থিম নির্বাচন করুন:', 'Select a pre-tuned mobile responsive design:')}
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-2.5">
                  {THEME_PRESETS.map((preset) => {
                    const isSelected = selectedPresetId === preset.id;
                    return (
                      <div
                        key={preset.id}
                        onClick={() => handleSelectPreset(preset)}
                        className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                          isSelected
                            ? 'bg-emerald-50/80 dark:bg-emerald-950/40 border-emerald-500 ring-2 ring-emerald-500/20 shadow-xs'
                            : 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700 hover:border-gray-300'
                        }`}
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <div 
                            className="w-10 h-10 rounded-xl shrink-0 flex items-center justify-center shadow-xs border border-black/10"
                            style={{ 
                              background: preset.options.primaryColor,
                              color: '#ffffff'
                            }}
                          >
                            <div 
                              className="w-4 h-4 rounded-full border border-white"
                              style={{ background: preset.options.accentColor }}
                            />
                          </div>
                          <div className="min-w-0">
                            <span className="text-xs font-black text-gray-900 dark:text-white block truncate">
                              {t(preset.nameBn, preset.name)}
                            </span>
                            <span className="text-[11px] text-gray-500 dark:text-gray-400 block truncate">
                              {preset.description}
                            </span>
                          </div>
                        </div>

                        {isSelected && (
                          <div className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0">
                            <Check className="w-3.5 h-3.5" />
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* TAB 2: COLOR & BRAND CUSTOMIZER */}
            {activeTab === 'customize' && (
              <div className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-gray-700 dark:text-gray-300 block mb-1">
                    {t('স্টোর নাম ও ট্যাগলাইন', 'Store Brand Name')}
                  </label>
                  <input
                    type="text"
                    value={themeOptions.storeName || ''}
                    onChange={(e) => setThemeOptions({ ...themeOptions, storeName: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white font-medium"
                    placeholder="e.g. DeshiBazar Commerce"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-bold text-gray-700 dark:text-gray-300 block mb-1">
                      {t('প্রাইমারি ব্র্যান্ড কালার', 'Primary Brand Color')}
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={themeOptions.primaryColor || '#059669'}
                        onChange={(e) => setThemeOptions({ ...themeOptions, primaryColor: e.target.value })}
                        className="w-8 h-8 rounded-lg cursor-pointer border-0 p-0"
                      />
                      <input
                        type="text"
                        value={themeOptions.primaryColor || '#059669'}
                        onChange={(e) => setThemeOptions({ ...themeOptions, primaryColor: e.target.value })}
                        className="w-full px-2 py-1.5 text-xs font-mono rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-700 dark:text-gray-300 block mb-1">
                      {t('অ্যাকসেন্ট / হাইলাইট কালার', 'Accent Badge Color')}
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={themeOptions.accentColor || '#f59e0b'}
                        onChange={(e) => setThemeOptions({ ...themeOptions, accentColor: e.target.value })}
                        className="w-8 h-8 rounded-lg cursor-pointer border-0 p-0"
                      />
                      <input
                        type="text"
                        value={themeOptions.accentColor || '#f59e0b'}
                        onChange={(e) => setThemeOptions({ ...themeOptions, accentColor: e.target.value })}
                        className="w-full px-2 py-1.5 text-xs font-mono rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800"
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-bold text-gray-700 dark:text-gray-300 block mb-1">
                      {t('পেজ ব্যাকগ্রাউন্ড', 'Page Background')}
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={themeOptions.bgColor || '#f8fafc'}
                        onChange={(e) => setThemeOptions({ ...themeOptions, bgColor: e.target.value })}
                        className="w-8 h-8 rounded-lg cursor-pointer border-0 p-0"
                      />
                      <input
                        type="text"
                        value={themeOptions.bgColor || '#f8fafc'}
                        onChange={(e) => setThemeOptions({ ...themeOptions, bgColor: e.target.value })}
                        className="w-full px-2 py-1.5 text-xs font-mono rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-700 dark:text-gray-300 block mb-1">
                      {t('কার্ড সারফেস কালার', 'Card Surface')}
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={themeOptions.cardBg || '#ffffff'}
                        onChange={(e) => setThemeOptions({ ...themeOptions, cardBg: e.target.value })}
                        className="w-8 h-8 rounded-lg cursor-pointer border-0 p-0"
                      />
                      <input
                        type="text"
                        value={themeOptions.cardBg || '#ffffff'}
                        onChange={(e) => setThemeOptions({ ...themeOptions, cardBg: e.target.value })}
                        className="w-full px-2 py-1.5 text-xs font-mono rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800"
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-bold text-gray-700 dark:text-gray-300 block mb-1">
                      {t('কার্ড রাউন্ডেড ব্যাসার্ধ', 'Card Corner Radius')}
                    </label>
                    <select
                      value={themeOptions.borderRadius || '16px'}
                      onChange={(e) => setThemeOptions({ ...themeOptions, borderRadius: e.target.value })}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white font-medium"
                    >
                      <option value="6px">Sharp (6px)</option>
                      <option value="12px">Classic (12px)</option>
                      <option value="16px">Smooth Modern (16px)</option>
                      <option value="24px">Curved Pill (24px)</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-700 dark:text-gray-300 block mb-1">
                      {t('মুদ্রা প্রতীক', 'Currency Symbol')}
                    </label>
                    <select
                      value={themeOptions.currencySymbol || '৳'}
                      onChange={(e) => setThemeOptions({ ...themeOptions, currencySymbol: e.target.value })}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white font-medium"
                    >
                      <option value="৳">৳ BDT (Taka)</option>
                      <option value="$">$ USD (Dollar)</option>
                      <option value="€">€ EUR (Euro)</option>
                      <option value="£">£ GBP (Pound)</option>
                      <option value="₹">₹ INR (Rupee)</option>
                      <option value="﷼">﷼ SAR (Riyal)</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 3: EXPORT & ZIP OVERVIEW */}
            {activeTab === 'export' && (
              <div className="space-y-4">
                <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800">
                  <h4 className="text-xs font-black text-emerald-800 dark:text-emerald-300 flex items-center gap-1.5 mb-1">
                    <FileCode2 className="w-4 h-4" />
                    <span>{t('জিপ প্যাকেজে যা যা অন্তর্ভুক্ত:', 'Files inside HTML ZIP bundle:')}</span>
                  </h4>
                  <ul className="text-[11px] text-gray-600 dark:text-gray-300 space-y-1 ml-4 list-disc mt-2">
                    <li><code className="text-emerald-700 font-bold">index.html</code> - Mobile-friendly home storefront</li>
                    <li><code className="text-emerald-700 font-bold">shop.html</code> - Product catalogue with instant filter</li>
                    <li><code className="text-emerald-700 font-bold">cart.html</code> - Checkout page with payment simulation</li>
                    <li><code className="text-emerald-700 font-bold">css/styles.css</code> - Responsive CSS with dynamic variables</li>
                    <li><code className="text-emerald-700 font-bold">js/store.js</code> - Full cart, search, toast & timer engine</li>
                    <li><code className="text-emerald-700 font-bold">theme-config.json</code> - Palette metadata and setup</li>
                    <li><code className="text-emerald-700 font-bold">README.md</code> - One-click deployment instructions</li>
                  </ul>
                </div>

                <div className="p-3.5 rounded-2xl bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 text-[11px] text-blue-800 dark:text-blue-300 flex items-start gap-2">
                  <Info className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>
                    {t(
                      'এটি কোনো বিল্ড টুল বা সার্ভার ছাড়াও যেকোনো ব্রাউজার, Netlify, Vercel, cPanel বা GitHub Pages-এ সরাসরি চলবে।',
                      'This template runs standalone in any browser with zero node_modules or build step needed. Ready for Netlify, Vercel, or cPanel.'
                    )}
                  </span>
                </div>
              </div>
            )}

            {/* Bottom Controls Buttons */}
            <div className="mt-auto pt-4 border-t border-gray-200 dark:border-gray-800 space-y-2">
              <button
                onClick={handleDownloadZip}
                disabled={isDownloading}
                className="w-full py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-gray-950 font-black text-xs rounded-2xl shadow-md flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50"
              >
                <Download className={`w-4 h-4 ${isDownloading ? 'animate-bounce' : ''}`} />
                <span>
                  {isDownloading 
                    ? t('ব্যাকএন্ড জিপ তৈরি হচ্ছে...', 'Building backend ZIP bundle...') 
                    : t('ব্যাকএন্ড থেকে HTML ZIP ডাউনলোড করুন', 'Download Backend HTML ZIP')}
                </span>
              </button>

              <button
                onClick={handleApplyToLiveSite}
                className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-2xl shadow-xs flex items-center justify-center gap-2 transition-all"
              >
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>{t('লাইভ সাইটে এই থিম সেট করুন', 'Apply Live to Current Store')}</span>
              </button>
            </div>
          </div>

          {/* RIGHT COLUMN: Live Interactive Responsive Preview */}
          <div className="lg:col-span-7 p-4 sm:p-6 flex flex-col bg-gray-100 dark:bg-gray-950 overflow-hidden">
            
            {/* Viewport Device Switcher Toolbar */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <span className="text-xs font-black text-gray-800 dark:text-gray-200">
                  {t('লাইভ রেসপনসিভ প্রিভিউ:', 'Device Preview:')}
                </span>
                <span className="text-[11px] text-gray-500">
                  {devicePreview === 'mobile' ? '375px Phone' : devicePreview === 'tablet' ? '768px Tablet' : 'Full Desktop'}
                </span>
              </div>

              <div className="flex items-center gap-1 bg-white dark:bg-gray-800 p-1 rounded-xl shadow-xs border border-gray-200 dark:border-gray-700">
                <button
                  onClick={() => setDevicePreview('mobile')}
                  className={`p-1.5 rounded-lg text-xs font-bold flex items-center gap-1 transition-all ${
                    devicePreview === 'mobile'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                  }`}
                  title="Mobile 375px"
                >
                  <Smartphone className="w-4 h-4" />
                  <span className="hidden sm:inline">Mobile</span>
                </button>

                <button
                  onClick={() => setDevicePreview('tablet')}
                  className={`p-1.5 rounded-lg text-xs font-bold flex items-center gap-1 transition-all ${
                    devicePreview === 'tablet'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                  }`}
                  title="Tablet 768px"
                >
                  <Tablet className="w-4 h-4" />
                  <span className="hidden sm:inline">Tablet</span>
                </button>

                <button
                  onClick={() => setDevicePreview('desktop')}
                  className={`p-1.5 rounded-lg text-xs font-bold flex items-center gap-1 transition-all ${
                    devicePreview === 'desktop'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                  }`}
                  title="Desktop 100%"
                >
                  <Monitor className="w-4 h-4" />
                  <span className="hidden sm:inline">Desktop</span>
                </button>
              </div>
            </div>

            {/* PREVIEW CONTAINER */}
            <div className="flex-1 flex items-center justify-center overflow-auto p-2">
              <div 
                className={`transition-all duration-300 overflow-hidden shadow-2xl border flex flex-col relative ${
                  devicePreview === 'mobile'
                    ? 'w-[360px] h-[580px] rounded-[36px] border-8 border-gray-800 shadow-2xl bg-white dark:bg-gray-900 ring-1 ring-black/20'
                    : devicePreview === 'tablet'
                    ? 'w-[640px] h-[580px] rounded-[24px] border-4 border-gray-700 shadow-xl bg-white dark:bg-gray-900'
                    : 'w-full h-full max-h-[580px] rounded-2xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900'
                }`}
                style={{
                  backgroundColor: themeOptions.bgColor || '#f8fafc',
                  color: themeOptions.textColor || '#0f172a'
                }}
              >
                {/* Mobile Speaker / Camera Notch if mobile frame */}
                {devicePreview === 'mobile' && (
                  <div className="h-5 bg-gray-800 w-full flex items-center justify-center shrink-0">
                    <div className="w-16 h-3 bg-black rounded-full" />
                  </div>
                )}

                {/* Simulated Header */}
                <div 
                  className="px-4 py-3 border-b flex items-center justify-between shrink-0 shadow-xs"
                  style={{ 
                    backgroundColor: themeOptions.cardBg || '#ffffff',
                    borderColor: themeOptions.borderColor || '#e2e8f0'
                  }}
                >
                  <div className="flex items-center gap-2">
                    <div 
                      className="w-7 h-7 rounded-lg flex items-center justify-center text-white font-black text-xs"
                      style={{ background: themeOptions.primaryColor }}
                    >
                      DB
                    </div>
                    <span className="font-extrabold text-xs truncate max-w-[140px]" style={{ color: themeOptions.primaryColor }}>
                      {themeOptions.storeName || 'DeshiBazar'}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <div 
                      className="relative p-1.5 rounded-lg cursor-pointer"
                      onClick={() => setSimCartCount(prev => prev + 1)}
                    >
                      <ShoppingBag className="w-4 h-4" style={{ color: themeOptions.textColor }} />
                      <span 
                        className="absolute -top-1 -right-1 text-[9px] font-bold text-white w-4 h-4 rounded-full flex items-center justify-center"
                        style={{ background: themeOptions.accentColor }}
                      >
                        {simCartCount}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Simulated Scrollable Body */}
                <div className="flex-1 overflow-y-auto p-3 space-y-3">
                  
                  {/* Simulated Search bar */}
                  <div 
                    className="px-3 py-1.5 rounded-xl border flex items-center gap-2 text-xs"
                    style={{ 
                      backgroundColor: themeOptions.cardBg, 
                      borderColor: themeOptions.borderColor,
                      color: themeOptions.textMuted
                    }}
                  >
                    <span>🔍</span>
                    <input 
                      type="text" 
                      placeholder="Search rice, honey, fish..." 
                      className="bg-transparent border-0 outline-none w-full text-[11px]" 
                      value={simSearchQuery}
                      onChange={(e) => setSimSearchQuery(e.target.value)}
                    />
                  </div>

                  {/* Simulated Hero Card */}
                  <div 
                    className="p-4 rounded-2xl text-white relative overflow-hidden shadow-sm"
                    style={{ 
                      background: `linear-gradient(135deg, ${themeOptions.primaryColor} 0%, #064e3b 100%)`,
                      borderRadius: themeOptions.borderRadius
                    }}
                  >
                    <span 
                      className="text-[9px] font-extrabold px-2 py-0.5 rounded-full inline-block mb-1"
                      style={{ background: themeOptions.accentColor, color: '#fff' }}
                    >
                      LIMITED PROMO
                    </span>
                    <h3 className="font-black text-sm leading-tight">Fresh Bengal River Hilsha & Mustard Oil</h3>
                    <p className="text-[10px] opacity-85 mt-1">Free delivery on orders over {themeOptions.currencySymbol}1,500</p>
                  </div>

                  {/* Simulated Category Pills */}
                  <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none text-[11px] font-bold">
                    {['All', 'Groceries', 'Fish & Meat', 'Fashion'].map((c) => (
                      <button
                        key={c}
                        onClick={() => setSimFilterCat(c)}
                        className="px-2.5 py-1 rounded-full whitespace-nowrap border transition-colors"
                        style={{
                          background: simFilterCat === c ? themeOptions.primaryColor : themeOptions.cardBg,
                          color: simFilterCat === c ? '#ffffff' : themeOptions.textColor,
                          borderColor: simFilterCat === c ? themeOptions.primaryColor : themeOptions.borderColor
                        }}
                      >
                        {c}
                      </button>
                    ))}
                  </div>

                  {/* Simulated Flash Sale Countdown */}
                  <div 
                    className="p-2 rounded-xl flex items-center justify-between text-[11px] border"
                    style={{ background: '#fef2f2', borderColor: '#fecaca', color: '#dc2626' }}
                  >
                    <div className="flex items-center gap-1 font-bold">
                      <Flame className="w-3.5 h-3.5 fill-red-500" />
                      <span>Flash Sale Deals</span>
                    </div>
                    <span className="font-mono font-bold bg-red-600 text-white px-1.5 py-0.5 rounded text-[10px]">
                      11:42:18
                    </span>
                  </div>

                  {/* Simulated Products Grid (2 cols) */}
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      {
                        name: 'Sundarbans Wild Honey',
                        price: 450,
                        oldPrice: 550,
                        img: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=300&q=80',
                        cat: 'Groceries'
                      },
                      {
                        name: 'Padma Fresh Hilsha',
                        price: 1850,
                        oldPrice: 2200,
                        img: 'https://images.unsplash.com/photo-1544943910-4c1dc44a0551?auto=format&fit=crop&w=300&q=80',
                        cat: 'Fish & Meat'
                      },
                      {
                        name: 'Tangail Handloom Gamcha',
                        price: 380,
                        oldPrice: 450,
                        img: 'https://images.unsplash.com/photo-1606744824163-985d376605aa?auto=format&fit=crop&w=300&q=80',
                        cat: 'Fashion'
                      },
                      {
                        name: 'Cold-Pressed Mustard Oil',
                        price: 280,
                        oldPrice: 320,
                        img: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?auto=format&fit=crop&w=300&q=80',
                        cat: 'Groceries'
                      }
                    ]
                      .filter(p => simFilterCat === 'All' || p.cat === simFilterCat)
                      .slice(0, 4)
                      .map((p, idx) => (
                        <div
                          key={idx}
                          className="border overflow-hidden shadow-xs flex flex-col justify-between"
                          style={{
                            background: themeOptions.cardBg,
                            borderColor: themeOptions.borderColor,
                            borderRadius: themeOptions.borderRadius
                          }}
                        >
                          <div className="aspect-square bg-gray-100 relative overflow-hidden">
                            <img src={p.img} alt={p.name} className="w-full h-full object-cover" />
                            <span className="absolute top-1.5 left-1.5 bg-red-600 text-white text-[9px] font-black px-1.5 py-0.5 rounded">
                              -20%
                            </span>
                          </div>
                          <div className="p-2 flex flex-col flex-1 justify-between">
                            <div>
                              <span className="text-[9px] text-gray-400 uppercase font-semibold">{p.cat}</span>
                              <h4 className="text-[11px] font-bold line-clamp-1 mt-0.5">{p.name}</h4>
                            </div>
                            <div className="mt-2 flex items-baseline justify-between">
                              <span className="text-xs font-black" style={{ color: themeOptions.primaryColor }}>
                                {themeOptions.currencySymbol}{p.price}
                              </span>
                              <span className="text-[9px] text-gray-400 line-through">
                                {themeOptions.currencySymbol}{p.oldPrice}
                              </span>
                            </div>
                            <button
                              onClick={() => {
                                setSimCartCount(prev => prev + 1);
                                showToast(t(`পণ্যটি কার্টে যোগ করা হয়েছে (+1)`, `Added to cart (+1)`), 'info');
                              }}
                              className="w-full mt-2 py-1 text-[10px] font-bold text-white rounded-lg flex items-center justify-center gap-1 transition-transform active:scale-95"
                              style={{ background: themeOptions.primaryColor }}
                            >
                              + Add to Cart
                            </button>
                          </div>
                        </div>
                      ))}
                  </div>

                </div>

                {/* Simulated Mobile Bottom Bar (If mobile view) */}
                {devicePreview === 'mobile' && (
                  <div 
                    className="h-14 border-t flex items-center justify-around text-[10px] font-bold shrink-0 px-2"
                    style={{ 
                      backgroundColor: themeOptions.cardBg,
                      borderColor: themeOptions.borderColor,
                      color: themeOptions.textMuted
                    }}
                  >
                    <div className="flex flex-col items-center" style={{ color: themeOptions.primaryColor }}>
                      <span>🏠</span>
                      <span>Home</span>
                    </div>
                    <div className="flex flex-col items-center">
                      <span>🛍️</span>
                      <span>Shop</span>
                    </div>
                    <div className="flex flex-col items-center relative">
                      <span>🛒</span>
                      <span>Cart</span>
                      <span 
                        className="absolute -top-1 right-1 w-3.5 h-3.5 text-[8px] font-black text-white rounded-full flex items-center justify-center"
                        style={{ background: themeOptions.accentColor }}
                      >
                        {simCartCount}
                      </span>
                    </div>
                    <div className="flex flex-col items-center">
                      <span>👤</span>
                      <span>Profile</span>
                    </div>
                  </div>
                )}
              </div>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
