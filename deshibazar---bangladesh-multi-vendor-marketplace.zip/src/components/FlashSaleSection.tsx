import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { ProductCard } from './ProductCard';
import { Flame, Clock, ArrowRight } from 'lucide-react';

export const FlashSaleSection: React.FC = () => {
  const { t, products, setCurrentView } = useApp();

  // 12-hour countdown timer simulation
  const [timeLeft, setTimeLeft] = useState({
    hours: 11,
    minutes: 42,
    seconds: 18
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 };
        }
        return { hours: 12, minutes: 0, seconds: 0 };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const flashProducts = products.filter(p => p.isFlashSale).slice(0, 4);

  return (
    <section className="py-12 bg-rose-50/40 dark:bg-rose-950/20 border-b border-rose-100 dark:border-rose-900/30 transition-colors">
      <div className="max-w-7xl mx-auto px-4">
        {/* Section Header with Countdown Timer */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-2 text-rose-600 dark:text-rose-400 text-xs font-black uppercase tracking-wider mb-1">
              <Flame className="w-4 h-4 fill-rose-500 text-rose-500 animate-bounce" />
              <span>{t('সীমিত সময়ের বিশেষ অফার', 'Limited Time Mega Savings')}</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white tracking-tight">
              {t('আজকের ফ্ল্যাশ সেল', 'Flash Sale Deals')}
            </h2>
          </div>

          <div className="flex items-center gap-3">
            {/* Countdown Clock */}
            <div className="flex items-center gap-1.5 bg-white dark:bg-gray-800 px-3.5 py-2 rounded-2xl shadow-sm border border-rose-200 dark:border-rose-800 text-gray-900 dark:text-white">
              <Clock className="w-4 h-4 text-rose-500" />
              <span className="text-xs text-gray-400 font-medium mr-1 hidden sm:inline">
                {t('বাকি সময়:', 'Ends in:')}
              </span>
              <div className="flex items-center gap-1 font-mono font-bold text-sm">
                <span className="bg-rose-500 text-white px-2 py-0.5 rounded-md">
                  {String(timeLeft.hours).padStart(2, '0')}
                </span>
                <span className="text-rose-500">:</span>
                <span className="bg-rose-500 text-white px-2 py-0.5 rounded-md">
                  {String(timeLeft.minutes).padStart(2, '0')}
                </span>
                <span className="text-rose-500">:</span>
                <span className="bg-rose-500 text-white px-2 py-0.5 rounded-md">
                  {String(timeLeft.seconds).padStart(2, '0')}
                </span>
              </div>
            </div>

            <button
              onClick={() => setCurrentView('shop')}
              className="hidden md:flex items-center gap-1.5 text-xs font-bold text-rose-600 dark:text-rose-400 hover:text-rose-700 transition-colors"
            >
              <span>{t('সব অফার দেখুন', 'View All Deals')}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Product Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-6">
          {flashProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        {/* Mobile View All Deals Button */}
        <div className="mt-6 text-center md:hidden">
          <button
            onClick={() => setCurrentView('shop')}
            className="w-full py-3 bg-white dark:bg-gray-800 border border-rose-300 dark:border-rose-800 text-rose-600 dark:text-rose-400 rounded-xl text-xs font-bold shadow-sm flex items-center justify-center gap-1.5"
          >
            <span>{t('সব ফ্ল্যাশ ডিল দেখুন', 'View All Deals')}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </section>
  );
};
