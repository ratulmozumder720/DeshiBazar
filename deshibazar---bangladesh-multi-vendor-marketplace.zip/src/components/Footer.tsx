import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  Phone, 
  Mail, 
  MapPin, 
  ShieldCheck, 
  Truck, 
  RotateCcw, 
  Award, 
  Facebook,
  Youtube,
  Instagram,
  Clock,
  Smartphone,
  Download,
  Sparkles,
  Star,
  CheckCircle2
} from 'lucide-react';
import { DESHIBAZAR_CONTACT } from '../data/contactConfig';

export const Footer: React.FC = () => {
  const { t, setCurrentView, setSelectedCategory, openDownloadAppModal } = useApp();

  return (
    <footer className="bg-gray-900 text-gray-300 pt-12 pb-24 md:pb-12 border-t border-gray-800 transition-colors">
      {/* 1. Value Propositions Strip */}
      <div className="max-w-7xl mx-auto px-4 pb-12 border-b border-gray-800">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-950/80 border border-emerald-800/60 flex items-center justify-center text-emerald-400 shrink-0">
              <Truck className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                {t('সারা দেশে ডেলিভারি', 'Nationwide Delivery')}
              </h4>
              <p className="text-[11px] text-gray-400">
                {t('ঢাকায় ২৪ ঘণ্টায় ও জেলায় ২-৩ দিনে', '24h in Dhaka, 2-3 days outside')}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-950/80 border border-amber-800/60 flex items-center justify-center text-amber-400 shrink-0">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                {t('১০০% খাঁটি ও নিরাপদ', '100% Pure & Safe')}
              </h4>
              <p className="text-[11px] text-gray-400">
                {t('রাসায়নিকমুক্ত ও ভেরিফাইড বিক্রেতা', 'Chemical-free & vetted sellers')}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-blue-950/80 border border-blue-800/60 flex items-center justify-center text-blue-400 shrink-0">
              <RotateCcw className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                {t('সহজ রিটার্ন পলিসি', 'Easy 7-Day Returns')}
              </h4>
              <p className="text-[11px] text-gray-400">
                {t('পণ্য পছন্দ না হলে তাৎক্ষণিক পরিবর্তন', 'Hassle-free replacement policy')}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-rose-950/80 border border-rose-800/60 flex items-center justify-center text-rose-400 shrink-0">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                {t('দেশি উদ্যোক্তা সহায়তা', 'Empowering Locals')}
              </h4>
              <p className="text-[11px] text-gray-400">
                {t('স্থানীয় কৃষক ও তাঁতিদের প্রত্যক্ষ বাজার', 'Direct market for artisans')}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 py-12 grid grid-cols-1 md:grid-cols-5 gap-8">
        {/* Brand & About */}
        <div className="md:col-span-2 space-y-4">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-emerald-500 flex items-center justify-center text-white shadow-lg">
              <span className="text-xl font-bold">দ</span>
            </div>
            <span className="text-2xl font-black tracking-tight text-white">
              Deshi<span className="text-amber-400">Bazar</span>
            </span>
          </div>

          <p className="text-xs text-gray-400 leading-relaxed max-w-sm">
            {t(
              'দেশিবাজার হলো বাংলাদেশের একটি আধুনিক বহুমুখী অনলাইন প্ল্যাটফর্ম। এখানে পাবেন কৃষক ও কারিগরদের উৎপাদিত খাঁটি খাদ্যপণ্য, ঐতিহ্যবাহী দেশি হস্তশিল্প, ফ্যাশন ও ইলেকট্রনিক্স।',
              'DeshiBazar is Bangladesh\'s modern multi-vendor marketplace connecting local farmers, traditional weavers, and certified brands directly to consumers across the country.'
            )}
          </p>

          <div className="space-y-3 text-xs text-gray-300">
            <div className="flex items-start gap-2.5">
              <MapPin className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <span className="text-white font-semibold block">
                  {t(DESHIBAZAR_CONTACT.location.bn, DESHIBAZAR_CONTACT.location.en)}
                </span>
                <span className="text-[11px] text-gray-400 block mt-0.5">
                  {t(DESHIBAZAR_CONTACT.hubLocation.bn, DESHIBAZAR_CONTACT.hubLocation.en)}
                </span>
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <Phone className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <a 
                  href={DESHIBAZAR_CONTACT.hotlineTel} 
                  className="font-bold text-amber-400 hover:underline block"
                >
                  {t('হটলাইন: ', 'Hotline: ')}{DESHIBAZAR_CONTACT.hotlineDisplay}
                </a>
                <span className="text-[11px] text-gray-300 block mt-0.5">
                  {t('কল ও হোয়াটসঅ্যাপ: ', 'Call & WhatsApp: ')}
                  <a 
                    href={DESHIBAZAR_CONTACT.phoneTelPrimary} 
                    className="hover:text-emerald-400 font-bold text-white"
                  >
                    {DESHIBAZAR_CONTACT.phonePrimary}
                  </a>
                </span>
                <span className="text-[10px] text-emerald-400 block mt-0.5 flex items-center gap-1">
                  <Clock className="w-3 h-3 inline" />
                  <span>{t(DESHIBAZAR_CONTACT.hours.bn, DESHIBAZAR_CONTACT.hours.en)}</span>
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2.5">
              <Mail className="w-4 h-4 text-blue-400 shrink-0" />
              <a href={`mailto:${DESHIBAZAR_CONTACT.emailSupport}`} className="hover:text-emerald-400 transition-colors">
                {DESHIBAZAR_CONTACT.emailSupport}
              </a>
            </div>
          </div>
        </div>

        {/* Popular Categories */}
        <div>
          <h3 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
            {t('জনপ্রিয় ক্যাটাগরি', 'Top Categories')}
          </h3>
          <ul className="space-y-2 text-xs text-gray-400">
            <li>
              <button 
                onClick={() => { setSelectedCategory('rice-dal-grocery'); setCurrentView('shop'); }}
                className="hover:text-emerald-400 transition-colors"
              >
                {t('চাল, ডাল ও তেল', 'Rice, Dal & Oils')}
              </button>
            </li>
            <li>
              <button 
                onClick={() => { setSelectedCategory('fish-meat'); setCurrentView('shop'); }}
                className="hover:text-emerald-400 transition-colors"
              >
                {t('পদ্মার রূপালী ইলিশ', 'Fresh River Hilsha')}
              </button>
            </li>
            <li>
              <button 
                onClick={() => { setSelectedCategory('deshi-products'); setCurrentView('shop'); }}
                className="hover:text-emerald-400 transition-colors"
              >
                {t('সুন্দরবনের খাঁটি মধু', 'Sundarbans Pure Honey')}
              </button>
            </li>
            <li>
              <button 
                onClick={() => { setSelectedCategory('fashion'); setCurrentView('shop'); }}
                className="hover:text-emerald-400 transition-colors"
              >
                {t('ঢাকাই জামদানি শাড়ি', 'Dhakai Jamdani Sarees')}
              </button>
            </li>
            <li>
              <button 
                onClick={() => { setSelectedCategory('handmade-crafts'); setCurrentView('shop'); }}
                className="hover:text-emerald-400 transition-colors"
              >
                {t('ঐতিহ্যবাহী নকশিকাঁথা', 'Artisan Nakshi Kantha')}
              </button>
            </li>
            <li>
              <button 
                onClick={() => { setSelectedCategory('dairy-eggs'); setCurrentView('shop'); }}
                className="hover:text-emerald-400 transition-colors"
              >
                {t('বগুড়ার স্পেশাল দই', 'Authentic Bogura Doi')}
              </button>
            </li>
          </ul>
        </div>

        {/* Customer Care */}
        <div>
          <h3 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
            {t('গ্রাহক সেবা', 'Customer Service')}
          </h3>
          <ul className="space-y-2 text-xs text-gray-400">
            <li>
              <button 
                onClick={() => openDownloadAppModal('android')} 
                className="text-emerald-400 hover:text-emerald-300 font-bold transition-colors flex items-center gap-1.5"
              >
                <Smartphone className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>{t('অ্যাপ ডাউনলোড (Google Play & App Store)', 'Download Mobile App (iOS & Android)')}</span>
                <span className="px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 text-[9px] font-black uppercase">Mobile</span>
              </button>
            </li>
            <li>
              <button 
                onClick={() => openDownloadAppModal('microsoft')} 
                className="text-sky-400 hover:text-sky-300 font-bold transition-colors flex items-center gap-1.5"
              >
                <svg className="w-3.5 h-3.5 shrink-0" viewBox="0 0 24 24">
                  <rect x="2" y="2" width="9.5" height="9.5" fill="#F25022"/>
                  <rect x="12.5" y="2" width="9.5" height="9.5" fill="#7FBA00"/>
                  <rect x="2" y="12.5" width="9.5" height="9.5" fill="#00A4EF"/>
                  <rect x="12.5" y="12.5" width="9.5" height="9.5" fill="#FFB900"/>
                </svg>
                <span>{t('মাইক্রোসফট স্টোর অ্যাপ (Windows 11 & 10)', 'Microsoft Store for Windows 11 & 10')}</span>
                <span className="px-1.5 py-0.2 rounded bg-sky-500/20 text-sky-300 text-[9px] font-black uppercase">PC</span>
              </button>
            </li>
            <li>
              <button 
                onClick={() => openDownloadAppModal('apk')} 
                className="text-gray-300 hover:text-emerald-400 transition-colors flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>{t('সরাসরি এপিকে ডাউনলোড (BDIX APK)', 'Direct Fast APK Download')}</span>
              </button>
            </li>
            <li>
              <button onClick={() => setCurrentView('track-order')} className="hover:text-emerald-400 transition-colors">
                {t('অর্ডার ট্র্যাক করুন', 'Track Order')}
              </button>
            </li>
            <li>
              <button onClick={() => setCurrentView('user-dashboard')} className="hover:text-emerald-400 transition-colors">
                {t('আমার অ্যাকাউন্ট', 'My Account')}
              </button>
            </li>
            <li>
              <a href="#help" className="hover:text-emerald-400 transition-colors">
                {t('রিটার্ন ও রিফান্ড নীতি', 'Return & Refund Policy')}
              </a>
            </li>
            <li>
              <a href="#shipping" className="hover:text-emerald-400 transition-colors">
                {t('ডেলিভারি সংক্রান্ত নিয়মাবলী', 'Shipping Policy')}
              </a>
            </li>
            <li>
              <a href="#terms" className="hover:text-emerald-400 transition-colors">
                {t('শর্তাবলী ও নীতিমালা', 'Terms & Conditions')}
              </a>
            </li>
            <li>
              <a href="#privacy" className="hover:text-emerald-400 transition-colors">
                {t('গোপনীয়তা নীতি', 'Privacy Policy')}
              </a>
            </li>
          </ul>
        </div>

        {/* Merchant & Community */}
        <div>
          <h3 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
            {t('সেলার ও পার্টনার', 'Merchant & Community')}
          </h3>
          <ul className="space-y-2 text-xs text-gray-400">
            <li>
              <button 
                onClick={() => setCurrentView('seller-dashboard')} 
                className="text-amber-400 hover:text-amber-300 font-semibold transition-colors"
              >
                {t('সেলার হিসেবে যোগ দিন', 'Become a Seller')}
              </button>
            </li>
            <li>
              <button onClick={() => setCurrentView('seller-dashboard')} className="hover:text-emerald-400 transition-colors">
                {t('সেলার নীতিমালা', 'Seller Code of Conduct')}
              </button>
            </li>
            <li>
              <button onClick={() => setCurrentView('admin-dashboard')} className="hover:text-emerald-400 transition-colors">
                {t('অ্যাডমিন ড্যাশবোর্ড', 'Admin Control Panel')}
              </button>
            </li>
            <li>
              <a href="#affiliate" className="hover:text-emerald-400 transition-colors">
                {t('অ্যাফিলিয়েট প্রোগ্রাম', 'Affiliate Program')}
              </a>
            </li>
          </ul>

          <div className="mt-5">
            <span className="text-[11px] font-bold text-white block mb-2">
              {t('আমাদের সাথে যুক্ত থাকুন', 'Follow DeshiBazar')}
            </span>
            <div className="flex items-center gap-2">
              <a href="#facebook" className="w-8 h-8 rounded-lg bg-gray-800 hover:bg-emerald-600 flex items-center justify-center text-white transition-colors" title="Facebook">
                <Facebook className="w-4 h-4" />
              </a>
              <a href="#youtube" className="w-8 h-8 rounded-lg bg-gray-800 hover:bg-red-600 flex items-center justify-center text-white transition-colors" title="YouTube">
                <Youtube className="w-4 h-4" />
              </a>
              <a href="#instagram" className="w-8 h-8 rounded-lg bg-gray-800 hover:bg-pink-600 flex items-center justify-center text-white transition-colors" title="Instagram">
                <Instagram className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* 2.5 Multi-Platform App Store Download Showcase */}
      <div className="max-w-7xl mx-auto px-4 py-8 border-t border-gray-800">
        <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-gray-850 via-gray-800 to-gray-850 border border-gray-750 shadow-xl relative overflow-hidden">
          {/* Subtle Ambient Glow */}
          <div className="absolute top-0 right-1/4 w-72 h-72 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-10 w-60 h-60 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 flex flex-col lg:flex-row items-center justify-between gap-8">
            {/* Left: Text & Info */}
            <div className="space-y-3 text-center lg:text-left max-w-xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-800/60 text-[11px] font-bold text-emerald-400">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>{t('মোবাইলে দেশিবাজার • একাধিক প্ল্যাটফর্মে উপলব্ধ', 'DeshiBazar Mobile • Available on All Platforms')}</span>
              </div>

              <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                {t(
                  'দেশিবাজার ডাউনলোড করুন: একাধিক প্ল্যাটফর্ম অ্যাপ স্টোর ও মাইক্রোসফট স্টোর',
                  'Download DeshiBazar on Multiple App Stores & Microsoft Store'
                )}
              </h3>

              <p className="text-xs text-gray-300 leading-relaxed">
                {t(
                  'গুগল প্লে স্টোর, অ্যাপল অ্যাপ স্টোর, উইন্ডোজের জন্য মাইক্রোসফট স্টোর (Windows 11 & 10), হুয়াওয়ে অ্যাপগ্যালারি ও সরাসরি এপিকে—যেকোনো ডিভাইসে উপভোগ করুন দ্রুততম দেশি কেনাকাটা, ইনস্ট্যান্ট নোটিফিকেশন ও রাইডার ট্র্যাকিং!',
                  'Get the official DeshiBazar app across Apple App Store, Google Play, Microsoft Store for Windows 11 & 10, Huawei AppGallery & Direct APK with lightning-fast performance!'
                )}
              </p>

              {/* Offer pill */}
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-bold">
                <span>🎁</span>
                <span>
                  {t('অ্যাপ ইনস্টল করলেই পাবেন ১০০ টাকা ছাড়! প্রোমো কোড: ', 'Get flat ৳100 OFF with voucher code: ')}
                  <strong className="text-amber-200 underline font-black">DESHIAPP</strong>
                </span>
              </div>
            </div>

            {/* Right: Platform App Store Buttons & QR code */}
            <div className="flex flex-col sm:flex-row items-center gap-4 w-full lg:w-auto shrink-0 justify-center">
              
              {/* Grid of Store Badges */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 w-full sm:w-auto">
                {/* 1. Google Play Store */}
                <button
                  onClick={() => openDownloadAppModal('android')}
                  className="flex items-center gap-2 px-3 py-2 rounded-xl bg-gray-950 hover:bg-black border border-gray-700 hover:border-emerald-500 text-white transition-all group shadow-md text-left"
                  title="Google Play Store (Android)"
                >
                  <svg className="w-5 h-5 fill-current text-emerald-400 shrink-0 group-hover:scale-110 transition-transform" viewBox="0 0 24 24">
                    <path d="M3.609 1.814L13.792 12 3.61 22.186c-.198-.198-.323-.473-.323-.775V2.589c0-.302.125-.577.323-.775zM15.207 13.414l2.422 2.422-12.019 6.845 9.597-9.267zm2.422-5.25L15.207 10.586 5.61 1.319l12.019 6.845zm1.536 2.685l2.49 1.417c.725.412.725 1.084 0 1.497l-2.49 1.417-2.148-2.165 2.148-2.166z"/>
                  </svg>
                  <div className="text-left">
                    <span className="block text-[8px] uppercase tracking-wider text-gray-400 leading-none">GET IT ON</span>
                    <span className="block text-xs font-black text-white leading-tight">Google Play</span>
                  </div>
                </button>

                {/* 2. Apple App Store */}
                <button
                  onClick={() => openDownloadAppModal('ios')}
                  className="flex items-center gap-2 px-3 py-2 rounded-xl bg-gray-950 hover:bg-black border border-gray-700 hover:border-blue-500 text-white transition-all group shadow-md text-left"
                  title="Apple App Store (iOS)"
                >
                  <svg className="w-5 h-5 fill-current text-white shrink-0 group-hover:scale-110 transition-transform" viewBox="0 0 24 24">
                    <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 6.37c.62-.75 1.04-1.8 0.92-2.85-.9.04-2 0.6-2.65 1.35-.58.67-.09 1.74.05 2.77 1.01.08 2.05-.52 2.68-1.27z"/>
                  </svg>
                  <div className="text-left">
                    <span className="block text-[8px] uppercase tracking-wider text-gray-400 leading-none">Download on</span>
                    <span className="block text-xs font-black text-white leading-tight">App Store</span>
                  </div>
                </button>

                {/* 3. Microsoft Store (Windows 11 & 10) - Featured Highlight */}
                <button
                  onClick={() => openDownloadAppModal('microsoft')}
                  className="flex items-center gap-2 px-3 py-2 rounded-xl bg-gray-950 hover:bg-black border border-sky-600/70 hover:border-sky-400 text-white transition-all group shadow-md shadow-sky-950/40 text-left relative overflow-hidden"
                  title="Microsoft Store (Windows 11 & 10)"
                >
                  <div className="absolute top-0 right-0 w-8 h-8 bg-sky-500/10 rounded-full blur-xs pointer-events-none" />
                  <svg className="w-4 h-4 shrink-0 group-hover:scale-110 transition-transform" viewBox="0 0 24 24">
                    <rect x="2" y="2" width="9.5" height="9.5" fill="#F25022"/>
                    <rect x="12.5" y="2" width="9.5" height="9.5" fill="#7FBA00"/>
                    <rect x="2" y="12.5" width="9.5" height="9.5" fill="#00A4EF"/>
                    <rect x="12.5" y="12.5" width="9.5" height="9.5" fill="#FFB900"/>
                  </svg>
                  <div className="text-left">
                    <div className="flex items-center gap-1">
                      <span className="text-[8px] uppercase tracking-wider text-sky-400 leading-none font-bold">Get it from</span>
                      <span className="text-[7px] px-1 rounded bg-sky-500/30 text-sky-200 font-bold leading-tight">PC</span>
                    </div>
                    <span className="block text-xs font-black text-white leading-tight">Microsoft Store</span>
                  </div>
                </button>

                {/* 4. Direct Android APK */}
                <button
                  onClick={() => openDownloadAppModal('apk')}
                  className="flex items-center gap-2 px-3 py-2 rounded-xl bg-gray-950 hover:bg-black border border-gray-700 hover:border-emerald-400 text-white transition-all group shadow-md text-left"
                  title="Direct BDIX Android APK"
                >
                  <div className="w-5 h-5 rounded-lg bg-emerald-600/30 text-emerald-400 flex items-center justify-center font-bold text-[10px] shrink-0 group-hover:scale-110 transition-transform">
                    APK
                  </div>
                  <div className="text-left">
                    <span className="block text-[8px] uppercase tracking-wider text-emerald-400 leading-none font-bold">Fast BDIX</span>
                    <span className="block text-xs font-black text-white leading-tight">Direct APK</span>
                  </div>
                </button>

                {/* 5. Huawei AppGallery */}
                <button
                  onClick={() => openDownloadAppModal('huawei')}
                  className="flex items-center gap-2 px-3 py-2 rounded-xl bg-gray-950 hover:bg-black border border-gray-700 hover:border-red-500 text-white transition-all group shadow-md text-left"
                  title="Huawei AppGallery"
                >
                  <div className="w-5 h-5 rounded-lg bg-red-600/30 text-red-400 flex items-center justify-center font-bold text-[10px] shrink-0 group-hover:scale-110 transition-transform">
                    H
                  </div>
                  <div className="text-left">
                    <span className="block text-[8px] uppercase tracking-wider text-gray-400 leading-none">Explore on</span>
                    <span className="block text-xs font-black text-white leading-tight">AppGallery</span>
                  </div>
                </button>

                {/* 6. Samsung Galaxy Store */}
                <button
                  onClick={() => openDownloadAppModal('huawei')}
                  className="flex items-center gap-2 px-3 py-2 rounded-xl bg-gray-950 hover:bg-black border border-gray-700 hover:border-indigo-500 text-white transition-all group shadow-md text-left"
                  title="Samsung Galaxy Store"
                >
                  <div className="w-5 h-5 rounded-lg bg-indigo-600/30 text-indigo-400 flex items-center justify-center font-bold text-[10px] shrink-0 group-hover:scale-110 transition-transform">
                    S
                  </div>
                  <div className="text-left">
                    <span className="block text-[8px] uppercase tracking-wider text-gray-400 leading-none">Available on</span>
                    <span className="block text-xs font-black text-white leading-tight">Galaxy Store</span>
                  </div>
                </button>
              </div>

              {/* Interactive QR Code Box */}
              <div 
                onClick={() => openDownloadAppModal('microsoft')}
                className="p-3 bg-white rounded-2xl shadow-md border border-gray-200 shrink-0 text-center cursor-pointer hover:scale-105 transition-all group"
                title={t('সবগুলো প্ল্যাটফর্মের লিংক ও কিউআর দেখতে ক্লিক করুন', 'Click to open download modal for all platforms')}
              >
                <img 
                  src="https://api.qrserver.com/v1/create-qr-code/?size=95x95&data=https://deshibazar.com.bd/download" 
                  alt="Download App QR Code" 
                  className="w-20 h-20 mx-auto"
                />
                <span className="text-[9px] font-bold text-gray-700 mt-1 block group-hover:text-emerald-600">
                  {t('স্ক্যান করুন 📲', 'Scan to Install 📲')}
                </span>
              </div>
            </div>
          </div>

          {/* Quick Details Bar */}
          <div className="mt-6 pt-4 border-t border-gray-750 flex flex-wrap items-center justify-between gap-3 text-xs text-gray-400">
            <div className="flex flex-wrap items-center gap-4 text-[11px]">
              <span className="flex items-center gap-1 text-emerald-400 font-bold">
                <CheckCircle2 className="w-3.5 h-3.5" />
                {t('অফিশিয়াল রিলিজ v2.8.4', 'Official Release v2.8.4')}
              </span>
              <span>•</span>
              <span className="flex items-center gap-1 text-gray-300">
                <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                {t('রেটিং ৪.৯ (৪৮,০০০+ রিভিউ)', '4.9 Rating (48,000+ Reviews)')}
              </span>
              <span>•</span>
              <span className="text-gray-300">
                {t('৫ লাখ+ ডাউনলোড', '500,000+ Downloads')}
              </span>
              <span>•</span>
              <span className="text-emerald-400">
                {t('১০০% নিরাপদ ও বিজ্ঞাপনমুক্ত', '100% Secure & Ad-Free')}
              </span>
            </div>

            <button
              onClick={() => openDownloadAppModal('microsoft')}
              className="text-xs font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1 transition-colors"
            >
              <span>{t('মাইক্রোসফট স্টোর ও অন্যান্য প্ল্যাটফর্ম ইনস্টলেশন গাইড →', 'Microsoft Store & Multi-Platform Installation Guide →')}</span>
            </button>
          </div>
        </div>
      </div>

      {/* 3. Payment Methods & Trust Badges */}
      <div className="max-w-7xl mx-auto px-4 pt-8 pb-4 border-t border-gray-800 flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-gray-400 block mb-2 text-center md:text-left">
            {t('নিরাপদ পেমেন্ট পার্টনারগণ', 'Verified Payment Methods')}
          </span>
          <div className="flex flex-wrap items-center justify-center md:justify-start gap-2">
            {/* bKash Badge */}
            <span className="px-3 py-1 rounded bg-[#E2136E] text-white text-xs font-black tracking-wider shadow-sm">
              bKash
            </span>
            {/* Nagad Badge */}
            <span className="px-3 py-1 rounded bg-[#F7931E] text-white text-xs font-black tracking-wider shadow-sm">
              NAGAD
            </span>
            {/* Rocket Badge */}
            <span className="px-3 py-1 rounded bg-[#8C3494] text-white text-xs font-black tracking-wider shadow-sm">
              Rocket
            </span>
            {/* Visa Badge */}
            <span className="px-3 py-1 rounded bg-[#1A1F71] text-white text-xs font-black tracking-wider shadow-sm">
              VISA
            </span>
            {/* Mastercard */}
            <span className="px-3 py-1 rounded bg-[#EB001B] text-white text-xs font-black tracking-wider shadow-sm">
              Mastercard
            </span>
            {/* Cash on Delivery */}
            <span className="px-3 py-1 rounded bg-emerald-700 text-white text-xs font-bold tracking-wider shadow-sm">
              {t('ক্যাশ অন ডেলিভারি (COD)', 'Cash on Delivery')}
            </span>
          </div>
        </div>

        {/* SEO tags & Copyright */}
        <div className="text-center md:text-right text-[11px] text-gray-500 space-y-1">
          <p>© {new Date().getFullYear()} DeshiBazar Bangladesh Limited. All rights reserved.</p>
          <p className="text-[10px] text-gray-400">
            দেশি পণ্য, সবার বাজার • Dhaka • Chattogram • Sylhet • Rajshahi • Khulna
          </p>
        </div>
      </div>
    </footer>
  );
};
