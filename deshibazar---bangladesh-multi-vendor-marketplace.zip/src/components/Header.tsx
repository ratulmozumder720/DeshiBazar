import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Search, 
  ShoppingCart, 
  Heart, 
  User as UserIcon, 
  MapPin, 
  Phone, 
  Moon, 
  Sun, 
  Menu, 
  X, 
  ChevronDown, 
  Sparkles, 
  Flame, 
  Tag, 
  Store, 
  ShieldCheck, 
  Clock, 
  Mic, 
  ChevronRight,
  LogOut,
  LayoutDashboard,
  Truck,
  Palette,
  Settings,
  Bell,
  MessageSquare,
  Wallet,
  Receipt
} from 'lucide-react';
import { BANGLADESH_DIVISIONS } from '../data/mockData';
import { DESHIBAZAR_CONTACT } from '../data/contactConfig';

export const Header: React.FC = () => {
  const {
    language,
    setLanguage,
    t,
    darkMode,
    toggleDarkMode,
    currentView,
    setCurrentView,
    cartItemsCount,
    cartSubtotal,
    wishlist,
    setIsCartDrawerOpen,
    setIsAuthModalOpen,
    user,
    userProfile,
    logOut,
    switchUserRole,
    searchQuery,
    setSearchQuery,
    recentSearches,
    addRecentSearch,
    clearRecentSearches,
    selectedLocation,
    setSelectedLocation,
    products,
    categories,
    openProductDetails,
    setSelectedCategory,
    setSelectedSellerId,
    setIsCourierModalOpen,
    openThemeStudio,
    customerUIConfig,
    unreadSmsCount,
    totalCustomerBakiDue,
    openSmsNotificationModal,
    openCategoryCashMemo
  } = useApp();

  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isCategoryDropdownOpen, setIsCategoryDropdownOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isSettingsMenuOpen, setIsSettingsMenuOpen] = useState(false);
  const [isMobileSettingsExpanded, setIsMobileSettingsExpanded] = useState(false);
  const [isListeningVoice, setIsListeningVoice] = useState(false);
  const [isLocationDropdownOpen, setIsLocationDropdownOpen] = useState(false);

  const searchContainerRef = useRef<HTMLDivElement>(null);
  const userMenuRef = useRef<HTMLDivElement>(null);
  const settingsMenuRef = useRef<HTMLDivElement>(null);
  const locationRef = useRef<HTMLDivElement>(null);

  // Close menus on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(e.target as Node)) {
        setIsSearchFocused(false);
      }
      if (userMenuRef.current && !userMenuRef.current.contains(e.target as Node)) {
        setIsUserMenuOpen(false);
      }
      if (settingsMenuRef.current && !settingsMenuRef.current.contains(e.target as Node)) {
        setIsSettingsMenuOpen(false);
      }
      if (locationRef.current && !locationRef.current.contains(e.target as Node)) {
        setIsLocationDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Filter suggestions based on query
  const searchResults = searchQuery.trim()
    ? products.filter(p => 
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.nameBn.includes(searchQuery) ||
        p.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.brand.toLowerCase().includes(searchQuery.toLowerCase())
      ).slice(0, 5)
    : [];

  const matchedCategories = searchQuery.trim()
    ? categories.filter(c => 
        c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.nameBn.includes(searchQuery)
      ).slice(0, 3)
    : [];

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      addRecentSearch(searchQuery.trim());
      setIsSearchFocused(false);
      setCurrentView('shop');
    }
  };

  const handleSelectProduct = (prodId: string) => {
    openProductDetails(prodId);
    setIsSearchFocused(false);
    setIsMobileMenuOpen(false);
  };

  const handleSelectCategory = (catId: string) => {
    setSelectedCategory(catId);
    setSelectedSellerId(null);
    setCurrentView('shop');
    setIsCategoryDropdownOpen(false);
    setIsMobileMenuOpen(false);
  };

  const handleVoiceSearch = () => {
    setIsListeningVoice(true);
    // Voice search simulation
    setTimeout(() => {
      const demoVoices = ['পদ্মা ইলিশ', 'মিনিকেট চাল', 'খাঁটি মধু', 'Sundarbans Honey', 'Nakshi Kantha'];
      const picked = demoVoices[Math.floor(Math.random() * demoVoices.length)];
      setSearchQuery(picked);
      addRecentSearch(picked);
      setIsListeningVoice(false);
      setCurrentView('shop');
    }, 1500);
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-white dark:bg-gray-900 border-b border-gray-100 dark:border-gray-800 shadow-sm transition-colors">
      {/* 1. Top Announcement Bar */}
      {customerUIConfig?.showAnnouncementTicker !== false && (
        <div className="bg-emerald-800 text-white text-xs py-1.5 px-4 font-medium transition-colors">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-1">
            <div className="flex items-center gap-2 text-emerald-100 text-center sm:text-left">
              <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>
                {customerUIConfig?.announcementText
                  ? t(customerUIConfig.announcementTextBn || customerUIConfig.announcementText, customerUIConfig.announcementText)
                  : t(
                      'সারা বাংলাদেশে ডেলিভারি | Cash on Delivery Available | bKash & Nagad Accepted',
                      'Nationwide Delivery | Cash on Delivery Available | bKash & Nagad Accepted'
                    )}
              </span>
            </div>

          <div className="flex items-center gap-4 text-emerald-100 text-[11px]">
            <a 
              href={DESHIBAZAR_CONTACT.hotlineTel} 
              className="flex items-center gap-1.5 hover:text-white transition-colors"
              title="Call DeshiBazar Hotline"
            >
              <Phone className="w-3.5 h-3.5 text-amber-300" />
              <span className="font-bold">{t('হটলাইন: ', 'Hotline: ')}{DESHIBAZAR_CONTACT.hotlineDisplay}</span>
            </a>

            <div className="h-3 w-[1px] bg-emerald-600"></div>

            {/* Language Switcher */}
            <div className="flex items-center bg-emerald-900/60 rounded-full p-0.5 border border-emerald-700/60">
              <button
                type="button"
                onClick={() => setLanguage('bn')}
                className={`px-2 py-0.5 rounded-full text-[11px] font-semibold transition-all ${
                  language === 'bn' 
                    ? 'bg-amber-400 text-emerald-950 shadow-sm' 
                    : 'text-emerald-200 hover:text-white'
                }`}
              >
                বাংলা
              </button>
              <button
                type="button"
                onClick={() => setLanguage('en')}
                className={`px-2 py-0.5 rounded-full text-[11px] font-semibold transition-all ${
                  language === 'en' 
                    ? 'bg-amber-400 text-emerald-950 shadow-sm' 
                    : 'text-emerald-200 hover:text-white'
                }`}
              >
                EN
              </button>
            </div>

            <div className="h-3 w-[1px] bg-emerald-600"></div>

            {/* Dark Mode Toggle */}
            <button
              onClick={toggleDarkMode}
              className="p-1 hover:bg-emerald-700/60 rounded-full text-emerald-100 hover:text-white transition-colors flex items-center gap-1"
              title={darkMode ? 'Switch to Light' : 'Switch to Dark'}
            >
              {darkMode ? <Sun className="w-3.5 h-3.5 text-amber-300" /> : <Moon className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>
      </div>
      )}

      {/* 2. Main Header */}
      <div className="max-w-7xl mx-auto px-4 py-3 sm:py-3.5">
        <div className="flex items-center justify-between gap-2 md:gap-6">
          {/* Logo & Mobile Menu Trigger */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden p-2 rounded-lg text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
              aria-label="Toggle Menu"
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

            <button
              onClick={() => {
                setSelectedCategory(null);
                setSelectedSellerId(null);
                setSearchQuery('');
                setCurrentView('home');
              }}
              className="flex items-center gap-2 group text-left"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-emerald-500 flex items-center justify-center text-white shadow-md shadow-emerald-500/20 group-hover:scale-105 transition-transform">
                <span className="text-xl font-bold tracking-tighter">দ</span>
              </div>
              <div className="flex flex-col">
                <div className="flex items-center gap-1">
                  <span className="text-xl font-black tracking-tight text-emerald-700 dark:text-emerald-400">
                    Deshi<span className="text-amber-500">Bazar</span>
                  </span>
                </div>
                <span className="text-[10px] text-gray-500 dark:text-gray-400 font-medium -mt-1 hidden sm:block">
                  দেশি পণ্য, সবার বাজার
                </span>
              </div>
            </button>
          </div>

          {/* Location Selector (Desktop) */}
          <div className="relative hidden lg:block" ref={locationRef}>
            <button
              onClick={() => setIsLocationDropdownOpen(!isLocationDropdownOpen)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-gray-200 dark:border-gray-700 hover:border-emerald-500 text-xs text-gray-700 dark:text-gray-300 transition-all bg-gray-50/50 dark:bg-gray-800/50"
            >
              <MapPin className="w-3.5 h-3.5 text-emerald-600" />
              <div className="text-left">
                <span className="text-[10px] text-gray-400 block leading-none">{t('ডেলিভারি এলাকা', 'Deliver to')}</span>
                <span className="font-semibold text-gray-800 dark:text-gray-100 flex items-center gap-1">
                  {selectedLocation}, BD <ChevronDown className="w-3 h-3 text-gray-400" />
                </span>
              </div>
            </button>

            {isLocationDropdownOpen && (
              <div className="absolute top-full mt-1.5 left-0 w-48 bg-white dark:bg-gray-800 rounded-xl shadow-xl border border-gray-100 dark:border-gray-700 py-1.5 z-50">
                <div className="px-3 py-1 text-[11px] font-semibold text-gray-400 uppercase tracking-wider">
                  {t('বিভাগ নির্বাচন করুন', 'Select Division')}
                </div>
                {BANGLADESH_DIVISIONS.map((div) => (
                  <button
                    key={div}
                    onClick={() => {
                      setSelectedLocation(div);
                      setIsLocationDropdownOpen(false);
                    }}
                    className={`w-full text-left px-3 py-1.5 text-xs flex items-center justify-between hover:bg-emerald-50 dark:hover:bg-emerald-950/40 hover:text-emerald-600 dark:hover:text-emerald-400 ${
                      selectedLocation === div ? 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 font-semibold' : 'text-gray-700 dark:text-gray-200'
                    }`}
                  >
                    <span>{div}</span>
                    {selectedLocation === div && <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Smart Search Bar */}
          <div className="flex-1 max-w-2xl relative" ref={searchContainerRef}>
            <form onSubmit={handleSearchSubmit} className="relative flex items-center">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => setIsSearchFocused(true)}
                placeholder={t(
                  'আপনি কী খুঁজছেন? Search products (চাল, ইলিশ, মধু, শাড়ি...)',
                  'What are you looking for? Search products...'
                )}
                className="w-full bg-gray-50 dark:bg-gray-800/80 text-gray-900 dark:text-white pl-10 pr-24 py-2.5 rounded-full border border-gray-200 dark:border-gray-700 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all shadow-inner"
              />
              <Search className="w-4 h-4 text-gray-400 absolute left-3.5 pointer-events-none" />

              <div className="absolute right-1.5 flex items-center gap-1">
                {/* Voice Search Button */}
                <button
                  type="button"
                  onClick={handleVoiceSearch}
                  className={`p-1.5 rounded-full text-gray-500 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-gray-700 transition-colors ${
                    isListeningVoice ? 'animate-pulse text-red-500 bg-red-50 dark:bg-red-950/30' : ''
                  }`}
                  title={t('ভয়েস সার্চ করুন', 'Voice Search')}
                >
                  <Mic className="w-4 h-4" />
                </button>

                {/* Submit Search Button */}
                <button
                  type="submit"
                  className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-1.5 rounded-full text-xs font-semibold shadow-sm transition-all"
                >
                  {t('খুঁজুন', 'Search')}
                </button>
              </div>
            </form>

            {/* Smart Search Autocomplete Dropdown */}
            {isSearchFocused && (
              <div className="absolute top-full left-0 right-0 mt-2 bg-white dark:bg-gray-800 rounded-2xl shadow-2xl border border-gray-100 dark:border-gray-700 p-4 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                {isListeningVoice && (
                  <div className="p-3 mb-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl flex items-center gap-3 text-emerald-800 dark:text-emerald-200 text-xs">
                    <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping"></span>
                    <span>{t('শুনছি... বলুন আপনি কী খুঁজছেন...', 'Listening... Speak your query...')}</span>
                  </div>
                )}

                {/* If typing: show matched products & categories */}
                {searchQuery.trim().length > 0 ? (
                  <div>
                    {matchedCategories.length > 0 && (
                      <div className="mb-3">
                        <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider block mb-1.5">
                          {t('ক্যাটাগরি সমূহ', 'Categories')}
                        </span>
                        <div className="flex flex-wrap gap-1.5">
                          {matchedCategories.map((c) => (
                            <button
                              key={c.id}
                              onClick={() => handleSelectCategory(c.id)}
                              className="px-3 py-1 rounded-lg text-xs bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 font-medium hover:bg-emerald-100 flex items-center gap-1.5"
                            >
                              <span>{t(c.nameBn, c.name)}</span>
                              <ChevronRight className="w-3 h-3 text-emerald-500" />
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    <div>
                      <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider block mb-2">
                        {t('পণ্য ফলাফল', 'Product Suggestions')}
                      </span>
                      {searchResults.length > 0 ? (
                        <div className="space-y-1.5">
                          {searchResults.map((p) => (
                            <button
                              key={p.id}
                              onClick={() => handleSelectProduct(p.id)}
                              className="w-full flex items-center justify-between p-2 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-700/60 transition-colors text-left"
                            >
                              <div className="flex items-center gap-3">
                                <img
                                  src={p.image}
                                  alt={p.name}
                                  className="w-10 h-10 rounded-lg object-cover bg-gray-100"
                                />
                                <div>
                                  <h4 className="text-xs font-semibold text-gray-900 dark:text-white line-clamp-1">
                                    {t(p.nameBn, p.name)}
                                  </h4>
                                  <span className="text-[11px] text-gray-400">{p.vendorName}</span>
                                </div>
                              </div>
                              <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">
                                ৳{p.price}
                              </span>
                            </button>
                          ))}
                        </div>
                      ) : (
                        <div className="text-xs text-gray-500 py-3 text-center">
                          {t('কোনো পণ্য পাওয়া যায়নি। এন্টার চেপে সব দেখুন।', 'No exact matches found. Press enter to search all.')}
                        </div>
                      )}
                    </div>
                  </div>
                ) : (
                  /* If empty query: show Recent Searches & Popular searches */
                  <div className="space-y-4">
                    {recentSearches.length > 0 && (
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {t('সাম্প্রতিক অনুসন্ধান', 'Recent Searches')}
                          </span>
                          <button
                            type="button"
                            onClick={clearRecentSearches}
                            className="text-[11px] text-gray-400 hover:text-red-500"
                          >
                            {t('মুছুন', 'Clear')}
                          </button>
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {recentSearches.map((term, i) => (
                            <button
                              key={i}
                              type="button"
                              onClick={() => {
                                setSearchQuery(term);
                                setCurrentView('shop');
                                setIsSearchFocused(false);
                              }}
                              className="px-3 py-1 rounded-full text-xs bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 transition-colors"
                            >
                              {term}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    <div>
                      <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider flex items-center gap-1 mb-2">
                        <Flame className="w-3 h-3 text-amber-500" />
                        {t('জনপ্রিয় অনুসন্ধান', 'Trending Searches')}
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {['Padma Hilsha', 'Miniket Rice', 'Sundarbans Honey', 'Ghani Mustard Oil', 'Jamdani Saree', 'Bogura Doi'].map((term) => (
                          <button
                            key={term}
                            type="button"
                            onClick={() => {
                              setSearchQuery(term);
                              setCurrentView('shop');
                              setIsSearchFocused(false);
                            }}
                            className="px-2.5 py-1 rounded-full text-xs border border-gray-200 dark:border-gray-700 text-emerald-700 dark:text-emerald-400 bg-white dark:bg-gray-800 hover:border-emerald-500 transition-colors"
                          >
                            {term}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Action Icons: Account, Wishlist, Cart */}
          <div className="flex items-center gap-1 sm:gap-3">
            {/* User Account Menu */}
            <div className="relative" ref={userMenuRef}>
              <button
                onClick={() => {
                  if (!user && !userProfile) {
                    setIsAuthModalOpen(true);
                  } else {
                    setIsUserMenuOpen(!isUserMenuOpen);
                  }
                }}
                className="flex items-center gap-1.5 p-2 rounded-xl text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors text-xs font-semibold"
              >
                <div className="relative w-8 h-8 rounded-full bg-emerald-100 dark:bg-emerald-950 flex items-center justify-center text-emerald-700 dark:text-emerald-400 overflow-hidden border border-emerald-200 dark:border-emerald-800">
                  {userProfile?.avatarUrl ? (
                    <img src={userProfile.avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
                  ) : (
                    <UserIcon className="w-4 h-4" />
                  )}
                  <Settings className="w-2.5 h-2.5 text-emerald-600 absolute bottom-0 right-0 bg-white dark:bg-gray-800 rounded-full" />
                </div>
                <div className="hidden xl:flex flex-col text-left">
                  <span className="text-[10px] text-gray-400 leading-none flex items-center gap-1">
                    <span>{user ? t('স্বাগতম', 'Welcome') : t('লগইন / সাইন আপ', 'Hello, Sign In')}</span>
                    <Settings className="w-2.5 h-2.5 text-gray-400" />
                  </span>
                  <span className="text-xs font-bold text-gray-800 dark:text-gray-100 max-w-[90px] truncate">
                    {user?.displayName || userProfile?.displayName || t('অ্যাকাউন্ট', 'Account')}
                  </span>
                </div>
              </button>

              {/* User Dropdown */}
              {isUserMenuOpen && (
                <div className="absolute right-0 top-full mt-2 w-64 bg-white dark:bg-gray-800 rounded-2xl shadow-2xl border border-gray-100 dark:border-gray-700 p-2 z-50 animate-in fade-in slide-in-from-top-2">
                  <div className="px-3 py-2 border-b border-gray-100 dark:border-gray-700 mb-1 flex items-center justify-between">
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-gray-900 dark:text-white truncate">
                        {userProfile?.displayName || user?.displayName || 'Deshi User'}
                      </p>
                      <p className="text-[11px] text-gray-400 truncate">
                        {userProfile?.email || user?.email}
                      </p>
                      <span className="inline-block mt-1 px-2 py-0.5 rounded text-[10px] font-semibold uppercase bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400">
                        {userProfile?.role || 'customer'}
                      </span>
                    </div>
                    <Settings className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                  </div>

                  <div className="space-y-0.5">
                    <button
                      onClick={() => {
                        setCurrentView('user-dashboard');
                        setIsUserMenuOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 rounded-xl text-xs font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2">
                        <UserIcon className="w-4 h-4 text-emerald-600" />
                        <span>{t('আমার প্রোফাইল ও অর্ডার', 'My Profile & Orders')}</span>
                      </div>
                      <Settings className="w-3.5 h-3.5 text-emerald-600/70" />
                    </button>

                    <button
                      onClick={() => {
                        setCurrentView('user-dashboard');
                        setIsUserMenuOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 rounded-xl text-xs font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2">
                        <Settings className="w-4 h-4 text-teal-600" />
                        <span>{t('অ্যাকাউন্ট ও নিরাপত্তা সেটিংস', 'Account & Security Settings')}</span>
                      </div>
                      <ChevronRight className="w-3 h-3 text-gray-400" />
                    </button>

                    {/* SMS Receipt Notification & Baki Payment under Settings */}
                    <button
                      onClick={() => {
                        openSmsNotificationModal('notifications');
                        setIsUserMenuOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-amber-800 dark:text-amber-300 bg-amber-50/70 dark:bg-amber-950/30 hover:bg-amber-100 dark:hover:bg-amber-900/50 border border-amber-200/70 dark:border-amber-800/60 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2">
                        <Bell className="w-4 h-4 text-amber-600 animate-pulse" />
                        <div className="leading-tight">
                          <span className="block">{t('রসিদ SMS নোটিফিকেশন', 'Receipt SMS Alerts')}</span>
                          {totalCustomerBakiDue > 0 && (
                            <span className="text-[10px] font-bold text-rose-600 dark:text-rose-400">
                              {t(`বাকি পরিশোধ: ৳${totalCustomerBakiDue.toLocaleString()}`, `Pay Baki: ৳${totalCustomerBakiDue.toLocaleString()}`)}
                            </span>
                          )}
                        </div>
                      </div>
                      {unreadSmsCount > 0 && (
                        <span className="min-w-[20px] h-5 px-1.5 rounded-full bg-rose-500 text-white text-[10px] font-extrabold flex items-center justify-center">
                          {unreadSmsCount}
                        </span>
                      )}
                    </button>

                    <button
                      onClick={() => {
                        setCurrentView('track-order');
                        setIsUserMenuOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 rounded-xl text-xs font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-2"
                    >
                      <ShieldCheck className="w-4 h-4 text-blue-600" />
                      <span>{t('অর্ডার ট্র্যাক করুন', 'Track Order')}</span>
                    </button>

                    <button
                      onClick={() => {
                        setCurrentView('seller-dashboard');
                        setIsUserMenuOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 rounded-xl text-xs font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2">
                        <Store className="w-4 h-4 text-amber-600" />
                        <span>{t('সেলার ড্যাশবোর্ড ও শপ', 'Seller Dashboard & Hub')}</span>
                      </div>
                      <Settings className="w-3.5 h-3.5 text-amber-500" />
                    </button>

                    <button
                      onClick={() => {
                        setCurrentView('admin-dashboard');
                        setIsUserMenuOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 rounded-xl text-xs font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2">
                        <LayoutDashboard className="w-4 h-4 text-purple-600" />
                        <span>{t('অ্যাডমিন প্যানেল ও সেটিংস', 'Admin Panel & Settings')}</span>
                      </div>
                      <Settings className="w-3.5 h-3.5 text-purple-500" />
                    </button>

                    {/* Quick Role Switcher for Testing */}
                    <div className="pt-2 mt-2 border-t border-gray-100 dark:border-gray-700 px-3">
                      <span className="text-[10px] text-gray-400 uppercase font-semibold flex items-center justify-between mb-1">
                        <span>{t('রোল টেস্ট করুন (Switch Role)', 'Role Sandbox')}</span>
                        <Settings className="w-3 h-3 text-gray-400" />
                      </span>
                      <div className="grid grid-cols-3 gap-1">
                        {(['customer', 'seller', 'admin'] as const).map((r) => (
                          <button
                            key={r}
                            onClick={() => switchUserRole(r)}
                            className={`py-1 text-[10px] rounded font-semibold capitalize border ${
                              userProfile?.role === r 
                                ? 'bg-emerald-600 text-white border-emerald-600'
                                : 'border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300'
                            }`}
                          >
                            {r}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="pt-2 border-t border-gray-100 dark:border-gray-700">
                      <button
                        onClick={() => {
                          logOut();
                          setIsUserMenuOpen(false);
                        }}
                        className="w-full text-left px-3 py-2 rounded-xl text-xs font-medium text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40 flex items-center justify-between"
                      >
                        <div className="flex items-center gap-2">
                          <LogOut className="w-4 h-4" />
                          <span>{t('লগআউট / সাইন আউট', 'Log Out / Sign Out')}</span>
                        </div>
                        <Settings className="w-3.5 h-3.5 text-red-400" />
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Wishlist Icon */}
            <button
              onClick={() => {
                setCurrentView('user-dashboard');
              }}
              className="p-2 rounded-xl text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors relative"
              title={t('উইশলিস্ট', 'Wishlist')}
            >
              <Heart className="w-5 h-5 text-gray-600 dark:text-gray-300" />
              {wishlist.length > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center">
                  {wishlist.length}
                </span>
              )}
            </button>

            {/* Cart Icon & Subtotal */}
            <button
              onClick={() => setIsCartDrawerOpen(true)}
              className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-3 sm:px-4 py-2 rounded-xl shadow-md shadow-emerald-600/20 font-semibold transition-all transform active:scale-95"
            >
              <div className="relative">
                <ShoppingCart className="w-5 h-5" />
                {cartItemsCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-amber-400 text-emerald-950 text-[10px] font-extrabold w-4 h-4 rounded-full flex items-center justify-center">
                    {cartItemsCount}
                  </span>
                )}
              </div>
              <div className="hidden sm:flex flex-col text-left">
                <span className="text-[10px] text-emerald-100 leading-none">{t('ব্যাগ', 'Cart')}</span>
                <span className="text-xs font-bold">৳{cartSubtotal}</span>
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* 3. Sticky Navigation Bar */}
      <nav className="hidden md:block bg-gray-50/90 dark:bg-gray-800/90 backdrop-blur border-t border-gray-100 dark:border-gray-800">
        <div className="max-w-7xl mx-auto px-4 flex items-center justify-between gap-3">
          <div className="flex items-center space-x-1 lg:space-x-2 min-w-0">
            {/* Mega Categories Dropdown */}
            <div className="relative shrink-0">
              <button
                onClick={() => setIsCategoryDropdownOpen(!isCategoryDropdownOpen)}
                className="flex items-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg transition-colors my-1 whitespace-nowrap"
              >
                <Menu className="w-4 h-4" />
                <span>{t('সকল ক্যাটাগরি', 'All Categories')}</span>
                <ChevronDown className="w-3.5 h-3.5" />
              </button>

              {isCategoryDropdownOpen && (
                <div 
                  onMouseLeave={() => setIsCategoryDropdownOpen(false)}
                  className="absolute top-full left-0 mt-1 w-72 max-h-[420px] overflow-y-auto bg-white dark:bg-gray-800 rounded-2xl shadow-2xl border border-gray-100 dark:border-gray-700 py-2 z-50 animate-in fade-in duration-100"
                >
                  {categories.map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => handleSelectCategory(cat.id)}
                      className="w-full text-left px-4 py-2 text-xs font-medium text-gray-700 dark:text-gray-200 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 hover:text-emerald-700 dark:hover:text-emerald-300 flex items-center justify-between transition-colors"
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                        <span>{t(cat.nameBn, cat.name)}</span>
                      </div>
                      <span className="text-[10px] text-gray-400">({cat.itemCount})</span>
                    </button>
                  ))}
                  <div className="pt-2 mt-2 border-t border-gray-100 dark:border-gray-700 px-4">
                    <button
                      onClick={() => {
                        setCurrentView('categories');
                        setIsCategoryDropdownOpen(false);
                      }}
                      className="text-xs text-emerald-600 dark:text-emerald-400 font-bold hover:underline"
                    >
                      {t('সব ক্যাটাগরি ব্রাউজ করুন →', 'Browse All Categories →')}
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Primary Nav Links */}
            <div className="flex items-center space-x-1 lg:space-x-2 overflow-x-auto no-scrollbar">
              <button
                onClick={() => {
                  setSelectedCategory(null);
                  setSelectedSellerId(null);
                  setCurrentView('home');
                }}
                className={`px-3 py-3 text-xs font-semibold hover:text-emerald-600 transition-colors whitespace-nowrap ${
                  currentView === 'home' ? 'text-emerald-600 border-b-2 border-emerald-600 font-bold' : 'text-gray-700 dark:text-gray-300'
                }`}
              >
                {t('হোম', 'Home')}
              </button>

              <button
                onClick={() => handleSelectCategory('rice-dal-grocery')}
                className="px-3 py-3 text-xs font-semibold text-gray-700 dark:text-gray-300 hover:text-emerald-600 transition-colors whitespace-nowrap"
              >
                {t('মুদি ও চাল-ডাল', 'Grocery')}
              </button>

              <button
                onClick={() => handleSelectCategory('fish-meat')}
                className="px-3 py-3 text-xs font-semibold text-gray-700 dark:text-gray-300 hover:text-emerald-600 transition-colors whitespace-nowrap"
              >
                {t('তাজা মাছ ও মাংস', 'Fresh Food')}
              </button>

              <button
                onClick={() => handleSelectCategory('deshi-products')}
                className="px-3 py-3 text-xs font-semibold text-emerald-700 dark:text-emerald-400 flex items-center gap-1 hover:text-emerald-800 transition-colors whitespace-nowrap"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>{t('দেশি পণ্য', 'Deshi Products')}</span>
              </button>

              <button
                onClick={() => handleSelectCategory('fashion')}
                className="px-3 py-3 text-xs font-semibold text-gray-700 dark:text-gray-300 hover:text-emerald-600 transition-colors whitespace-nowrap"
              >
                {t('ফ্যাশন', 'Fashion')}
              </button>

              <button
                onClick={() => handleSelectCategory('electronics')}
                className="px-3 py-3 text-xs font-semibold text-gray-700 dark:text-gray-300 hover:text-emerald-600 transition-colors whitespace-nowrap"
              >
                {t('ইলেকট্রনিক্স', 'Electronics')}
              </button>

              <button
                onClick={() => handleSelectCategory('beauty-personal-care')}
                className="px-3 py-3 text-xs font-semibold text-gray-700 dark:text-gray-300 hover:text-emerald-600 transition-colors whitespace-nowrap"
              >
                {t('রূপচর্চা', 'Beauty')}
              </button>

              <button
                onClick={() => {
                  setCurrentView('shop');
                }}
                className={`px-3 py-3 text-xs font-semibold hover:text-emerald-600 transition-colors whitespace-nowrap ${
                  currentView === 'shop' ? 'text-emerald-600 border-b-2 border-emerald-600 font-bold' : 'text-gray-700 dark:text-gray-300'
                }`}
              >
                {t('সকল পণ্য', 'Shop All')}
              </button>
            </div>
          </div>

          {/* Right Action: Unified Settings Dropdown Menu */}
          <div className="relative flex items-center shrink-0" ref={settingsMenuRef}>
            <button
              onClick={() => setIsSettingsMenuOpen(!isSettingsMenuOpen)}
              className={`relative flex items-center gap-2 text-xs font-bold px-3.5 py-2 rounded-xl border transition-all shadow-2xs whitespace-nowrap ${
                isSettingsMenuOpen
                  ? 'bg-emerald-600 text-white border-emerald-600 shadow-md shadow-emerald-600/20'
                  : 'text-gray-800 dark:text-gray-100 hover:text-emerald-600 border-gray-200 dark:border-gray-700 hover:border-emerald-500 bg-white dark:bg-gray-800'
              }`}
              title={t('সেটিংস মেনু (ফ্ল্যাশ সেল, অফার, থিম, কুরিয়ার, ড্যাশবোর্ড ও রসিদ SMS)', 'Settings Menu')}
            >
              <Settings className={`w-4 h-4 transition-transform duration-300 ${isSettingsMenuOpen ? 'text-white rotate-90' : 'text-emerald-600'}`} />
              <span>{t('সেটিংস', 'Settings')}</span>
              {unreadSmsCount > 0 && (
                <span className="min-w-[18px] h-[18px] px-1 rounded-full bg-rose-500 text-white text-[10px] font-extrabold flex items-center justify-center">
                  {unreadSmsCount}
                </span>
              )}
              <ChevronDown className={`w-3.5 h-3.5 transition-transform ${isSettingsMenuOpen ? 'rotate-180' : ''}`} />
            </button>

            {isSettingsMenuOpen && (
              <div className="absolute right-0 top-full mt-2 w-72 bg-white dark:bg-gray-800 rounded-2xl shadow-2xl border border-gray-100 dark:border-gray-700 p-2 z-50 animate-in fade-in slide-in-from-top-2">
                <div className="px-3 py-2 border-b border-gray-100 dark:border-gray-700 mb-1.5 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Settings className="w-4 h-4 text-emerald-600" />
                    <span className="text-xs font-extrabold text-gray-900 dark:text-white">
                      {t('সব টুলস ও সেটিংস', 'All Tools & Settings')}
                    </span>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold">
                    {t('মেনু', 'Menu')}
                  </span>
                </div>

                <div className="space-y-1">
                  {/* Receipt SMS / Baki */}
                  <button
                    onClick={() => {
                      openSmsNotificationModal('notifications');
                      setIsSettingsMenuOpen(false);
                    }}
                    className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-amber-800 dark:text-amber-300 bg-amber-50/80 dark:bg-amber-950/40 hover:bg-amber-100 dark:hover:bg-amber-900/60 border border-amber-200/80 dark:border-amber-800/60 flex items-center justify-between transition-colors"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="flex items-center gap-1">
                        <Bell className="w-4 h-4 text-amber-600" />
                        <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                      </div>
                      <div className="leading-tight">
                        <span className="block">{t('রসিদ SMS / বাকি', 'Receipt SMS / Baki')}</span>
                        {totalCustomerBakiDue > 0 && (
                          <span className="text-[10px] font-bold text-rose-600 dark:text-rose-400">
                            {t(`বাকি: ৳${totalCustomerBakiDue.toLocaleString()}`, `Due: ৳${totalCustomerBakiDue.toLocaleString()}`)}
                          </span>
                        )}
                      </div>
                    </div>
                    {unreadSmsCount > 0 && (
                      <span className="min-w-[20px] h-5 px-1.5 rounded-full bg-rose-500 text-white text-[10px] font-extrabold flex items-center justify-center">
                        {unreadSmsCount}
                      </span>
                    )}
                  </button>

                  {/* All-Category Cash Memo / Invoice */}
                  <button
                    onClick={() => {
                      openCategoryCashMemo('all');
                      setIsSettingsMenuOpen(false);
                    }}
                    className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-emerald-800 dark:text-emerald-300 bg-emerald-50/80 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 border border-emerald-200/80 dark:border-emerald-800/60 flex items-center justify-between transition-colors"
                  >
                    <div className="flex items-center gap-2.5">
                      <Receipt className="w-4 h-4 text-emerald-600" />
                      <span>{t('ক্যাটাগরি ক্যাশ মেমো / ইনভয়েজ', 'Category Cash Memo / Invoice')}</span>
                    </div>
                    <ChevronRight className="w-3.5 h-3.5 text-emerald-600" />
                  </button>

                  {/* Flash Sale */}
                  <button
                    onClick={() => {
                      setCurrentView('shop');
                      setIsSettingsMenuOpen(false);
                    }}
                    className="w-full text-left px-3 py-2 rounded-xl text-xs font-semibold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 flex items-center justify-between transition-colors"
                  >
                    <div className="flex items-center gap-2.5">
                      <Flame className="w-4 h-4 text-rose-500" />
                      <span>{t('ফ্ল্যাশ সেল', 'Flash Sale')}</span>
                    </div>
                    <ChevronRight className="w-3.5 h-3.5 text-gray-400" />
                  </button>

                  {/* Offers */}
                  <button
                    onClick={() => {
                      setCurrentView('shop');
                      setIsSettingsMenuOpen(false);
                    }}
                    className="w-full text-left px-3 py-2 rounded-xl text-xs font-semibold text-amber-700 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950/40 flex items-center justify-between transition-colors"
                  >
                    <div className="flex items-center gap-2.5">
                      <Tag className="w-4 h-4 text-amber-500" />
                      <span>{t('অফার সমূহ', 'Offers')}</span>
                    </div>
                    <ChevronRight className="w-3.5 h-3.5 text-gray-400" />
                  </button>

                  {/* 100+ Themes */}
                  <button
                    onClick={() => {
                      openThemeStudio();
                      setIsSettingsMenuOpen(false);
                    }}
                    className="w-full text-left px-3 py-2 rounded-xl text-xs font-semibold text-purple-700 dark:text-purple-300 hover:bg-purple-50 dark:hover:bg-purple-950/40 flex items-center justify-between transition-colors"
                  >
                    <div className="flex items-center gap-2.5">
                      <Palette className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                      <span>{t('১০০+ থিম', '100+ Themes')}</span>
                    </div>
                    <ChevronRight className="w-3.5 h-3.5 text-gray-400" />
                  </button>

                  {/* BD Couriers */}
                  <button
                    onClick={() => {
                      setIsCourierModalOpen(true);
                      setIsSettingsMenuOpen(false);
                    }}
                    className="w-full text-left px-3 py-2 rounded-xl text-xs font-semibold text-teal-700 dark:text-teal-300 hover:bg-teal-50 dark:hover:bg-teal-950/40 flex items-center justify-between transition-colors"
                  >
                    <div className="flex items-center gap-2.5">
                      <Truck className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                      <span>{t('বিডি কুরিয়ার', 'BD Couriers')}</span>
                    </div>
                    <ChevronRight className="w-3.5 h-3.5 text-gray-400" />
                  </button>

                  <div className="my-1 border-t border-gray-100 dark:border-gray-700"></div>

                  {/* Seller Dashboard */}
                  <button
                    onClick={() => {
                      setCurrentView('seller-dashboard');
                      setIsSettingsMenuOpen(false);
                    }}
                    className="w-full text-left px-3 py-2 rounded-xl text-xs font-semibold text-emerald-700 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 flex items-center justify-between transition-colors"
                  >
                    <div className="flex items-center gap-2.5">
                      <Store className="w-4 h-4 text-amber-500" />
                      <span>{t('সেলার ড্যাশবোর্ড', 'Seller Dashboard')}</span>
                    </div>
                    <ChevronRight className="w-3.5 h-3.5 text-gray-400" />
                  </button>

                  {/* Admin Dashboard */}
                  <button
                    onClick={() => {
                      setCurrentView('admin-dashboard');
                      setIsSettingsMenuOpen(false);
                    }}
                    className="w-full text-left px-3 py-2 rounded-xl text-xs font-semibold text-purple-700 dark:text-purple-300 hover:bg-purple-50 dark:hover:bg-purple-950/40 flex items-center justify-between transition-colors"
                  >
                    <div className="flex items-center gap-2.5">
                      <LayoutDashboard className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                      <span>{t('অ্যাডমিন ড্যাশবোর্ড', 'Admin Dashboard')}</span>
                    </div>
                    <ChevronRight className="w-3.5 h-3.5 text-gray-400" />
                  </button>

                  {/* Customer Profile / Sign In & Settings */}
                  <button
                    onClick={() => {
                      if (user) {
                        setCurrentView('user-dashboard');
                      } else {
                        setIsAuthModalOpen(true);
                      }
                      setIsSettingsMenuOpen(false);
                    }}
                    className="w-full text-left px-3 py-2 rounded-xl text-xs font-semibold text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center justify-between transition-colors"
                  >
                    <div className="flex items-center gap-2.5">
                      <UserIcon className="w-4 h-4 text-emerald-600" />
                      <span>{user ? t('কাস্টমার প্রোফাইল ও অ্যাকাউন্ট', 'Customer Profile & Account') : t('লগইন / রেজিস্টার করুন', 'Sign In / Register')}</span>
                    </div>
                    <ChevronRight className="w-3.5 h-3.5 text-gray-400" />
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </nav>

      {/* Mobile Menu Drawer */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white dark:bg-gray-900 border-t border-gray-100 dark:border-gray-800 p-4 space-y-3 animate-in slide-in-from-top duration-200">
          <div className="grid grid-cols-2 gap-2 pb-3 border-b border-gray-100 dark:border-gray-800">
            <button
              onClick={() => {
                setCurrentView('home');
                setIsMobileMenuOpen(false);
              }}
              className="p-2 text-xs font-semibold rounded-lg bg-gray-50 dark:bg-gray-800 text-left"
            >
              🏠 {t('হোম', 'Home')}
            </button>
            <button
              onClick={() => {
                setCurrentView('shop');
                setIsMobileMenuOpen(false);
              }}
              className="p-2 text-xs font-semibold rounded-lg bg-gray-50 dark:bg-gray-800 text-left"
            >
              🛍️ {t('সকল পণ্য', 'Shop All')}
            </button>
            <button
              onClick={() => {
                setCurrentView('categories');
                setIsMobileMenuOpen(false);
              }}
              className="p-2 text-xs font-semibold rounded-lg bg-gray-50 dark:bg-gray-800 text-left"
            >
              📂 {t('ক্যাটাগরি', 'Categories')}
            </button>
            <button
              onClick={() => {
                handleSelectCategory('deshi-products');
                setIsMobileMenuOpen(false);
              }}
              className="p-2 text-xs font-semibold rounded-lg bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-400 text-left"
            >
              ✨ {t('দেশি পণ্য', 'Deshi Products')}
            </button>
          </div>

          <div>
            <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider block mb-2">
              {t('ক্যাটাগরি ব্রাউজ করুন', 'Browse Categories')}
            </span>
            <div className="max-h-52 overflow-y-auto space-y-1">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => {
                    handleSelectCategory(cat.id);
                    setIsMobileMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 text-xs font-medium rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 flex items-center justify-between text-gray-700 dark:text-gray-200"
                >
                  <span>{t(cat.nameBn, cat.name)}</span>
                  <span className="text-[10px] text-gray-400">({cat.itemCount})</span>
                </button>
              ))}
            </div>
          </div>

          {/* All Utility Icons Grouped Inside Settings Button (Mobile) */}
          <div className="pt-3 border-t border-gray-100 dark:border-gray-800 space-y-2">
            <button
              onClick={() => setIsMobileSettingsExpanded(!isMobileSettingsExpanded)}
              className="w-full py-2.5 px-3 bg-emerald-600 text-white rounded-xl text-xs font-bold flex items-center justify-between shadow-sm"
            >
              <div className="flex items-center gap-2">
                <Settings className={`w-4 h-4 transition-transform ${isMobileSettingsExpanded ? 'rotate-90' : ''}`} />
                <span>{t('সেটিংস ও সকল টুলস', 'Settings & All Tools')}</span>
                {unreadSmsCount > 0 && (
                  <span className="px-1.5 py-0.5 rounded-full bg-rose-500 text-white text-[10px] font-extrabold">
                    {unreadSmsCount}
                  </span>
                )}
              </div>
              <ChevronDown className={`w-4 h-4 transition-transform ${isMobileSettingsExpanded ? 'rotate-180' : ''}`} />
            </button>

            {isMobileSettingsExpanded && (
              <div className="flex flex-col gap-1.5 p-2 rounded-2xl bg-gray-50 dark:bg-gray-800/70 border border-gray-200 dark:border-gray-700">
                <button
                  onClick={() => {
                    openSmsNotificationModal('notifications');
                    setIsMobileMenuOpen(false);
                  }}
                  className="w-full py-2 px-3 bg-amber-50 dark:bg-amber-950/50 text-amber-800 dark:text-amber-300 border border-amber-300 dark:border-amber-700 rounded-xl text-xs font-bold flex items-center justify-between"
                >
                  <div className="flex items-center gap-2">
                    <Bell className="w-4 h-4 text-amber-600" />
                    <Wallet className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{t('রসিদ SMS / বাকি', 'Receipt SMS & Pay Baki')}</span>
                  </div>
                  {unreadSmsCount > 0 && (
                    <span className="px-1.5 py-0.5 rounded-full bg-rose-500 text-white text-[10px]">
                      {unreadSmsCount}
                    </span>
                  )}
                </button>
                <button
                  onClick={() => {
                    openCategoryCashMemo('all');
                    setIsMobileMenuOpen(false);
                  }}
                  className="w-full py-2 px-3 bg-emerald-50 dark:bg-emerald-950/50 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 rounded-xl text-xs font-bold flex items-center gap-2"
                >
                  <Receipt className="w-4 h-4 text-emerald-600" />
                  <span>{t('ক্যাটাগরি ক্যাশ মেমো / ইনভয়েজ', 'Category Cash Memo / Invoice')}</span>
                </button>
                <button
                  onClick={() => {
                    setCurrentView('shop');
                    setIsMobileMenuOpen(false);
                  }}
                  className="w-full py-2 px-3 bg-rose-50 dark:bg-rose-950/40 text-rose-600 rounded-xl text-xs font-bold flex items-center gap-2"
                >
                  <Flame className="w-4 h-4" />
                  <span>{t('ফ্ল্যাশ সেল', 'Flash Sale')}</span>
                </button>
                <button
                  onClick={() => {
                    setCurrentView('shop');
                    setIsMobileMenuOpen(false);
                  }}
                  className="w-full py-2 px-3 bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400 rounded-xl text-xs font-bold flex items-center gap-2"
                >
                  <Tag className="w-4 h-4" />
                  <span>{t('অফার সমূহ', 'Offers')}</span>
                </button>
                <button
                  onClick={() => {
                    openThemeStudio();
                    setIsMobileMenuOpen(false);
                  }}
                  className="w-full py-2 px-3 bg-purple-50 dark:bg-purple-950/50 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800 rounded-xl text-xs font-bold flex items-center gap-2"
                >
                  <Palette className="w-4 h-4 text-purple-600" />
                  <span>{t('১০০+ থিম', '100+ Themes')}</span>
                </button>
                <button
                  onClick={() => {
                    setIsCourierModalOpen(true);
                    setIsMobileMenuOpen(false);
                  }}
                  className="w-full py-2 px-3 bg-teal-50 dark:bg-teal-950/50 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800 rounded-xl text-xs font-bold flex items-center gap-2"
                >
                  <Truck className="w-4 h-4 text-teal-600" />
                  <span>{t('বিডি কুরিয়ার', 'BD Couriers')}</span>
                </button>
                <button
                  onClick={() => {
                    setCurrentView('seller-dashboard');
                    setIsMobileMenuOpen(false);
                  }}
                  className="w-full py-2 px-3 bg-amber-500 text-gray-950 rounded-xl text-xs font-bold flex items-center gap-2"
                >
                  <Store className="w-4 h-4" />
                  <span>{t('সেলার ড্যাশবোর্ড', 'Seller Dashboard')}</span>
                </button>
                <button
                  onClick={() => {
                    setCurrentView('admin-dashboard');
                    setIsMobileMenuOpen(false);
                  }}
                  className="w-full py-2 px-3 bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-200 border border-gray-200 dark:border-gray-700 rounded-xl text-xs font-bold flex items-center gap-2"
                >
                  <LayoutDashboard className="w-4 h-4 text-purple-600" />
                  <span>{t('অ্যাডমিন ড্যাশবোর্ড', 'Admin Dashboard')}</span>
                </button>
                <button
                  onClick={() => {
                    if (user) {
                      setCurrentView('user-dashboard');
                    } else {
                      setIsAuthModalOpen(true);
                    }
                    setIsMobileMenuOpen(false);
                  }}
                  className="w-full py-2 px-3 bg-emerald-600 text-white rounded-xl text-xs font-bold flex items-center gap-2"
                >
                  <UserIcon className="w-4 h-4" />
                  <span>{user ? t('কাস্টমার প্রোফাইল ও সেটিংস', 'Customer Profile & Settings') : t('লগইন / সাইন ইন ও রেজিস্টার', 'Customer Sign In & Register')}</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
