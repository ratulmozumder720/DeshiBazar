import React from 'react';
import { useApp } from '../context/AppContext';
import { ShoppingCart, Tag, Sparkles, ShieldCheck, Zap, ArrowRight, CheckCircle2 } from 'lucide-react';

export const HeroSection: React.FC = () => {
  const { t, setCurrentView, setSelectedCategory } = useApp();

  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-emerald-50 via-white to-gray-50 dark:from-gray-900 dark:via-gray-850 dark:to-gray-900 py-8 lg:py-14 border-b border-gray-100 dark:border-gray-800 transition-colors">
      {/* Background Decorative patterns */}
      <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 rounded-full bg-emerald-300/15 dark:bg-emerald-500/10 blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-80 h-80 rounded-full bg-amber-300/15 dark:bg-amber-500/10 blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Column: Copy & CTAs */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            {/* Top pill */}
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-100 dark:bg-emerald-950/80 border border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs font-bold shadow-sm">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>{t('১০০% খাঁটি ও তাজা দেশি পণ্য', '100% Fresh & Authentic Deshi Goods')}</span>
            </div>

            {/* Headline */}
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-gray-900 dark:text-white leading-[1.18] tracking-tight">
              {t(
                'দেশি বাজার এখন আপনার হাতের মুঠোয়',
                'Your Local Market, Delivered Better'
              )}
            </h1>

            {/* Subheadline */}
            <p className="text-base sm:text-lg text-gray-600 dark:text-gray-300 max-w-xl mx-auto lg:mx-0 font-normal leading-relaxed">
              {t(
                'তাজা খাবার, দেশি পণ্য ও দৈনন্দিন প্রয়োজনীয় সবকিছু—এক জায়গায়। সরাসরি কৃষক ও বিশ্বস্ত কারিগরদের থেকে আপনার দরজায়।',
                'Fresh produce, authentic deshi items, and everyday essentials—all in one place. Sourced directly from local farmers and vetted master artisans.'
              )}
            </p>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3 sm:gap-4 pt-2">
              <button
                onClick={() => setCurrentView('shop')}
                className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 transform active:scale-95 transition-all"
              >
                <ShoppingCart className="w-4 h-4" />
                <span>{t('এখনই শপিং করুন', 'Shop Now')}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => {
                  setSelectedCategory(null);
                  setCurrentView('shop');
                }}
                className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-gray-950 font-bold text-sm shadow-md shadow-amber-500/20 flex items-center justify-center gap-2 transform active:scale-95 transition-all"
              >
                <Tag className="w-4 h-4 text-emerald-950" />
                <span>{t('অফার দেখুন', 'Explore Offers')}</span>
              </button>
            </div>

            {/* 3 Core Trust Badges */}
            <div className="pt-4 grid grid-cols-3 gap-3 border-t border-gray-200 dark:border-gray-800 text-left">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-emerald-100 dark:bg-emerald-950 flex items-center justify-center text-emerald-600 dark:text-emerald-400 shrink-0">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-gray-900 dark:text-white">
                    {t('১০০% খাঁটি', '100% Organic')}
                  </h4>
                  <p className="text-[10px] text-gray-500">{t('রাসায়নিকমুক্ত', 'Pure & Natural')}</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-950 flex items-center justify-center text-blue-600 dark:text-blue-400 shrink-0">
                  <Zap className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-gray-900 dark:text-white">
                    {t('দ্রুত ডেলিভারি', 'Fast Delivery')}
                  </h4>
                  <p className="text-[10px] text-gray-500">{t('আপনার দরজায়', 'To Your Doorstep')}</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-amber-100 dark:bg-amber-950 flex items-center justify-center text-amber-600 dark:text-amber-400 shrink-0">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-gray-900 dark:text-white">
                    {t('নিরাপদ পেমেন্ট', 'Secure COD')}
                  </h4>
                  <p className="text-[10px] text-gray-500">{t('বিকাশ ও নগদ', 'bKash & Nagad')}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Visual Grocery & Deshi Showcase */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              {/* Main Bangladesh shopping hero card */}
              <div className="relative rounded-3xl overflow-hidden shadow-2xl border-4 border-white dark:border-gray-800 bg-white dark:bg-gray-800">
                <img
                  src="https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=800&q=80"
                  alt="Deshi Bazar Fresh Produce"
                  className="w-full h-80 sm:h-96 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-950/80 via-black/20 to-transparent flex flex-col justify-end p-6 text-white">
                  <span className="bg-amber-500 text-gray-950 text-xs font-black px-2.5 py-1 rounded-md inline-block w-max mb-1 uppercase tracking-wide">
                    {t('বিশেষ ছাড় ২৫%', 'Special 25% Off')}
                  </span>
                  <h3 className="text-lg font-bold">
                    {t('মাওয়া ঘাটের তাজা ইলিশ ও দিনাজপুরের মিনিকেট চাল', 'Fresh Mawa Hilsha & Dinajpur Miniket')}
                  </h3>
                  <p className="text-xs text-gray-200 mt-1">
                    {t('সরাসরি নদী ও গ্রাম থেকে সেরা মূল্যে', 'Direct from river & rural farms at best rates')}
                  </p>
                </div>
              </div>

              {/* Floating Badge 1: Farm Fresh Everyday */}
              <div className="absolute -top-4 -right-4 sm:-right-6 bg-white dark:bg-gray-800 rounded-2xl p-3 shadow-xl border border-gray-100 dark:border-gray-700 flex items-center gap-3 animate-bounce duration-1000">
                <div className="w-10 h-10 rounded-xl bg-emerald-500 text-white flex items-center justify-center font-bold text-lg shadow-md">
                  🌾
                </div>
                <div>
                  <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 block uppercase">
                    {t('গ্রামের খাঁটি পণ্য', 'Pure Village Harvest')}
                  </span>
                  <span className="text-xs font-black text-gray-900 dark:text-white">
                    {t('শতভাগ তাজা ও নিরাপদ', '100% Farm Fresh')}
                  </span>
                </div>
              </div>

              {/* Floating Badge 2: Coupon Voucher Callout */}
              <div className="absolute -bottom-5 -left-4 sm:-left-6 bg-emerald-900 text-white rounded-2xl p-3 shadow-2xl border border-emerald-700 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-400 text-gray-950 flex items-center justify-center font-bold text-lg">
                  🎁
                </div>
                <div>
                  <span className="text-[10px] text-amber-300 font-bold block">
                    {t('প্রথম অর্ডারে ২০% ছাড়!', 'First Order 20% OFF!')}
                  </span>
                  <span className="text-xs font-mono font-bold tracking-wider bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-700">
                    WELCOME20
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
