import React from 'react';
import { useApp } from '../context/AppContext';
import { Store, ShieldCheck, Star, MapPin, Package, ArrowRight } from 'lucide-react';

export const LocalSellersSection: React.FC = () => {
  const { t, sellers, setSelectedSellerId, setSelectedCategory, setCurrentView } = useApp();

  const handleVisitStore = (sellerId: string) => {
    setSelectedSellerId(sellerId);
    setSelectedCategory(null);
    setCurrentView('shop');
  };

  return (
    <section className="py-12 bg-white dark:bg-gray-900 border-b border-gray-100 dark:border-gray-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4">
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 text-xs font-bold uppercase tracking-wider mb-1">
              <Store className="w-4 h-4 text-emerald-500" />
              <span>{t('মাল্টি-ভেন্ডর মার্কেটপ্লেস', 'Multi-Vendor Marketplace')}</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white tracking-tight">
              {t('আপনার কাছের বিক্রেতা', 'Local Verified Sellers')}
            </h2>
            <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400 mt-1">
              {t(
                'বাংলাদেশের বিভিন্ন প্রান্তের বিশ্বস্ত খামারি, তাঁতি ও অনুমোদিত বিক্রেতাদের নিজস্ব দোকান',
                'Connect directly with vetted regional farmers, weaver guilds, and specialty shops'
              )}
            </p>
          </div>

          <button
            onClick={() => setCurrentView('seller-dashboard')}
            className="flex items-center gap-1.5 text-xs font-bold text-amber-600 dark:text-amber-400 hover:text-amber-700 transition-colors"
          >
            <span>{t('বিক্রেতা হতে চান? মার্চেন্ট সাইন-আপ', 'Want to sell on DeshiBazar?')}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Sellers Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sellers.map((seller) => (
            <div
              key={seller.id}
              className="bg-gray-50 dark:bg-gray-800/80 rounded-2xl border border-gray-200 dark:border-gray-700/80 p-5 hover:border-emerald-500 hover:shadow-xl transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                {/* Header with Logo and Verified Badge */}
                <div className="flex items-start justify-between gap-3 mb-4">
                  <div className="flex items-center gap-3">
                    <img
                      src={seller.logo}
                      alt={seller.name}
                      className="w-14 h-14 rounded-2xl object-cover border-2 border-white dark:border-gray-700 shadow-sm"
                    />
                    <div>
                      <div className="flex items-center gap-1.5">
                        <h3 className="text-sm font-bold text-gray-900 dark:text-white line-clamp-1">
                          {t(seller.nameBn, seller.name)}
                        </h3>
                      </div>
                      <div className="flex items-center gap-1 text-[11px] text-gray-500 dark:text-gray-400 mt-0.5">
                        <MapPin className="w-3 h-3 text-emerald-600 shrink-0" />
                        <span>{seller.location}</span>
                      </div>
                    </div>
                  </div>

                  {seller.verified && (
                    <span className="inline-flex items-center gap-1 bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-300 dark:border-emerald-800">
                      <ShieldCheck className="w-3 h-3 text-emerald-600" />
                      <span>{t('ভেরিফাইড', 'Verified')}</span>
                    </span>
                  )}
                </div>

                {/* Seller Description */}
                <p className="text-xs text-gray-600 dark:text-gray-300 line-clamp-2 mb-4 leading-relaxed">
                  {t(seller.descriptionBn, seller.description)}
                </p>

                {/* Metrics */}
                <div className="grid grid-cols-2 gap-2 bg-white dark:bg-gray-750 p-2.5 rounded-xl border border-gray-100 dark:border-gray-700 mb-4 text-center">
                  <div className="flex items-center justify-center gap-1 text-xs font-bold text-gray-800 dark:text-gray-200">
                    <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                    <span>{seller.rating}</span>
                    <span className="text-[10px] text-gray-400">({seller.reviewsCount})</span>
                  </div>
                  <div className="flex items-center justify-center gap-1 text-xs font-bold text-gray-800 dark:text-gray-200">
                    <Package className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{seller.productsCount} {t('পণ্য', 'Products')}</span>
                  </div>
                </div>
              </div>

              {/* Visit Store Button */}
              <button
                type="button"
                onClick={() => handleVisitStore(seller.id)}
                className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 shadow-sm"
              >
                <Store className="w-3.5 h-3.5" />
                <span>{t('দোকান ভিজিট করুন', 'Visit Store')}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
