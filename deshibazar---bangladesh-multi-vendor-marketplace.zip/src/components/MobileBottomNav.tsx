import React from 'react';
import { useApp } from '../context/AppContext';
import { Home, Grid, Search, ShoppingBag, User } from 'lucide-react';

export const MobileBottomNav: React.FC = () => {
  const { currentView, setCurrentView, cartItemsCount, setIsCartDrawerOpen, setIsAuthModalOpen, user, t, customerUIConfig } = useApp();

  const navStyle = customerUIConfig?.mobileBottomNavStyle || 'floating-pill';

  let containerClass = "md:hidden fixed z-40 px-3 py-2 flex items-center justify-around transition-all";
  if (navStyle === 'floating-pill') {
    containerClass += " bottom-3 left-4 right-4 bg-white/95 dark:bg-gray-900/95 backdrop-blur-xl border border-gray-200/80 dark:border-gray-800/80 rounded-full shadow-2xl max-w-md mx-auto px-4";
  } else if (navStyle === 'glassmorphism') {
    containerClass += " bottom-0 left-0 right-0 bg-white/75 dark:bg-gray-900/75 backdrop-blur-2xl border-t border-gray-200/50 dark:border-gray-800/50 shadow-lg";
  } else if (navStyle === 'glow-active') {
    containerClass += " bottom-0 left-0 right-0 bg-gray-950/95 backdrop-blur-md border-t border-gray-800 shadow-2xl text-gray-400";
  } else {
    containerClass += " bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800 shadow-md";
  }

  return (
    <div className={containerClass}>
      <button
        onClick={() => setCurrentView('home')}
        className={`flex flex-col items-center gap-1 transition-colors ${
          currentView === 'home' ? 'text-emerald-600 dark:text-emerald-400 font-bold' : 'text-gray-500 dark:text-gray-400'
        }`}
      >
        <Home className="w-5 h-5" />
        <span className="text-[10px]">{t('হোম', 'Home')}</span>
      </button>

      <button
        onClick={() => setCurrentView('categories')}
        className={`flex flex-col items-center gap-1 transition-colors ${
          currentView === 'categories' ? 'text-emerald-600 dark:text-emerald-400 font-bold' : 'text-gray-500 dark:text-gray-400'
        }`}
      >
        <Grid className="w-5 h-5" />
        <span className="text-[10px]">{t('ক্যাটাগরি', 'Categories')}</span>
      </button>

      <button
        onClick={() => setCurrentView('shop')}
        className={`flex flex-col items-center gap-1 transition-colors ${
          currentView === 'shop' ? 'text-emerald-600 dark:text-emerald-400 font-bold' : 'text-gray-500 dark:text-gray-400'
        }`}
      >
        <Search className="w-5 h-5" />
        <span className="text-[10px]">{t('সার্চ', 'Search')}</span>
      </button>

      <button
        onClick={() => setIsCartDrawerOpen(true)}
        className="flex flex-col items-center gap-1 text-gray-500 dark:text-gray-400 relative transition-colors"
      >
        <div className="relative">
          <ShoppingBag className="w-5 h-5" />
          {cartItemsCount > 0 && (
            <span className="absolute -top-1.5 -right-2 bg-emerald-600 text-white text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
              {cartItemsCount}
            </span>
          )}
        </div>
        <span className="text-[10px]">{t('ব্যাগ', 'Cart')}</span>
      </button>

      <button
        onClick={() => {
          if (user) {
            setCurrentView('user-dashboard');
          } else {
            setIsAuthModalOpen(true);
          }
        }}
        className={`flex flex-col items-center gap-1 transition-colors ${
          currentView === 'user-dashboard' ? 'text-emerald-600 dark:text-emerald-400 font-bold' : 'text-gray-500 dark:text-gray-400'
        }`}
      >
        <User className="w-5 h-5" />
        <span className="text-[10px]">{t('অ্যাকাউন্ট', 'Account')}</span>
      </button>
    </div>
  );
};
