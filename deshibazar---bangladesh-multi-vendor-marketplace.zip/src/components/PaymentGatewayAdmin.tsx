import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { apiService } from '../utils/apiService';
import { BANGLADESHI_BANKS, DEFAULT_PAYMENT_GATEWAY_CONFIG, PaymentGatewayConfig } from '../data/bangladeshiBanks';
import { BangladeshiBank } from '../types';
import { 
  Building2, 
  CreditCard, 
  CheckCircle2, 
  ShieldCheck, 
  Edit, 
  Save, 
  RefreshCw, 
  ChevronDown,
  Search
} from 'lucide-react';

export const PaymentGatewayAdmin: React.FC = () => {
  const { t, language, showToast, orders } = useApp();

  const [banksList, setBanksList] = useState<BangladeshiBank[]>(BANGLADESHI_BANKS);
  const [gatewayConfig, setGatewayConfig] = useState<PaymentGatewayConfig>(DEFAULT_PAYMENT_GATEWAY_CONFIG);
  const [loading, setLoading] = useState(false);
  const [activeSubTab, setActiveSubTab] = useState<'banks' | 'aggregators' | 'verification' | 'logs'>('banks');

  // Bank Edit Modal state
  const [editingBank, setEditingBank] = useState<BangladeshiBank | null>(null);
  const [editAccName, setEditAccName] = useState('');
  const [editAccNum, setEditAccNum] = useState('');
  const [editBranch, setEditBranch] = useState('');
  const [editRouting, setEditRouting] = useState('');

  // Manual verification tool state
  const [verifyOrderNum, setVerifyOrderNum] = useState('');
  const [verifyBankId, setVerifyBankId] = useState('ibbl');
  const [verifyTxnRef, setVerifyTxnRef] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [adminSelectedBankFilter, setAdminSelectedBankFilter] = useState<string>('all');
  const [adminBankSearchQuery, setAdminBankSearchQuery] = useState<string>('');

  // Load from backend
  const loadPaymentData = async () => {
    setLoading(true);
    try {
      const [banksRes, gatewayRes] = await Promise.all([
        apiService.getBangladeshiBanks(),
        apiService.getPaymentGateways()
      ]);
      if (banksRes?.success && Array.isArray(banksRes.banks)) {
        setBanksList(banksRes.banks);
      }
      if (gatewayRes?.success && gatewayRes.config) {
        setGatewayConfig(gatewayRes.config);
      }
    } catch (e) {
      console.warn(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPaymentData();
  }, []);

  const handleToggleBank = async (bankId: string, currentStatus: boolean) => {
    const nextStatus = !currentStatus;
    setBanksList(prev => prev.map(b => b.id === bankId ? { ...b, isActive: nextStatus } : b));
    try {
      await apiService.toggleBankStatus(bankId, nextStatus);
      showToast(
        nextStatus 
          ? t('ব্যাংক সফলভাবে সক্রিয় করা হয়েছে!', 'Bank payment activated!') 
          : t('ব্যাংক নিষ্ক্রিয় করা হয়েছে', 'Bank payment deactivated'), 
        'info'
      );
    } catch {
      showToast('Status update failed', 'error');
    }
  };

  const handleOpenEditModal = (bank: BangladeshiBank) => {
    setEditingBank(bank);
    setEditAccName(bank.accountName);
    setEditAccNum(bank.accountNumber);
    setEditBranch(bank.branchName);
    setEditRouting(bank.routingNumber);
  };

  const handleSaveBankDetails = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingBank) return;

    const updated = {
      accountName: editAccName.trim(),
      accountNumber: editAccNum.trim(),
      branchName: editBranch.trim(),
      routingNumber: editRouting.trim()
    };

    setBanksList(prev => prev.map(b => b.id === editingBank.id ? { ...b, ...updated } : b));
    try {
      await apiService.updateBankDetails(editingBank.id, updated);
      showToast(t('ব্যাংক অ্যাকাউন্টের বিবরণ সফলভাবে সংরক্ষিত হয়েছে!', 'Bank account details saved successfully!'), 'success');
      setEditingBank(null);
    } catch {
      showToast('Failed to save bank details', 'error');
    }
  };

  const handleSaveGatewayConfig = async () => {
    try {
      await apiService.updatePaymentGateways(gatewayConfig);
      showToast(t('পেমেন্ট গেটওয়ে কনফিগারেশন সংরক্ষিত হয়েছে!', 'Gateway credentials saved successfully!'), 'success');
    } catch {
      showToast('Failed to save gateway config', 'error');
    }
  };

  const handleVerifyBankTxn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!verifyOrderNum.trim() || !verifyTxnRef.trim()) {
      showToast(t('অনুগ্রহ করে অর্ডার নম্বর ও ট্রানজেকশন রেফারেন্স দিন', 'Please enter order number and transaction reference'), 'error');
      return;
    }
    setIsVerifying(true);
    try {
      const res = await apiService.verifyBankTransfer(verifyOrderNum.trim(), verifyBankId, verifyTxnRef.trim());
      if (res?.success) {
        showToast(t(`অর্ডার ${verifyOrderNum} এর ব্যাংক পেমেন্ট সফলভাবে অনুমোদিত হয়েছে!`, `Order ${verifyOrderNum} bank payment approved!`), 'success');
        setVerifyOrderNum('');
        setVerifyTxnRef('');
      } else {
        showToast(res?.error || 'Verification failed', 'error');
      }
    } catch (err: any) {
      showToast(err?.message || 'Verification error', 'error');
    } finally {
      setIsVerifying(false);
    }
  };

  // Filter bank transfer orders
  const bankTransferOrders = orders.filter(o => o.paymentMethod === 'bank_transfer');

  return (
    <div className="space-y-6">
      
      {/* 1. TOP HEADER & METRICS */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-base font-black text-gray-900 dark:text-white">
              {t('বাংলাদেশি ব্যাংক পেমেন্ট গেটওয়ে ও একাউন্ট কন্ট্রোল', 'Bangladeshi Bank Payment Gateway & Merchant Management')}
            </h3>
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-700 text-[10px] font-black uppercase">
              Live Gateway
            </span>
          </div>
          <p className="text-xs text-gray-400 mt-0.5">
            {t('ইসলামী ব্যাংক (CellFin), ডিবিবিএল (NexusPay), সিটি টাচ, ব্র্যাক ব্যাংক (Astha) ও এনপিএসবি ২৪/৭ চ্যানেল নিয়ন্ত্রণ', 'Manage IBBL, DBBL, City Bank, BRAC Astha, EBL, Sonali Bank accounts and NPSB channels')}
          </p>
        </div>

        <button
          onClick={loadPaymentData}
          disabled={loading}
          className="px-3.5 py-2 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 text-gray-700 dark:text-gray-200 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 active:scale-95"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>{t('রিফ্রেশ', 'Sync Gateways')}</span>
        </button>
      </div>

      {/* 4 SUMMARY STATS */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="p-4 rounded-2xl bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 shadow-xs">
          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">
            {t('সংযুক্ত ব্যাংক সংখ্যা', 'Active Banks')}
          </span>
          <div className="text-xl font-black text-emerald-600">
            {banksList.filter(b => b.isActive).length} / {banksList.length}
          </div>
          <span className="text-[10px] text-gray-400 mt-1 block">IBBL, DBBL, City, BRAC, EBL</span>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 shadow-xs">
          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">
            {t('মোট ব্যাংক সেটেলমেন্ট', 'Bank Settlements')}
          </span>
          <div className="text-xl font-black text-purple-600">
            ৳492,850
          </div>
          <span className="text-[10px] text-emerald-600 font-bold mt-1 block">NPSB & BEFTN 100% Settled</span>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 shadow-xs">
          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">
            {t('মোবাইল ও ওয়ালেট গেটওয়ে', 'MFS Gateways')}
          </span>
          <div className="text-xl font-black text-[#E2136E]">
            bKash, Nagad, Rocket
          </div>
          <span className="text-[10px] text-gray-400 mt-1 block">Direct Merchant API Connected</span>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 shadow-xs">
          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">
            {t('অনুমোদনের অপেক্ষায় স্লিপ', 'Pending Slips')}
          </span>
          <div className="text-xl font-black text-amber-500">
            {bankTransferOrders.filter(o => o.paymentStatus === 'pending').length} Orders
          </div>
          <span className="text-[10px] text-amber-600 font-semibold mt-1 block">Awaiting Verification</span>
        </div>
      </div>

      {/* SUB-TABS (BANKS / AGGREGATORS / VERIFICATION) */}
      <div className="flex border-b border-gray-200 dark:border-gray-700 gap-2">
        {[
          { id: 'banks', label: t('বাংলাদেশি ব্যাংকসমূহ (৯টি ব্যাংক)', 'Bangladeshi Banks (9)'), icon: Building2 },
          { id: 'aggregators', label: t('গেটওয়ে ও এপিআই ক্রিডেনশিয়ালস', 'Gateways & API Credentials'), icon: CreditCard },
          { id: 'verification', label: t('ব্যাংক স্লিপ যাচাইকরণ টুল', 'Bank Transfer Verification'), icon: ShieldCheck, badge: bankTransferOrders.length },
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as any)}
              className={`flex items-center gap-2 py-3 px-4 border-b-2 text-xs font-bold transition-all relative ${
                isActive
                  ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400'
                  : 'border-transparent text-gray-500 hover:text-gray-900 dark:hover:text-white'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
              {Boolean(tab.badge) && (
                <span className="px-1.5 py-0.2 rounded-full bg-emerald-600 text-white text-[10px] font-bold">
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* SUB-TAB 1: BANGLADESHI BANKS DIRECTORY & CONTROLS */}
      {activeSubTab === 'banks' && (() => {
        const filteredAdminBanks = banksList.filter(b => {
          if (adminSelectedBankFilter === 'active' && !b.isActive) return false;
          if (adminSelectedBankFilter === 'inactive' && b.isActive) return false;
          if (adminSelectedBankFilter !== 'all' && adminSelectedBankFilter !== 'active' && adminSelectedBankFilter !== 'inactive' && b.id !== adminSelectedBankFilter) return false;
          if (adminBankSearchQuery.trim()) {
            const q = adminBankSearchQuery.toLowerCase();
            return b.name.toLowerCase().includes(q) || b.nameBn.toLowerCase().includes(q) || b.shortCode.toLowerCase().includes(q) || b.accountNumber.toLowerCase().includes(q);
          }
          return true;
        });

        return (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <p className="text-xs text-gray-500">
                {t(
                  'চেকআউটে গ্রাহকদের জন্য যেসব ব্যাংক সক্রিয় থাকবে তাদের তালিকা নিচে দেওয়া হলো। একাউন্ট নম্বর বা রাউটিং নম্বর পরিবর্তন করতে "এডিট" চাপুন।',
                  'Toggle active banks for customer checkout and configure merchant receiving account details.'
                )}
              </p>
            </div>

            {/* Bank Dropdown Filter & Search Control */}
            <div className="p-3.5 rounded-2xl bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 shadow-xs flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2 flex-1">
                <div className="relative flex-1">
                  <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={adminBankSearchQuery}
                    onChange={(e) => setAdminBankSearchQuery(e.target.value)}
                    placeholder={t('ব্যাংকের নাম বা কোড দিয়ে খুঁজুন...', 'Search bank by name or code...')}
                    className="w-full bg-gray-50 dark:bg-gray-750 border border-gray-200 dark:border-gray-600 rounded-xl pl-8 pr-3 py-1.5 text-xs text-gray-900 dark:text-white"
                  />
                </div>

                {/* Bank Selector Dropdown Button */}
                <div className="relative min-w-[200px]">
                  <select
                    value={adminSelectedBankFilter}
                    onChange={(e) => setAdminSelectedBankFilter(e.target.value)}
                    className="w-full bg-gray-50 dark:bg-gray-750 border border-gray-200 dark:border-gray-600 rounded-xl px-3 py-1.5 text-xs font-bold text-gray-800 dark:text-gray-200 cursor-pointer appearance-none pr-8"
                  >
                    <option value="all">🏦 {t('সকল ব্যাংক (All Banks)', 'All Banks')}</option>
                    <option value="active">✅ {t('সক্রিয় ব্যাংকসমূহ (Active Only)', 'Active Only')}</option>
                    <option value="inactive">❌ {t('নিষ্ক্রিয় ব্যাংকসমূহ (Inactive)', 'Inactive')}</option>
                    {banksList.map(b => (
                      <option key={b.id} value={b.id}>
                        {b.shortCode} - {b.name}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="w-3.5 h-3.5 text-gray-500 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                </div>
              </div>

              <span className="text-[11px] text-gray-400 font-bold self-center">
                {filteredAdminBanks.length} / {banksList.length} {t('টি ব্যাংক প্রদর্শিত', 'Banks shown')}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredAdminBanks.map((bank) => (
              <div 
                key={bank.id}
                className={`p-4 rounded-2xl border transition-all flex flex-col justify-between space-y-3 bg-white dark:bg-gray-800 ${
                  bank.isActive 
                    ? 'border-emerald-500/50 shadow-xs' 
                    : 'border-gray-200 dark:border-gray-700 opacity-60'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div className="flex items-center gap-2.5">
                      <div 
                        className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-black text-xs shrink-0 shadow-xs"
                        style={{ backgroundColor: bank.color }}
                      >
                        {bank.id.substring(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-900 dark:text-white text-xs leading-snug">
                          {language === 'bn' ? bank.nameBn : bank.name}
                        </h4>
                        <span className="text-[10px] text-gray-400 block font-semibold">{bank.shortCode}</span>
                      </div>
                    </div>

                    {/* Active toggle */}
                    <button
                      type="button"
                      onClick={() => handleToggleBank(bank.id, bank.isActive)}
                      className={`px-2.5 py-1 rounded-full text-[10px] font-bold transition-all shrink-0 ${
                        bank.isActive 
                          ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300' 
                          : 'bg-gray-100 text-gray-500 dark:bg-gray-700 dark:text-gray-400'
                      }`}
                    >
                      {bank.isActive ? t('সক্রিয় (Active)', 'Active') : t('নিষ্ক্রিয় (Off)', 'Disabled')}
                    </button>
                  </div>

                  {/* Bank Account Snapshot */}
                  <div className="p-3 rounded-xl bg-gray-50 dark:bg-gray-750 text-[11px] space-y-1.5 border border-gray-100 dark:border-gray-700/80">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">{t('হিসাব নাম:', 'A/C Name:')}</span>
                      <span className="font-bold text-gray-900 dark:text-white truncate max-w-[170px]">{bank.accountName}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">{t('হিসাব নম্বর:', 'A/C No:')}</span>
                      <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">{bank.accountNumber}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">{t('রাউটিং নম্বর:', 'Routing:')}</span>
                      <span className="font-mono text-gray-700 dark:text-gray-300">{bank.routingNumber}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">{t('শাখা:', 'Branch:')}</span>
                      <span className="text-gray-700 dark:text-gray-300 truncate max-w-[170px]">{bank.branchName}</span>
                    </div>
                  </div>

                  {/* Supported channels tags */}
                  <div className="flex flex-wrap gap-1 mt-2">
                    {bank.transferMethods.slice(0, 3).map((m, idx) => (
                      <span key={idx} className="px-2 py-0.5 rounded-md bg-gray-100 dark:bg-gray-700 text-[9px] font-semibold text-gray-600 dark:text-gray-300">
                        {m}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-2 border-t border-gray-100 dark:border-gray-700 flex items-center justify-between">
                  <span className="text-[10px] text-gray-400">{bank.appPlatform}</span>
                  <button
                    onClick={() => handleOpenEditModal(bank)}
                    className="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-650 text-gray-800 dark:text-gray-200 rounded-lg text-xs font-bold flex items-center gap-1 transition-all active:scale-95"
                  >
                    <Edit className="w-3.5 h-3.5" />
                    <span>{t('এডিট একাউন্ট', 'Edit Details')}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      );
    })()}

      {/* SUB-TAB 2: AGGREGATORS & MFS GATEWAYS CONFIG */}
      {activeSubTab === 'aggregators' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* 1. SSLCommerz Aggregator */}
            <div className="bg-white dark:bg-gray-800 rounded-3xl p-5 border border-gray-100 dark:border-gray-700 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <span className="px-2.5 py-1 bg-[#1A1F71] text-white text-[11px] font-black rounded-lg">SSL</span>
                  <div>
                    <h4 className="text-xs font-black text-gray-900 dark:text-white">SSLCommerz Payment Gateway</h4>
                    <span className="text-[10px] text-gray-400">Bangladesh's Largest Payment Aggregator</span>
                  </div>
                </div>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={gatewayConfig.sslCommerz.enabled}
                    onChange={(e) => setGatewayConfig(prev => ({
                      ...prev,
                      sslCommerz: { ...prev.sslCommerz, enabled: e.target.checked }
                    }))}
                    className="accent-emerald-600 rounded"
                  />
                  <span className="text-xs font-bold">{t('সক্রিয়', 'Enabled')}</span>
                </label>
              </div>

              <div className="space-y-2.5 text-xs">
                <div>
                  <label className="text-[11px] text-gray-400 block mb-1">Store ID</label>
                  <input
                    type="text"
                    value={gatewayConfig.sslCommerz.storeId}
                    onChange={(e) => setGatewayConfig(prev => ({
                      ...prev,
                      sslCommerz: { ...prev.sslCommerz, storeId: e.target.value }
                    }))}
                    className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl p-2 font-mono text-xs"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-gray-400 block mb-1">Store Password / Secret</label>
                  <input
                    type="password"
                    value={gatewayConfig.sslCommerz.storePassword}
                    onChange={(e) => setGatewayConfig(prev => ({
                      ...prev,
                      sslCommerz: { ...prev.sslCommerz, storePassword: e.target.value }
                    }))}
                    className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl p-2 font-mono text-xs"
                  />
                </div>
              </div>
            </div>

            {/* 2. ShurjoPay Aggregator */}
            <div className="bg-white dark:bg-gray-800 rounded-3xl p-5 border border-gray-100 dark:border-gray-700 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <span className="px-2.5 py-1 bg-amber-500 text-white text-[11px] font-black rounded-lg">SP</span>
                  <div>
                    <h4 className="text-xs font-black text-gray-900 dark:text-white">shurjoPay Merchant Gateway</h4>
                    <span className="text-[10px] text-gray-400">Bangladesh Bank Authorized PSO</span>
                  </div>
                </div>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={gatewayConfig.shurjoPay.enabled}
                    onChange={(e) => setGatewayConfig(prev => ({
                      ...prev,
                      shurjoPay: { ...prev.shurjoPay, enabled: e.target.checked }
                    }))}
                    className="accent-emerald-600 rounded"
                  />
                  <span className="text-xs font-bold">{t('সক্রিয়', 'Enabled')}</span>
                </label>
              </div>

              <div className="space-y-2.5 text-xs">
                <div>
                  <label className="text-[11px] text-gray-400 block mb-1">Merchant Username</label>
                  <input
                    type="text"
                    value={gatewayConfig.shurjoPay.merchantUsername}
                    onChange={(e) => setGatewayConfig(prev => ({
                      ...prev,
                      shurjoPay: { ...prev.shurjoPay, merchantUsername: e.target.value }
                    }))}
                    className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl p-2 font-mono text-xs"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-gray-400 block mb-1">Merchant Password</label>
                  <input
                    type="password"
                    value={gatewayConfig.shurjoPay.merchantPassword}
                    onChange={(e) => setGatewayConfig(prev => ({
                      ...prev,
                      shurjoPay: { ...prev.shurjoPay, merchantPassword: e.target.value }
                    }))}
                    className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl p-2 font-mono text-xs"
                  />
                </div>
              </div>
            </div>

            {/* 3. bKash Merchant Gateway */}
            <div className="bg-white dark:bg-gray-800 rounded-3xl p-5 border border-gray-100 dark:border-gray-700 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <span className="px-2.5 py-1 bg-[#E2136E] text-white text-[11px] font-black rounded-lg">bKash</span>
                  <div>
                    <h4 className="text-xs font-black text-gray-900 dark:text-white">bKash Direct PGW API</h4>
                    <span className="text-[10px] text-gray-400">Tokenized Checkout API</span>
                  </div>
                </div>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={gatewayConfig.bkashMerchant.enabled}
                    onChange={(e) => setGatewayConfig(prev => ({
                      ...prev,
                      bkashMerchant: { ...prev.bkashMerchant, enabled: e.target.checked }
                    }))}
                    className="accent-[#E2136E] rounded"
                  />
                  <span className="text-xs font-bold">{t('সক্রিয়', 'Enabled')}</span>
                </label>
              </div>

              <div className="space-y-2.5 text-xs">
                <div>
                  <label className="text-[11px] text-gray-400 block mb-1">Merchant MSISDN Number</label>
                  <input
                    type="text"
                    value={gatewayConfig.bkashMerchant.merchantNumber}
                    onChange={(e) => setGatewayConfig(prev => ({
                      ...prev,
                      bkashMerchant: { ...prev.bkashMerchant, merchantNumber: e.target.value }
                    }))}
                    className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl p-2 font-mono text-xs"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-gray-400 block mb-1">App Key</label>
                  <input
                    type="text"
                    value={gatewayConfig.bkashMerchant.appKey}
                    onChange={(e) => setGatewayConfig(prev => ({
                      ...prev,
                      bkashMerchant: { ...prev.bkashMerchant, appKey: e.target.value }
                    }))}
                    className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl p-2 font-mono text-xs"
                  />
                </div>
              </div>
            </div>

            {/* 4. Nagad Direct Gateway */}
            <div className="bg-white dark:bg-gray-800 rounded-3xl p-5 border border-gray-100 dark:border-gray-700 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <span className="px-2.5 py-1 bg-[#F7931E] text-white text-[11px] font-black rounded-lg">NAGAD</span>
                  <div>
                    <h4 className="text-xs font-black text-gray-900 dark:text-white">Nagad Direct PGW</h4>
                    <span className="text-[10px] text-gray-400">Postal Financial Service</span>
                  </div>
                </div>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={gatewayConfig.nagadMerchant.enabled}
                    onChange={(e) => setGatewayConfig(prev => ({
                      ...prev,
                      nagadMerchant: { ...prev.nagadMerchant, enabled: e.target.checked }
                    }))}
                    className="accent-[#F7931E] rounded"
                  />
                  <span className="text-xs font-bold">{t('সক্রিয়', 'Enabled')}</span>
                </label>
              </div>

              <div className="space-y-2.5 text-xs">
                <div>
                  <label className="text-[11px] text-gray-400 block mb-1">Merchant ID</label>
                  <input
                    type="text"
                    value={gatewayConfig.nagadMerchant.merchantId}
                    onChange={(e) => setGatewayConfig(prev => ({
                      ...prev,
                      nagadMerchant: { ...prev.nagadMerchant, merchantId: e.target.value }
                    }))}
                    className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl p-2 font-mono text-xs"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-gray-400 block mb-1">Public Key Fingerprint</label>
                  <input
                    type="password"
                    value={gatewayConfig.nagadMerchant.publicKey}
                    onChange={(e) => setGatewayConfig(prev => ({
                      ...prev,
                      nagadMerchant: { ...prev.nagadMerchant, publicKey: e.target.value }
                    }))}
                    className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl p-2 font-mono text-xs"
                  />
                </div>
              </div>
            </div>

          </div>

          <div className="flex justify-end pt-2">
            <button
              onClick={handleSaveGatewayConfig}
              className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-600/20 flex items-center gap-1.5 transition-all active:scale-95"
            >
              <Save className="w-4 h-4" />
              <span>{t('গেটওয়ে কনফিগারেশন সংরক্ষণ করুন', 'Save Gateway Credentials')}</span>
            </button>
          </div>
        </div>
      )}

      {/* SUB-TAB 3: BANK SLIP VERIFICATION & APPROVAL */}
      {activeSubTab === 'verification' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Direct Verification Form (Left Column) */}
            <div className="lg:col-span-5 bg-white dark:bg-gray-800 rounded-3xl p-6 border border-gray-100 dark:border-gray-700 shadow-xs space-y-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-purple-100 dark:bg-purple-950 text-purple-600 flex items-center justify-center font-bold">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-black text-gray-900 dark:text-white">
                    {t('ব্যাংক ডিপোজিট / রেফারেন্স অনুমোদন', 'Verify Bank Transfer Slip')}
                  </h4>
                  <p className="text-[11px] text-gray-400">{t('অর্ডার নম্বর ও ব্যাংকের ট্রানজেকশন স্লিপ মিলিয়ে সরাসরি অর্ডার পেইড ও কনফার্ম করুন', 'Approve customer bank deposit slip and confirm order')}</p>
                </div>
              </div>

              <form onSubmit={handleVerifyBankTxn} className="space-y-3 pt-2 text-xs">
                <div>
                  <label className="text-[11px] font-bold text-gray-700 dark:text-gray-300 block mb-1">
                    {t('অর্ডার নম্বর *', 'Order Number *')}
                  </label>
                  <input
                    type="text"
                    required
                    value={verifyOrderNum}
                    onChange={(e) => setVerifyOrderNum(e.target.value)}
                    placeholder="e.g. DB-260315-8921"
                    className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl p-2.5 font-mono text-xs text-gray-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-gray-700 dark:text-gray-300 block mb-1">
                    {t('জমা গ্রহণকারী ব্যাংক *', 'Receiving Bank *')}
                  </label>
                  <select
                    value={verifyBankId}
                    onChange={(e) => setVerifyBankId(e.target.value)}
                    className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl p-2.5 text-xs text-gray-900 dark:text-white"
                  >
                    {banksList.map(b => (
                      <option key={b.id} value={b.id}>
                        {b.name} ({b.accountNumber})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-gray-700 dark:text-gray-300 block mb-1">
                    {t('ব্যাংক ট্রানজেকশন আইডি / ভাউচার নম্বর *', 'Bank Transaction ID / Slip Ref *')}
                  </label>
                  <input
                    type="text"
                    required
                    value={verifyTxnRef}
                    onChange={(e) => setVerifyTxnRef(e.target.value)}
                    placeholder="e.g. TXN-894210"
                    className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl p-2.5 font-mono text-xs text-gray-900 dark:text-white"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isVerifying}
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-600/20 flex items-center justify-center gap-1.5 transition-all active:scale-95 disabled:opacity-50"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{isVerifying ? t('যাচাই চলছে...', 'Verifying...') : t('পেমেন্ট অনুমোদন ও নিশ্চিত করুন', 'Approve & Confirm Order')}</span>
                </button>
              </form>
            </div>

            {/* List of Orders with Bank Payment (Right Column) */}
            <div className="lg:col-span-7 bg-white dark:bg-gray-800 rounded-3xl p-6 border border-gray-100 dark:border-gray-700 shadow-xs space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-gray-100 dark:border-gray-700">
                <h4 className="text-xs font-black text-gray-900 dark:text-white flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-emerald-600" />
                  <span>{t('ব্যাংক পেমেন্টকৃত অর্ডারসমূহ', 'Bank Transfer Order Queue')}</span>
                </h4>
                <span className="text-[10px] text-gray-400 font-bold">
                  {bankTransferOrders.length} {t('মোট ব্যাংক অর্ডার', 'Total Bank Orders')}
                </span>
              </div>

              {bankTransferOrders.length === 0 ? (
                <div className="py-16 text-center text-gray-400 text-xs space-y-2">
                  <Building2 className="w-8 h-8 mx-auto text-gray-300 dark:text-gray-600" />
                  <p>{t('এখনো কোনো ব্যাংক ট্রান্সফার অর্ডার পেন্ডিং নেই।', 'No bank transfer orders pending verification.')}</p>
                </div>
              ) : (
                <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
                  {bankTransferOrders.map(ord => (
                    <div 
                      key={ord.id}
                      className="p-3.5 rounded-2xl bg-gray-50 dark:bg-gray-750 border border-gray-100 dark:border-gray-700 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-purple-600">{ord.orderNumber}</span>
                          <span className={`px-2 py-0.2 rounded-full text-[9px] font-bold ${
                            ord.paymentStatus === 'paid_online' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
                          }`}>
                            {ord.paymentStatus}
                          </span>
                        </div>
                        <div className="text-gray-700 dark:text-gray-300 font-medium">
                          {ord.customerName} ({ord.customerPhone})
                        </div>
                        <div className="text-[11px] text-gray-400">
                          {ord.bankPaymentDetails?.bankName || 'Bangladeshi Bank'} • Txn: <code className="text-emerald-600 font-bold">{ord.transactionId || 'Pending'}</code>
                        </div>
                      </div>

                      <div className="flex sm:flex-col items-end justify-between sm:justify-center gap-2 shrink-0">
                        <span className="text-sm font-black text-emerald-600">৳{ord.total}</span>
                        {ord.paymentStatus !== 'paid_online' && (
                          <button
                            onClick={() => {
                              setVerifyOrderNum(ord.orderNumber);
                              setVerifyTxnRef(ord.transactionId || `BNK-${Math.floor(100000 + Math.random() * 900000)}`);
                            }}
                            className="px-2.5 py-1 bg-emerald-600 text-white rounded-lg text-[10px] font-bold hover:bg-emerald-700"
                          >
                            {t('সিলেক্ট করুন', 'Fill Details')}
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

          </div>
        </div>
      )}

      {/* BANK EDIT MODAL */}
      {editingBank && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-gray-800 rounded-3xl max-w-md w-full p-6 border border-gray-100 dark:border-gray-700 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-gray-100 dark:border-gray-700">
              <div className="flex items-center gap-2.5">
                <div 
                  className="w-8 h-8 rounded-lg flex items-center justify-center text-white font-black text-xs shrink-0"
                  style={{ backgroundColor: editingBank.color }}
                >
                  {editingBank.id.substring(0, 2).toUpperCase()}
                </div>
                <div>
                  <h4 className="text-xs font-black text-gray-900 dark:text-white">{editingBank.name}</h4>
                  <span className="text-[10px] text-gray-400">{t('মার্কেটপ্লেস হিসাব তথ্য সম্পাদন', 'Edit Merchant Account Credentials')}</span>
                </div>
              </div>
              <button
                onClick={() => setEditingBank(null)}
                className="w-7 h-7 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-500 hover:text-gray-900 flex items-center justify-center text-xs font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveBankDetails} className="space-y-3 text-xs">
              <div>
                <label className="text-[11px] font-bold text-gray-700 dark:text-gray-300 block mb-1">
                  {t('অ্যাকাউন্টের নাম (Account Holder Name) *', 'Account Holder Name *')}
                </label>
                <input
                  type="text"
                  required
                  value={editAccName}
                  onChange={(e) => setEditAccName(e.target.value)}
                  className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl p-2.5 text-xs text-gray-900 dark:text-white"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-gray-700 dark:text-gray-300 block mb-1">
                  {t('অ্যাকাউন্ট নম্বর (Account Number) *', 'Account Number *')}
                </label>
                <input
                  type="text"
                  required
                  value={editAccNum}
                  onChange={(e) => setEditAccNum(e.target.value)}
                  className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl p-2.5 font-mono text-xs text-gray-900 dark:text-white font-bold"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-gray-700 dark:text-gray-300 block mb-1">
                  {t('শাখার নাম (Branch Name) *', 'Branch Name *')}
                </label>
                <input
                  type="text"
                  required
                  value={editBranch}
                  onChange={(e) => setEditBranch(e.target.value)}
                  className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl p-2.5 text-xs text-gray-900 dark:text-white"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-gray-700 dark:text-gray-300 block mb-1">
                  {t('রাউটিং নম্বর (Routing Number) *', 'Routing Number (9 Digits) *')}
                </label>
                <input
                  type="text"
                  required
                  value={editRouting}
                  onChange={(e) => setEditRouting(e.target.value)}
                  className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl p-2.5 font-mono text-xs text-gray-900 dark:text-white font-bold"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingBank(null)}
                  className="flex-1 py-2.5 rounded-xl border border-gray-200 dark:border-gray-600 text-gray-700 dark:text-gray-300 font-bold hover:bg-gray-50"
                >
                  {t('বাতিল', 'Cancel')}
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold shadow-md shadow-emerald-600/20"
                >
                  {t('সংরক্ষণ করুন', 'Save Details')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
