import React from 'react';
import { useApp } from '../context/AppContext';
import { Product } from '../types';
import { Heart, Star, ShoppingBag, Eye, Zap, Sparkles } from 'lucide-react';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const {
    t,
    addToCart,
    openProductDetails,
    setQuickViewProduct,
    isInWishlist,
    toggleWishlist,
    setCurrentView,
    customerUIConfig
  } = useApp();

  const isFavorited = isInWishlist(product.id);

  const handleBuyNow = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product, 1);
    setCurrentView('checkout');
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product, 1);
  };

  const handleQuickView = (e: React.MouseEvent) => {
    e.stopPropagation();
    setQuickViewProduct(product);
  };

  const cardStyle = customerUIConfig?.productCardStyle || 'modern';
  let cardClass = "group relative bg-white dark:bg-gray-800 transition-all duration-300 flex flex-col overflow-hidden cursor-pointer";
  if (cardStyle === 'minimal-border') {
    cardClass += " rounded-xl border-2 border-gray-200 dark:border-gray-700 hover:border-emerald-500 shadow-none";
  } else if (cardStyle === 'elevated-glow') {
    cardClass += " rounded-3xl border border-gray-100 dark:border-gray-700 shadow-lg ring-1 ring-emerald-500/20 hover:ring-emerald-500 hover:shadow-2xl";
  } else if (cardStyle === 'supermarket-compact') {
    cardClass += " rounded-xl border border-gray-200 dark:border-gray-700 hover:border-emerald-500 shadow-xs";
  } else {
    cardClass += " rounded-2xl border border-gray-100 dark:border-gray-700/80 hover:border-emerald-500/50 shadow-sm hover:shadow-xl";
  }

  const badgeRadius = customerUIConfig?.badgeStyle === 'pill' ? 'rounded-full' : customerUIConfig?.badgeStyle === 'ribbon' ? 'rounded-none rounded-br-lg' : 'rounded-xs';
  const showDiscount = customerUIConfig ? customerUIConfig.showDiscountPercent : true;
  const showStars = customerUIConfig ? customerUIConfig.showRatingStars : true;
  const showStock = customerUIConfig ? customerUIConfig.showStockCount : true;
  const actionStyle = customerUIConfig?.cardActionStyle || 'both-buttons';

  return (
    <div 
      onClick={() => openProductDetails(product.id)}
      className={cardClass}
    >
      {/* 1. Image Container & Badges */}
      <div className="relative aspect-[4/3] bg-gray-50 dark:bg-gray-700/50 overflow-hidden">
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />

        {/* Badges on Top Left */}
        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1 items-start z-10">
          {showDiscount && product.discountPercent > 0 && (
            <span 
              className={`text-white text-[10px] font-black px-2 py-0.5 shadow-sm ${badgeRadius}`}
              style={{ backgroundColor: customerUIConfig?.badgeColor || '#e11d48' }}
            >
              {product.discountPercent}% {t('ছাড়', 'OFF')}
            </span>
          )}

          {product.isDeshi && (
            <span className={`bg-emerald-600 text-white text-[10px] font-bold px-2 py-0.5 shadow-sm flex items-center gap-1 ${badgeRadius}`}>
              <Sparkles className="w-2.5 h-2.5 text-amber-300" />
              <span>{t('দেশি', 'Deshi')}</span>
            </span>
          )}

          {product.isOrganic && (
            <span className={`bg-lime-600 text-white text-[10px] font-bold px-2 py-0.5 shadow-sm ${badgeRadius}`}>
              {t('অরগানিক', 'Organic')}
            </span>
          )}
        </div>

        {/* Wishlist Heart Top Right */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            toggleWishlist(product.id);
          }}
          className={`absolute top-2.5 right-2.5 w-8 h-8 rounded-full flex items-center justify-center transition-all z-10 shadow-sm ${
            isFavorited
              ? 'bg-rose-50 dark:bg-rose-950/80 text-rose-500'
              : 'bg-white/80 dark:bg-gray-800/80 text-gray-500 hover:text-rose-500 backdrop-blur-sm'
          }`}
          title={isFavorited ? 'Remove from wishlist' : 'Add to wishlist'}
        >
          <Heart className={`w-4 h-4 ${isFavorited ? 'fill-rose-500' : ''}`} />
        </button>

        {/* Quick View Button on Hover */}
        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center p-3 pointer-events-none">
          <button
            type="button"
            onClick={handleQuickView}
            className="pointer-events-auto bg-white/95 dark:bg-gray-900/95 text-gray-800 dark:text-gray-100 hover:text-emerald-600 px-3 py-1.5 rounded-full text-xs font-semibold shadow-lg flex items-center gap-1.5 transform translate-y-2 group-hover:translate-y-0 transition-transform"
          >
            <Eye className="w-3.5 h-3.5 text-emerald-600" />
            <span>{t('কুইক ভিউ', 'Quick View')}</span>
          </button>
        </div>
      </div>

      {/* 2. Content */}
      <div className="p-3.5 sm:p-4 flex flex-col flex-1">
        {/* Vendor & Location */}
        <div className="flex items-center justify-between gap-1 text-[11px] text-gray-400 mb-1">
          <span className="truncate hover:text-emerald-600 transition-colors">
            {product.vendorName}
          </span>
          <span className="shrink-0 text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">
            {product.vendorLocation.split(',')[0]}
          </span>
        </div>

        {/* Product Title */}
        <h3 className="text-xs sm:text-sm font-bold text-gray-900 dark:text-white line-clamp-2 leading-tight group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors mb-1.5">
          {t(product.nameBn, product.name)}
        </h3>

        {/* Unit & Stock */}
        <div className="flex items-center justify-between text-[11px] text-gray-500 dark:text-gray-400 mb-2">
          <span>{t(product.unitBn, product.unit)}</span>
          {showStock && (
            product.stock <= 20 ? (
              <span className="text-amber-600 font-semibold text-[10px]">
                {t(`মাত্র ${product.stock} টি বাকি`, `Only ${product.stock} left`)}
              </span>
            ) : (
              <span className="text-emerald-600 font-medium text-[10px]">
                {t('স্টকে আছে', 'In Stock')}
              </span>
            )
          )}
        </div>

        {/* Rating & Reviews */}
        {showStars && (
          <div className="flex items-center gap-1 mb-2.5">
            <div className="flex items-center text-amber-400">
              <Star className="w-3.5 h-3.5 fill-amber-400" />
            </div>
            <span className="text-xs font-bold text-gray-700 dark:text-gray-200">
              {product.rating}
            </span>
            <span className="text-[11px] text-gray-400">
              ({product.reviewCount})
            </span>
          </div>
        )}

        {/* Price & Action Buttons */}
        <div className="mt-auto pt-2 border-t border-gray-100 dark:border-gray-700/60">
          <div className="flex items-baseline gap-2 mb-3">
            <span 
              className="text-base sm:text-lg font-black"
              style={{ color: customerUIConfig?.primaryColor || '#047857' }}
            >
              ৳{product.price}
            </span>
            {product.originalPrice > product.price && (
              <span className="text-xs text-gray-400 line-through">
                ৳{product.originalPrice}
              </span>
            )}
          </div>

          {actionStyle === 'cart-only' ? (
            <button
              type="button"
              onClick={handleAddToCart}
              className="w-full py-2 px-2 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1 shadow-sm"
              style={{ backgroundColor: customerUIConfig?.primaryColor || '#059669' }}
              title={t('ব্যাগে যোগ করুন', 'Add to Cart')}
            >
              <ShoppingBag className="w-3.5 h-3.5 shrink-0" />
              <span>{t('ব্যাগে যোগ করুন', '+ Add to Cart')}</span>
            </button>
          ) : (
            <div className={`grid grid-cols-2 gap-1.5 ${actionStyle === 'hover-reveal' ? 'opacity-90 group-hover:opacity-100' : ''}`}>
              <button
                type="button"
                onClick={handleAddToCart}
                className="w-full py-2 px-2 bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-600 text-emerald-700 dark:text-emerald-300 hover:text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1 shadow-sm"
                title={t('ব্যাগে যোগ করুন', 'Add to Cart')}
              >
                <ShoppingBag className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">{t('ব্যাগে নিন', 'Add to Cart')}</span>
              </button>

              <button
                type="button"
                onClick={handleBuyNow}
                className="w-full py-2 px-2 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1 shadow-sm shadow-emerald-600/20"
                style={{ backgroundColor: customerUIConfig?.primaryColor || '#059669' }}
                title={t('এখনই কিনুন', 'Buy Now')}
              >
                <Zap className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">{t('অর্ডার করুন', 'Buy Now')}</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
