import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, Star, ShoppingBag, Zap, Heart, ArrowRight } from 'lucide-react';

export const ProductQuickViewModal: React.FC = () => {
  const {
    quickViewProduct,
    setQuickViewProduct,
    addToCart,
    openProductDetails,
    setCurrentView,
    isInWishlist,
    toggleWishlist,
    t
  } = useApp();

  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  if (!quickViewProduct) return null;

  const currentImg = selectedImage || quickViewProduct.image;
  const isFav = isInWishlist(quickViewProduct.id);

  const handleBuyNow = () => {
    addToCart(quickViewProduct, quantity);
    setQuickViewProduct(null);
    setCurrentView('checkout');
  };

  const handleAddToCart = () => {
    addToCart(quickViewProduct, quantity);
    setQuickViewProduct(null);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto p-4 flex items-center justify-center">
      {/* Backdrop */}
      <div
        onClick={() => setQuickViewProduct(null)}
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
      />

      <div className="relative bg-white dark:bg-gray-900 rounded-3xl max-w-2xl w-full p-6 shadow-2xl border border-gray-100 dark:border-gray-800 z-10 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        <button
          onClick={() => setQuickViewProduct(null)}
          className="absolute top-4 right-4 p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
          {/* Image & gallery preview */}
          <div>
            <div className="aspect-square rounded-2xl overflow-hidden bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700 mb-3">
              <img
                src={currentImg}
                alt={quickViewProduct.name}
                className="w-full h-full object-cover"
              />
            </div>
            {quickViewProduct.gallery && quickViewProduct.gallery.length > 1 && (
              <div className="flex gap-2">
                {[quickViewProduct.image, ...quickViewProduct.gallery].map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setSelectedImage(img)}
                    className={`w-14 h-14 rounded-xl overflow-hidden border-2 transition-all ${
                      currentImg === img ? 'border-emerald-500 scale-105' : 'border-transparent opacity-70'
                    }`}
                  >
                    <img src={img} alt="Thumbnail" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product details */}
          <div className="space-y-4">
            <div>
              <span className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider block mb-1">
                {quickViewProduct.vendorName} • {quickViewProduct.vendorLocation}
              </span>
              <h3 className="text-lg sm:text-xl font-bold text-gray-900 dark:text-white leading-snug">
                {t(quickViewProduct.nameBn, quickViewProduct.name)}
              </h3>
            </div>

            {/* Rating */}
            <div className="flex items-center gap-2">
              <div className="flex items-center text-amber-400">
                <Star className="w-4 h-4 fill-amber-400" />
              </div>
              <span className="text-xs font-bold text-gray-800 dark:text-gray-200">
                {quickViewProduct.rating}
              </span>
              <span className="text-xs text-gray-400">
                ({quickViewProduct.reviewCount} {t('রিভিউ', 'reviews')})
              </span>
            </div>

            {/* Price */}
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-black text-emerald-600 dark:text-emerald-400">
                ৳{quickViewProduct.price}
              </span>
              {quickViewProduct.originalPrice > quickViewProduct.price && (
                <span className="text-sm text-gray-400 line-through">
                  ৳{quickViewProduct.originalPrice}
                </span>
              )}
              {quickViewProduct.discountPercent > 0 && (
                <span className="bg-rose-500 text-white text-[10px] font-black px-2 py-0.5 rounded">
                  {quickViewProduct.discountPercent}% {t('ছাড়', 'OFF')}
                </span>
              )}
            </div>

            <p className="text-xs text-gray-600 dark:text-gray-300 line-clamp-3 leading-relaxed">
              {t(quickViewProduct.descriptionBn, quickViewProduct.description)}
            </p>

            {/* Quantity Stepper */}
            <div className="flex items-center gap-4">
              <span className="text-xs font-semibold text-gray-600 dark:text-gray-300">
                {t('পরিমাণ:', 'Quantity:')}
              </span>
              <div className="flex items-center border border-gray-200 dark:border-gray-700 rounded-xl overflow-hidden bg-gray-50 dark:bg-gray-800">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-3 py-1.5 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700"
                >
                  -
                </button>
                <span className="px-3 py-1 text-xs font-bold text-gray-900 dark:text-white">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="px-3 py-1.5 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700"
                >
                  +
                </button>
              </div>
            </div>

            {/* Buttons */}
            <div className="space-y-2 pt-2">
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={handleAddToCart}
                  className="w-full py-2.5 px-4 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-600 hover:text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition-colors"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>{t('ব্যাগে যোগ করুন', 'Add to Cart')}</span>
                </button>

                <button
                  onClick={handleBuyNow}
                  className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-md transition-colors"
                >
                  <Zap className="w-4 h-4 text-amber-300" />
                  <span>{t('এখনই কিনুন', 'Buy Now')}</span>
                </button>
              </div>

              <div className="flex items-center justify-between text-xs text-gray-500 pt-2 border-t border-gray-100 dark:border-gray-800">
                <button
                  onClick={() => toggleWishlist(quickViewProduct.id)}
                  className="flex items-center gap-1 hover:text-rose-500"
                >
                  <Heart className={`w-4 h-4 ${isFav ? 'fill-rose-500 text-rose-500' : ''}`} />
                  <span>{isFav ? t('উইশলিস্টে আছে', 'In Wishlist') : t('উইশলিস্টে রাখুন', 'Add to Wishlist')}</span>
                </button>

                <button
                  onClick={() => {
                    setQuickViewProduct(null);
                    openProductDetails(quickViewProduct.id);
                  }}
                  className="text-emerald-600 dark:text-emerald-400 font-bold hover:underline flex items-center gap-1"
                >
                  <span>{t('সম্পূর্ণ বিবরণ দেখুন', 'Full Details')}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
