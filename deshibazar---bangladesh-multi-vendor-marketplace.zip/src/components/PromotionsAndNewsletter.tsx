import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { TESTIMONIALS } from '../data/mockData';
import { Star, Mail, Send, CheckCircle2, Gift, Sparkles, ShieldCheck } from 'lucide-react';
import { addDoc, collection } from 'firebase/firestore';
import { db } from '../firebase';

export const PromotionsAndNewsletter: React.FC = () => {
  const { t, showToast, setCurrentView } = useApp();

  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterPhone, setNewsletterPhone] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail && !newsletterPhone) {
      showToast(t('অনুগ্রহ করে ইমেইল বা ফোন নম্বর দিন', 'Please enter email or phone number'), 'error');
      return;
    }

    try {
      await addDoc(collection(db, 'newsletter'), {
        email: newsletterEmail || null,
        phone: newsletterPhone || null,
        createdAt: new Date().toISOString()
      });
    } catch {
      // Local fallback
    }

    setSubscribed(true);
    showToast(t('ধন্যবাদ! আপনাকে ২০% ডিসকাউন্ট কুপন পাঠানো হয়েছে: WELCOME20', 'Subscribed! Your 20% discount coupon is: WELCOME20'), 'success');
  };

  return (
    <div>
      {/* 1. Promotional Campaign Cards */}
      <section className="py-12 bg-white dark:bg-gray-900 border-b border-gray-100 dark:border-gray-800 transition-colors">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Promo 1: First Order Offer */}
            <div className="rounded-3xl p-6 sm:p-8 bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-900 text-white relative overflow-hidden flex flex-col justify-between shadow-xl">
              <div className="relative z-10 max-w-sm">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-700/80 text-emerald-200 text-xs font-bold uppercase tracking-wider mb-3">
                  <Gift className="w-3.5 h-3.5 text-amber-400" />
                  {t('নতুন গ্রাহকদের জন্য', 'New Customer Welcome')}
                </span>
                <h3 className="text-2xl sm:text-3xl font-black leading-tight mb-2">
                  {t('প্রথম অর্ডারে ২০% ছাড়!', 'Get 20% OFF on Your First Order!')}
                </h3>
                <p className="text-xs sm:text-sm text-emerald-100/90 mb-4">
                  {t('দেশিবাজারে আপনার প্রথম কেনাকাটায় ব্যবহার করুন কুপন কোড:', 'Use coupon code at checkout for up to ৳300 instant discount:')}
                </p>
                <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-md px-4 py-2 rounded-xl border border-white/20 font-mono font-black text-amber-300 text-sm tracking-wider">
                  <span>WELCOME20</span>
                </div>
              </div>
              <div className="mt-6 relative z-10">
                <button
                  onClick={() => setCurrentView('shop')}
                  className="px-6 py-2.5 bg-amber-400 hover:bg-amber-300 text-emerald-950 font-bold text-xs rounded-xl shadow-md transition-all active:scale-95"
                >
                  {t('এখনই বাজার করুন', 'Shop With Discount')}
                </button>
              </div>
            </div>

            {/* Promo 2: Seasonal / Eid Offer */}
            <div className="rounded-3xl p-6 sm:p-8 bg-gradient-to-r from-amber-600 via-orange-600 to-rose-600 text-white relative overflow-hidden flex flex-col justify-between shadow-xl">
              <div className="relative z-10 max-w-sm">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/20 text-amber-100 text-xs font-bold uppercase tracking-wider mb-3">
                  <Sparkles className="w-3.5 h-3.5 text-amber-200" />
                  {t('উৎসব স্পেশাল কালেকশন', 'Festive Grand Bazaar')}
                </span>
                <h3 className="text-2xl sm:text-3xl font-black leading-tight mb-2">
                  {t('ঈদ ও উৎসবের সেরা কেনাকাটা', 'Festive Saree, Panjabi & Sweets')}
                </h3>
                <p className="text-xs sm:text-sm text-amber-100 mb-4">
                  {t('টাঙ্গাইলের জামদানি, খাঁটি সুতি পাঞ্জাবি এবং বগুড়ার ঐতিহ্যবাহী দইয়ে ২৫% পর্যন্ত ছাড়।', 'Up to 25% discount on heritage Jamdani, pure cotton Panjabi, and Bogura Doi.')}
                </p>
                <div className="inline-flex items-center gap-2 bg-black/20 backdrop-blur-md px-4 py-2 rounded-xl border border-white/20 font-mono font-black text-amber-100 text-sm tracking-wider">
                  <span>EID2026</span>
                </div>
              </div>
              <div className="mt-6 relative z-10">
                <button
                  onClick={() => setCurrentView('shop')}
                  className="px-6 py-2.5 bg-white hover:bg-gray-100 text-gray-900 font-bold text-xs rounded-xl shadow-md transition-all active:scale-95"
                >
                  {t('উৎসবের সংগ্রহ দেখুন', 'Explore Festive Deals')}
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Customer Reviews / Testimonials */}
      <section className="py-14 bg-gray-50/70 dark:bg-gray-850/50 border-b border-gray-100 dark:border-gray-800 transition-colors">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center max-w-xl mx-auto mb-10">
            <span className="text-xs font-bold uppercase text-emerald-600 dark:text-emerald-400 tracking-wider block mb-1">
              {t('গ্রাহকদের সন্তুষ্টি', 'Verified Customer Stories')}
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white">
              {t('গ্রাহকরা দেশিবাজার সম্পর্কে কী বলছেন', 'What Our Customers Say')}
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {TESTIMONIALS.map((item, idx) => (
              <div
                key={idx}
                className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-100 dark:border-gray-700 shadow-sm hover:shadow-lg transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center gap-1 text-amber-400 mb-3">
                    {[...Array(item.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-amber-400" />
                    ))}
                  </div>

                  <p className="text-xs sm:text-sm text-gray-700 dark:text-gray-300 italic mb-4 leading-relaxed">
                    "{t(item.commentBn, item.comment)}"
                  </p>
                </div>

                <div className="flex items-center gap-3 pt-4 border-t border-gray-100 dark:border-gray-700/60">
                  <img
                    src={item.avatar}
                    alt={item.name}
                    className="w-11 h-11 rounded-full object-cover border-2 border-emerald-500"
                  />
                  <div>
                    <h4 className="text-xs font-bold text-gray-900 dark:text-white flex items-center gap-1.5">
                      <span>{t(item.nameBn, item.name)}</span>
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                    </h4>
                    <span className="text-[11px] text-gray-400">
                      {t(item.locationBn, item.location)}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 3. Newsletter Section */}
      <section className="py-12 bg-emerald-800 text-white relative overflow-hidden transition-colors">
        <div className="max-w-4xl mx-auto px-4 text-center relative z-10">
          <div className="w-12 h-12 rounded-2xl bg-emerald-700/60 flex items-center justify-center mx-auto mb-3 text-amber-300">
            <Mail className="w-6 h-6" />
          </div>

          <h2 className="text-2xl sm:text-3xl font-black mb-2 tracking-tight">
            {t('DeshiBazar-এর নতুন অফার মিস করবেন না', 'Never Miss DeshiBazar Weekly Offers')}
          </h2>
          <p className="text-xs sm:text-sm text-emerald-100 max-w-md mx-auto mb-6">
            {t(
              'আপনার ইমেইল বা ফোন নম্বর দিয়ে সাবস্ক্রাইব করুন। সেরা ডিল ও নতুন দেশি পণ্যের আপডেট পান সবার আগে।',
              'Subscribe with your email or phone to get exclusive discounts, flash deal alerts, and farm-fresh harvest updates.'
            )}
          </p>

          {subscribed ? (
            <div className="bg-emerald-900/80 border border-emerald-600 rounded-2xl p-4 max-w-md mx-auto flex items-center justify-center gap-3 text-emerald-200 text-xs font-bold">
              <CheckCircle2 className="w-5 h-5 text-amber-400 shrink-0" />
              <span>{t('অভিনন্দন! আপনার সাবস্ক্রিপশন সম্পন্ন হয়েছে।', 'Congratulations! You are subscribed to DeshiBazar deals.')}</span>
            </div>
          ) : (
            <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-2 max-w-lg mx-auto">
              <div className="relative flex-1">
                <input
                  type="email"
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  placeholder={t('আপনার ইমেইল ঠিকানা...', 'Enter your email address...')}
                  className="w-full bg-emerald-900/70 border border-emerald-600 rounded-xl px-4 py-3 text-xs text-white placeholder-emerald-300 focus:outline-none focus:ring-2 focus:ring-amber-400 shadow-inner"
                />
              </div>

              <div className="relative flex-1">
                <input
                  type="tel"
                  value={newsletterPhone}
                  onChange={(e) => setNewsletterPhone(e.target.value)}
                  placeholder={t('মোবাইল নম্বর (ঐচ্ছিক)', 'Mobile 017xxxxxxxx')}
                  className="w-full bg-emerald-900/70 border border-emerald-600 rounded-xl px-4 py-3 text-xs text-white placeholder-emerald-300 focus:outline-none focus:ring-2 focus:ring-amber-400 shadow-inner"
                />
              </div>

              <button
                type="submit"
                className="bg-amber-400 hover:bg-amber-300 text-emerald-950 font-bold px-6 py-3 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-lg active:scale-95 transition-all shrink-0"
              >
                <span>{t('সাবস্ক্রাইব', 'Subscribe')}</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          )}

          <p className="text-[10px] text-emerald-300/80 mt-3">
            {t('আমরা কোনো স্প্যাম করি না। যেকোনো সময় আনসাবস্ক্রাইব করা যাবে।', 'No spam. Unsubscribe at any time with a single tap.')}
          </p>
        </div>
      </section>
    </div>
  );
};
