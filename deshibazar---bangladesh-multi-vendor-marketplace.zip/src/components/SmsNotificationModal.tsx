import React, { useEffect, useMemo, useState } from 'react';
import {
  X,
  Bell,
  MessageSquare,
  Receipt,
  Wallet,
  Settings,
  CheckCircle2,
  CheckCheck,
  CreditCard,
  Building2,
  Smartphone,
  ArrowRight,
  Clock,
  ShieldCheck,
  Sparkles,
  FileText
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { BANGLADESHI_BANKS } from '../data/bangladeshiBanks';
import { BakiAccount, Order, SmsNotification } from '../types';

export const SmsNotificationModal: React.FC = () => {
  const {
    t,
    language,
    isNotificationModalOpen,
    setIsNotificationModalOpen,
    notificationModalInitialTab,
    selectedBakiIdForPayment,
    setSelectedBakiIdForPayment,
    smsNotifications,
    bakiAccounts,
    smsGatewaySettings,
    unreadSmsCount,
    totalCustomerBakiDue,
    markSmsNotificationRead,
    markAllSmsNotificationsRead,
    payBakiAmount,
    updateSmsGatewaySettings,
    orders,
    openCashMemoModal
  } = useApp();

  const [activeTab, setActiveTab] = useState<'notifications' | 'baki-payment' | 'sms-settings'>('notifications');
  const [filterType, setFilterType] = useState<'all' | 'receipt' | 'baki' | 'promo'>('all');

  // Baki Payment Form State
  const [selectedBakiId, setSelectedBakiId] = useState<string>('');
  const [payAmount, setPayAmount] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<'bkash' | 'nagad' | 'rocket' | 'bank_transfer' | 'card'>('bkash');
  const [selectedBankId, setSelectedBankId] = useState<string>(BANGLADESHI_BANKS[0]?.id || 'ibbl');
  const [senderAccountOrPhone, setSenderAccountOrPhone] = useState<string>('01819-234567');
  const [txnRef, setTxnRef] = useState<string>('');
  const [isPaying, setIsPaying] = useState<boolean>(false);
  const [lastReceiptSms, setLastReceiptSms] = useState<SmsNotification | null>(null);

  useEffect(() => {
    if (isNotificationModalOpen) {
      setActiveTab(notificationModalInitialTab || 'notifications');
      setLastReceiptSms(null);
      if (selectedBakiIdForPayment) {
        setSelectedBakiId(selectedBakiIdForPayment);
        const found = bakiAccounts.find(b => b.id === selectedBakiIdForPayment);
        if (found) setPayAmount(String(found.bakiAmount));
      } else {
        const firstDue = bakiAccounts.find(b => b.bakiAmount > 0) || bakiAccounts[0];
        if (firstDue) {
          setSelectedBakiId(firstDue.id);
          setPayAmount(String(firstDue.bakiAmount));
        }
      }
    }
  }, [isNotificationModalOpen, notificationModalInitialTab, selectedBakiIdForPayment]);

  const activeBakiAccount: BakiAccount | undefined = useMemo(
    () => bakiAccounts.find(b => b.id === selectedBakiId) || bakiAccounts.find(b => b.bakiAmount > 0) || bakiAccounts[0],
    [bakiAccounts, selectedBakiId]
  );

  const selectedBank = useMemo(
    () => BANGLADESHI_BANKS.find(b => b.id === selectedBankId) || BANGLADESHI_BANKS[0],
    [selectedBankId]
  );

  const filteredNotifications = useMemo(() => {
    return smsNotifications.filter(n => {
      if (filterType === 'all') return true;
      if (filterType === 'receipt') return n.type === 'order_receipt' || n.type === 'baki_payment_receipt';
      if (filterType === 'baki') return n.type === 'baki_due' || n.type === 'baki_payment_receipt';
      if (filterType === 'promo') return n.type === 'bulk_promo' || n.type === 'system_alert';
      return true;
    });
  }, [smsNotifications, filterType]);

  if (!isNotificationModalOpen) return null;

  const handleOpenCashMemoForSms = (notif: SmsNotification) => {
    const existingOrder = orders.find(
      o => (notif.orderNumber && o.orderNumber === notif.orderNumber) || o.id === notif.orderNumber
    );
    if (existingOrder) {
      openCashMemoModal(existingOrder);
      return;
    }

    // Build an official Cash Memo preview object from receipt SMS / Baki ledger
    const baki = notif.bakiId ? bakiAccounts.find(b => b.id === notif.bakiId) : undefined;
    const total = notif.totalBillAmount || baki?.totalBill || notif.paidAmount || 0;
    const bakiDue = baki ? baki.bakiAmount : (notif.bakiDueAmount ?? 0);
    const memoOrder: Order = {
      id: `memo-${notif.id}`,
      orderNumber: notif.orderNumber || `RCPT-${notif.id.slice(-6).toUpperCase()}`,
      customerName: notif.recipientName,
      customerPhone: notif.recipientPhone,
      division: 'Dhaka',
      district: 'Dhaka',
      upazila: 'Dhaka Metro',
      address: baki?.descriptionBn || notif.titleBn || 'DeshiBazar Customer Ledger Receipt',
      paymentMethod: (notif.paymentMethod as any) || 'bkash',
      paymentStatus: bakiDue <= 0 ? 'completed' : 'pending',
      transactionId: notif.transactionRef || baki?.lastTransactionRef,
      deliveryType: 'regular',
      deliveryFee: 0,
      subtotal: total,
      discount: 0,
      total,
      status: bakiDue <= 0 ? 'delivered' : 'confirmed',
      items: [],
      createdAt: notif.createdAt,
      estimatedDelivery: bakiDue > 0 ? `Baki Due: ৳${bakiDue}` : 'Paid in Full',
      trackingSteps: []
    };
    openCashMemoModal(memoOrder);
  };

  const handlePayBakiSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeBakiAccount) return;
    const numericAmt = Number(payAmount);
    if (!numericAmt || numericAmt <= 0) return;

    setIsPaying(true);
    try {
      const refText =
        txnRef.trim() ||
        `${paymentMethod === 'bank_transfer' ? selectedBank.shortCode.split(' ')[0] : paymentMethod.toUpperCase()}-${Math.floor(100000 + Math.random() * 900000)}`;
      const res = await payBakiAmount(activeBakiAccount.id, numericAmt, paymentMethod, refText);
      if (res) {
        setLastReceiptSms(res.receiptSms);
        setPayAmount(res.account.bakiAmount > 0 ? String(res.account.bakiAmount) : '0');
        setTxnRef('');
      }
    } finally {
      setIsPaying(false);
    }
  };

  const handleSelectBakiAccount = (acc: BakiAccount) => {
    setSelectedBakiId(acc.id);
    setSelectedBakiIdForPayment(acc.id);
    setPayAmount(String(acc.bakiAmount > 0 ? acc.bakiAmount : 0));
    setLastReceiptSms(null);
  };

  const getBadgeStyle = (type: SmsNotification['type']) => {
    switch (type) {
      case 'baki_due':
        return 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300 border-amber-200 dark:border-amber-800';
      case 'baki_payment_receipt':
        return 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800';
      case 'order_receipt':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300 border-blue-200 dark:border-blue-800';
      default:
        return 'bg-purple-100 text-purple-800 dark:bg-purple-900/40 dark:text-purple-300 border-purple-200 dark:border-purple-800';
    }
  };

  const getTypeLabel = (type: SmsNotification['type']) => {
    switch (type) {
      case 'baki_due':
        return t('বাকি টাকা তাগাদা SMS', 'Baki Due Alert');
      case 'baki_payment_receipt':
        return t('বাকি পরিশোধ রসিদ SMS', 'Baki Paid Receipt');
      case 'order_receipt':
        return t('অর্ডার রসিদ SMS', 'Order Receipt SMS');
      case 'bulk_promo':
        return t('অ্যাডমিন বাল্ক SMS', 'Admin Bulk SMS');
      default:
        return t('সিস্টেম অ্যালার্ট', 'System Alert');
    }
  };

  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center p-3 sm:p-4 bg-black/65 backdrop-blur-sm animate-fadeIn">
      <div className="w-full max-w-4xl max-h-[92vh] bg-white dark:bg-gray-900 rounded-2xl shadow-2xl border border-gray-200 dark:border-gray-800 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-700 via-teal-700 to-emerald-800 text-white px-5 py-4 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="relative w-11 h-11 rounded-xl bg-white/15 backdrop-blur-md border border-white/20 flex items-center justify-center">
              <Bell className="w-6 h-6 text-amber-300" />
              {unreadSmsCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 min-w-[20px] h-5 px-1 rounded-full bg-rose-500 text-white text-[11px] font-bold flex items-center justify-center shadow">
                  {unreadSmsCount}
                </span>
              )}
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold flex items-center gap-2">
                {t('এসএমএস রসিদ নোটিফিকেশন ও বাকি পরিশোধ কেন্দ্র', 'SMS Receipt Notifications & Baki Payment Center')}
              </h2>
              <p className="text-xs text-emerald-100 flex flex-wrap items-center gap-2 mt-0.5">
                <span className="inline-flex items-center gap-1">
                  <Settings className="w-3 h-3" /> {t('সেটিংস-এর অধীনে', 'Under Settings')}
                </span>
                <span>•</span>
                <span>{t(`মোট বাকি: ৳${totalCustomerBakiDue.toLocaleString()}`, `Total Baki Due: ৳${totalCustomerBakiDue.toLocaleString()}`)}</span>
                <span>•</span>
                <span>{t(`গেটওয়ে: ${smsGatewaySettings.provider.toUpperCase()}`, `Gateway: ${smsGatewaySettings.provider.toUpperCase()}`)}</span>
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsNotificationModalOpen(false)}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Sub Navigation Tabs */}
        <div className="bg-gray-50 dark:bg-gray-800/80 border-b border-gray-200 dark:border-gray-700 px-4 py-2.5 flex flex-wrap items-center justify-between gap-2">
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setActiveTab('notifications')}
              className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-all ${
                activeTab === 'notifications'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-700 hover:bg-gray-100'
              }`}
            >
              <MessageSquare className="w-4 h-4" />
              <span>{t('রসিদ ও SMS ইনবক্স', 'Receipt SMS Inbox')}</span>
              {unreadSmsCount > 0 && (
                <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-extrabold ${
                  activeTab === 'notifications' ? 'bg-white text-emerald-700' : 'bg-rose-500 text-white'
                }`}>
                  {unreadSmsCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('baki-payment')}
              className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-all ${
                activeTab === 'baki-payment'
                  ? 'bg-amber-600 text-white shadow-sm'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-700 hover:bg-gray-100'
              }`}
            >
              <Wallet className="w-4 h-4" />
              <span>{t('বাকি টাকা পরিশোধ করুন', 'Pay Baki Amount')}</span>
              {totalCustomerBakiDue > 0 && (
                <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-extrabold ${
                  activeTab === 'baki-payment' ? 'bg-white text-amber-700' : 'bg-amber-100 text-amber-800 dark:bg-amber-900/50 dark:text-amber-300'
                }`}>
                  ৳{totalCustomerBakiDue.toLocaleString()}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('sms-settings')}
              className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-all ${
                activeTab === 'sms-settings'
                  ? 'bg-slate-800 text-white dark:bg-slate-700 shadow-sm'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-700 hover:bg-gray-100'
              }`}
            >
              <Settings className="w-4 h-4" />
              <span>{t('SMS সেটিংস', 'SMS Settings')}</span>
            </button>
          </div>

          {activeTab === 'notifications' && unreadSmsCount > 0 && (
            <button
              onClick={markAllSmsNotificationsRead}
              className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 hover:underline flex items-center gap-1"
            >
              <CheckCheck className="w-4 h-4" />
              {t('সবগুলো পঠিত করুন', 'Mark all read')}
            </button>
          )}
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {/* TAB 1: RECEIPT SMS NOTIFICATION INBOX */}
          {activeTab === 'notifications' && (
            <div className="space-y-4">
              {/* Filter bar */}
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex flex-wrap gap-1.5">
                  {[
                    { id: 'all', bn: 'সকল SMS', en: 'All SMS' },
                    { id: 'receipt', bn: 'রসিদ SMS', en: 'Receipt SMS' },
                    { id: 'baki', bn: 'বাকি হিসাব', en: 'Baki Ledger' },
                    { id: 'promo', bn: 'বাল্ক অফার', en: 'Bulk Offers' }
                  ].map(tab => (
                    <button
                      key={tab.id}
                      onClick={() => setFilterType(tab.id as any)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                        filterType === tab.id
                          ? 'bg-emerald-600 text-white'
                          : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 hover:bg-gray-200'
                      }`}
                    >
                      {t(tab.bn, tab.en)}
                    </button>
                  ))}
                </div>
                <span className="text-xs text-gray-500 dark:text-gray-400">
                  {t(`মোট ${filteredNotifications.length}টি নোটিফিকেশন`, `Showing ${filteredNotifications.length} notifications`)}
                </span>
              </div>

              {filteredNotifications.length === 0 ? (
                <div className="text-center py-12 bg-gray-50 dark:bg-gray-800/50 rounded-2xl border border-dashed border-gray-300 dark:border-gray-700">
                  <MessageSquare className="w-10 h-10 text-gray-400 mx-auto mb-2" />
                  <p className="text-sm font-semibold text-gray-600 dark:text-gray-300">
                    {t('এই ক্যাটাগরিতে কোনো SMS নোটিফিকেশন নেই', 'No SMS notifications in this category')}
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {filteredNotifications.map(notif => {
                    const linkedBaki = notif.bakiId ? bakiAccounts.find(b => b.id === notif.bakiId) : undefined;
                    const liveBakiDue = linkedBaki ? linkedBaki.bakiAmount : (notif.bakiDueAmount || 0);

                    return (
                      <div
                        key={notif.id}
                        onClick={() => !notif.isRead && markSmsNotificationRead(notif.id)}
                        className={`rounded-2xl border p-4 transition-all ${
                          notif.isRead
                            ? 'bg-white dark:bg-gray-800/60 border-gray-200 dark:border-gray-700'
                            : 'bg-emerald-50/70 dark:bg-emerald-950/25 border-emerald-300 dark:border-emerald-800 shadow-sm'
                        }`}
                      >
                        <div className="flex flex-wrap items-start justify-between gap-2">
                          <div className="flex items-center gap-2 flex-wrap">
                            {!notif.isRead && (
                              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
                            )}
                            <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${getBadgeStyle(notif.type)}`}>
                              {getTypeLabel(notif.type)}
                            </span>
                            <span className="text-xs font-semibold text-gray-500 dark:text-gray-400">
                              {notif.senderName} → {notif.recipientNameBn || notif.recipientName} ({notif.recipientPhone})
                            </span>
                          </div>
                          <div className="flex items-center gap-2 text-[11px] text-gray-500 dark:text-gray-400">
                            <span className="px-2 py-0.5 rounded bg-gray-100 dark:bg-gray-800 font-mono">
                              {notif.gatewayProvider || 'BulkSMSBD'}
                            </span>
                            <span className="flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {new Date(notif.createdAt).toLocaleString(language === 'bn' ? 'bn-BD' : 'en-US', {
                                month: 'short',
                                day: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit'
                              })}
                            </span>
                          </div>
                        </div>

                        <h4 className="font-bold text-sm sm:text-base text-gray-900 dark:text-white mt-2">
                          {language === 'bn' ? notif.titleBn : notif.title}
                        </h4>
                        <p className="text-xs sm:text-sm text-gray-700 dark:text-gray-300 mt-1 leading-relaxed">
                          {language === 'bn' ? notif.messageBn : notif.message}
                        </p>

                        {/* Receipt & Baki Breakdown Bar */}
                        {(notif.totalBillAmount !== undefined || liveBakiDue > 0 || notif.orderNumber) && (
                          <div className="mt-3 p-3 rounded-xl bg-white dark:bg-gray-900/80 border border-gray-200 dark:border-gray-700 flex flex-wrap items-center justify-between gap-3">
                            <div className="flex flex-wrap items-center gap-3 text-xs">
                              {notif.orderNumber && (
                                <span className="font-mono font-bold text-emerald-700 dark:text-emerald-400">
                                  #{notif.orderNumber}
                                </span>
                              )}
                              {notif.totalBillAmount !== undefined && (
                                <span className="text-gray-600 dark:text-gray-300">
                                  {t('মোট বিল:', 'Total:')} <strong>৳{notif.totalBillAmount.toLocaleString()}</strong>
                                </span>
                              )}
                              {notif.paidAmount !== undefined && (
                                <span className="text-emerald-700 dark:text-emerald-400">
                                  {t('পরিশোধিত:', 'Paid:')} <strong>৳{notif.paidAmount.toLocaleString()}</strong>
                                </span>
                              )}
                              <span className={`font-bold ${liveBakiDue > 0 ? 'text-amber-600 dark:text-amber-400' : 'text-emerald-600'}`}>
                                {liveBakiDue > 0
                                  ? t(`বাকি: ৳${liveBakiDue.toLocaleString()}`, `Baki Due: ৳${liveBakiDue.toLocaleString()}`)
                                  : t('বাকি নেই (পরিশোধিত)', 'Settled (৳0 Due)')}
                              </span>
                            </div>

                            <div className="flex flex-wrap items-center gap-2">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleOpenCashMemoForSms(notif);
                                }}
                                className="px-3 py-1.5 rounded-lg text-xs font-bold bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 text-gray-800 dark:text-gray-200 flex items-center gap-1.5"
                              >
                                <FileText className="w-3.5 h-3.5 text-emerald-600" />
                                {t('রসিদ/ক্যাশ মেমো', 'Cash Memo')}
                              </button>

                              {liveBakiDue > 0 && (notif.bakiId || linkedBaki) && (
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    const targetId = notif.bakiId || linkedBaki?.id || '';
                                    setSelectedBakiId(targetId);
                                    setSelectedBakiIdForPayment(targetId);
                                    setPayAmount(String(liveBakiDue));
                                    setActiveTab('baki-payment');
                                  }}
                                  className="px-3 py-1.5 rounded-lg text-xs font-bold bg-amber-500 hover:bg-amber-600 text-white flex items-center gap-1.5 shadow-sm"
                                >
                                  <Wallet className="w-3.5 h-3.5" />
                                  {t(`বাকি পরিশোধ (৳${liveBakiDue})`, `Pay Baki (৳${liveBakiDue})`)}
                                  <ArrowRight className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: BAKI AMOUNT PAYMENT */}
          {activeTab === 'baki-payment' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
              {/* Left: Baki Accounts List */}
              <div className="lg:col-span-5 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-gray-900 dark:text-white flex items-center gap-2">
                    <Receipt className="w-4 h-4 text-amber-600" />
                    {t('কাস্টমার বাকি খাতা তালিকা', 'Customer Baki Accounts')}
                  </h3>
                  <span className="text-xs font-bold text-amber-700 dark:text-amber-400">
                    {t(`মোট বাকি: ৳${totalCustomerBakiDue.toLocaleString()}`, `Total: ৳${totalCustomerBakiDue.toLocaleString()}`)}
                  </span>
                </div>

                <div className="space-y-2.5 max-h-[420px] overflow-y-auto pr-1">
                  {bakiAccounts.map(acc => {
                    const isSelected = activeBakiAccount?.id === acc.id;
                    return (
                      <button
                        key={acc.id}
                        type="button"
                        onClick={() => handleSelectBakiAccount(acc)}
                        className={`w-full text-left p-3.5 rounded-xl border transition-all ${
                          isSelected
                            ? 'border-amber-500 bg-amber-50/70 dark:bg-amber-900/20 shadow-sm ring-2 ring-amber-400/30'
                            : 'border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:border-amber-300'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-bold text-sm text-gray-900 dark:text-white">
                            {language === 'bn' ? acc.customerNameBn || acc.customerName : acc.customerName}
                          </span>
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                              acc.status === 'paid'
                                ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300'
                                : acc.status === 'partial'
                                ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300'
                                : 'bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300'
                            }`}
                          >
                            {acc.status === 'paid'
                              ? t('পরিশোধিত', 'Paid')
                              : acc.status === 'partial'
                              ? t('আংশিক বাকি', 'Partial')
                              : t('বাকি', 'Due')}
                          </span>
                        </div>
                        <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                          {acc.customerPhone} • {acc.orderNumber}
                        </p>
                        <p className="text-xs text-gray-600 dark:text-gray-300 mt-1 line-clamp-1">
                          {language === 'bn' ? acc.descriptionBn : acc.description}
                        </p>
                        <div className="mt-2 pt-2 border-t border-gray-100 dark:border-gray-700 flex items-center justify-between text-xs">
                          <span className="text-gray-500">
                            {t(`মোট: ৳${acc.totalBill}`, `Total: ৳${acc.totalBill}`)} • {t(`জমা: ৳${acc.paidAmount}`, `Paid: ৳${acc.paidAmount}`)}
                          </span>
                          <span className={`font-extrabold ${acc.bakiAmount > 0 ? 'text-rose-600 dark:text-rose-400' : 'text-emerald-600'}`}>
                            {t(`বাকি: ৳${acc.bakiAmount}`, `Due: ৳${acc.bakiAmount}`)}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Right: Payment Form */}
              <div className="lg:col-span-7">
                {activeBakiAccount ? (
                  <form
                    onSubmit={handlePayBakiSubmit}
                    className="bg-gray-50 dark:bg-gray-800/70 border border-gray-200 dark:border-gray-700 rounded-2xl p-4 sm:p-5 space-y-4"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-gray-200 dark:border-gray-700">
                      <div>
                        <span className="text-[11px] font-bold uppercase tracking-wider text-amber-600">
                          {t('বাকি টাকা পরিশোধ গেটওয়ে', 'Baki Amount Payment Checkout')}
                        </span>
                        <h4 className="text-base font-bold text-gray-900 dark:text-white">
                          {language === 'bn'
                            ? activeBakiAccount.customerNameBn || activeBakiAccount.customerName
                            : activeBakiAccount.customerName}{' '}
                          ({activeBakiAccount.orderNumber})
                        </h4>
                      </div>
                      <div className="text-right">
                        <span className="text-xs text-gray-500 block">{t('অবশিষ্ট বাকি টাকা', 'Remaining Baki Due')}</span>
                        <span className="text-xl font-black text-rose-600 dark:text-rose-400">
                          ৳{activeBakiAccount.bakiAmount.toLocaleString()}
                        </span>
                      </div>
                    </div>

                    {lastReceiptSms && (
                      <div className="p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-900/30 border border-emerald-300 dark:border-emerald-700 space-y-2">
                        <div className="flex items-center gap-2 text-emerald-800 dark:text-emerald-300 font-bold text-sm">
                          <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                          <span>{t('বাকি পরিশোধ সম্পন্ন ও রসিদ SMS পাঠানো হয়েছে!', 'Baki Paid & Receipt SMS Delivered!')}</span>
                        </div>
                        <p className="text-xs text-emerald-700 dark:text-emerald-200">
                          {language === 'bn' ? lastReceiptSms.messageBn : lastReceiptSms.message}
                        </p>
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={() => handleOpenCashMemoForSms(lastReceiptSms)}
                            className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-bold hover:bg-emerald-700 flex items-center gap-1.5"
                          >
                            <FileText className="w-3.5 h-3.5" />
                            {t('রসিদ মেমো ডাউনলোড করুন', 'Download Receipt Memo')}
                          </button>
                          <button
                            type="button"
                            onClick={() => setActiveTab('notifications')}
                            className="px-3 py-1.5 rounded-lg bg-white dark:bg-gray-800 border border-emerald-300 text-emerald-700 dark:text-emerald-300 text-xs font-bold"
                          >
                            {t('ইনবক্সে SMS দেখুন', 'View SMS in Inbox')}
                          </button>
                        </div>
                      </div>
                    )}

                    {activeBakiAccount.bakiAmount <= 0 ? (
                      <div className="p-6 text-center rounded-xl bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800">
                        <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto mb-2" />
                        <p className="font-bold text-emerald-800 dark:text-emerald-300">
                          {t('এই হিসাবের সম্পূর্ণ বাকি পরিশোধ হয়ে গেছে!', 'This Baki account is completely settled!')}
                        </p>
                      </div>
                    ) : (
                      <>
                        {/* Amount selector */}
                        <div>
                          <div className="flex items-center justify-between mb-1.5">
                            <label className="text-xs font-bold text-gray-700 dark:text-gray-300">
                              {t('পরিশোধের পরিমাণ (৳)', 'Payment Amount (৳)')}
                            </label>
                            <div className="flex gap-1.5">
                              <button
                                type="button"
                                onClick={() => setPayAmount(String(activeBakiAccount.bakiAmount))}
                                className="px-2 py-0.5 rounded bg-amber-100 text-amber-800 text-[11px] font-bold hover:bg-amber-200"
                              >
                                {t('সম্পূর্ণ (১০০%)', 'Full (100%)')}
                              </button>
                              <button
                                type="button"
                                onClick={() => setPayAmount(String(Math.max(1, Math.round(activeBakiAccount.bakiAmount / 2))))}
                                className="px-2 py-0.5 rounded bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-200 text-[11px] font-bold"
                              >
                                50%
                              </button>
                            </div>
                          </div>
                          <input
                            type="number"
                            min={1}
                            max={activeBakiAccount.bakiAmount}
                            value={payAmount}
                            onChange={e => setPayAmount(e.target.value)}
                            required
                            className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-900 text-base font-extrabold text-gray-900 dark:text-white focus:ring-2 focus:ring-amber-500 outline-none"
                          />
                        </div>

                        {/* Payment Method Grid */}
                        <div>
                          <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-2">
                            {t('পেমেন্ট মাধ্যম নির্বাচন করুন', 'Select Payment Gateway')}
                          </label>
                          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                            {[
                              { id: 'bkash', label: 'bKash (বিকাশ)', icon: Smartphone },
                              { id: 'nagad', label: 'Nagad (নগদ)', icon: Smartphone },
                              { id: 'rocket', label: 'Rocket (রকেট)', icon: Smartphone },
                              { id: 'bank_transfer', label: 'BD Bank (ব্যাংক)', icon: Building2 },
                              { id: 'card', label: 'Card (কার্ড)', icon: CreditCard }
                            ].map(method => {
                              const IconComp = method.icon;
                              return (
                                <button
                                  key={method.id}
                                  type="button"
                                  onClick={() => setPaymentMethod(method.id as any)}
                                  className={`p-2.5 rounded-xl border text-xs font-bold flex items-center gap-2 transition-all ${
                                    paymentMethod === method.id
                                      ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300 ring-1 ring-emerald-500'
                                      : 'border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-700 dark:text-gray-300'
                                  }`}
                                >
                                  <IconComp className="w-4 h-4 shrink-0" />
                                  <span className="truncate">{method.label}</span>
                                </button>
                              );
                            })}
                          </div>
                        </div>

                        {/* Bangladeshi Bank Dropdown */}
                        {paymentMethod === 'bank_transfer' && (
                          <div className="p-3 rounded-xl bg-white dark:bg-gray-900 border border-emerald-200 dark:border-emerald-800 space-y-2">
                            <label className="block text-xs font-bold text-emerald-800 dark:text-emerald-300">
                              {t('বাংলাদেশি ব্যাংক নির্বাচন করুন (Dropdown)', 'Select Bangladeshi Bank')}
                            </label>
                            <select
                              value={selectedBankId}
                              onChange={e => setSelectedBankId(e.target.value)}
                              className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 text-xs sm:text-sm font-semibold"
                            >
                              {BANGLADESHI_BANKS.filter(b => b.isActive).map(bank => (
                                <option key={bank.id} value={bank.id}>
                                  {language === 'bn' ? `${bank.nameBn} (${bank.shortCode})` : `${bank.name} (${bank.shortCode})`}
                                </option>
                              ))}
                            </select>
                            {selectedBank && (
                              <div className="text-[11px] text-gray-600 dark:text-gray-300 bg-emerald-50/70 dark:bg-emerald-950/30 p-2 rounded-lg">
                                <div>
                                  <strong>{t('একাউন্ট নম্বর:', 'A/C No:')}</strong> {selectedBank.accountNumber} ({selectedBank.branchName})
                                </div>
                                <div>
                                  <strong>{t('রাউটিং:', 'Routing:')}</strong> {selectedBank.routingNumber} • {selectedBank.appPlatform}
                                </div>
                              </div>
                            )}
                          </div>
                        )}

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div>
                            <label className="block text-xs font-semibold text-gray-600 dark:text-gray-300 mb-1">
                              {t('প্রেরক নম্বর / একাউন্ট', 'Sender Mobile / Account')}
                            </label>
                            <input
                              type="text"
                              value={senderAccountOrPhone}
                              onChange={e => setSenderAccountOrPhone(e.target.value)}
                              placeholder="01XXXXXXXXX"
                              className="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-900 text-sm"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-semibold text-gray-600 dark:text-gray-300 mb-1">
                              {t('ট্রানজেকশন আইডি (ঐচ্ছিক)', 'Transaction Ref / TrxID')}
                            </label>
                            <input
                              type="text"
                              value={txnRef}
                              onChange={e => setTxnRef(e.target.value)}
                              placeholder="e.g. TXN849201"
                              className="w-full px-3 py-2 rounded-xl border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-900 text-sm"
                            />
                          </div>
                        </div>

                        <button
                          type="submit"
                          disabled={isPaying || Number(payAmount) <= 0}
                          className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold text-sm shadow-lg flex items-center justify-center gap-2 disabled:opacity-60"
                        >
                          <ShieldCheck className="w-5 h-5" />
                          <span>
                            {isPaying
                              ? t('প্রসেসিং হচ্ছে...', 'Processing Payment...')
                              : t(
                                  `৳${Number(payAmount || 0).toLocaleString()} বাকি পরিশোধ করুন ও রসিদ SMS পান`,
                                  `Pay ৳${Number(payAmount || 0).toLocaleString()} Baki & Get Receipt SMS`
                                )}
                          </span>
                        </button>
                      </>
                    )}
                  </form>
                ) : (
                  <div className="p-8 text-center text-gray-500">
                    {t('কোনো বাকি হিসাব পাওয়া যায়নি', 'No Baki accounts available')}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 3: CUSTOMER SMS & NOTIFICATION SETTINGS */}
          {activeTab === 'sms-settings' && (
            <div className="max-w-2xl mx-auto space-y-4">
              <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-800/70 border border-gray-200 dark:border-gray-700 space-y-4">
                <div className="flex items-center gap-2.5">
                  <Sparkles className="w-5 h-5 text-emerald-600" />
                  <div>
                    <h3 className="text-sm font-bold text-gray-900 dark:text-white">
                      {t('কাস্টমার SMS রসিদ ও বাকি নোটিফিকেশন পছন্দসমূহ', 'Customer SMS Receipt & Baki Alert Preferences')}
                    </h3>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {t('সেটিংসের অধীনে আপনার মোবাইল এসএমএস রসিদ ও বাকি তাগাদা নিয়ন্ত্রণ করুন।', 'Control your receipt SMS, Baki reminders, and bulk alerts under Settings.')}
                    </p>
                  </div>
                </div>

                {[
                  {
                    key: 'customerReceiveReceiptSms' as const,
                    bn: 'অর্ডার ও ক্যাশ মেমো রসিদ SMS গ্রহণ করুন',
                    en: 'Receive Order & Cash Memo Receipt SMS'
                  },
                  {
                    key: 'customerReceiveBakiAlertSms' as const,
                    bn: 'বাকি টাকা পরিশোধ ও তাগাদা SMS নোটিফিকেশন',
                    en: 'Receive Baki Due & Payment Receipt SMS Alerts'
                  },
                  {
                    key: 'customerReceiveBulkPromoSms' as const,
                    bn: 'অ্যাডমিন থেকে পাঠানো বাল্ক ডিসকাউন্ট ও ক্যাম্পেইন SMS',
                    en: 'Receive Admin Bulk Offer & Campaign SMS'
                  }
                ].map(item => (
                  <label
                    key={item.key}
                    className="flex items-center justify-between p-3 rounded-xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 cursor-pointer"
                  >
                    <span className="text-xs sm:text-sm font-semibold text-gray-800 dark:text-gray-200">
                      {t(item.bn, item.en)}
                    </span>
                    <input
                      type="checkbox"
                      checked={!!smsGatewaySettings[item.key]}
                      onChange={e => updateSmsGatewaySettings({ [item.key]: e.target.checked })}
                      className="w-4 h-4 accent-emerald-600 rounded"
                    />
                  </label>
                ))}

                <div className="flex items-center justify-between p-3 rounded-xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700">
                  <span className="text-xs sm:text-sm font-semibold text-gray-800 dark:text-gray-200">
                    {t('SMS রসিদের ভাষা', 'Preferred SMS Language')}
                  </span>
                  <select
                    value={smsGatewaySettings.smsLanguage}
                    onChange={e => updateSmsGatewaySettings({ smsLanguage: e.target.value as any })}
                    className="px-3 py-1.5 rounded-lg border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 text-xs font-bold"
                  >
                    <option value="bilingual">{t('বাংলা + English (দ্বিভাষিক)', 'Bilingual (BN + EN)')}</option>
                    <option value="bn">{t('শুধুমাত্র বাংলা', 'Bangla Only')}</option>
                    <option value="en">{t('English Only', 'English Only')}</option>
                  </select>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
