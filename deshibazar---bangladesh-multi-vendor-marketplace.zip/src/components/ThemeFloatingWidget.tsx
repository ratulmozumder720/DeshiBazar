import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Palette, X, Shuffle, Check, Download, Settings } from 'lucide-react';

export const ThemeFloatingWidget: React.FC = () => {
  const { openThemeStudio, openEcommerceStudio, currentTheme, t, language, allThemes, setThemeId } = useApp();
  const [isOpenMenu, setIsOpenMenu] = useState(false);

  const handleSurprise = (e: React.MouseEvent) => {
    e.stopPropagation();
    const randomIndex = Math.floor(Math.random() * allThemes.length);
    setThemeId(allThemes[randomIndex].id);
  };

  return (
    <div className="fixed bottom-20 md:bottom-6 right-4 md:right-6 z-40 flex flex-col items-end">
      {/* Quick menu balloon when open */}
      {isOpenMenu && (
        <div className="mb-2 p-3 bg-white dark:bg-gray-800 rounded-2xl shadow-2xl border border-gray-200 dark:border-gray-700 w-56 animate-in slide-in-from-bottom-2 duration-150 text-xs">
          <div className="flex items-center justify-between pb-2 border-b border-gray-100 dark:border-gray-700 mb-2">
            <span className="font-extrabold text-gray-800 dark:text-gray-100 flex items-center gap-1.5">
              <Palette className="w-3.5 h-3.5 text-emerald-600" />
              <span>{t('১০০+ ব্যাকগ্রাউন্ড থিম', '100+ BG Themes')}</span>
            </span>
            <button 
              onClick={() => setIsOpenMenu(false)}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-1.5">
            <div className="text-[11px] text-gray-500 dark:text-gray-400 flex items-center justify-between">
              <span>{t('বর্তমান থিম', 'Current')}:</span>
              <span className="font-bold text-gray-800 dark:text-gray-200 truncate max-w-[100px]">
                {language === 'bn' ? currentTheme.nameBn : currentTheme.name}
              </span>
            </div>

            {/* Quick 4 popular themes swatches */}
            <div className="grid grid-cols-4 gap-1.5 py-1">
              {[
                { id: 'deshi-emerald-gold', title: 'Padma' },
                { id: 'sundarbans-mangrove', title: 'Sundarban' },
                { id: 'cyberpunk-neon-yellow', title: 'Cyber' },
                { id: 'imperial-royal-gold', title: 'Royal' }
              ].map((item) => {
                const target = allThemes.find(th => th.id === item.id);
                if (!target) return null;
                const isSelected = currentTheme.id === target.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setThemeId(item.id)}
                    className={`h-8 rounded-lg border flex items-center justify-center relative transition-transform hover:scale-105 ${
                      isSelected ? 'ring-2 ring-emerald-500 border-white' : 'border-gray-200 dark:border-gray-700'
                    }`}
                    style={{ background: target.bgGradient || target.bgColor }}
                    title={target.name}
                  >
                    {isSelected && <Check className="w-3.5 h-3.5 text-emerald-700 stroke-[3]" />}
                  </button>
                );
              })}
            </div>

            <div className="pt-2 border-t border-gray-100 dark:border-gray-700 flex flex-col gap-1.5">
              <button
                onClick={(e) => {
                  handleSurprise(e);
                  setIsOpenMenu(false);
                }}
                className="w-full py-1.5 px-2.5 rounded-xl bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 font-bold flex items-center justify-center gap-1.5 hover:bg-purple-100 transition-colors"
              >
                <Shuffle className="w-3.5 h-3.5" />
                <span>{t('র্যান্ডম থিম ট্রাই করুন', 'Surprise Random Theme')}</span>
              </button>

              <button
                onClick={() => {
                  setIsOpenMenu(false);
                  openEcommerceStudio();
                }}
                className="w-full py-1.5 px-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-gray-950 font-black flex items-center justify-center gap-1.5 shadow-sm hover:from-amber-300 hover:to-amber-400 transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{t('ই-কমার্স থিম জিপ ডাউনলোড', 'E-Com Theme ZIP')}</span>
              </button>

              <button
                onClick={() => {
                  setIsOpenMenu(false);
                  openThemeStudio();
                }}
                className="w-full py-1.5 px-2.5 rounded-xl bg-emerald-600 text-white font-bold flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/20 hover:bg-emerald-700 transition-colors"
              >
                <Settings className="w-3.5 h-3.5" />
                <span>{t('১০০+ থিম সেটিংস খুলুন', 'Open 100+ Theme Studio')}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Floating Trigger Button */}
      <div className="flex items-center gap-2">
        <button
          onClick={() => setIsOpenMenu(!isOpenMenu)}
          className="group relative flex items-center gap-1.5 bg-gradient-to-r from-emerald-600 via-teal-600 to-indigo-600 text-white px-3.5 py-2.5 rounded-full shadow-xl shadow-emerald-900/30 hover:shadow-2xl hover:scale-105 active:scale-95 transition-all border border-white/20"
          title={t('১০০+ ব্যাকগ্রাউন্ড থিম ও কালার সেটিংস পরিবর্তন করুন', 'Change 100+ Background Themes & Colors')}
        >
          <Settings className="w-4 h-4 animate-spin-slow group-hover:rotate-45 transition-transform" />
          <Palette className="w-4 h-4" />
          <span className="text-xs font-black tracking-wide">
            {t('🎨 থিম সেটিংস', '🎨 Themes')}
          </span>
          <span className="w-2 h-2 rounded-full bg-amber-300 animate-ping absolute top-1 right-1" />
        </button>
      </div>
    </div>
  );
};
