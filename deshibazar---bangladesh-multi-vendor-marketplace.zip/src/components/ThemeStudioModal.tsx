import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { BackgroundTheme } from '../data/themesData';
import { 
  X, 
  Search, 
  Palette, 
  Check, 
  Sparkles, 
  Shuffle, 
  RotateCcw, 
  Sun, 
  Moon, 
  Smartphone, 
  Monitor, 
  ShoppingBag, 
  Download,
  Settings
} from 'lucide-react';

export const ThemeStudioModal: React.FC = () => {
  const {
    t,
    language,
    isThemeModalOpen,
    setIsThemeModalOpen,
    openEcommerceStudio,
    allThemes,
    themeCategories,
    currentThemeId,
    currentTheme,
    setThemeId,
    customTheme,
    setCustomTheme,
    showToast
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [modeFilter, setModeFilter] = useState<'all' | 'light' | 'dark'>('all');
  const [colorFilter, setColorFilter] = useState<string>('all');
  const [previewDevice, setPreviewDevice] = useState<'desktop' | 'mobile'>('desktop');
  const [isCustomizerOpen, setIsCustomizerOpen] = useState(false);

  // Customizer state
  const [customBg, setCustomBg] = useState(currentTheme.bgColor || '#f0fdf4');
  const [customSurface, setCustomSurface] = useState(currentTheme.surfaceColor || '#ffffff');
  const [customAccent, setCustomAccent] = useState(currentTheme.accentColor || '#059669');
  const [customHeader, setCustomHeader] = useState(currentTheme.headerBg || '#065f46');
  const [customText, setCustomText] = useState(currentTheme.textColor || '#0f172a');
  const [customName, setCustomName] = useState('My Custom Theme');

  // Filtered themes
  const filteredThemes = useMemo(() => {
    return allThemes.filter((th) => {
      // Category filter
      if (selectedCategory !== 'all' && th.category !== selectedCategory) {
        return false;
      }
      // Mode filter
      if (modeFilter !== 'all' && th.mode !== modeFilter) {
        return false;
      }
      // Color family filter
      if (colorFilter !== 'all') {
        const matchesTag = th.tags.some(tag => tag.toLowerCase().includes(colorFilter.toLowerCase()));
        if (!matchesTag) return false;
      }
      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchName = th.name.toLowerCase().includes(q);
        const matchNameBn = th.nameBn.toLowerCase().includes(q);
        const matchTags = th.tags.some(tag => tag.toLowerCase().includes(q));
        const matchCat = th.category.toLowerCase().includes(q) || th.categoryBn.toLowerCase().includes(q);
        if (!matchName && !matchNameBn && !matchTags && !matchCat) {
          return false;
        }
      }
      return true;
    });
  }, [allThemes, selectedCategory, modeFilter, colorFilter, searchQuery]);

  if (!isThemeModalOpen) return null;

  const handlePickRandomTheme = () => {
    const randomIndex = Math.floor(Math.random() * allThemes.length);
    const randomTheme = allThemes[randomIndex];
    setThemeId(randomTheme.id);
  };

  const handleResetDefault = () => {
    setThemeId('deshi-emerald-gold');
  };

  const handleApplyCustomTheme = () => {
    const isDark = customBg === '#000000' || customBg.startsWith('#0') || customBg.startsWith('#1');
    const newCustom: Partial<BackgroundTheme> = {
      id: `custom-${Date.now()}`,
      name: customName || 'Custom Studio Theme',
      nameBn: customName || 'কাস্টম থিম',
      category: 'tech-studio',
      categoryBn: 'কাস্টম স্টুডিও',
      mode: isDark ? 'dark' : 'light',
      bgGradient: customBg,
      bgColor: customBg,
      surfaceColor: customSurface,
      surfaceBorder: isDark ? '#333333' : '#e2e8f0',
      headerBg: customHeader,
      headerText: '#ffffff',
      textColor: customText,
      mutedText: isDark ? '#a1a1aa' : '#64748b',
      accentColor: customAccent,
      accentHover: customAccent,
      accentText: '#ffffff',
      previewColors: [customHeader, customAccent, customSurface, customBg]
    };

    setCustomTheme(newCustom);
    try {
      localStorage.setItem('deshibazar_custom_theme', JSON.stringify(newCustom));
    } catch {}
    showToast(t('কাস্টম থিম সফলভাবে প্রয়োগ করা হয়েছে!', 'Custom theme applied successfully!'), 'success');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full max-w-6xl max-h-[94vh] flex flex-col bg-white dark:bg-gray-900 rounded-3xl shadow-2xl border border-gray-100 dark:border-gray-800 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header Bar */}
        <div className="px-5 py-4 border-b border-gray-100 dark:border-gray-800 flex items-center justify-between bg-gradient-to-r from-emerald-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-850 dark:to-gray-900">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 via-teal-500 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-emerald-600/20 shrink-0">
              <Palette className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-gray-900 dark:text-white">
                  {t('১০০+ ব্যাকগ্রাউন্ড থিম ও কালার স্টুডিও', '100+ Background Themes & Colors')}
                </h2>
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 text-[10px] font-black tracking-wider uppercase border border-emerald-200 dark:border-emerald-800">
                  <Settings className="w-3 h-3 text-emerald-600 animate-spin-slow" />
                  <span>{allThemes.length} {t('থিম ও সেটিংস', 'Themes & Settings')}</span>
                </span>
              </div>
              <p className="text-xs text-gray-500 dark:text-gray-400 hidden sm:block">
                {t('ওয়েবসাইট ও মোবাইল অ্যাপের জন্য যেকোনো ব্যাকগ্রাউন্ড কালার ও স্টাইল এক ক্লিকে পরিবর্তন করুন', 'Instantly switch background colors & palettes for website and mobile apps')}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePickRandomTheme}
              className="px-3 py-1.5 rounded-xl border border-gray-200 dark:border-gray-700 text-xs font-bold text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 flex items-center gap-1.5 transition-colors shadow-xs"
              title={t('যেকোনো র্যান্ডম থিম ট্রাই করুন', 'Try a random theme')}
            >
              <Shuffle className="w-3.5 h-3.5 text-purple-500" />
              <span className="hidden sm:inline">{t('র্যান্ডম থিম', 'Surprise Me')}</span>
            </button>

            <button
              onClick={handleResetDefault}
              className="px-3 py-1.5 rounded-xl border border-gray-200 dark:border-gray-700 text-xs font-bold text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 flex items-center gap-1.5 transition-colors shadow-xs"
              title={t('ডিফল্ট পদ্মা থিমে ফিরুন', 'Reset to Padma default')}
            >
              <RotateCcw className="w-3.5 h-3.5 text-emerald-500" />
              <span className="hidden sm:inline">{t('ডিফল্ট', 'Reset')}</span>
            </button>

            <button
              onClick={() => setIsThemeModalOpen(false)}
              className="w-9 h-9 rounded-xl flex items-center justify-center text-gray-400 hover:text-gray-700 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* E-Commerce Theme & Backend HTML ZIP Download Promo Bar */}
        <div className="px-5 py-2.5 bg-gradient-to-r from-amber-500 via-amber-600 to-emerald-600 text-gray-950 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs font-bold shadow-xs">
          <div className="flex items-center gap-2">
            <span className="bg-black text-amber-300 text-[10px] font-black uppercase px-2 py-0.5 rounded-full">
              NEW
            </span>
            <span className="text-white">
              {t(
                'সম্পূর্ণ ফাংশনাল ও মোবাইল রেসপনসিভ ই-কমার্স থিম খুঁজছেন? ব্যাকএন্ড থেকে সরাসরি HTML ZIP ডাউনলোড করুন!',
                'Looking for a fully functional, mobile responsive e-commerce theme? Download full HTML ZIP from backend!'
              )}
            </span>
          </div>
          <button
            onClick={() => {
              setIsThemeModalOpen(false);
              openEcommerceStudio();
            }}
            className="px-3.5 py-1.5 bg-gray-950 hover:bg-black text-amber-300 rounded-xl text-xs font-black shadow-md flex items-center gap-1.5 transition-all shrink-0 active:scale-95"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span>{t('ই-কমার্স থিম স্টুডিও ও জিপ ডাউনলোড →', 'Open E-Com Studio & Download ZIP →')}</span>
          </button>
        </div>

        {/* Live Simulator Preview Bar */}
        <div className="px-5 py-3 border-b border-gray-100 dark:border-gray-800 bg-gray-50/70 dark:bg-gray-850/60 flex flex-col md:flex-row items-center justify-between gap-3">
          {/* Active Theme Badge & Info */}
          <div className="flex items-center gap-3 w-full md:w-auto">
            <div className="flex -space-x-1.5 shrink-0">
              {currentTheme.previewColors.slice(0, 4).map((c, idx) => (
                <div 
                  key={idx} 
                  className="w-5 h-5 rounded-full border-2 border-white dark:border-gray-800 shadow-xs" 
                  style={{ backgroundColor: c }} 
                />
              ))}
            </div>
            <div className="text-xs">
              <span className="text-gray-400 block text-[10px] uppercase tracking-wider font-semibold">
                {t('বর্তমান সক্রিয় থিম', 'Active Theme')}:
              </span>
              <span className="font-extrabold text-gray-900 dark:text-white flex items-center gap-1.5">
                {language === 'bn' ? currentTheme.nameBn : currentTheme.name}
                <span className="px-1.5 py-0.2 rounded text-[10px] font-semibold bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300">
                  {currentTheme.mode === 'dark' ? '🌙 Dark' : '☀️ Light'}
                </span>
              </span>
            </div>
          </div>

          {/* Quick simulator preview switcher */}
          <div className="flex items-center gap-2 w-full md:w-auto justify-between md:justify-end">
            <div className="flex items-center bg-gray-200/80 dark:bg-gray-700/80 rounded-xl p-0.5 text-xs font-semibold">
              <button
                onClick={() => setPreviewDevice('desktop')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-lg transition-all ${
                  previewDevice === 'desktop'
                    ? 'bg-white dark:bg-gray-900 text-emerald-600 dark:text-emerald-400 shadow-xs font-bold'
                    : 'text-gray-600 dark:text-gray-300'
                }`}
              >
                <Monitor className="w-3.5 h-3.5" />
                <span>{t('ওয়েবসাইট ভিউ', 'Website')}</span>
              </button>
              <button
                onClick={() => setPreviewDevice('mobile')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-lg transition-all ${
                  previewDevice === 'mobile'
                    ? 'bg-white dark:bg-gray-900 text-emerald-600 dark:text-emerald-400 shadow-xs font-bold'
                    : 'text-gray-600 dark:text-gray-300'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>{t('মোবাইল অ্যাপ ভিউ', 'Mobile App')}</span>
              </button>
            </div>

            <button
              onClick={() => setIsCustomizerOpen(!isCustomizerOpen)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all border ${
                isCustomizerOpen
                  ? 'bg-purple-600 text-white border-purple-600 shadow-xs'
                  : 'bg-white dark:bg-gray-800 text-purple-600 dark:text-purple-400 border-purple-200 dark:border-purple-800 hover:bg-purple-50'
              }`}
            >
              <Settings className="w-3.5 h-3.5" />
              <span>{t('থিম ও কালার সেটিংস', 'Theme Settings & Colors')}</span>
            </button>
          </div>
        </div>

        {/* Customizer Drawer */}
        {isCustomizerOpen && (
          <div className="p-4 bg-purple-50/60 dark:bg-purple-950/20 border-b border-purple-100 dark:border-purple-900/40 animate-in slide-in-from-top-2 duration-150">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 w-full sm:w-auto">
                <div>
                  <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider block mb-1">
                    {t('ব্যাকগ্রাউন্ড', 'Background')}
                  </label>
                  <div className="flex items-center gap-1.5">
                    <input
                      type="color"
                      value={customBg.startsWith('#') ? customBg : '#f0fdf4'}
                      onChange={(e) => setCustomBg(e.target.value)}
                      className="w-7 h-7 rounded cursor-pointer border-0 p-0"
                    />
                    <input
                      type="text"
                      value={customBg}
                      onChange={(e) => setCustomBg(e.target.value)}
                      className="text-xs font-mono px-1.5 py-1 rounded bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 w-20"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider block mb-1">
                    {t('সারফেস / কার্ড', 'Surface Card')}
                  </label>
                  <div className="flex items-center gap-1.5">
                    <input
                      type="color"
                      value={customSurface}
                      onChange={(e) => setCustomSurface(e.target.value)}
                      className="w-7 h-7 rounded cursor-pointer border-0 p-0"
                    />
                    <input
                      type="text"
                      value={customSurface}
                      onChange={(e) => setCustomSurface(e.target.value)}
                      className="text-xs font-mono px-1.5 py-1 rounded bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 w-20"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider block mb-1">
                    {t('হেডার ব্যাকগ্রাউন্ড', 'Header')}
                  </label>
                  <div className="flex items-center gap-1.5">
                    <input
                      type="color"
                      value={customHeader}
                      onChange={(e) => setCustomHeader(e.target.value)}
                      className="w-7 h-7 rounded cursor-pointer border-0 p-0"
                    />
                    <input
                      type="text"
                      value={customHeader}
                      onChange={(e) => setCustomHeader(e.target.value)}
                      className="text-xs font-mono px-1.5 py-1 rounded bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 w-20"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider block mb-1">
                    {t('অ্যাকসেন্ট বাটন', 'Accent Button')}
                  </label>
                  <div className="flex items-center gap-1.5">
                    <input
                      type="color"
                      value={customAccent}
                      onChange={(e) => setCustomAccent(e.target.value)}
                      className="w-7 h-7 rounded cursor-pointer border-0 p-0"
                    />
                    <input
                      type="text"
                      value={customAccent}
                      onChange={(e) => setCustomAccent(e.target.value)}
                      className="text-xs font-mono px-1.5 py-1 rounded bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 w-20"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider block mb-1">
                    {t('টেক্সট কালার', 'Text Color')}
                  </label>
                  <div className="flex items-center gap-1.5">
                    <input
                      type="color"
                      value={customText}
                      onChange={(e) => setCustomText(e.target.value)}
                      className="w-7 h-7 rounded cursor-pointer border-0 p-0"
                    />
                    <input
                      type="text"
                      value={customText}
                      onChange={(e) => setCustomText(e.target.value)}
                      className="text-xs font-mono px-1.5 py-1 rounded bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 w-20"
                    />
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                <input
                  type="text"
                  placeholder={t('থিমের নাম...', 'Theme name...')}
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  className="text-xs px-2.5 py-1.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 w-32"
                />
                <button
                  onClick={handleApplyCustomTheme}
                  className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-1.5 rounded-xl text-xs font-bold shadow-md transition-all shrink-0"
                >
                  {t('প্রয়োগ করুন', 'Save & Apply')}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Filter and Search Toolbar */}
        <div className="p-4 border-b border-gray-100 dark:border-gray-800 space-y-3">
          {/* Search & Mode toggles */}
          <div className="flex flex-col sm:flex-row items-center gap-2.5">
            <div className="relative flex-1 w-full">
              <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t(
                  '১০০+ থিম খুঁজুন (পদ্মা, নিওন, গোল্ড, সাইবার, ডার্ক, সাকুরা...)',
                  'Search 100+ themes (Padma, Gold, Cyber, Neon, Dark, Sakura...)'
                )}
                className="w-full pl-9 pr-4 py-2 rounded-xl text-xs bg-gray-50 dark:bg-gray-800/80 border border-gray-200 dark:border-gray-700 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
              />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 text-xs"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Mode Filters */}
            <div className="flex items-center gap-1 bg-gray-100 dark:bg-gray-800 p-1 rounded-xl shrink-0 w-full sm:w-auto justify-center">
              <button
                onClick={() => setModeFilter('all')}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                  modeFilter === 'all'
                    ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-xs'
                    : 'text-gray-500 hover:text-gray-800 dark:hover:text-gray-200'
                }`}
              >
                {t('সকল মোড', 'All')}
              </button>
              <button
                onClick={() => setModeFilter('light')}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1 ${
                  modeFilter === 'light'
                    ? 'bg-white dark:bg-gray-700 text-amber-600 dark:text-amber-400 shadow-xs'
                    : 'text-gray-500 hover:text-gray-800 dark:hover:text-gray-200'
                }`}
              >
                <Sun className="w-3 h-3" />
                <span>Light</span>
              </button>
              <button
                onClick={() => setModeFilter('dark')}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1 ${
                  modeFilter === 'dark'
                    ? 'bg-white dark:bg-gray-700 text-indigo-600 dark:text-indigo-400 shadow-xs'
                    : 'text-gray-500 hover:text-gray-800 dark:hover:text-gray-200'
                }`}
              >
                <Moon className="w-3 h-3" />
                <span>Dark / OLED</span>
              </button>
            </div>

            {/* Color Family Quick Selector */}
            <div className="flex items-center gap-1 shrink-0 overflow-x-auto max-w-full pb-1 sm:pb-0">
              {[
                { id: 'all', label: 'All', color: '#94a3b8' },
                { id: 'green', label: 'Green', color: '#10b981' },
                { id: 'blue', label: 'Blue', color: '#3b82f6' },
                { id: 'purple', label: 'Purple', color: '#a855f7' },
                { id: 'gold', label: 'Gold', color: '#f59e0b' },
                { id: 'pink', label: 'Pink', color: '#ec4899' },
                { id: 'dark', label: 'Dark', color: '#18181b' },
              ].map(c => (
                <button
                  key={c.id}
                  onClick={() => setColorFilter(c.id)}
                  className={`w-6 h-6 rounded-full border-2 transition-transform ${
                    colorFilter === c.id ? 'scale-115 border-emerald-500 shadow-xs' : 'border-transparent hover:scale-105'
                  }`}
                  style={{ backgroundColor: c.color }}
                  title={`Filter ${c.label}`}
                />
              ))}
            </div>
          </div>

          {/* Category Tabs Scrollable */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {themeCategories.map((cat) => {
              const isActive = selectedCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 shrink-0 ${
                    isActive
                      ? 'bg-emerald-600 text-white shadow-sm shadow-emerald-600/20'
                      : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
                  }`}
                >
                  <span>{language === 'bn' ? cat.nameBn : cat.name}</span>
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                    isActive ? 'bg-emerald-700 text-emerald-100' : 'bg-gray-200 dark:bg-gray-700 text-gray-500 dark:text-gray-400'
                  }`}>
                    {cat.count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Main Theme Grid & Live Device Preview */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5">
          {filteredThemes.length === 0 ? (
            <div className="text-center py-16">
              <Palette className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-3" />
              <h3 className="text-base font-bold text-gray-700 dark:text-gray-300">
                {t('কোনো থিম খুঁজে পাওয়া যায়নি', 'No themes found matching your filter')}
              </h3>
              <p className="text-xs text-gray-400 mt-1">
                {t('ফিল্টার রিসেট করে আবার চেষ্টা করুন', 'Try clearing search or filters')}
              </p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory('all');
                  setModeFilter('all');
                  setColorFilter('all');
                }}
                className="mt-3 px-4 py-1.5 rounded-xl bg-emerald-600 text-white text-xs font-bold"
              >
                {t('সব থিম প্রদর্শন করুন', 'Show All 100+ Themes')}
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filteredThemes.map((th) => {
                const isActive = currentThemeId === th.id && !customTheme;
                return (
                  <div
                    key={th.id}
                    onClick={() => setThemeId(th.id)}
                    className={`rounded-2xl border transition-all cursor-pointer group relative overflow-hidden flex flex-col justify-between ${
                      isActive
                        ? 'ring-2 ring-emerald-500 border-emerald-500 shadow-lg shadow-emerald-500/10'
                        : 'border-gray-200 dark:border-gray-800 hover:border-gray-300 dark:hover:border-gray-700 hover:shadow-md'
                    }`}
                    style={{
                      background: th.bgGradient || th.bgColor
                    }}
                  >
                    {/* Active Checkmark Badge */}
                    {isActive && (
                      <div className="absolute top-2.5 right-2.5 z-10 bg-emerald-600 text-white rounded-full p-1 shadow-md">
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                      </div>
                    )}

                    {/* Miniature UI Card Preview */}
                    <div className="p-3">
                      {/* Mini Preview Mockup */}
                      <div 
                        className="rounded-xl p-2.5 shadow-sm border mb-3 transition-transform group-hover:scale-[1.02]"
                        style={{
                          backgroundColor: th.surfaceColor,
                          borderColor: th.surfaceBorder,
                          color: th.textColor
                        }}
                      >
                        {/* Mini Header Bar */}
                        <div 
                          className="rounded-lg p-1.5 mb-2 flex items-center justify-between text-[10px] font-bold"
                          style={{
                            backgroundColor: th.headerBg,
                            color: th.headerText
                          }}
                        >
                          <div className="flex items-center gap-1 truncate">
                            <ShoppingBag className="w-3 h-3 shrink-0" />
                            <span className="truncate">DeshiBazar</span>
                          </div>
                          <span 
                            className="w-2 h-2 rounded-full" 
                            style={{ backgroundColor: th.accentColor }} 
                          />
                        </div>

                        {/* Mini Content Card */}
                        <div className="flex items-center justify-between gap-1 mb-2">
                          <div>
                            <div 
                              className="text-[11px] font-bold truncate max-w-[120px]"
                              style={{ color: th.textColor }}
                            >
                              {language === 'bn' ? th.nameBn : th.name}
                            </div>
                            <span 
                              className="text-[9px] block" 
                              style={{ color: th.mutedText }}
                            >
                              ৳1,250 · Verified Deshi
                            </span>
                          </div>
                          <span 
                            className="px-2 py-0.5 rounded text-[9px] font-bold shrink-0 shadow-xs"
                            style={{
                              backgroundColor: th.accentColor,
                              color: th.accentText
                            }}
                          >
                            Buy
                          </span>
                        </div>

                        {/* Color Swatch Dots */}
                        <div className="flex items-center gap-1.5 pt-1 border-t" style={{ borderColor: th.surfaceBorder }}>
                          {th.previewColors.slice(0, 4).map((clr, i) => (
                            <span
                              key={i}
                              className="w-3.5 h-3.5 rounded-full border border-black/10 dark:border-white/10 shadow-xs"
                              style={{ backgroundColor: clr }}
                            />
                          ))}
                        </div>
                      </div>

                      {/* Theme Details Footer */}
                      <div className="flex items-center justify-between gap-1">
                        <div>
                          <h4 
                            className="text-xs font-bold leading-tight"
                            style={{ color: th.textColor }}
                          >
                            {language === 'bn' ? th.nameBn : th.name}
                          </h4>
                          <span 
                            className="text-[10px]"
                            style={{ color: th.mutedText }}
                          >
                            {th.categoryBn}
                          </span>
                        </div>

                        <span 
                          className="text-[10px] px-2 py-0.5 rounded-full font-bold uppercase shrink-0"
                          style={{
                            backgroundColor: th.mode === 'dark' ? '#1e1b4b' : '#f1f5f9',
                            color: th.mode === 'dark' ? '#a5b4fc' : '#475569'
                          }}
                        >
                          {th.mode === 'dark' ? 'Dark' : 'Light'}
                        </span>
                      </div>
                    </div>

                    {/* Bottom Apply Action */}
                    <div className="px-3 pb-3 pt-1">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setThemeId(th.id);
                        }}
                        className={`w-full py-1.5 rounded-xl text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-1.5 ${
                          isActive
                            ? 'bg-emerald-600 text-white'
                            : 'bg-white/80 dark:bg-gray-800/80 hover:bg-white dark:hover:bg-gray-750 text-gray-800 dark:text-gray-100 backdrop-blur-xs'
                        }`}
                      >
                        {isActive ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            <span>{t('সক্রিয় রয়েছে', 'Active Theme')}</span>
                          </>
                        ) : (
                          <span>{t('থিম সিলেক্ট করুন', 'Apply Theme')}</span>
                        )}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer info bar */}
        <div className="px-5 py-3 border-t border-gray-100 dark:border-gray-800 flex flex-col sm:flex-row items-center justify-between text-xs text-gray-500 dark:text-gray-400 gap-2 bg-gray-50/50 dark:bg-gray-900">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-500" />
            <span>
              {t(
                'মোট ১১২টি প্রিমিয়াম থিম ওয়েবসাইট এবং মোবাইল অ্যাপ সিমুলেটরে কাজ করবে',
                'All 112 premium themes instantly apply to the live web app and mobile app previews'
              )}
            </span>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-[11px] text-gray-400">
              {filteredThemes.length} / {allThemes.length} {t('থিম প্রদর্শিত', 'Themes shown')}
            </span>
            <button
              onClick={() => setIsThemeModalOpen(false)}
              className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-1.5 rounded-xl font-bold shadow-xs transition-colors"
            >
              {t('ঠিক আছে', 'Done')}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
