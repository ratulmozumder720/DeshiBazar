import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  User, 
  signInWithPopup, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged 
} from 'firebase/auth';
import { 
  doc, 
  setDoc, 
  getDoc, 
  collection, 
  addDoc, 
  onSnapshot 
} from 'firebase/firestore';
import { auth, googleProvider, db } from '../firebase';
import { Product, Category, CartItem, Order, UserProfile, Coupon, Language, Seller, CustomerUIConfig, SmsNotification, BakiAccount, SmsGatewaySettings, SmsNotificationType } from '../types';
import { PRODUCTS, SELLERS, COUPONS, CATEGORIES } from '../data/mockData';
import { BANGLADESH_COURIERS } from '../data/courierData';
import { BackgroundTheme, ALL_THEMES, THEME_CATEGORIES } from '../data/themesData';
import { DEFAULT_CUSTOMER_UI_CONFIG } from '../data/defaultCustomerUIConfig';

interface Toast {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}

interface AppContextType {
  // Localization & Theme
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (bn: string, en: string) => string;
  darkMode: boolean;
  toggleDarkMode: () => void;
  currentThemeId: string;
  currentTheme: BackgroundTheme;
  setThemeId: (id: string) => void;
  customTheme: Partial<BackgroundTheme> | null;
  setCustomTheme: (custom: Partial<BackgroundTheme> | null) => void;
  isThemeModalOpen: boolean;
  setIsThemeModalOpen: (open: boolean) => void;
  openThemeStudio: () => void;
  allThemes: BackgroundTheme[];
  themeCategories: typeof THEME_CATEGORIES;

  // Navigation & Views
  currentView: string;
  setCurrentView: (view: string) => void;
  selectedProductId: string | null;
  openProductDetails: (productId: string) => void;
  selectedCategory: string | null;
  setSelectedCategory: (catId: string | null) => void;
  selectedSellerId: string | null;
  setSelectedSellerId: (sellerId: string | null) => void;

  // Search & Filter
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  recentSearches: string[];
  addRecentSearch: (query: string) => void;
  clearRecentSearches: () => void;
  selectedLocation: string;
  setSelectedLocation: (loc: string) => void;

  // Products & Sellers
  products: Product[];
  addProduct: (newProduct: Partial<Product>) => Product;
  sellers: Seller[];
  categories: Category[];
  addCategory: (categoryData: Omit<Category, 'id'> & { id?: string }) => Category;
  updateCategory: (id: string, updatedData: Partial<Category>) => void;
  deleteCategory: (id: string) => void;
  resetCategoriesToDefault: () => void;
  isCategoryModalOpen: boolean;
  setIsCategoryModalOpen: (open: boolean) => void;
  categoryModalInitialTab: 'general' | 'image' | 'style' | 'tags';
  setCategoryModalInitialTab: (tab: 'general' | 'image' | 'style' | 'tags') => void;
  selectedCategoryForEdit: Category | null;
  setSelectedCategoryForEdit: (cat: Category | null) => void;
  openAddCategoryModal: () => void;
  openEditCategoryModal: (cat: Category, tab?: 'general' | 'image' | 'style' | 'tags') => void;
  quickViewProduct: Product | null;
  setQuickViewProduct: (prod: Product | null) => void;

  // Cart
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  cartSubtotal: number;
  cartItemsCount: number;
  appliedCoupon: Coupon | null;
  applyCoupon: (code: string) => { success: boolean; message: string };
  removeCoupon: () => void;
  deliveryFee: number;
  discountAmount: number;
  cartGrandTotal: number;

  // Wishlist
  wishlist: string[];
  toggleWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;

  // Auth & User Profile
  user: User | null;
  userProfile: UserProfile | null;
  authLoading: boolean;
  signInWithGoogle: () => Promise<void>;
  loginWithEmail: (email: string, pass: string) => Promise<void>;
  registerWithEmail: (name: string, email: string, pass: string, phone: string, role?: 'customer' | 'seller') => Promise<void>;
  logOut: () => Promise<void>;
  switchUserRole: (role: 'customer' | 'seller' | 'admin') => void;
  updateUserProfile: (data: Partial<UserProfile>) => Promise<void>;

  // Orders
  orders: Order[];
  createOrder: (orderData: Omit<Order, 'id' | 'orderNumber' | 'createdAt' | 'trackingSteps' | 'estimatedDelivery'>) => Promise<Order>;
  activeOrderToTrack: Order | null;
  setActiveOrderToTrack: (order: Order | null) => void;
  updateOrderStatus: (orderId: string, status: Order['status']) => Promise<void>;
  cancelOrder: (orderId: string, reason?: string) => Promise<boolean>;
  assignOrderCourier: (orderId: string, courierId: string, customTrackingCode?: string) => Promise<void>;

  // UI Modals & Toasts
  isCartDrawerOpen: boolean;
  setIsCartDrawerOpen: (open: boolean) => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  isCourierModalOpen: boolean;
  setIsCourierModalOpen: (open: boolean) => void;
  isAddProductModalOpen: boolean;
  setIsAddProductModalOpen: (open: boolean) => void;
  isDownloadAppModalOpen: boolean;
  setIsDownloadAppModalOpen: (open: boolean) => void;
  downloadAppInitialTab: 'android' | 'ios' | 'microsoft' | 'apk' | 'huawei' | 'pwa';
  setDownloadAppInitialTab: (tab: 'android' | 'ios' | 'microsoft' | 'apk' | 'huawei' | 'pwa') => void;
  openDownloadAppModal: (tab?: 'android' | 'ios' | 'microsoft' | 'apk' | 'huawei' | 'pwa') => void;
  isEcommerceStudioOpen: boolean;
  setIsEcommerceStudioOpen: (open: boolean) => void;
  openEcommerceStudio: () => void;
  customerUIConfig: CustomerUIConfig;
  updateCustomerUIConfig: (newConfig: Partial<CustomerUIConfig>) => void;
  toasts: Toast[];
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;

  // Cash Memo & Official Invoice
  isCashMemoModalOpen: boolean;
  setIsCashMemoModalOpen: (open: boolean) => void;
  selectedCashMemoOrder: Order | null;
  cashMemoInitialCategory: string;
  cashMemoIsBuilder: boolean;
  openCashMemoModal: (order: Order) => void;
  openCategoryCashMemo: (categoryId?: string) => void;
  closeCashMemoModal: () => void;

  // Bulk SMS, Receipt Notifications & Baki Payment Ledger
  smsNotifications: SmsNotification[];
  bakiAccounts: BakiAccount[];
  smsGatewaySettings: SmsGatewaySettings;
  unreadSmsCount: number;
  totalCustomerBakiDue: number;
  isNotificationModalOpen: boolean;
  setIsNotificationModalOpen: (open: boolean) => void;
  notificationModalInitialTab: 'notifications' | 'baki-payment' | 'sms-settings';
  setNotificationModalInitialTab: (tab: 'notifications' | 'baki-payment' | 'sms-settings') => void;
  selectedBakiIdForPayment: string | null;
  setSelectedBakiIdForPayment: (bakiId: string | null) => void;
  openSmsNotificationModal: (tab?: 'notifications' | 'baki-payment' | 'sms-settings', preselectBakiId?: string) => void;
  sendBulkSmsNotifications: (payload: {
    recipients: Array<{
      name: string;
      nameBn?: string;
      phone: string;
      bakiId?: string;
      orderNumber?: string;
      totalBillAmount?: number;
      paidAmount?: number;
      bakiDueAmount?: number;
    }>;
    type: SmsNotificationType;
    title: string;
    titleBn: string;
    message: string;
    messageBn: string;
  }) => Promise<SmsNotification[]>;
  updateSmsGatewaySettings: (update: Partial<SmsGatewaySettings>) => Promise<void>;
  addOrUpdateBakiAccount: (data: Partial<BakiAccount>) => Promise<BakiAccount>;
  payBakiAmount: (bakiId: string, amount: number, paymentMethod: string, transactionRef?: string) => Promise<{ account: BakiAccount; receiptSms: SmsNotification } | null>;
  markSmsNotificationRead: (id: string) => void;
  markAllSmsNotificationsRead: () => void;

  // Network Connectivity
  isOnline: boolean;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Language & Theme
  const [language, setLanguage] = useState<Language>(() => {
    return (localStorage.getItem('deshibazar_lang') as Language) || 'bn';
  });
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('deshibazar_dark') === 'true';
  });

  // 100+ Background Themes State
  const [currentThemeId, setCurrentThemeId] = useState<string>(() => {
    return localStorage.getItem('deshibazar_theme_id') || 'deshi-emerald-gold';
  });
  const [customTheme, setCustomTheme] = useState<Partial<BackgroundTheme> | null>(() => {
    try {
      const saved = localStorage.getItem('deshibazar_custom_theme');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [isThemeModalOpen, setIsThemeModalOpen] = useState<boolean>(false);

  const openThemeStudio = () => setIsThemeModalOpen(true);

  // Compute active theme
  const activeBaseTheme = ALL_THEMES.find(t => t.id === currentThemeId) || ALL_THEMES[0];
  const currentTheme: BackgroundTheme = customTheme ? { ...activeBaseTheme, ...customTheme } : activeBaseTheme;

  const setThemeId = (id: string) => {
    setCurrentThemeId(id);
    setCustomTheme(null);
    try {
      localStorage.removeItem('deshibazar_custom_theme');
      localStorage.setItem('deshibazar_theme_id', id);
    } catch {}
    const target = ALL_THEMES.find(t => t.id === id);
    if (target) {
      if (target.mode === 'dark' && !darkMode) {
        setDarkMode(true);
      } else if (target.mode === 'light' && darkMode) {
        setDarkMode(false);
      }
      showToast(
        language === 'bn' 
          ? `থিম সক্রিয় করা হয়েছে: "${target.nameBn}"` 
          : `Theme applied: "${target.name}"`, 
        'info'
      );
    }
  };

  // Views & Filters
  const [currentView, setCurrentView] = useState<string>('home');
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedSellerId, setSelectedSellerId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedLocation, setSelectedLocation] = useState<string>('Dhaka');
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [activeOrderToTrack, setActiveOrderToTrack] = useState<Order | null>(null);

  // Modals & Drawers
  const [isCartDrawerOpen, setIsCartDrawerOpen] = useState<boolean>(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [isCourierModalOpen, setIsCourierModalOpen] = useState<boolean>(false);
  const [isDownloadAppModalOpen, setIsDownloadAppModalOpen] = useState<boolean>(false);
  const [downloadAppInitialTab, setDownloadAppInitialTab] = useState<'android' | 'ios' | 'microsoft' | 'apk' | 'huawei' | 'pwa'>('android');

  const openDownloadAppModal = (tab: 'android' | 'ios' | 'microsoft' | 'apk' | 'huawei' | 'pwa' = 'android') => {
    setDownloadAppInitialTab(tab);
    setIsDownloadAppModalOpen(true);
  };
  const [isEcommerceStudioOpen, setIsEcommerceStudioOpen] = useState<boolean>(false);
  const openEcommerceStudio = () => setIsEcommerceStudioOpen(true);

  // Cash Memo & Official Invoice Modal State
  const [isCashMemoModalOpen, setIsCashMemoModalOpen] = useState<boolean>(false);
  const [selectedCashMemoOrder, setSelectedCashMemoOrder] = useState<Order | null>(null);
  const [cashMemoInitialCategory, setCashMemoInitialCategory] = useState<string>('all');
  const [cashMemoIsBuilder, setCashMemoIsBuilder] = useState<boolean>(false);

  const openCashMemoModal = (order: Order) => {
    setSelectedCashMemoOrder(order);
    setCashMemoInitialCategory('all');
    setCashMemoIsBuilder(false);
    setIsCashMemoModalOpen(true);
  };

  const openCategoryCashMemo = (categoryId: string = 'all') => {
    const activeCatIds = new Set(categories.filter(c => c.status !== 'inactive').map(c => c.id));
    const matchedProducts = products.filter(p =>
      categoryId === 'all' ? activeCatIds.has(p.category) || Boolean(p.category) : p.category === categoryId
    );
    const itemsList: CartItem[] = matchedProducts.map(p => ({ product: p, quantity: 1 }));
    const subtotalVal = itemsList.reduce((acc, it) => acc + it.product.price * it.quantity, 0);
    const deliveryVal = itemsList.length > 0 ? 60 : 0;
    const nowIso = new Date().toISOString();
    const catCode = categoryId === 'all' ? 'ALLCAT' : categoryId.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);
    const serial = Math.floor(1000 + Math.random() * 9000);

    const syntheticOrder: Order = {
      id: `CAT-MEMO-${serial}`,
      orderNumber: `DB-${catCode}-${serial}`,
      userId: user?.uid || 'guest',
      customerName: userProfile?.displayName || user?.displayName || (language === 'bn' ? 'সম্মানিত গ্রাহক (ক্যাশ মেমো)' : 'Valued Customer'),
      customerPhone: userProfile?.phone || '01712-009988',
      customerEmail: userProfile?.email || user?.email || 'customer@deshibazar.bd',
      division: selectedLocation || 'Dhaka',
      district: selectedLocation || 'Dhaka',
      upazila: 'Dhanmondi',
      address: userProfile?.addresses?.[0]?.fullAddress || (language === 'bn' ? 'বাড়ি ১৪, রোড ১১, ঢাকা' : 'House 14, Road 11, Dhaka'),
      paymentMethod: 'cod',
      paymentStatus: 'pending',
      deliveryType: 'regular',
      deliveryFee: deliveryVal,
      subtotal: subtotalVal,
      discount: 0,
      total: subtotalVal + deliveryVal,
      status: 'confirmed',
      items: itemsList,
      createdAt: nowIso,
      estimatedDelivery: '24 - 48 Hours',
      trackingSteps: [],
      courierName: 'Steadfast BD Courier',
      courierTrackingCode: `ST-CAT-${serial}`
    };

    setSelectedCashMemoOrder(syntheticOrder);
    setCashMemoInitialCategory(categoryId);
    setCashMemoIsBuilder(true);
    setIsCashMemoModalOpen(true);
  };

  const closeCashMemoModal = () => {
    setIsCashMemoModalOpen(false);
    setSelectedCashMemoOrder(null);
    setCashMemoIsBuilder(false);
    setCashMemoInitialCategory('all');
  };

  // Bulk SMS, Receipt Notifications & Baki Amount Payment State
  const DEFAULT_SMS_SETTINGS: SmsGatewaySettings = {
    provider: 'bulksmsbd',
    senderId: 'DESHIBAZAR',
    apiKeyMasked: 'BD-SMS-LIVE-••••••••9421',
    enableAutoOrderReceiptSms: true,
    enableAutoBakiReminderSms: true,
    enableAutoBakiPaymentReceiptSms: true,
    customerReceiveReceiptSms: true,
    customerReceiveBakiAlertSms: true,
    customerReceiveBulkPromoSms: true,
    smsLanguage: 'bilingual'
  };

  const DEFAULT_BAKI_ACCOUNTS: BakiAccount[] = [
    {
      id: 'baki-1',
      customerName: 'Tanvir Hossain',
      customerNameBn: 'তানভীর হোসেন',
      customerPhone: '01819234567',
      customerEmail: 'tanvir@example.com',
      orderNumber: 'DB-260315-8921',
      description: 'Sundarban Honey & Premium Deshi Grocery Credit',
      descriptionBn: 'সুন্দরবনের মধু ও দেশি গ্রোসারি বাকি খাতা',
      totalBill: 2500,
      paidAmount: 1000,
      bakiAmount: 1500,
      dueDate: '2026-04-25',
      lastPaymentAt: new Date(Date.now() - 48 * 3600 * 1000).toISOString(),
      lastPaymentMethod: 'bkash',
      lastTransactionRef: 'BK984210',
      status: 'partial',
      updatedAt: new Date(Date.now() - 12 * 3600 * 1000).toISOString()
    },
    {
      id: 'baki-2',
      customerName: 'Nusrat Jahan',
      customerNameBn: 'নুসরাত জাহান',
      customerPhone: '01711987654',
      customerEmail: 'nusrat@example.com',
      orderNumber: 'DB-260318-4410',
      description: 'Tangail Tant Saree Wholesale Balance',
      descriptionBn: 'টাঙ্গাইল তাঁতের শাড়ি আংশিক বাকি',
      totalBill: 4800,
      paidAmount: 2000,
      bakiAmount: 2800,
      dueDate: '2026-04-28',
      status: 'partial',
      updatedAt: new Date(Date.now() - 24 * 3600 * 1000).toISOString()
    },
    {
      id: 'baki-3',
      customerName: 'Dr. Shahana Akhter',
      customerNameBn: 'ডা. শাহানা আখতার',
      customerPhone: '01912341234',
      customerEmail: 'shahana@example.com',
      orderNumber: 'DB-260319-7721',
      description: 'Organic Rajshahi Mango & Mustard Oil Box',
      descriptionBn: 'রাজশাহীর আম ও খাঁটি সরিষার তেল বাকি',
      totalBill: 1850,
      paidAmount: 0,
      bakiAmount: 1850,
      dueDate: '2026-04-30',
      status: 'due',
      updatedAt: new Date(Date.now() - 6 * 3600 * 1000).toISOString()
    }
  ];

  const DEFAULT_SMS_NOTIFICATIONS: SmsNotification[] = [
    {
      id: 'sms-seed-1',
      recipientPhone: '01819234567',
      recipientName: 'Tanvir Hossain',
      recipientNameBn: 'তানভীর হোসেন',
      senderName: 'DeshiBazar Admin',
      senderRole: 'admin',
      type: 'baki_due',
      title: 'Baki Payment & Cash Memo Receipt Reminder',
      titleBn: 'বাকি টাকা পরিশোধ ও ক্যাশ মেমো রসিদ নোটিফিকেশন',
      message: 'Dear Tanvir Hossain, your order DB-260315-8921 total bill is ৳2,500 (Paid: ৳1,000). Remaining Baki Due: ৳1,500. Pay via bKash/Nagad/Bangladeshi Bank.',
      messageBn: 'প্রিয় তানভীর হোসেন, আপনার অর্ডার DB-260315-8921 এর মোট বিল ৳২,৫০০ (জমা: ৳১,০০০)। অবশিষ্ট বাকি: ৳১,৫০০। সেটিংসের নিচে নোটিফিকেশন থেকে বাকি পরিশোধ করুন।',
      orderNumber: 'DB-260315-8921',
      bakiId: 'baki-1',
      totalBillAmount: 2500,
      paidAmount: 1000,
      bakiDueAmount: 1500,
      isRead: false,
      deliveryStatus: 'delivered',
      gatewayProvider: 'BulkSMSBD',
      createdAt: new Date(Date.now() - 2 * 3600 * 1000).toISOString()
    },
    {
      id: 'sms-seed-2',
      recipientPhone: '01711987654',
      recipientName: 'Nusrat Jahan',
      recipientNameBn: 'নুসরাত জাহান',
      senderName: 'DeshiBazar Admin',
      senderRole: 'admin',
      type: 'order_receipt',
      title: 'Official Order Receipt SMS — DB-260318-4410',
      titleBn: 'অফিসিয়াল অর্ডার ও রসিদ এসএমএস — DB-260318-4410',
      message: 'Thank you Nusrat Jahan! Receipt #DB-260318-4410 confirmed. Total: ৳4,800, Advance Paid: ৳2,000, Baki Due: ৳2,800.',
      messageBn: 'ধন্যবাদ নুসরাত জাহান! রসিদ #DB-260318-4410 নিশ্চিত হয়েছে। মোট: ৳৪,৮০০, অগ্রিম জমা: ৳২,০০০, বাকি: ৳২,৮০০।',
      orderNumber: 'DB-260318-4410',
      bakiId: 'baki-2',
      totalBillAmount: 4800,
      paidAmount: 2000,
      bakiDueAmount: 2800,
      isRead: false,
      deliveryStatus: 'delivered',
      gatewayProvider: 'BulkSMSBD',
      createdAt: new Date(Date.now() - 5 * 3600 * 1000).toISOString()
    }
  ];

  const [smsNotifications, setSmsNotifications] = useState<SmsNotification[]>(() => {
    try {
      const saved = localStorage.getItem('deshibazar_sms_notifications');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return DEFAULT_SMS_NOTIFICATIONS;
  });

  const [bakiAccounts, setBakiAccounts] = useState<BakiAccount[]>(() => {
    try {
      const saved = localStorage.getItem('deshibazar_baki_accounts');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return DEFAULT_BAKI_ACCOUNTS;
  });

  const [smsGatewaySettings, setSmsGatewaySettings] = useState<SmsGatewaySettings>(() => {
    try {
      const saved = localStorage.getItem('deshibazar_sms_settings');
      if (saved) return { ...DEFAULT_SMS_SETTINGS, ...JSON.parse(saved) };
    } catch {}
    return DEFAULT_SMS_SETTINGS;
  });

  const [isNotificationModalOpen, setIsNotificationModalOpen] = useState<boolean>(false);
  const [notificationModalInitialTab, setNotificationModalInitialTab] = useState<'notifications' | 'baki-payment' | 'sms-settings'>('notifications');
  const [selectedBakiIdForPayment, setSelectedBakiIdForPayment] = useState<string | null>(null);

  const openSmsNotificationModal = (
    tab: 'notifications' | 'baki-payment' | 'sms-settings' = 'notifications',
    preselectBakiId?: string
  ) => {
    setNotificationModalInitialTab(tab);
    if (preselectBakiId) {
      setSelectedBakiIdForPayment(preselectBakiId);
    }
    setIsNotificationModalOpen(true);
  };

  useEffect(() => {
    try {
      localStorage.setItem('deshibazar_sms_notifications', JSON.stringify(smsNotifications.slice(0, 100)));
    } catch {}
  }, [smsNotifications]);

  useEffect(() => {
    try {
      localStorage.setItem('deshibazar_baki_accounts', JSON.stringify(bakiAccounts));
    } catch {}
  }, [bakiAccounts]);

  useEffect(() => {
    try {
      localStorage.setItem('deshibazar_sms_settings', JSON.stringify(smsGatewaySettings));
    } catch {}
  }, [smsGatewaySettings]);

  // Initial sync with Express backend store if localStorage had defaults
  useEffect(() => {
    let cancelled = false;
    fetch('/api/sms/data')
      .then(r => (r.ok ? r.json() : null))
      .then(data => {
        if (cancelled || !data || !data.success) return;
        const hasLocalSms = !!localStorage.getItem('deshibazar_sms_notifications');
        const hasLocalBaki = !!localStorage.getItem('deshibazar_baki_accounts');
        if (!hasLocalSms && Array.isArray(data.notifications) && data.notifications.length > 0) {
          setSmsNotifications(data.notifications);
        }
        if (!hasLocalBaki && Array.isArray(data.bakiAccounts) && data.bakiAccounts.length > 0) {
          setBakiAccounts(data.bakiAccounts);
        }
        if (!localStorage.getItem('deshibazar_sms_settings') && data.settings) {
          setSmsGatewaySettings(prev => ({ ...prev, ...data.settings }));
        }
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, []);

  const unreadSmsCount = smsNotifications.filter(n => !n.isRead).length;
  const totalCustomerBakiDue = bakiAccounts.reduce((sum, b) => sum + (b.bakiAmount || 0), 0);

  const sendBulkSmsNotifications: AppContextType['sendBulkSmsNotifications'] = async (payload) => {
    try {
      const res = await fetch('/api/sms/send-bulk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (res.ok) {
        const json = await res.json();
        if (json.success && Array.isArray(json.notifications)) {
          setSmsNotifications(prev => [...json.notifications, ...prev].slice(0, 100));
          showToast(
            language === 'bn'
              ? `${json.notifications.length}টি গ্রাহকের কাছে বাল্ক/রসিদ এসএমএস পাঠানো হয়েছে!`
              : `Sent ${json.notifications.length} Bulk / Receipt SMS notification(s)!`,
            'success'
          );
          return json.notifications;
        }
      }
    } catch {}

    // Client fallback
    const created: SmsNotification[] = payload.recipients.map((rec, idx) => {
      const render = (tpl: string) =>
        tpl
          .replace(/\{name\}/g, rec.nameBn || rec.name)
          .replace(/\{baki\}/g, String(rec.bakiDueAmount ?? 0))
          .replace(/\{paid\}/g, String(rec.paidAmount ?? 0))
          .replace(/\{total\}/g, String(rec.totalBillAmount ?? 0))
          .replace(/\{orderNo\}/g, rec.orderNumber || 'DB-RECEIPT');
      return {
        id: `sms-${Date.now()}-${idx}`,
        recipientPhone: rec.phone,
        recipientName: rec.name,
        recipientNameBn: rec.nameBn,
        senderName: 'DeshiBazar Admin',
        senderRole: 'admin',
        type: payload.type,
        title: render(payload.title),
        titleBn: render(payload.titleBn),
        message: render(payload.message),
        messageBn: render(payload.messageBn),
        orderNumber: rec.orderNumber,
        bakiId: rec.bakiId,
        totalBillAmount: rec.totalBillAmount,
        paidAmount: rec.paidAmount,
        bakiDueAmount: rec.bakiDueAmount,
        isRead: false,
        deliveryStatus: 'delivered',
        gatewayProvider: smsGatewaySettings.provider.toUpperCase(),
        createdAt: new Date().toISOString()
      };
    });
    setSmsNotifications(prev => [...created, ...prev].slice(0, 100));
    showToast(
      language === 'bn'
        ? `${created.length}টি গ্রাহকের কাছে রসিদ ও বাকি এসএমএস পাঠানো হয়েছে!`
        : `Sent ${created.length} SMS notification(s)!`,
      'success'
    );
    return created;
  };

  const updateSmsGatewaySettings = async (update: Partial<SmsGatewaySettings>) => {
    setSmsGatewaySettings(prev => ({ ...prev, ...update }));
    try {
      await fetch('/api/sms/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(update)
      });
    } catch {}
    showToast(
      language === 'bn' ? 'এসএমএস ও নোটিফিকেশন সেটিংস সংরক্ষিত হয়েছে!' : 'SMS & Notification settings saved!',
      'success'
    );
  };

  const addOrUpdateBakiAccount = async (data: Partial<BakiAccount>): Promise<BakiAccount> => {
    try {
      const res = await fetch('/api/baki/add', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (res.ok) {
        const json = await res.json();
        if (json.success && json.account) {
          setBakiAccounts(prev => {
            const exists = prev.some(b => b.id === json.account.id);
            return exists ? prev.map(b => (b.id === json.account.id ? json.account : b)) : [json.account, ...prev];
          });
          showToast(
            language === 'bn' ? 'বাকি খাতার হিসাব আপডেট হয়েছে!' : 'Baki account ledger updated!',
            'success'
          );
          return json.account;
        }
      }
    } catch {}

    const totalBill = Number(data.totalBill) || 0;
    const paidAmount = Number(data.paidAmount) || 0;
    const bakiAmount = Math.max(0, totalBill - paidAmount);
    const status: BakiAccount['status'] = bakiAmount <= 0 ? 'paid' : paidAmount > 0 ? 'partial' : 'due';
    const created: BakiAccount = {
      id: data.id || `baki-${Date.now()}`,
      customerName: data.customerName || 'Customer',
      customerNameBn: data.customerNameBn || data.customerName || 'গ্রাহক',
      customerPhone: data.customerPhone || '01700000000',
      customerEmail: data.customerEmail,
      orderNumber: data.orderNumber || `DB-BAKI-${Math.floor(1000 + Math.random() * 9000)}`,
      description: data.description || 'Customer Baki Account',
      descriptionBn: data.descriptionBn || data.description || 'গ্রাহকের বাকি হিসাব',
      totalBill,
      paidAmount,
      bakiAmount,
      dueDate: data.dueDate || new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10),
      status,
      updatedAt: new Date().toISOString()
    };
    setBakiAccounts(prev => {
      const exists = prev.some(b => b.id === created.id);
      return exists ? prev.map(b => (b.id === created.id ? created : b)) : [created, ...prev];
    });
    showToast(
      language === 'bn' ? 'বাকি খাতার হিসাব সংরক্ষিত হয়েছে!' : 'Baki account saved!',
      'success'
    );
    return created;
  };

  const payBakiAmount = async (
    bakiId: string,
    amount: number,
    paymentMethod: string,
    transactionRef?: string
  ) => {
    const target = bakiAccounts.find(b => b.id === bakiId);
    if (!target) {
      showToast(language === 'bn' ? 'বাকি হিসাব পাওয়া যায়নি' : 'Baki account not found', 'error');
      return null;
    }

    try {
      const res = await fetch('/api/baki/pay', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ bakiId, amount, paymentMethod, transactionRef })
      });
      if (res.ok) {
        const json = await res.json();
        if (json.success && json.account && json.receiptSms) {
          setBakiAccounts(prev => prev.map(b => (b.id === bakiId ? json.account : b)));
          setSmsNotifications(prev => [json.receiptSms, ...prev].slice(0, 100));
          showToast(
            language === 'bn'
              ? `৳${amount} বাকি পরিশোধ সফল! রসিদ এসএমএস পাঠানো হয়েছে।`
              : `৳${amount} Baki payment successful! Receipt SMS delivered.`,
            'success'
          );
          return { account: json.account as BakiAccount, receiptSms: json.receiptSms as SmsNotification };
        }
      }
    } catch {}

    const payAmt = Math.min(target.bakiAmount, Math.max(1, Number(amount) || 0));
    const newPaid = target.paidAmount + payAmt;
    const newBaki = Math.max(0, target.totalBill - newPaid);
    const txnRef = transactionRef?.trim() || `BK-PAY-${Math.floor(100000 + Math.random() * 900000)}`;
    const now = new Date().toISOString();

    const updatedAccount: BakiAccount = {
      ...target,
      paidAmount: newPaid,
      bakiAmount: newBaki,
      status: newBaki <= 0 ? 'paid' : 'partial',
      lastPaymentAt: now,
      lastPaymentMethod: paymentMethod,
      lastTransactionRef: txnRef,
      updatedAt: now
    };

    const receiptSms: SmsNotification = {
      id: `sms-rec-${Date.now()}`,
      recipientPhone: updatedAccount.customerPhone,
      recipientName: updatedAccount.customerName,
      recipientNameBn: updatedAccount.customerNameBn,
      senderName: 'DeshiBazar Payment & Receipt Desk',
      senderRole: 'system',
      type: 'baki_payment_receipt',
      title: `Baki Payment Receipt (${paymentMethod.toUpperCase()}) — ৳${payAmt}`,
      titleBn: `বাকি টাকা পরিশোধের রসিদ (${paymentMethod.toUpperCase()}) — ৳${payAmt}`,
      message: `Payment Received! ৳${payAmt} paid via ${paymentMethod.toUpperCase()} (Ref: ${txnRef}) for ${updatedAccount.orderNumber || updatedAccount.id}. Remaining Baki Due: ৳${newBaki}.`,
      messageBn: `বাকি পরিশোধ সফল! ${updatedAccount.orderNumber || updatedAccount.id} বাবদ ৳${payAmt} (${paymentMethod.toUpperCase()}, Ref: ${txnRef}) জমা হয়েছে। অবশিষ্ট বাকি: ৳${newBaki}।`,
      orderNumber: updatedAccount.orderNumber,
      bakiId: updatedAccount.id,
      totalBillAmount: updatedAccount.totalBill,
      paidAmount: payAmt,
      bakiDueAmount: newBaki,
      paymentMethod,
      transactionRef: txnRef,
      isRead: false,
      deliveryStatus: 'delivered',
      gatewayProvider: smsGatewaySettings.provider.toUpperCase(),
      createdAt: now
    };

    setBakiAccounts(prev => prev.map(b => (b.id === bakiId ? updatedAccount : b)));
    setSmsNotifications(prev => [receiptSms, ...prev].slice(0, 100));
    showToast(
      language === 'bn'
        ? `৳${payAmt} বাকি পরিশোধ সফল! রসিদ এসএমএস যুক্ত হয়েছে।`
        : `৳${payAmt} Baki payment successful! Receipt SMS issued.`,
      'success'
    );
    return { account: updatedAccount, receiptSms };
  };

  const markSmsNotificationRead = (id: string) => {
    setSmsNotifications(prev => prev.map(n => (n.id === id ? { ...n, isRead: true } : n)));
  };

  const markAllSmsNotificationsRead = () => {
    setSmsNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
  };

  // Customer Web & Apps UI/UX Configuration State
  const [customerUIConfig, setCustomerUIConfig] = useState<CustomerUIConfig>(() => {
    try {
      const saved = localStorage.getItem('deshibazar_customer_ui_config');
      return saved ? { ...DEFAULT_CUSTOMER_UI_CONFIG, ...JSON.parse(saved) } : DEFAULT_CUSTOMER_UI_CONFIG;
    } catch {
      return DEFAULT_CUSTOMER_UI_CONFIG;
    }
  });

  // Listen to Firestore for remote admin UI/UX updates
  useEffect(() => {
    try {
      const unsub = onSnapshot(doc(db, 'settings', 'customer_ui'), (snapshot) => {
        if (snapshot.exists()) {
          const data = snapshot.data() as CustomerUIConfig;
          setCustomerUIConfig(prev => ({ ...prev, ...data }));
          try {
            localStorage.setItem('deshibazar_customer_ui_config', JSON.stringify(data));
          } catch {}
        }
      }, () => {
        // quiet fallback
      });
      return () => unsub();
    } catch {}
  }, []);

  const updateCustomerUIConfig = (newConfig: Partial<CustomerUIConfig>) => {
    setCustomerUIConfig(prev => {
      const updated: CustomerUIConfig = { ...prev, ...newConfig, lastUpdated: new Date().toISOString() };
      try {
        localStorage.setItem('deshibazar_customer_ui_config', JSON.stringify(updated));
      } catch {}
      return updated;
    });
  };

  const [toasts, setToasts] = useState<Toast[]>([]);

  // Live Internet Connectivity State
  const [isOnline, setIsOnline] = useState<boolean>(() => {
    return typeof navigator !== 'undefined' ? navigator.onLine : true;
  });

  // Helper to ensure strictly unique products by ID
  const deduplicateProducts = (items: Product[]): Product[] => {
    const seen = new Set<string>();
    const unique: Product[] = [];
    for (const item of items) {
      if (!item || !item.id) continue;
      if (!seen.has(item.id)) {
        seen.add(item.id);
        unique.push(item);
      }
    }
    return unique;
  };

  // Data & State
  const [products, setProducts] = useState<Product[]>(() => {
    let customItems: Product[] = [];
    try {
      const savedCustom = localStorage.getItem('deshibazar_custom_products');
      if (savedCustom) {
        const parsed = JSON.parse(savedCustom);
        if (Array.isArray(parsed)) {
          customItems = deduplicateProducts(parsed);
          // Auto-clean any pre-existing duplicates in localStorage
          localStorage.setItem('deshibazar_custom_products', JSON.stringify(customItems));
        }
      }
    } catch {}

    let wpItems: Product[] = [];
    try {
      const savedWp = localStorage.getItem('deshibazar_wp_products');
      if (savedWp) {
        const parsed = JSON.parse(savedWp);
        if (Array.isArray(parsed) && parsed.length > 0) {
          wpItems = deduplicateProducts(parsed);
        }
      }
    } catch {}

    return deduplicateProducts([...customItems, ...wpItems, ...PRODUCTS]);
  });
  // Dynamic Categories with LocalStorage persistence and full CRUD
  const [categories, setCategories] = useState<Category[]>(() => {
    try {
      const saved = localStorage.getItem('deshibazar_categories');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const existingIds = new Set(parsed.map((c: any) => c.id));
          const missingDefaults = CATEGORIES.filter(c => !existingIds.has(c.id));
          if (missingDefaults.length > 0) {
            const merged = [...parsed, ...missingDefaults];
            try {
              localStorage.setItem('deshibazar_categories', JSON.stringify(merged));
            } catch {}
            return merged;
          }
          return parsed;
        }
      }
    } catch (e) {
      console.error('Error loading saved categories:', e);
    }
    return CATEGORIES;
  });

  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [categoryModalInitialTab, setCategoryModalInitialTab] = useState<'general' | 'image' | 'style' | 'tags'>('general');
  const [selectedCategoryForEdit, setSelectedCategoryForEdit] = useState<Category | null>(null);

  const openAddCategoryModal = () => {
    setSelectedCategoryForEdit(null);
    setCategoryModalInitialTab('general');
    setIsCategoryModalOpen(true);
  };

  const openEditCategoryModal = (cat: Category, tab: 'general' | 'image' | 'style' | 'tags' = 'general') => {
    setSelectedCategoryForEdit(cat);
    setCategoryModalInitialTab(tab);
    setIsCategoryModalOpen(true);
  };

  const addCategory = (categoryData: Omit<Category, 'id'> & { id?: string }): Category => {
    const generatedId = categoryData.id || 
      categoryData.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') || 
      `category-${Date.now()}`;

    const newCategory: Category = {
      id: generatedId,
      name: categoryData.name.trim(),
      nameBn: categoryData.nameBn?.trim() || categoryData.name.trim(),
      iconName: categoryData.iconName || 'Package',
      itemCount: Number(categoryData.itemCount) || 0,
      image: categoryData.image || 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80',
      color: categoryData.color || 'from-emerald-500/20 to-teal-500/10',
      popularItems: Array.isArray(categoryData.popularItems) ? categoryData.popularItems : [],
      commissionRate: categoryData.commissionRate !== undefined ? Number(categoryData.commissionRate) : 8.5,
      status: categoryData.status || 'active',
      description: categoryData.description || '',
      descriptionBn: categoryData.descriptionBn || ''
    };

    setCategories(prev => {
      const existsIndex = prev.findIndex(c => c.id === generatedId);
      let updated: Category[];
      if (existsIndex >= 0) {
        updated = [...prev];
        updated[existsIndex] = newCategory;
      } else {
        updated = [...prev, newCategory];
      }
      try {
        localStorage.setItem('deshibazar_categories', JSON.stringify(updated));
      } catch {}
      return updated;
    });

    showToast(t(`ক্যাটাগরি "${newCategory.nameBn}" সফলভাবে তৈরি হয়েছে!`, `Category "${newCategory.name}" created successfully!`), 'success');
    return newCategory;
  };

  const updateCategory = (id: string, updatedData: Partial<Category>) => {
    setCategories(prev => {
      const updated = prev.map(cat => {
        if (cat.id === id) {
          return { ...cat, ...updatedData };
        }
        return cat;
      });
      try {
        localStorage.setItem('deshibazar_categories', JSON.stringify(updated));
      } catch {}
      return updated;
    });
    showToast(t('ক্যাটাগরি ও ছবি সফলভাবে আপডেট করা হয়েছে!', 'Category and image updated successfully!'), 'success');
  };

  const deleteCategory = (id: string) => {
    setCategories(prev => {
      const target = prev.find(c => c.id === id);
      const updated = prev.filter(cat => cat.id !== id);
      try {
        localStorage.setItem('deshibazar_categories', JSON.stringify(updated));
      } catch {}
      const targetName = target?.name || id;
      showToast(t(`ক্যাটাগরি "${targetName}" মুছে ফেলা হয়েছে!`, `Category "${targetName}" deleted successfully!`), 'info');
      return updated;
    });
  };

  const resetCategoriesToDefault = () => {
    setCategories(CATEGORIES);
    try {
      localStorage.removeItem('deshibazar_categories');
    } catch {}
    showToast(t('ক্যাটাগরি ডিফল্ট সেটিংসে ফিরিয়ে আনা হয়েছে!', 'Categories reset to default configuration!'), 'info');
  };

  const [isAddProductModalOpen, setIsAddProductModalOpen] = useState<boolean>(false);

  const addProduct = (newProdData: Partial<Product>): Product => {
    const id = newProdData.id || `prod-custom-${Date.now()}`;
    const categoryInfo = categories.find(c => c.id === newProdData.category) || CATEGORIES.find(c => c.id === newProdData.category) || categories[0] || CATEGORIES[0];
    
    const formattedProduct: Product = {
      id,
      name: newProdData.name || 'New Deshi Product',
      nameBn: newProdData.nameBn || newProdData.name || 'নতুন দেশি পণ্য',
      category: newProdData.category || 'deshi-products',
      categoryBn: newProdData.categoryBn || categoryInfo.nameBn,
      brand: newProdData.brand || 'DeshiBazar Verified',
      vendorId: newProdData.vendorId || 'seller-dhaka-crafts',
      vendorName: newProdData.vendorName || 'Deshi Artisan Hub',
      vendorLocation: newProdData.vendorLocation || 'Dhaka',
      price: Number(newProdData.price) || 100,
      originalPrice: newProdData.originalPrice ? Number(newProdData.originalPrice) : Math.round((Number(newProdData.price) || 100) * 1.2),
      discountPercent: newProdData.discountPercent || (newProdData.originalPrice ? Math.round(((Number(newProdData.originalPrice) - Number(newProdData.price)) / Number(newProdData.originalPrice)) * 100) : 15),
      unit: newProdData.unit || '1 Unit',
      unitBn: newProdData.unitBn || '১ টি',
      rating: 4.9,
      reviewCount: 1,
      stock: Number(newProdData.stock) || 50,
      image: newProdData.image || categoryInfo.image,
      gallery: newProdData.gallery && newProdData.gallery.length > 0 ? newProdData.gallery : [newProdData.image || categoryInfo.image],
      description: newProdData.description || 'Authentic quality product verified by DeshiBazar marketplace.',
      descriptionBn: newProdData.descriptionBn || 'দেশিবাজার ভেরিফাইড খাঁটি মানসম্মত পণ্য।',
      specifications: newProdData.specifications || {
        'Quality': '100% Premium Grade',
        'Packaging': 'Eco-Friendly Safe Pack'
      },
      origin: newProdData.origin || 'Bangladesh',
      isDeshi: newProdData.isDeshi ?? true,
      isOrganic: newProdData.isOrganic ?? false,
      isBestSeller: newProdData.isBestSeller ?? false,
      isFlashSale: newProdData.isFlashSale ?? false,
      isDailyDeal: newProdData.isDailyDeal ?? false
    };

    setProducts(prev => {
      // Remove any duplicate if present before prepending
      const filteredPrev = prev.filter(p => p.id !== formattedProduct.id);
      const updated = [formattedProduct, ...filteredPrev];
      try {
        const savedCustom = localStorage.getItem('deshibazar_custom_products');
        const existing: Product[] = savedCustom ? JSON.parse(savedCustom) : [];
        const filteredExisting = existing.filter(p => p.id !== formattedProduct.id);
        const cleanedCustom = [formattedProduct, ...filteredExisting];
        localStorage.setItem('deshibazar_custom_products', JSON.stringify(cleanedCustom));
      } catch {}
      return updated;
    });

    showToast(t(`পণ্য "${formattedProduct.nameBn}" সফলভাবে ক্যাটালগে যুক্ত হয়েছে!`, `Product "${formattedProduct.name}" added to catalog!`), 'success');
    return formattedProduct;
  };
  const [sellers] = useState<Seller[]>(SELLERS);
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('deshibazar_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [wishlist, setWishlist] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('deshibazar_wishlist');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('deshibazar_recent_searches');
      return saved ? JSON.parse(saved) : ['Padma Hilsha', 'Miniket Rice', 'Sundarbans Honey', 'Jamdani'];
    } catch {
      return ['Padma Hilsha', 'Miniket Rice', 'Sundarbans Honey'];
    }
  });
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('deshibazar_orders');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Auth State
  const [user, setUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(() => {
    try {
      const saved = localStorage.getItem('deshibazar_user_profile');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [authLoading, setAuthLoading] = useState<boolean>(true);

  // Sync UserProfile to localStorage
  useEffect(() => {
    if (userProfile) {
      try {
        localStorage.setItem('deshibazar_user_profile', JSON.stringify(userProfile));
      } catch {}
    }
  }, [userProfile]);

  // Sync Language
  useEffect(() => {
    localStorage.setItem('deshibazar_lang', language);
    document.documentElement.lang = language;
  }, [language]);

  // Sync Dark Mode
  useEffect(() => {
    localStorage.setItem('deshibazar_dark', String(darkMode));
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Sync 100+ Background Themes & Colors
  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty('--theme-bg', currentTheme.bgGradient || currentTheme.bgColor);
    root.style.setProperty('--theme-bg-color', currentTheme.bgColor);
    root.style.setProperty('--theme-surface', currentTheme.surfaceColor);
    root.style.setProperty('--theme-border', currentTheme.surfaceBorder);
    root.style.setProperty('--theme-header', currentTheme.headerBg);
    root.style.setProperty('--theme-header-text', currentTheme.headerText);
    root.style.setProperty('--theme-text', currentTheme.textColor);
    root.style.setProperty('--theme-muted', currentTheme.mutedText);
    root.style.setProperty('--theme-accent', currentTheme.accentColor);
    root.style.setProperty('--theme-accent-hover', currentTheme.accentHover);
    root.style.setProperty('--theme-accent-text', currentTheme.accentText);

    // Dynamic style element for smooth background applying to app wrapper
    let styleEl = document.getElementById('deshibazar-theme-dynamic-styles') as HTMLStyleElement | null;
    if (!styleEl) {
      styleEl = document.createElement('style');
      styleEl.id = 'deshibazar-theme-dynamic-styles';
      document.head.appendChild(styleEl);
    }

    styleEl.innerHTML = `
      :root {
        --current-theme-id: "${currentTheme.id}";
      }
      body {
        background: ${currentTheme.bgGradient || currentTheme.bgColor} !important;
        background-attachment: fixed !important;
        color: ${currentTheme.textColor};
        transition: background 0.3s ease, color 0.3s ease;
      }
      .app-themed-bg {
        background: ${currentTheme.bgGradient || currentTheme.bgColor} !important;
        background-attachment: fixed !important;
      }
      .app-themed-surface {
        background-color: ${currentTheme.surfaceColor} !important;
        border-color: ${currentTheme.surfaceBorder} !important;
      }
      .app-themed-accent-btn {
        background-color: ${currentTheme.accentColor} !important;
        color: ${currentTheme.accentText} !important;
      }
      .app-themed-accent-btn:hover {
        background-color: ${currentTheme.accentHover} !important;
      }
      .app-themed-accent-text {
        color: ${currentTheme.accentColor} !important;
      }
      .app-themed-border {
        border-color: ${currentTheme.surfaceBorder} !important;
      }
    `;

    if (currentTheme.mode === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [currentTheme]);

  // Sync Cart
  useEffect(() => {
    localStorage.setItem('deshibazar_cart', JSON.stringify(cart));
  }, [cart]);

  // Sync Wishlist
  useEffect(() => {
    localStorage.setItem('deshibazar_wishlist', JSON.stringify(wishlist));
  }, [wishlist]);

  // Sync Recent Searches
  useEffect(() => {
    localStorage.setItem('deshibazar_recent_searches', JSON.stringify(recentSearches));
  }, [recentSearches]);

  // Sync Orders
  useEffect(() => {
    localStorage.setItem('deshibazar_orders', JSON.stringify(orders));
  }, [orders]);

  // Helper text translator
  const t = (bn: string, en: string) => (language === 'bn' ? bn : en);

  const toggleDarkMode = () => setDarkMode(prev => !prev);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts(prev => [...prev, { id, type, message }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(item => item.id !== id));
    }, 4000);
  };

  // Live Internet Online / Offline Monitor
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      showToast(t('ইন্টারনেট সংযোগ সক্রিয় হয়েছে (অনলাইন)', 'Live Internet connection active (Online)'), 'success');
    };
    const handleOffline = () => {
      setIsOnline(false);
      showToast(t('ইন্টারনেট সংযোগ বিচ্ছিন্ন (অফলাইন)', 'Internet connection lost (Offline)'), 'error');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [language]);

  // Auth Listener with Firestore integration
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        try {
          const userDocRef = doc(db, 'users', currentUser.uid);
          const snap = await getDoc(userDocRef);
          if (snap.exists()) {
            setUserProfile(snap.data() as UserProfile);
          } else {
            // Create user doc
            const newProfile: UserProfile = {
              uid: currentUser.uid,
              displayName: currentUser.displayName || 'Deshi Shopper',
              email: currentUser.email || '',
              phone: currentUser.phoneNumber || '+8801700000000',
              role: currentUser.email?.includes('admin') ? 'admin' : 'customer',
              avatarUrl: currentUser.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80',
              addresses: [
                {
                  id: 'addr-default',
                  title: 'Home (বাসা)',
                  division: 'Dhaka',
                  district: 'Dhaka',
                  upazila: 'Gulshan',
                  fullAddress: 'House 14, Road 11, Block D, Banani, Dhaka-1213',
                  phone: '+8801711223344',
                  isDefault: true
                }
              ]
            };
            await setDoc(userDocRef, newProfile);
            setUserProfile(newProfile);
          }
        } catch (err) {
          console.warn('Firestore user fetch fallback:', err);
          setUserProfile({
            uid: currentUser.uid,
            displayName: currentUser.displayName || 'Deshi Shopper',
            email: currentUser.email || '',
            role: 'customer',
            addresses: []
          });
        }
      } else {
        setUserProfile(null);
      }
      setAuthLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Fetch Firestore products & orders in real-time if available
  useEffect(() => {
    try {
      const ordersCol = collection(db, 'orders');
      const unsubscribe = onSnapshot(ordersCol, (snapshot) => {
        if (!snapshot.empty) {
          const remoteOrders: Order[] = [];
          snapshot.forEach(docSnap => {
            remoteOrders.push({ id: docSnap.id, ...docSnap.data() } as Order);
          });
          // Merge with local orders, sorting by date
          setOrders(prev => {
            const map = new Map<string, Order>();
            prev.forEach(o => map.set(o.id, o));
            remoteOrders.forEach(o => map.set(o.id, o));
            return Array.from(map.values()).sort(
              (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
            );
          });
        }
      }, (err) => {
        console.warn('Real-time order sync warning:', err);
      });
      return () => unsubscribe();
    } catch {
      // Fallback to local state
    }
  }, []);

  // Auth Handlers
  const signInWithGoogle = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
      showToast(t('গুগল দিয়ে সফলভাবে লগইন হয়েছে!', 'Successfully signed in with Google!'), 'success');
      setIsAuthModalOpen(false);
    } catch (error: any) {
      console.error(error);
      showToast(t('লগইন ব্যর্থ হয়েছে। আবার চেষ্টা করুন।', 'Google sign in failed. Please try again.'), 'error');
    }
  };

  const loginWithEmail = async (email: string, pass: string) => {
    try {
      await signInWithEmailAndPassword(auth, email, pass);
      showToast(t('সফলভাবে লগইন হয়েছে!', 'Successfully logged in!'), 'success');
      setIsAuthModalOpen(false);
    } catch (error: any) {
      console.error(error);
      showToast(t('ইমেইল বা পাসওয়ার্ড ভুল হয়েছে।', 'Invalid email or password.'), 'error');
      throw error;
    }
  };

  const registerWithEmail = async (
    name: string, 
    email: string, 
    pass: string, 
    phone: string, 
    role: 'customer' | 'seller' = 'customer'
  ) => {
    try {
      const cred = await createUserWithEmailAndPassword(auth, email, pass);
      const newProfile: UserProfile = {
        uid: cred.user.uid,
        displayName: name,
        email,
        phone,
        role,
        addresses: [
          {
            id: 'addr-1',
            title: 'Primary Address',
            division: 'Dhaka',
            district: 'Dhaka',
            upazila: 'Dhanmondi',
            fullAddress: 'Road 8A, Dhanmondi, Dhaka',
            phone,
            isDefault: true
          }
        ]
      };
      try {
        await setDoc(doc(db, 'users', cred.user.uid), newProfile);
      } catch (e) {
        console.warn(e);
      }
      setUserProfile(newProfile);
      showToast(t('অ্যাকাউন্ট সফলভাবে তৈরি হয়েছে!', 'Account successfully created!'), 'success');
      setIsAuthModalOpen(false);
    } catch (error: any) {
      console.error(error);
      showToast(t('নিবন্ধন ব্যর্থ হয়েছে: ' + (error.message || ''), 'Registration failed.'), 'error');
      throw error;
    }
  };

  const logOut = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.warn('Sign out warning:', error);
    } finally {
      setUser(null);
      setUserProfile(null);
      try {
        localStorage.removeItem('deshibazar_user_profile');
      } catch {}
      showToast(t('লগআউট সফল হয়েছে।', 'Successfully signed out.'), 'info');
      setCurrentView('home');
    }
  };

  const switchUserRole = (role: 'customer' | 'seller' | 'admin') => {
    if (userProfile) {
      setUserProfile({ ...userProfile, role });
      showToast(t(`রোল পরিবর্তিত হয়েছে: ${role}`, `Role switched to: ${role}`), 'info');
    } else {
      // Demo guest switched
      setUserProfile({
        uid: 'demo-user',
        displayName: role === 'admin' ? 'Admin Officer' : role === 'seller' ? 'Kawran Seller' : 'Demo Customer',
        email: `${role}@deshibazar.bd`,
        role,
        addresses: []
      });
      showToast(t(`ডেমো রোল সক্রিয়: ${role}`, `Demo role active: ${role}`), 'info');
    }
  };

  const updateUserProfile = async (data: Partial<UserProfile>) => {
    if (!userProfile) return;
    const updated = { ...userProfile, ...data };
    setUserProfile(updated);
    if (user) {
      try {
        await setDoc(doc(db, 'users', user.uid), updated, { merge: true });
      } catch (err) {
        console.warn(err);
      }
    }
    showToast(t('প্রোফাইল আপডেট হয়েছে', 'Profile updated successfully'), 'success');
  };

  // Cart Handlers
  const addToCart = (product: Product, quantity = 1) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item => 
          item.product.id === product.id 
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity }];
    });
    showToast(t(`${product.nameBn} ব্যাগে যোগ করা হয়েছে!`, `Added ${product.name} to cart!`), 'success');
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
    showToast(t('পণ্যটি ব্যাগ থেকে বাদ দেওয়া হয়েছে', 'Removed from cart'), 'info');
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart(prev => 
      prev.map(item => 
        item.product.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const clearCart = () => {
    setCart([]);
    setAppliedCoupon(null);
  };

  const cartSubtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const cartItemsCount = cart.reduce((count, item) => count + item.quantity, 0);

  // Delivery calculation: Dhaka is ৳60, Outside is ৳120; FREE delivery over ৳1500
  const isDhaka = selectedLocation.toLowerCase().includes('dhaka');
  const baseDelivery = isDhaka ? 60 : 120;
  const deliveryFee = cartSubtotal >= 1500 || cartSubtotal === 0 ? 0 : baseDelivery;

  // Coupon application
  const applyCoupon = (code: string) => {
    const trimmed = code.trim().toUpperCase();
    const found = COUPONS.find(c => c.code === trimmed);
    if (!found) {
      return { success: false, message: t('অবৈধ কুপন কোড', 'Invalid coupon code') };
    }
    if (cartSubtotal < found.minOrder) {
      return { 
        success: false, 
        message: t(
          `এই কুপনের জন্য ন্যূনতম ৳${found.minOrder} টাকার অর্ডার প্রয়োজন`, 
          `Minimum order of ৳${found.minOrder} required for this coupon`
        ) 
      };
    }
    setAppliedCoupon(found);
    return { success: true, message: t('কুপন সফলভাবে যুক্ত হয়েছে!', 'Coupon applied successfully!') };
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
    showToast(t('কুপন বাতিল করা হয়েছে', 'Coupon removed'), 'info');
  };

  const discountAmount = appliedCoupon 
    ? Math.min((cartSubtotal * appliedCoupon.discountPercent) / 100, appliedCoupon.maxDiscount)
    : 0;

  const cartGrandTotal = Math.max(0, cartSubtotal + deliveryFee - discountAmount);

  // Wishlist Handlers
  const toggleWishlist = (productId: string) => {
    setWishlist(prev => {
      const exists = prev.includes(productId);
      if (exists) {
        showToast(t('উইশলিস্ট থেকে সরানো হয়েছে', 'Removed from wishlist'), 'info');
        return prev.filter(id => id !== productId);
      } else {
        showToast(t('উইশলিস্টে যুক্ত করা হয়েছে!', 'Added to wishlist!'), 'success');
        return [...prev, productId];
      }
    });
  };

  const isInWishlist = (productId: string) => wishlist.includes(productId);

  // Navigation
  const openProductDetails = (productId: string) => {
    setSelectedProductId(productId);
    setCurrentView('product-details');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Recent Searches
  const addRecentSearch = (term: string) => {
    if (!term.trim()) return;
    setRecentSearches(prev => {
      const filtered = prev.filter(item => item.toLowerCase() !== term.toLowerCase());
      return [term, ...filtered].slice(0, 8);
    });
  };

  const clearRecentSearches = () => {
    setRecentSearches([]);
  };

  // Order Placement
  const createOrder = async (orderData: Omit<Order, 'id' | 'orderNumber' | 'createdAt' | 'trackingSteps' | 'estimatedDelivery'>): Promise<Order> => {
    const orderNumber = 'DB-' + Math.floor(100000 + Math.random() * 900000);
    const now = new Date();
    
    // Estimate delivery: Tomorrow if Dhaka, 2-3 days outside
    const isDhakaOrder = orderData.division.toLowerCase().includes('dhaka');
    const deliveryDate = new Date();
    deliveryDate.setDate(deliveryDate.getDate() + (isDhakaOrder ? 1 : 3));
    const estimatedDelivery = deliveryDate.toLocaleDateString('en-GB', { 
      day: 'numeric', 
      month: 'short', 
      year: 'numeric' 
    });

    const selectedCourierId = orderData.courierId || 'steadfast';
    const courierObj = BANGLADESH_COURIERS.find((c: any) => c.id === selectedCourierId) || BANGLADESH_COURIERS[0];
    const prefix = selectedCourierId === 'pathao' ? 'PT' :
                   selectedCourierId === 'redx' ? 'REDX' :
                   selectedCourierId === 'paperfly' ? 'PF' :
                   selectedCourierId === 'sundarban' ? 'SC' :
                   selectedCourierId === 'ecourier' ? 'ECR' :
                   selectedCourierId === 'sa_paribahan' ? 'SAP' :
                   selectedCourierId === 'karatoa' ? 'KC' : 'ST';
    const generatedTracking = orderData.courierTrackingCode || `${prefix}-${Math.floor(1000000 + Math.random() * 9000000)}`;

    const newOrder: Order = {
      ...orderData,
      courierId: selectedCourierId,
      courierName: orderData.courierName || courierObj.name,
      courierTrackingCode: generatedTracking,
      courierStatus: 'Booking Confirmed (কুরিয়ার পিকআপের জন্য প্রস্তুত)',
      courierPhone: courierObj.hotline,
      id: 'ord-' + Date.now(),
      orderNumber,
      createdAt: now.toISOString(),
      estimatedDelivery,
      status: 'placed',
      trackingSteps: [
        {
          status: 'placed',
          label: 'Order Placed',
          labelBn: 'অর্ডার গৃহীত হয়েছে',
          timestamp: now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          completed: true
        },
        {
          status: 'confirmed',
          label: 'Confirmed',
          labelBn: 'অর্ডার নিশ্চিত হয়েছে',
          completed: false
        },
        {
          status: 'processing',
          label: 'Processing',
          labelBn: 'প্রস্তুত করা হচ্ছে',
          completed: false
        },
        {
          status: 'packed',
          label: 'Packed',
          labelBn: 'প্যাকেট সম্পন্ন',
          completed: false
        },
        {
          status: 'shipped',
          label: 'Shipped to Courier',
          labelBn: 'কুরিয়ারে পাঠানো হয়েছে',
          completed: false
        },
        {
          status: 'out_for_delivery',
          label: 'Out for Delivery',
          labelBn: 'ডেলিভারির জন্য বের হয়েছে',
          completed: false
        },
        {
          status: 'delivered',
          label: 'Delivered',
          labelBn: 'ডেলিভারি সম্পন্ন',
          completed: false
        }
      ]
    };

    // Save to Firestore
    try {
      const docRef = await addDoc(collection(db, 'orders'), newOrder);
      newOrder.id = docRef.id;
    } catch (err) {
      console.warn('Saved order locally as Firestore was unreachable:', err);
    }

    setOrders(prev => [newOrder, ...prev]);
    clearCart();
    setActiveOrderToTrack(newOrder);

    if (smsGatewaySettings.enableAutoOrderReceiptSms) {
      const receiptSms: SmsNotification = {
        id: `sms-ord-${Date.now()}`,
        recipientPhone: newOrder.customerPhone,
        recipientName: newOrder.customerName,
        senderName: 'DeshiBazar Order & Receipt Desk',
        senderRole: 'system',
        type: 'order_receipt',
        title: `Order Receipt SMS — ${newOrder.orderNumber}`,
        titleBn: `অর্ডার ও ক্যাশ মেমো রসিদ এসএমএস — ${newOrder.orderNumber}`,
        message: `Dear ${newOrder.customerName}, your order ${newOrder.orderNumber} (Total: ৳${newOrder.total}) is confirmed via ${newOrder.paymentMethod.toUpperCase()}.`,
        messageBn: `প্রিয় ${newOrder.customerName}, আপনার অর্ডার ${newOrder.orderNumber} (মোট বিল: ৳${newOrder.total}) সফলভাবে গৃহীত হয়েছে।`,
        orderNumber: newOrder.orderNumber,
        totalBillAmount: newOrder.total,
        paidAmount: newOrder.paymentStatus === 'completed' || newOrder.paymentStatus === 'paid_online' ? newOrder.total : 0,
        bakiDueAmount: newOrder.paymentMethod === 'cod' ? newOrder.total : 0,
        paymentMethod: newOrder.paymentMethod,
        transactionRef: newOrder.transactionId,
        isRead: false,
        deliveryStatus: 'delivered',
        gatewayProvider: smsGatewaySettings.provider.toUpperCase(),
        createdAt: new Date().toISOString()
      };
      setSmsNotifications(prev => [receiptSms, ...prev].slice(0, 100));
    }

    return newOrder;
  };

  const updateOrderStatus = async (orderId: string, status: Order['status']) => {
    const statusOrder: Order['status'][] = [
      'placed', 
      'confirmed', 
      'processing', 
      'packed', 
      'shipped', 
      'out_for_delivery', 
      'delivered'
    ];
    const targetIdx = statusOrder.indexOf(status);

    setOrders(prev => prev.map(ord => {
      if (ord.id === orderId || ord.orderNumber === orderId) {
        const updatedSteps = ord.trackingSteps.map((step) => {
          const stepIdx = statusOrder.indexOf(step.status);
          const isDone = stepIdx <= targetIdx;
          return {
            ...step,
            completed: isDone,
            timestamp: isDone && !step.timestamp ? new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : step.timestamp
          };
        });
        return { ...ord, status, trackingSteps: updatedSteps };
      }
      return ord;
    }));

    // Update in Firestore
    try {
      const orderRef = doc(db, 'orders', orderId);
      await setDoc(orderRef, { status }, { merge: true });
    } catch (err) {
      console.warn('Firestore update warning:', err);
    }

    showToast(t(`অর্ডার স্ট্যাটাস আপডেট: ${status}`, `Order status updated to: ${status}`), 'info');
  };

  const assignOrderCourier = async (orderId: string, courierId: string, customTrackingCode?: string) => {
    const courierObj = BANGLADESH_COURIERS.find((c: any) => c.id === courierId) || BANGLADESH_COURIERS[0];
    const prefix = courierId === 'pathao' ? 'PT' :
                   courierId === 'redx' ? 'REDX' :
                   courierId === 'paperfly' ? 'PF' :
                   courierId === 'sundarban' ? 'SC' :
                   courierId === 'ecourier' ? 'ECR' :
                   courierId === 'sa_paribahan' ? 'SAP' :
                   courierId === 'karatoa' ? 'KC' : 'ST';
    
    const trackingCode = customTrackingCode || `${prefix}-${Math.floor(1000000 + Math.random() * 9000000)}`;

    setOrders(prev => prev.map(ord => {
      if (ord.id === orderId || ord.orderNumber === orderId) {
        return {
          ...ord,
          courierId,
          courierName: courierObj.name,
          courierTrackingCode: trackingCode,
          courierStatus: 'Dispatched to Courier Central Hub (কুরিয়ার হাবে প্রেরিত)',
          courierPhone: courierObj.hotline,
          status: 'shipped'
        };
      }
      return ord;
    }));

    showToast(
      t(`অর্ডার সফলভাবে ${courierObj.nameBn}-এ বুক করা হয়েছে! ট্র্যাকিং নম্বর: ${trackingCode}`, 
        `Order successfully booked with ${courierObj.name}! Tracking ID: ${trackingCode}`), 
      'success'
    );
  };

  const cancelOrder = async (orderId: string, reason = 'Customer requested cancellation'): Promise<boolean> => {
    const targetOrder = orders.find(o => o.id === orderId || o.orderNumber === orderId);
    if (!targetOrder) {
      showToast(t('অর্ডার খুঁজে পাওয়া যায়নি', 'Order not found'), 'error');
      return false;
    }

    if (targetOrder.status === 'cancelled') {
      showToast(t('অর্ডারটি আগেই বাতিল করা হয়েছে', 'Order is already cancelled'), 'info');
      return false;
    }

    if (targetOrder.status === 'delivered') {
      showToast(t('ডেলিভারি সম্পন্ন হওয়া অর্ডার বাতিল করা সম্ভব নয়। রিটার্ন রিকোয়েস্ট করুন।', 'Delivered orders cannot be cancelled. Please request a return.'), 'error');
      return false;
    }

    if (targetOrder.status === 'shipped' || targetOrder.status === 'out_for_delivery') {
      showToast(t('পণ্য কুরিয়ারে পাঠানো হয়েছে, তাই সরাসরি বাতিল করা সম্ভব নয়। ডেলিভারির সময় প্রত্যাখ্যান করতে পারবেন।', 'Order is already in transit. Please refuse the package upon delivery.'), 'error');
      return false;
    }

    const nowStr = new Date().toISOString();
    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    setOrders(prev => prev.map(ord => {
      if (ord.id === orderId || ord.orderNumber === orderId) {
        const updatedSteps = ord.trackingSteps.map(step => {
          if (step.status === 'placed') return { ...step, completed: true };
          return { ...step, completed: false };
        });
        const finalSteps = [
          ...updatedSteps.filter(s => s.status !== 'cancelled'),
          {
            status: 'cancelled' as const,
            label: 'Order Cancelled',
            labelBn: 'অর্ডার বাতিল করা হয়েছে',
            timestamp: timeStr,
            completed: true
          }
        ];
        return {
          ...ord,
          status: 'cancelled' as const,
          cancelledAt: nowStr,
          cancellationReason: reason,
          trackingSteps: finalSteps
        };
      }
      return ord;
    }));

    if (activeOrderToTrack && (activeOrderToTrack.id === orderId || activeOrderToTrack.orderNumber === orderId)) {
      setActiveOrderToTrack({
        ...activeOrderToTrack,
        status: 'cancelled',
        cancelledAt: nowStr,
        cancellationReason: reason
      });
    }

    // Update in Firestore
    try {
      const orderRef = doc(db, 'orders', orderId);
      await setDoc(orderRef, {
        status: 'cancelled',
        cancelledAt: nowStr,
        cancellationReason: reason
      }, { merge: true });
    } catch (err) {
      console.warn('Firestore cancel order warning:', err);
    }

    showToast(t('অর্ডারটি সফলভাবে বাতিল করা হয়েছে।', 'Your order has been successfully cancelled.'), 'info');
    return true;
  };

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        t,
        darkMode,
        toggleDarkMode,
        currentThemeId,
        currentTheme,
        setThemeId,
        customTheme,
        setCustomTheme,
        isThemeModalOpen,
        setIsThemeModalOpen,
        openThemeStudio,
        allThemes: ALL_THEMES,
        themeCategories: THEME_CATEGORIES,
        currentView,
        setCurrentView,
        selectedProductId,
        openProductDetails,
        selectedCategory,
        setSelectedCategory,
        selectedSellerId,
        setSelectedSellerId,
        searchQuery,
        setSearchQuery,
        recentSearches,
        addRecentSearch,
        clearRecentSearches,
        selectedLocation,
        setSelectedLocation,
        products,
        addProduct,
        sellers,
        categories,
        addCategory,
        updateCategory,
        deleteCategory,
        resetCategoriesToDefault,
        isCategoryModalOpen,
        setIsCategoryModalOpen,
        categoryModalInitialTab,
        setCategoryModalInitialTab,
        selectedCategoryForEdit,
        setSelectedCategoryForEdit,
        openAddCategoryModal,
        openEditCategoryModal,
        quickViewProduct,
        setQuickViewProduct,
        cart,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        cartSubtotal,
        cartItemsCount,
        appliedCoupon,
        applyCoupon,
        removeCoupon,
        deliveryFee,
        discountAmount,
        cartGrandTotal,
        wishlist,
        toggleWishlist,
        isInWishlist,
        user,
        userProfile,
        authLoading,
        signInWithGoogle,
        loginWithEmail,
        registerWithEmail,
        logOut,
        switchUserRole,
        updateUserProfile,
        orders,
        createOrder,
        activeOrderToTrack,
        setActiveOrderToTrack,
        updateOrderStatus,
        cancelOrder,
        assignOrderCourier,
        isCartDrawerOpen,
        setIsCartDrawerOpen,
        isAuthModalOpen,
        setIsAuthModalOpen,
        isCourierModalOpen,
        setIsCourierModalOpen,
        isAddProductModalOpen,
        setIsAddProductModalOpen,
        isDownloadAppModalOpen,
        setIsDownloadAppModalOpen,
        downloadAppInitialTab,
        setDownloadAppInitialTab,
        openDownloadAppModal,
        isEcommerceStudioOpen,
        setIsEcommerceStudioOpen,
        openEcommerceStudio,
        isCashMemoModalOpen,
        setIsCashMemoModalOpen,
        selectedCashMemoOrder,
        cashMemoInitialCategory,
        cashMemoIsBuilder,
        openCashMemoModal,
        openCategoryCashMemo,
        closeCashMemoModal,
        smsNotifications,
        bakiAccounts,
        smsGatewaySettings,
        unreadSmsCount,
        totalCustomerBakiDue,
        isNotificationModalOpen,
        setIsNotificationModalOpen,
        notificationModalInitialTab,
        setNotificationModalInitialTab,
        selectedBakiIdForPayment,
        setSelectedBakiIdForPayment,
        openSmsNotificationModal,
        sendBulkSmsNotifications,
        updateSmsGatewaySettings,
        addOrUpdateBakiAccount,
        payBakiAmount,
        markSmsNotificationRead,
        markAllSmsNotificationsRead,
        customerUIConfig,
        updateCustomerUIConfig,
        toasts,
        showToast,
        isOnline
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
