import type { BangladeshiBank } from '../types.ts';

export const BANGLADESHI_BANKS: BangladeshiBank[] = [
  {
    id: 'ibbl',
    name: 'Islami Bank Bangladesh Ltd (IBBL)',
    nameBn: 'ইসলামী ব্যাংক বাংলাদেশ লিমিটেড',
    shortCode: 'IBBL / CellFin',
    logo: 'https://images.unsplash.com/photo-1541354329998-f4d9a9f9297f?auto=format&fit=crop&w=200&q=80',
    color: '#00843D',
    accountName: 'DeshiBazar Marketplace Ltd',
    accountNumber: '2050-2130-2019-8745',
    branchName: 'Motijheel Corporate Branch, Dhaka',
    routingNumber: '125272841',
    swiftCode: 'IBBLBDDH',
    transferMethods: ['CellFin Transfer', 'IBBL iBanking', 'NPSB Instant', 'BEFTN', 'Cash Deposit Machine (CRM)'],
    transferMethodsBn: ['সেলফিন অ্যাপ ট্রান্সফার', 'আই-ব্যাংকিং', 'এনপিএসবি ইনস্ট্যান্ট', 'বিইএফটিএন', 'সিআরএম বুথ ডিপোজিট'],
    appPlatform: 'CellFin & iBanking',
    isPopular: true,
    isActive: true,
    instructionsBn: 'সেলফিন বা ইসলামী ব্যাংক অ্যাপ থেকে সরাসরি একাউন্ট বা ফান্ড ট্রান্সফার করুন। রেফারেন্সে আপনার নাম লিখুন এবং ট্রানজেকশন আইডি দিন।'
  },
  {
    id: 'dbbl',
    name: 'Dutch-Bangla Bank Ltd (DBBL)',
    nameBn: 'ডাচ-বাংলা ব্যাংক লিমিটেড',
    shortCode: 'DBBL / NexusPay',
    logo: 'https://images.unsplash.com/photo-1501167786227-4cba60f6d58f?auto=format&fit=crop&w=200&q=80',
    color: '#D81E05',
    accountName: 'DeshiBazar Marketplace Ltd',
    accountNumber: '115-110-0034981',
    branchName: 'Gulshan Branch, Dhaka',
    routingNumber: '090261314',
    swiftCode: 'DBBLBDDH',
    transferMethods: ['NexusPay App', 'Rocket Transfer', 'DBBL Internet Banking', 'NPSB', 'FastTrack ATM Deposit'],
    transferMethodsBn: ['নেক্সাসপে অ্যাপ', 'রকেট ট্রান্সফার', 'ইন্টারনেট ব্যাংকিং', 'এনপিএসবি', 'ফাস্টট্র্যাক এটিএম ডিপোজিট'],
    appPlatform: 'NexusPay & Rocket',
    isPopular: true,
    isActive: true,
    instructionsBn: 'নেক্সাসপে অ্যাপ অথবা ডিবিবিএল অ্যাকাউন্ট থেকে সরাসরি ফান্ড ট্রান্সফার করুন। ট্রানজেকশন স্লিপের কোডটি এখানে সাবমিট করুন।'
  },
  {
    id: 'city',
    name: 'The City Bank Ltd',
    nameBn: 'সিটি ব্যাংক লিমিটেড',
    shortCode: 'City Touch',
    logo: 'https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?auto=format&fit=crop&w=200&q=80',
    color: '#ED1C24',
    accountName: 'DeshiBazar Marketplace Ltd',
    accountNumber: '310-2458-921001',
    branchName: 'Dhanmondi Branch, Dhaka',
    routingNumber: '225271890',
    swiftCode: 'CIYBDDH',
    transferMethods: ['City Touch App', 'NPSB Transfer', 'City Bank Debit Card', 'BEFTN'],
    transferMethodsBn: ['সিটি টাচ অ্যাপ', 'এনপিএসবি ট্রান্সফার', 'সিটি ব্যাংক কার্ড', 'বিইএফটিএন'],
    appPlatform: 'City Touch Mobile App',
    isPopular: true,
    isActive: true,
    instructionsBn: 'সিটি টাচ অ্যাপ থেকে ইনস্ট্যান্ট ফান্ড ট্রান্সফার (NPSB) সম্পন্ন করে রেফারেন্স নম্বর প্রদান করুন।'
  },
  {
    id: 'brac',
    name: 'BRAC Bank Ltd',
    nameBn: 'ব্র্যাক ব্যাংক লিমিটেড',
    shortCode: 'BRAC Astha',
    logo: 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?auto=format&fit=crop&w=200&q=80',
    color: '#0054A6',
    accountName: 'DeshiBazar Marketplace Ltd',
    accountNumber: '1501-2048-9123-4001',
    branchName: 'Banani Branch, Dhaka',
    routingNumber: '060260485',
    swiftCode: 'BRAKBDDH',
    transferMethods: ['BRAC Bank Astha App', 'Internet Banking', 'NPSB 24/7', 'BEFTN'],
    transferMethodsBn: ['আস্থা অ্যাপ', 'ইন্টারনেট ব্যাংকিং', 'এনপিএসবি ২৪/৭', 'বিইএফটিএন'],
    appPlatform: 'Astha App',
    isPopular: true,
    isActive: true,
    instructionsBn: 'আস্থা অ্যাপের মাধ্যমে যেকোনো সময় ইনস্ট্যান্ট একাউন্ট ট্রান্সফার করুন এবং অর্ডারে ট্রানজেকশন রেফারেন্স দিন।'
  },
  {
    id: 'ebl',
    name: 'Eastern Bank Ltd (EBL)',
    nameBn: 'ইস্টার্ন ব্যাংক লিমিটেড',
    shortCode: 'EBL SKYBANKING',
    logo: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=200&q=80',
    color: '#002B49',
    accountName: 'DeshiBazar Marketplace Ltd',
    accountNumber: '104-107-0298412',
    branchName: 'Principal Branch, Dilkusha, Dhaka',
    routingNumber: '095271630',
    swiftCode: 'EBLBDDH',
    transferMethods: ['EBL SKYBANKING', 'EBL Visa/Mastercard', 'NPSB', 'BEFTN'],
    transferMethodsBn: ['স্কাইব্যাংকিং অ্যাপ', 'ইবিএল কার্ড', 'এনপিএসবি', 'বিইএফটিএন'],
    appPlatform: 'EBL SKYBANKING',
    isPopular: true,
    isActive: true,
    instructionsBn: 'EBL SKYBANKING অ্যাপ থেকে সরাসরি দেশিবাজার একাউন্টে ট্রান্সফার করে ট্রানজেকশন আইডি প্রবেশ করান।'
  },
  {
    id: 'sonali',
    name: 'Sonali Bank PLC',
    nameBn: 'সোনালী ব্যাংক পিএলসি',
    shortCode: 'Sonali eSheba',
    logo: 'https://images.unsplash.com/photo-1541354329998-f4d9a9f9297f?auto=format&fit=crop&w=200&q=80',
    color: '#007A33',
    accountName: 'DeshiBazar Marketplace Ltd',
    accountNumber: '0010-2034-98124',
    branchName: 'Local Office Branch, Motijheel, Dhaka',
    routingNumber: '200270432',
    swiftCode: 'BSONBDDH',
    transferMethods: ['Sonali eSheba App', 'Sonali e-Wallet', 'BEFTN / RTGS', 'Bank Branch Counter'],
    transferMethodsBn: ['সোনালী ই-সেবা অ্যাপ', 'ই-ওয়ালেট', 'বিইএফটিএন / আরটিজিএস', 'শাখা কাউন্টার ডিপোজিট'],
    appPlatform: 'Sonali eSheba & e-Wallet',
    isPopular: false,
    isActive: true,
    instructionsBn: 'সোনালী ই-সেবা অথবা সোনালী ব্যাংকের যেকোনো শাখা থেকে সরাসরি ব্যাংক অ্যাকাউন্টে জমা দিন।'
  },
  {
    id: 'bank_asia',
    name: 'Bank Asia Ltd',
    nameBn: 'ব্যাংক এশিয়া লিমিটেড',
    shortCode: 'Bank Asia SMART',
    logo: 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?auto=format&fit=crop&w=200&q=80',
    color: '#00529B',
    accountName: 'DeshiBazar Marketplace Ltd',
    accountNumber: '0123-6009-841',
    branchName: 'Kawran Bazar Branch, Dhaka',
    routingNumber: '035262780',
    swiftCode: 'BKASBDDH',
    transferMethods: ['Bank Asia SMART App', 'Agent Banking Outlet', 'NPSB', 'BEFTN'],
    transferMethodsBn: ['স্মার্ট অ্যাপ', 'এজেন্ট ব্যাংকিং আউটলেট', 'এনপিএসবি', 'বিইএফটিএন'],
    appPlatform: 'Bank Asia SMART',
    isPopular: false,
    isActive: true,
    instructionsBn: 'ব্যাংক এশিয়া স্মার্ট অ্যাপ অথবা যেকোনো এজেন্ট ব্যাংকিং আউটলেট থেকে সরাসরি অ্যাকাউন্টে ডিপোজিট করতে পারেন।'
  },
  {
    id: 'prime',
    name: 'Prime Bank Ltd',
    nameBn: 'প্রাইম ব্যাংক লিমিটেড',
    shortCode: 'PrimePay',
    logo: 'https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?auto=format&fit=crop&w=200&q=80',
    color: '#00833E',
    accountName: 'DeshiBazar Marketplace Ltd',
    accountNumber: '2110-1140-02981',
    branchName: 'Mohakhali Branch, Dhaka',
    routingNumber: '170262910',
    swiftCode: 'PRBLBDDH',
    transferMethods: ['PrimePay App', 'Altitude Cards', 'NPSB Transfer', 'BEFTN'],
    transferMethodsBn: ['প্রাইমপে অ্যাপ', 'অলটিটিউড কার্ড', 'এনপিএসবি', 'বিইএফটিএন'],
    appPlatform: 'PrimePay',
    isPopular: false,
    isActive: true,
    instructionsBn: 'প্রাইমপে অ্যাপ বা ইন্টারনেট ব্যাংকিং থেকে সরাসরি ট্রান্সফার সম্পন্ন করুন।'
  },
  {
    id: 'pubali',
    name: 'Pubali Bank Ltd',
    nameBn: 'পূবালী ব্যাংক লিমিটেড',
    shortCode: 'PI Banking',
    logo: 'https://images.unsplash.com/photo-1501167786227-4cba60f6d58f?auto=format&fit=crop&w=200&q=80',
    color: '#0B5394',
    accountName: 'DeshiBazar Marketplace Ltd',
    accountNumber: '3555-9010-48120',
    branchName: 'Stadium Corporate Branch, Dhaka',
    routingNumber: '175273910',
    swiftCode: 'PUBABDDA',
    transferMethods: ['PI Banking App', 'Counter Deposit', 'NPSB', 'BEFTN'],
    transferMethodsBn: ['পিআই ব্যাংকিং অ্যাপ', 'শাখা কাউন্টার জমা', 'এনপিএসবি', 'বিইএফটিএন'],
    appPlatform: 'PI Banking',
    isPopular: false,
    isActive: true,
    instructionsBn: 'পূবালী পিআই ব্যাংকিং অ্যাপের মাধ্যমে তাৎক্ষণিক ট্রান্সফার অথবা শাখায় জমা দিয়ে ভাউচার নম্বর দিন।'
  }
];

export interface PaymentGatewayConfig {
  sslCommerz: {
    enabled: boolean;
    storeId: string;
    storePassword: string;
    isSandbox: boolean;
  };
  shurjoPay: {
    enabled: boolean;
    merchantUsername: string;
    merchantPassword: string;
    isSandbox: boolean;
  };
  bkashMerchant: {
    enabled: boolean;
    merchantNumber: string;
    appKey: string;
    appSecret: string;
  };
  nagadMerchant: {
    enabled: boolean;
    merchantId: string;
    publicKey: string;
  };
  bangladeshiBankGateway: {
    enabled: boolean;
    allowDirectDeposit: boolean;
    allowInternetBanking: boolean;
    requireSlipUpload: boolean;
    autoVerifyNPSB: boolean;
    activeBankIds: string[];
  };
}

export const DEFAULT_PAYMENT_GATEWAY_CONFIG: PaymentGatewayConfig = {
  sslCommerz: {
    enabled: true,
    storeId: 'deshibazar_live_01',
    storePassword: '••••••••••••••••',
    isSandbox: false
  },
  shurjoPay: {
    enabled: true,
    merchantUsername: 'deshibazar_sp',
    merchantPassword: '••••••••••••••••',
    isSandbox: false
  },
  bkashMerchant: {
    enabled: true,
    merchantNumber: '01713009988',
    appKey: 'bkash_app_key_prod_891',
    appSecret: '••••••••••••••••'
  },
  nagadMerchant: {
    enabled: true,
    merchantId: 'NAGAD_DESHIBAZAR_01',
    publicKey: '••••••••••••••••'
  },
  bangladeshiBankGateway: {
    enabled: true,
    allowDirectDeposit: true,
    allowInternetBanking: true,
    requireSlipUpload: false,
    autoVerifyNPSB: true,
    activeBankIds: ['ibbl', 'dbbl', 'city', 'brAC', 'ebl', 'sonali', 'bank_asia', 'prime', 'pubali']
  }
};
