export const DESHIBAZAR_CONTACT = {
  // Hotline
  hotlineShort: '+8801935824505',
  hotlineDisplay: '+8801935824505',
  hotlineTel: 'tel:+8801935824505',
  
  // Phone numbers & WhatsApp
  phonePrimary: '+880 1935824505',
  phoneDisplay: '+880 1935824505',
  phoneTelPrimary: 'tel:+8801935824505',
  whatsAppUrl: 'https://wa.me/8801935824505',
  
  // Headquarters Location
  location: {
    bn: 'কাঁচকুড়া, ভারারদি, উত্তরখান, উত্তরা, ঢাকা-১২৩০, বাংলাদেশ',
    en: 'Kanchkura, Bharardi, Uttarkhan, Uttara, Dhaka-1230, Bangladesh'
  },
  
  // Logistics Hub
  hubLocation: {
    bn: 'কাঁচকুড়া, ভারারদি, উত্তরখান, উত্তরা, ঢাকা-১২৩০, বাংলাদেশ',
    en: 'Kanchkura, Bharardi, Uttarkhan, Uttara, Dhaka-1230, Bangladesh'
  },

  // Support Emails
  emailSupport: 'support@deshibazar.bd',
  emailMerchant: 'merchant@deshibazar.bd',

  // Working Hours
  hours: {
    bn: 'সকাল ৮:০০ - রাত ১০:০০ (প্রতিদিন খোলা)',
    en: '8:00 AM - 10:00 PM (Open 7 Days)'
  }
};
