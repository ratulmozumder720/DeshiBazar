import type { BangladeshiCourier } from '../types.ts';

export const BANGLADESHI_COURIERS: BangladeshiCourier[] = [
  {
    id: 'steadfast',
    name: 'Steadfast Courier',
    nameBn: 'স্টেডফাস্ট কুরিয়ার',
    logo: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=200&q=80',
    tagline: 'Fastest Doorstep Delivery & 0% COD Fraud Protection',
    taglineBn: 'বাংলাদেশের সবচেয়ে দ্রুততম ই-কমার্স ডোরস্টেপ ডেলিভারি',
    deliveryTimeInsideDhaka: '24 Hours',
    deliveryTimeOutsideDhaka: '48-72 Hours',
    baseRateInsideDhaka: 60,
    baseRateOutsideDhaka: 120,
    codChargePercent: 1.0,
    trackingUrlTemplate: 'https://steadfast.com.bd/tracking?consignment_id={tracking}',
    hotline: '+8809678045045',
    coverage: '64 Districts, 495+ Upazilas (All BD)',
    features: ['Real-time SMS & Consignment Tracking', 'Fastest 24-hr Dhaka Delivery', 'Digital COD Return within 24h'],
    featuresBn: ['রিয়েল-টাইম এসএমএস ও ট্র্যাকিং', '২৪ ঘণ্টায় ঢাকা সিটিতে ডেলিভারি', 'দ্রুততম ক্যাশ অন ডেলিভারি পেমেন্ট'],
    popularFor: 'E-commerce parcels & fragile items',
    isPopular: true
  },
  {
    id: 'pathao',
    name: 'Pathao Courier',
    nameBn: 'পাঠাও কুরিয়ার',
    logo: 'https://images.unsplash.com/photo-1616401784845-180882ba9ba8?auto=format&fit=crop&w=200&q=80',
    tagline: 'Reliable Nationwide Delivery Powered by Live GPS',
    taglineBn: 'লাইভ জিপিএস ট্র্যাকিং ও দ্রুততম দেশব্যাপী কুরিয়ার নেটওয়ার্ক',
    deliveryTimeInsideDhaka: 'Same Day / 24 Hours',
    deliveryTimeOutsideDhaka: '48 Hours',
    baseRateInsideDhaka: 70,
    baseRateOutsideDhaka: 130,
    codChargePercent: 1.0,
    trackingUrlTemplate: 'https://pathao.com/courier/tracking/?consignment_id={tracking}',
    hotline: '+8809678100800',
    coverage: 'Nationwide (Every Thana & Union)',
    features: ['Live Rider Map & OTP Delivery', 'Same-Day Express in Metropolitan Areas', 'Integrated Pathao Merchant App'],
    featuresBn: ['রাইডার লাইভ ম্যাপ ও ওটিপি ডেলিভারি', 'মেট্রোপলিটন এলাকায় সেম-ডে এক্সপ্রেস', 'সহজ মার্চেন্ট প্যানেল ও ট্র্যাকিং'],
    popularFor: 'Express & high-value electronics',
    isPopular: true
  },
  {
    id: 'redx',
    name: 'RedX Delivery',
    nameBn: 'রেডএক্স ডেলিভারি',
    logo: 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&w=200&q=80',
    tagline: 'Largest Logistics Network Across 64 Districts',
    taglineBn: '৬৪ জেলায় নিজস্ব হাব ও সুবিশাল ডেলিভারি নেটওয়ার্ক',
    deliveryTimeInsideDhaka: '24-48 Hours',
    deliveryTimeOutsideDhaka: '48-72 Hours',
    baseRateInsideDhaka: 65,
    baseRateOutsideDhaka: 125,
    codChargePercent: 1.0,
    trackingUrlTemplate: 'https://redx.com.bd/track?trackingId={tracking}',
    hotline: '+8809610007339',
    coverage: '64 Districts, 100% Hub Coverage',
    features: ['Doorstep Delivery to Village Unions', 'Secure OTP Verification', 'Free Return on Failed Delivery'],
    featuresBn: ['গ্রাম পর্যন্ত হোম ডেলিভারি সুবিধা', 'নিরাপদ ওটিপি ভেরিফিকেশন', 'ব্যর্থ ডেলিভারিতে ফ্রি রিটার্ন'],
    popularFor: 'Apparel, handicrafts & general parcels',
    isPopular: true
  },
  {
    id: 'paperfly',
    name: 'Paperfly Delivery',
    nameBn: 'পেপারফ্লাই ডেলিভারি',
    logo: 'https://images.unsplash.com/photo-1578575437130-527eed3abbec?auto=format&fit=crop&w=200&q=80',
    tagline: 'Pioneer of Doorstep Delivery to Remote Bangladesh',
    taglineBn: 'বাংলাদেশের প্রত্যন্ত অঞ্চলে ডোরস্টেপ ডেলিভারির পথিকৃৎ',
    deliveryTimeInsideDhaka: '24-48 Hours',
    deliveryTimeOutsideDhaka: '48-72 Hours',
    baseRateInsideDhaka: 60,
    baseRateOutsideDhaka: 110,
    codChargePercent: 1.0,
    trackingUrlTemplate: 'https://paperfly.com.bd/tracking?order_id={tracking}',
    hotline: '+8809666774433',
    coverage: '4500+ Unions Across Bangladesh',
    features: ['Wings Express Point-to-Point', 'Smart Return Management', 'Paperfly Smart Check'],
    featuresBn: ['পয়েন্ট-টু-পয়েন্ট এক্সপ্রেস সার্ভিস', 'স্মার্ট রিটার্ন ম্যানেজমেন্ট', 'পেপারফ্লাই স্মার্ট চেক'],
    popularFor: 'Remote union delivery & bulky parcels'
  },
  {
    id: 'sundarban',
    name: 'Sundarban Courier Service (Pvt) Ltd',
    nameBn: 'সুন্দরবন কুরিয়ার সার্ভিস',
    logo: 'https://images.unsplash.com/photo-1512909006721-3d6018887383?auto=format&fit=crop&w=200&q=80',
    tagline: 'Bangladesh’s Oldest & Most Trusted Courier with 700+ Branches',
    taglineBn: 'বাংলাদেশের প্রাচীনতম ও ৭০০+ শাখা বিশিষ্ট বিশ্বস্ত কুরিয়ার',
    deliveryTimeInsideDhaka: '24 Hours',
    deliveryTimeOutsideDhaka: '24-48 Hours',
    baseRateInsideDhaka: 50,
    baseRateOutsideDhaka: 100,
    codChargePercent: 0.5,
    trackingUrlTemplate: 'https://sundarbancourierltd.com/track/{tracking}',
    hotline: '+88029342407',
    coverage: 'Every District, Sub-district & Upazila (700+ Hubs)',
    features: ['Branch Pickup & Home Delivery', 'Lowest Shipping Rates in BD', 'Heavy Cargo & Document Specialist'],
    featuresBn: ['শাখা থেকে পণ্য সংগ্রহ ও হোম ডেলিভারি', 'সবচেয়ে সাশ্রয়ী কুরিয়ার চার্জ', 'ভারী কার্গো ও ডকুমেন্ট স্পেশালিস্ট'],
    popularFor: 'Affordable rates, bulk cargo & traditional deshi goods',
    isPopular: true
  },
  {
    id: 'ecourier',
    name: 'eCourier',
    nameBn: 'ই-কুরিয়ার',
    logo: 'https://images.unsplash.com/photo-1580674684081-7617fbf3d745?auto=format&fit=crop&w=200&q=80',
    tagline: 'Smart 360° Logistics & Digital Tracking Solutions',
    taglineBn: 'স্মার্ট ৩৬০ ডিগ্রি লজিস্টিকস ও ডিজিটাল ট্র্যাকিং সলিউশন',
    deliveryTimeInsideDhaka: '24 Hours',
    deliveryTimeOutsideDhaka: '48 Hours',
    baseRateInsideDhaka: 65,
    baseRateOutsideDhaka: 120,
    codChargePercent: 1.0,
    trackingUrlTemplate: 'https://ecourier.com.bd/tracking?ecr={tracking}',
    hotline: '+8809612500500',
    coverage: '64 Districts (Air & Surface cargo)',
    features: ['Smart Parcel Locker System', 'Air Express for Urgent Deliveries', 'Automated Tracking API'],
    featuresBn: ['স্মার্ট পার্সেল লকার সিস্টেম', 'জরুরি ডেলিভারিতে এয়ার এক্সপ্রেস', 'স্বয়ংক্রিয় ট্র্যাকিং এপিআই'],
    popularFor: 'Tech gadgets, documents & express air parcels'
  },
  {
    id: 'sa_paribahan',
    name: 'SA Paribahan Parcel Service',
    nameBn: 'এস এ পরিবহন পার্সেল সার্ভিস',
    logo: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=200&q=80',
    tagline: 'Pioneer of Conditional Delivery & Fast Bus Route Logistics',
    taglineBn: 'কন্ডিশনাল ডেলিভারি ও দ্রুততম হাইওয়ে এক্সপ্রেস সার্ভিস',
    deliveryTimeInsideDhaka: 'Same Day / 24 Hours',
    deliveryTimeOutsideDhaka: '24-36 Hours (Superfast Highway)',
    baseRateInsideDhaka: 70,
    baseRateOutsideDhaka: 130,
    codChargePercent: 1.5,
    trackingUrlTemplate: 'https://saparibahan.com/tracking?receipt={tracking}',
    hotline: '+8809613112233',
    coverage: 'All Main Highway Hubs & District Centers',
    features: ['Conditional Cash on Counter Delivery', 'Overnight Inter-district Transit', 'High Security for Valuables'],
    featuresBn: ['কাউন্টার কন্ডিশনে টাকা ও পণ্য ডেলিভারি', 'একরাতেই দূরপাল্লার জেলায় ডেলিভারি', 'মূল্যবান পণ্যের জন্য সর্বোচ্চ নিরাপত্তা'],
    popularFor: 'Conditional payments & urgent overnight deliveries'
  },
  {
    id: 'karatoa',
    name: 'Karatoa Courier Service',
    nameBn: 'করতোয়া কুরিয়ার সার্ভিস',
    logo: 'https://images.unsplash.com/photo-1519003722824-194d4455a60c?auto=format&fit=crop&w=200&q=80',
    tagline: 'Leading Express Service for Northern & All Bangladesh',
    taglineBn: 'উত্তরবঙ্গসহ সারা বাংলাদেশে দ্রুততম কুরিয়ার সেবা',
    deliveryTimeInsideDhaka: '24 Hours',
    deliveryTimeOutsideDhaka: '24-48 Hours',
    baseRateInsideDhaka: 55,
    baseRateOutsideDhaka: 105,
    codChargePercent: 1.0,
    trackingUrlTemplate: 'https://karatoacourier.com/track/{tracking}',
    hotline: '+8801713400500',
    coverage: 'Northern Bengal Specialist & Nationwide Network',
    features: ['Direct Highway Express', 'Very Low Weight Surcharges', 'Deshi Agro & Handicraft Safe Transit'],
    featuresBn: ['সরাসরি হাইওয়ে এক্সপ্রেস', 'সাশ্রয়ী পার্সেল চার্জ', 'দেশি কৃষিপণ্য ও খাদ্যদ্রব্যে বিশেষ যত্ন'],
    popularFor: 'Rajshahi, Bogura, Rangpur routes & seasonal agricultural goods'
  }
];

export const BANGLADESH_COURIERS = BANGLADESHI_COURIERS;

// Sample simulated live tracking details for any BD courier tracking code
export function generateLiveCourierTrackingInfo(trackingCode: string, orderNumber?: string, courierId?: string) {
  const code = trackingCode.trim().toUpperCase();
  const courier = BANGLADESHI_COURIERS.find((c: BangladeshiCourier) => c.id === courierId) || 
    (code.startsWith('ST') ? BANGLADESHI_COURIERS[0] : // Steadfast
     code.startsWith('PT') ? BANGLADESHI_COURIERS[1] : // Pathao
     code.startsWith('REDX') ? BANGLADESHI_COURIERS[2] : // RedX
     code.startsWith('PF') ? BANGLADESHI_COURIERS[3] : // Paperfly
     code.startsWith('SC') ? BANGLADESHI_COURIERS[4] : // Sundarban
     code.startsWith('ECR') ? BANGLADESHI_COURIERS[5] : // eCourier
     code.startsWith('SAP') ? BANGLADESHI_COURIERS[6] : // SA Paribahan
     code.startsWith('KC') ? BANGLADESHI_COURIERS[7] : // Karatoa
     BANGLADESHI_COURIERS[0]); // default Steadfast

  const now = new Date();
  const timeFormatted = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  return {
    consignmentId: code || `ST-${Math.floor(1000000 + Math.random() * 9000000)}`,
    orderNumber: orderNumber || `DB-${Math.floor(100000 + Math.random() * 900000)}`,
    courier,
    currentStatus: 'Out for Delivery (আজই আপনার হাতে পৌঁছাবে)',
    currentStatusEn: 'Out for Delivery (Rider on the way)',
    statusCode: 'out_for_delivery',
    riderName: 'Md. Al-Amin Hossain (আল-আমিন হোসেন)',
    riderPhone: '+8801712-349812',
    deliveryVehicle: 'Hero Glamour Motorcycle (DHAKA METRO HA-54-1290)',
    pickupHub: 'Tejgaon Central Sorting Hub, Dhaka',
    destinationHub: 'Mirpur-10 Regional Distribution Center, Dhaka',
    estimatedDelivery: 'Today by 06:30 PM (আজ সন্ধ্যা ৬:৩০ এর মধ্যে)',
    codAmount: '৳1,450 (Cash on Delivery)',
    weightKg: '1.8 kg',
    liveTimeline: [
      {
        title: 'অর্ডার কুরিয়ারে হস্তান্তর সম্পন্ন (Consignment Handed Over)',
        location: 'DeshiBazar Central Fulfillment Center, Savar',
        time: 'Yesterday, 04:30 PM',
        completed: true,
        desc: 'প্যাকেট প্রস্তুত করে কুরিয়ার ভ্যানে লোড করা হয়েছে।'
      },
      {
        title: 'সেন্ট্রাল হাবে রিসিভড ও স্ক্যানিং (Arrived at Central Hub)',
        location: `${courier.name} Tejgaon Mega Sorting Facility`,
        time: 'Yesterday, 09:15 PM',
        completed: true,
        desc: 'অটোমেটেড বারকোড স্ক্যান এবং আঞ্চলিক হাবের জন্য সাজানো হয়েছে।'
      },
      {
        title: 'আঞ্চলিক ডেলিভারি হাবে প্রেরিত (Dispatched to Local Hub)',
        location: 'En-route to Local Hub via Night Highway Fleet',
        time: 'Today, 03:20 AM',
        completed: true,
        desc: 'ডেলিভারি এরিয়ার হাবের উদ্দেশ্যে রওনা হয়েছে।'
      },
      {
        title: 'ডেলিভারি হাবে পৌঁছেছে (Received at Delivery Branch)',
        location: 'Mirpur-10 Distribution Branch',
        time: 'Today, 08:45 AM',
        completed: true,
        desc: 'পার্সেল সফলভাবে স্থানীয় ডেলিভারি শাখায় গৃহীত হয়েছে।'
      },
      {
        title: 'ডেলিভারির জন্য বের হয়েছে (Out for Delivery with Rider)',
        location: 'Assigned to Rider: Md. Al-Amin Hossain',
        time: `Today, ${timeFormatted}`,
        completed: true,
        activeNow: true,
        desc: 'রাইডার ডেলিভারি সম্পন্ন করার জন্য আপনার ঠিকানায় আসছে। অনুগ্রহ করে ফোন সচল রাখুন।'
      },
      {
        title: 'ডেলিভারি ও ক্যাশ কালেকশন (Delivered & Cash Collected)',
        location: 'Customer Doorstep',
        time: 'Expected: Today by 06:30 PM',
        completed: false,
        desc: 'গ্রাহকের নিকট পার্সেল পৌঁছানো এবং ওটিপি/ক্যাশ নিশ্চিতকরণ।'
      }
    ]
  };
}
