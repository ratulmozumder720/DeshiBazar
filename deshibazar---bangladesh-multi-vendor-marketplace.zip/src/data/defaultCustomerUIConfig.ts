import type { CustomerUIConfig } from '../types.ts';

export const DEFAULT_CUSTOMER_UI_CONFIG: CustomerUIConfig = {
  storeName: 'DeshiBazar Marketplace',
  storeNameBn: 'দেশিবাজার মার্কেটপ্লেস',
  tagline: 'Authentic Bangladeshi & Global Marketplace',
  taglineBn: 'দেশি পণ্য, সবার বাজার — খাঁটি পণ্য সারাদেশে হোম ডেলিভারি',
  primaryColor: '#059669',
  accentColor: '#f59e0b',
  badgeColor: '#dc2626',
  fontFamily: 'plus-jakarta',
  borderRadius: 'rounded-2xl',

  showAnnouncementTicker: true,
  announcementText: 'Nationwide Delivery | Cash on Delivery Available | bKash & Nagad Accepted',
  announcementTextBn: 'সারা বাংলাদেশে ক্যাশ অন ডেলিভারি | বিকাশ ও নগদ গ্রহণ করা হয় | ২৪-৪৮ ঘণ্টায় হোম ডেলিভারি',

  heroLayout: 'carousel',
  heroAutoPlaySpeed: 5,
  showCustomerStories: true,
  stories: [
    {
      id: 'story-1',
      title: 'Mega Flash Sale',
      titleBn: 'ফ্ল্যাশ সেল ৫০% ছাড়',
      image: 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?auto=format&fit=crop&w=300&q=80',
      badge: '50% OFF',
      linkCategory: 'flash-sale',
      isLive: true
    },
    {
      id: 'story-2',
      title: 'Padma Hilsha',
      titleBn: 'পদ্মার রূপালী ইলিশ',
      image: 'https://images.unsplash.com/photo-1544943910-4c1dc44a0551?auto=format&fit=crop&w=300&q=80',
      badge: 'Fresh',
      linkCategory: 'fish-meat',
      isLive: true
    },
    {
      id: 'story-3',
      title: 'Sundarbans Honey',
      titleBn: 'সুন্দরবনের খাঁটি মধু',
      image: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=300&q=80',
      badge: '100% Pure',
      linkCategory: 'deshi-products',
      isLive: true
    },
    {
      id: 'story-4',
      title: 'Jamdani Sarees',
      titleBn: 'ঢাকাই জামদানি শাড়ি',
      image: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=300&q=80',
      badge: 'Handloom',
      linkCategory: 'fashion',
      isLive: true
    },
    {
      id: 'story-5',
      title: 'Chinigura Rice',
      titleBn: 'সুগন্ধি চিনিগুঁড়া চাল',
      image: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=300&q=80',
      badge: 'Premium',
      linkCategory: 'rice-dal-grocery',
      isLive: true
    },
    {
      id: 'story-6',
      title: 'Free Delivery',
      titleBn: 'ফ্রি ডেলিভারি অফার',
      image: 'https://images.unsplash.com/photo-1578575437130-527eed3abbec?auto=format&fit=crop&w=300&q=80',
      badge: '৳1500+',
      isLive: false
    }
  ],

  showFlashSale: true,
  showCategoryPills: true,
  showDeshiSpotlight: true,
  showDailyDeals: true,
  showLocalSellers: true,
  showBestSellers: true,
  showAppDownloadBanner: true,
  showNewsletter: true,

  productCardStyle: 'modern',
  badgeStyle: 'pill',
  cardActionStyle: 'both-buttons',
  showDiscountPercent: true,
  showRatingStars: true,
  showStockCount: true,

  mobileBottomNavStyle: 'floating-pill',
  mobileShowLocationChip: true,
  mobileShowFloatingSupport: true,
  mobileSupportType: 'both',
  mobileSupportNumber: '+8801700123456',
  splashScreenColor: '#059669',

  lastUpdated: new Date().toISOString()
};

export interface CustomerUIPreset {
  id: string;
  name: string;
  nameBn: string;
  description: string;
  descriptionBn: string;
  config: Partial<CustomerUIConfig>;
}

export const CUSTOMER_UI_PRESETS: CustomerUIPreset[] = [
  {
    id: 'bengal-supermall',
    name: 'Modern Bangladeshi Supermall',
    nameBn: 'দারাজ ও দেশিবাজার আধুনিক মেগামল',
    description: 'Vibrant, high-conversion commercial shopping look with prominent flash deals, floating pill bottom nav and attractive story circles.',
    descriptionBn: 'উচ্চ কনভার্সনযুক্ত মেগামল লুক, দ্রুত ফ্ল্যাশ ডিল এবং ইনস্টাগ্রাম স্টাইল স্টোরি বাবল।',
    config: {
      primaryColor: '#059669',
      accentColor: '#f59e0b',
      badgeColor: '#dc2626',
      borderRadius: 'rounded-2xl',
      productCardStyle: 'modern',
      badgeStyle: 'pill',
      mobileBottomNavStyle: 'floating-pill',
      heroLayout: 'carousel',
      showCustomerStories: true,
      cardActionStyle: 'both-buttons'
    }
  },
  {
    id: 'gramin-agro-pure',
    name: 'Organic Gramin Agro Bazaar',
    nameBn: 'খাঁটি গ্রামীণ অর্গানিক হাট',
    description: 'Earthy forest tones, traditional Bengali typography, highlighting river catches and village farm harvests.',
    descriptionBn: 'প্রাকৃতিক সবুজ ও মাটির রঙের সমাহার, তাজা মাছ, খাঁটি মধু ও ঘানি তেলের জন্য সেরা।',
    config: {
      primaryColor: '#15803d',
      accentColor: '#d97706',
      badgeColor: '#16a34a',
      borderRadius: 'rounded-3xl',
      productCardStyle: 'elevated-glow',
      badgeStyle: 'pill',
      mobileBottomNavStyle: 'glassmorphism',
      heroLayout: 'bento',
      showCustomerStories: true,
      cardActionStyle: 'both-buttons'
    }
  },
  {
    id: 'dhaka-luxe-silk',
    name: 'Dhakai Luxe Boutique & Silk',
    nameBn: 'ঢাকাই রাজকীয় বুটিক ও জামদানি',
    description: 'Ultra-refined luxury aesthetic for fashion, gold jewelry, and authentic Dhakai Jamdani sarees.',
    descriptionBn: 'অভিজাত শাড়ি, গহনা ও ফ্যাশনের জন্য চমৎকার মার্জিত রাজকীয় লুক।',
    config: {
      primaryColor: '#7c2d12',
      accentColor: '#eab308',
      badgeColor: '#991b1b',
      borderRadius: 'rounded-xl',
      productCardStyle: 'minimal-border',
      badgeStyle: 'minimal-tag',
      mobileBottomNavStyle: 'classic-dock',
      heroLayout: 'split-banner',
      showCustomerStories: false,
      cardActionStyle: 'hover-reveal'
    }
  },
  {
    id: 'midnight-neon-speed',
    name: 'Midnight Cyber Gadget Mart',
    nameBn: 'মধ্যরাত নিয়ন ইলেকট্রনিক্স ও গ্যাজেট',
    description: 'High-contrast dark mode for electronics, mobile accessories, computers, and gamers.',
    descriptionBn: 'ইলেকট্রনিক্স ও স্মার্ট গ্যাজেটের জন্য হাই-কনট্রাস্ট ডার্ক ও নিয়ন অ্যাকসেন্ট।',
    config: {
      primaryColor: '#06b6d4',
      accentColor: '#ec4899',
      badgeColor: '#8b5cf6',
      borderRadius: 'rounded-2xl',
      productCardStyle: 'elevated-glow',
      badgeStyle: 'pill',
      mobileBottomNavStyle: 'glow-active',
      heroLayout: 'clean-minimal',
      showCustomerStories: true,
      cardActionStyle: 'both-buttons'
    }
  }
];
