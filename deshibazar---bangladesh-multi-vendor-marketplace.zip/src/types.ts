export type Language = 'bn' | 'en';

export interface Product {
  id: string;
  name: string;
  nameBn: string;
  category: string;
  categoryBn: string;
  subCategory?: string;
  brand: string;
  vendorId: string;
  vendorName: string;
  vendorLocation: string;
  price: number; // In BDT (৳)
  originalPrice: number;
  discountPercent: number;
  unit: string;
  unitBn: string;
  rating: number;
  reviewCount: number;
  stock: number;
  isFlashSale?: boolean;
  isDeshi?: boolean;
  isDailyDeal?: boolean;
  isOrganic?: boolean;
  isBestSeller?: boolean;
  isNewArrival?: boolean;
  image: string;
  gallery: string[];
  description: string;
  descriptionBn: string;
  specifications: Record<string, string>;
  origin?: string;
}

export interface Category {
  id: string;
  name: string;
  nameBn: string;
  iconName: string;
  itemCount: number;
  image: string;
  color: string;
  popularItems: string[];
  commissionRate?: number;
  status?: 'active' | 'inactive';
  description?: string;
  descriptionBn?: string;
}

export interface Seller {
  id: string;
  name: string;
  nameBn: string;
  location: string;
  division: string;
  rating: number;
  reviewsCount: number;
  productsCount: number;
  verified: boolean;
  logo: string;
  banner: string;
  badge: string;
  badgeBn: string;
  description: string;
  descriptionBn: string;
  joinedYear: number;
}

export interface Review {
  id: string;
  productId: string;
  userName: string;
  userAvatar?: string;
  rating: number;
  comment: string;
  date: string;
  verifiedPurchase: boolean;
  location: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface OrderTrackingStep {
  status: 'placed' | 'confirmed' | 'processing' | 'packed' | 'shipped' | 'out_for_delivery' | 'delivered' | 'cancelled';
  label: string;
  labelBn: string;
  timestamp?: string;
  completed: boolean;
}

export interface Order {
  id: string;
  orderNumber: string;
  userId?: string;
  customerName: string;
  customerPhone: string;
  customerEmail?: string;
  division: string;
  district: string;
  upazila: string;
  address: string;
  deliveryInstructions?: string;
  paymentMethod: 'cod' | 'bkash' | 'nagad' | 'rocket' | 'card' | 'bank_transfer';
  paymentStatus: 'pending' | 'completed' | 'paid_online';
  transactionId?: string;
  bankPaymentDetails?: BankPaymentDetails;
  deliveryType: 'regular' | 'express';
  deliveryFee: number;
  subtotal: number;
  discount: number;
  couponCode?: string;
  total: number;
  status: 'placed' | 'confirmed' | 'processing' | 'packed' | 'shipped' | 'out_for_delivery' | 'delivered' | 'cancelled';
  items: CartItem[];
  createdAt: string;
  estimatedDelivery: string;
  trackingSteps: OrderTrackingStep[];
  cancelledAt?: string;
  cancellationReason?: string;
  courierId?: string;
  courierName?: string;
  courierTrackingCode?: string;
  courierStatus?: string;
  courierPhone?: string;
}

export interface BankPaymentDetails {
  bankId: string;
  bankName: string;
  accountNumber: string;
  senderAccountOrPhone?: string;
  bankTransactionRef: string;
  depositSlipUrl?: string;
  paymentMethodType: 'internet_banking' | 'nexus_pay' | 'cellfin' | 'branch_deposit' | 'npsb_beftn';
}

export interface BangladeshiBank {
  id: string;
  name: string;
  nameBn: string;
  shortCode: string;
  logo: string;
  color: string;
  accountName: string;
  accountNumber: string;
  branchName: string;
  routingNumber: string;
  swiftCode: string;
  transferMethods: string[];
  transferMethodsBn: string[];
  appPlatform: string;
  isPopular?: boolean;
  isActive: boolean;
  instructionsBn: string;
}

export interface Coupon {
  code: string;
  discountPercent: number;
  minOrder: number;
  maxDiscount: number;
  description: string;
  descriptionBn: string;
}

export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  phone?: string;
  role: 'customer' | 'seller' | 'admin';
  avatarUrl?: string;
  addresses: {
    id: string;
    title: string;
    division: string;
    district: string;
    upazila: string;
    fullAddress: string;
    phone: string;
    isDefault: boolean;
  }[];
}

export interface BangladeshiCourier {
  id: string;
  name: string;
  nameBn: string;
  logo: string;
  tagline: string;
  taglineBn: string;
  deliveryTimeInsideDhaka: string;
  deliveryTimeOutsideDhaka: string;
  baseRateInsideDhaka: number;
  baseRateOutsideDhaka: number;
  codChargePercent: number;
  trackingUrlTemplate: string;
  hotline: string;
  coverage: string;
  features: string[];
  featuresBn: string[];
  popularFor: string;
  isPopular?: boolean;
}

export interface CustomerStoryItem {
  id: string;
  title: string;
  titleBn: string;
  image: string;
  badge?: string;
  linkCategory?: string;
  isLive?: boolean;
}

export interface CustomerUIConfig {
  // Brand & Visual Identity
  storeName: string;
  storeNameBn: string;
  tagline: string;
  taglineBn: string;
  primaryColor: string;
  accentColor: string;
  badgeColor: string;
  fontFamily: 'plus-jakarta' | 'inter' | 'hind-siliguri' | 'playfair' | 'tiro-bangla';
  borderRadius: 'rounded-xl' | 'rounded-2xl' | 'rounded-3xl' | 'rounded-none';

  // Announcement & Banner Bar
  showAnnouncementTicker: boolean;
  announcementText: string;
  announcementTextBn: string;
  
  // Hero & Visual Layout
  heroLayout: 'carousel' | 'bento' | 'split-banner' | 'clean-minimal';
  heroAutoPlaySpeed: number; // in seconds
  showCustomerStories: boolean;
  stories: CustomerStoryItem[];

  // Homepage Section Toggles & Order
  showFlashSale: boolean;
  showCategoryPills: boolean;
  showDeshiSpotlight: boolean;
  showDailyDeals: boolean;
  showLocalSellers: boolean;
  showBestSellers: boolean;
  showAppDownloadBanner: boolean;
  showNewsletter: boolean;

  // Product Card UI/UX
  productCardStyle: 'modern' | 'minimal-border' | 'elevated-glow' | 'supermarket-compact';
  badgeStyle: 'pill' | 'ribbon' | 'minimal-tag';
  cardActionStyle: 'both-buttons' | 'cart-only' | 'hover-reveal' | 'stepper';
  showDiscountPercent: boolean;
  showRatingStars: boolean;
  showStockCount: boolean;

  // Mobile App UX (Android / iOS / PWA)
  mobileBottomNavStyle: 'floating-pill' | 'classic-dock' | 'glassmorphism' | 'glow-active';
  mobileShowLocationChip: boolean;
  mobileShowFloatingSupport: boolean;
  mobileSupportType: 'whatsapp' | 'call' | 'both';
  mobileSupportNumber: string;
  splashScreenColor: string;

  lastUpdated: string;
}

export type SmsNotificationType =
  | 'order_receipt'
  | 'baki_due'
  | 'baki_payment_receipt'
  | 'bulk_promo'
  | 'system_alert';

export interface SmsNotification {
  id: string;
  recipientPhone: string;
  recipientName: string;
  recipientNameBn?: string;
  senderName: string;
  senderRole: 'admin' | 'system';
  type: SmsNotificationType;
  title: string;
  titleBn: string;
  message: string;
  messageBn: string;
  orderNumber?: string;
  bakiId?: string;
  totalBillAmount?: number;
  paidAmount?: number;
  bakiDueAmount?: number;
  paymentMethod?: string;
  transactionRef?: string;
  isRead: boolean;
  deliveryStatus: 'delivered' | 'queued' | 'failed';
  gatewayProvider?: string;
  createdAt: string;
}

export interface BakiAccount {
  id: string;
  customerName: string;
  customerNameBn?: string;
  customerPhone: string;
  customerEmail?: string;
  orderNumber?: string;
  description: string;
  descriptionBn: string;
  totalBill: number;
  paidAmount: number;
  bakiAmount: number;
  dueDate: string;
  lastPaymentAt?: string;
  lastPaymentMethod?: string;
  lastTransactionRef?: string;
  status: 'due' | 'partial' | 'paid';
  updatedAt: string;
}

export interface SmsGatewaySettings {
  provider: 'bulksmsbd' | 'ssl_wireless' | 'greenweb_bd' | 'elitbuzz' | 'mimsms';
  senderId: string;
  apiKeyMasked: string;
  enableAutoOrderReceiptSms: boolean;
  enableAutoBakiReminderSms: boolean;
  enableAutoBakiPaymentReceiptSms: boolean;
  customerReceiveReceiptSms: boolean;
  customerReceiveBakiAlertSms: boolean;
  customerReceiveBulkPromoSms: boolean;
  smsLanguage: 'bn' | 'en' | 'bilingual';
}

