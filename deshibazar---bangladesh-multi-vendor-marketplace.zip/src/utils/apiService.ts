import type { Product, Category, Order, CustomerUIConfig } from '../types';

const API_BASE = '/api';

export const apiService = {
  // System Health
  async getHealth() {
    try {
      const res = await fetch(`${API_BASE}/health`);
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  },

  // Live Internet Status
  async getInternetStatus() {
    try {
      const res = await fetch(`${API_BASE}/internet/status`);
      return await res.json();
    } catch (e: any) {
      return { online: false, error: e.message };
    }
  },

  // Products
  async getProducts(params?: Record<string, any>) {
    try {
      const query = new URLSearchParams();
      if (params) {
        Object.entries(params).forEach(([k, v]) => {
          if (v !== undefined && v !== null && v !== '') {
            query.append(k, String(v));
          }
        });
      }
      const res = await fetch(`${API_BASE}/products?${query.toString()}`);
      return await res.json();
    } catch (e: any) {
      console.warn('API getProducts error, falling back:', e);
      return { success: false, error: e.message };
    }
  },

  async getProductById(id: string) {
    try {
      const res = await fetch(`${API_BASE}/products/${id}`);
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  },

  async createProduct(product: Partial<Product>) {
    try {
      const res = await fetch(`${API_BASE}/products`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(product)
      });
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  },

  async updateProduct(id: string, product: Partial<Product>) {
    try {
      const res = await fetch(`${API_BASE}/products/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(product)
      });
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  },

  async deleteProduct(id: string) {
    try {
      const res = await fetch(`${API_BASE}/products/${id}`, { method: 'DELETE' });
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  },

  // Categories
  async getCategories() {
    try {
      const res = await fetch(`${API_BASE}/categories`);
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  },

  async createCategory(category: Partial<Category>) {
    try {
      const res = await fetch(`${API_BASE}/categories`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(category)
      });
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  },

  async updateCategory(id: string, update: Partial<Category>) {
    try {
      const res = await fetch(`${API_BASE}/categories/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(update)
      });
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  },

  async deleteCategory(id: string) {
    try {
      const res = await fetch(`${API_BASE}/categories/${id}`, { method: 'DELETE' });
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  },

  async resetCategories() {
    try {
      const res = await fetch(`${API_BASE}/categories/reset`, { method: 'POST' });
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  },

  // Orders
  async getOrders(userId?: string) {
    try {
      const url = userId ? `${API_BASE}/orders?userId=${encodeURIComponent(userId)}` : `${API_BASE}/orders`;
      const res = await fetch(url);
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  },

  async getOrder(orderIdOrNumber: string) {
    try {
      const res = await fetch(`${API_BASE}/orders/${encodeURIComponent(orderIdOrNumber)}`);
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  },

  async createOrder(orderData: Partial<Order>) {
    try {
      const res = await fetch(`${API_BASE}/orders`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderData)
      });
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  },

  async updateOrderStatus(orderId: string, status: Order['status']) {
    try {
      const res = await fetch(`${API_BASE}/orders/${encodeURIComponent(orderId)}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  },

  async cancelOrder(orderId: string, reason?: string) {
    try {
      const res = await fetch(`${API_BASE}/orders/${encodeURIComponent(orderId)}/cancel`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason })
      });
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  },

  async assignCourier(orderId: string, courierId: string, trackingCode?: string) {
    try {
      const res = await fetch(`${API_BASE}/orders/${encodeURIComponent(orderId)}/courier`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ courierId, trackingCode })
      });
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  },

  // Couriers
  async getCouriers() {
    try {
      const res = await fetch(`${API_BASE}/couriers`);
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  },

  async getCourierTracking(courierId: string, trackingCode: string, orderNumber?: string) {
    try {
      const query = orderNumber ? `?orderNumber=${encodeURIComponent(orderNumber)}` : '';
      const res = await fetch(`${API_BASE}/couriers/${encodeURIComponent(courierId)}/tracking/${encodeURIComponent(trackingCode)}${query}`);
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  },

  // Coupons
  async getCoupons() {
    try {
      const res = await fetch(`${API_BASE}/coupons`);
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  },

  async validateCoupon(code: string, subtotal: number) {
    try {
      const res = await fetch(`${API_BASE}/coupons/validate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code, subtotal })
      });
      return await res.json();
    } catch (e: any) {
      return { valid: false, discount: 0, message: e.message, messageBn: 'কুপন যাচাইকরণে সমস্যা হয়েছে' };
    }
  },

  // Store UI Settings
  async getSettings() {
    try {
      const res = await fetch(`${API_BASE}/settings/ui`);
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  },

  async updateSettings(settings: Partial<CustomerUIConfig>) {
    try {
      const res = await fetch(`${API_BASE}/settings/ui`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings)
      });
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  },

  // Newsletter
  async subscribeNewsletter(email: string) {
    try {
      const res = await fetch(`${API_BASE}/newsletter`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  },

  // Bangladeshi Banks & Payment Gateways
  async getBangladeshiBanks() {
    try {
      const res = await fetch(`${API_BASE}/payment/banks`);
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  },

  async getPaymentGateways() {
    try {
      const res = await fetch(`${API_BASE}/payment/gateways`);
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  },

  async updatePaymentGateways(config: any) {
    try {
      const res = await fetch(`${API_BASE}/payment/gateways`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config)
      });
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  },

  async toggleBankStatus(id: string, active: boolean) {
    try {
      const res = await fetch(`${API_BASE}/payment/banks/${encodeURIComponent(id)}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ active })
      });
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  },

  async updateBankDetails(id: string, details: any) {
    try {
      const res = await fetch(`${API_BASE}/payment/banks/${encodeURIComponent(id)}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(details)
      });
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  },

  async verifyBankTransfer(orderNumber: string, bankId: string, transactionRef: string) {
    try {
      const res = await fetch(`${API_BASE}/payment/verify-bank-transfer`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderNumber, bankId, transactionRef })
      });
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  }
};
