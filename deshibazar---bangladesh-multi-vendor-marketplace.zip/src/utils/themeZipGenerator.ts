import JSZip from 'jszip';

export interface ThemeZipOptions {
  themeName?: string;
  themeId?: string;
  storeName?: string;
  storeTagline?: string;
  primaryColor?: string;
  accentColor?: string;
  bgColor?: string;
  cardBg?: string;
  textColor?: string;
  textMuted?: string;
  borderColor?: string;
  borderRadius?: string; // '8px' | '16px' | '24px'
  currencySymbol?: string;
  fontFamily?: string;
  isDarkMode?: boolean;
}

export const DEFAULT_THEME_OPTIONS: ThemeZipOptions = {
  themeName: 'Deshi Heritage Emerald',
  themeId: 'deshi-emerald',
  storeName: 'DeshiBazar Commerce',
  storeTagline: 'Authentic Bangladeshi & Global Marketplace',
  primaryColor: '#059669',
  accentColor: '#f59e0b',
  bgColor: '#f8fafc',
  cardBg: '#ffffff',
  textColor: '#0f172a',
  textMuted: '#64748b',
  borderColor: '#e2e8f0',
  borderRadius: '16px',
  currencySymbol: '৳',
  fontFamily: "'Plus Jakarta Sans', system-ui, -apple-system, sans-serif",
  isDarkMode: false
};

export async function generateEcommerceThemeZip(options: Partial<ThemeZipOptions> = {}): Promise<JSZip> {
  const opts: ThemeZipOptions = { ...DEFAULT_THEME_OPTIONS, ...options };
  const zip = new JSZip();

  // 1. CSS STYLESHEET (css/styles.css)
  const cssContent = `/* ==========================================================
   DESHIBAZAR E-COMMERCE THEME - RESPONSIVE & FUNCTIONAL
   Theme Name: ${opts.themeName}
   Generated: ${new Date().toISOString()}
   ========================================================== */

:root {
  --primary: ${opts.primaryColor};
  --primary-hover: ${opts.primaryColor}dd;
  --primary-light: ${opts.primaryColor}1a;
  --accent: ${opts.accentColor};
  --accent-light: ${opts.accentColor}20;
  --bg-page: ${opts.bgColor};
  --bg-card: ${opts.cardBg};
  --bg-header: ${opts.cardBg};
  --text-main: ${opts.textColor};
  --text-muted: ${opts.textMuted};
  --border-color: ${opts.borderColor};
  --radius: ${opts.borderRadius};
  --radius-sm: calc(${opts.borderRadius} / 2);
  --shadow-sm: 0 1px 3px rgba(0,0,0,0.06), 0 1px 2px rgba(0,0,0,0.04);
  --shadow-md: 0 4px 6px -1px rgba(0,0,0,0.08), 0 2px 4px -2px rgba(0,0,0,0.06);
  --shadow-lg: 0 10px 15px -3px rgba(0,0,0,0.1), 0 4px 6px -4px rgba(0,0,0,0.08);
  --font-family: ${opts.fontFamily};
}

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: var(--font-family);
  background-color: var(--bg-page);
  color: var(--text-main);
  line-height: 1.5;
  -webkit-font-smoothing: antialiased;
  padding-bottom: 72px; /* space for mobile bottom bar */
}

@media (min-width: 769px) {
  body {
    padding-bottom: 0;
  }
}

a {
  color: inherit;
  text-decoration: none;
}

img {
  max-width: 100%;
  height: auto;
  display: block;
}

button, input, select, textarea {
  font-family: inherit;
  font-size: inherit;
}

.container {
  width: 100%;
  max-width: 1240px;
  margin: 0 auto;
  padding: 0 16px;
}

/* ==========================================================
   HEADER & NAVIGATION (Desktop & Mobile)
   ========================================================== */
.top-banner {
  background: var(--primary);
  color: #ffffff;
  font-size: 12px;
  padding: 8px 16px;
  text-align: center;
  font-weight: 600;
  letter-spacing: 0.3px;
}

.site-header {
  position: sticky;
  top: 0;
  z-index: 100;
  background: var(--bg-header);
  border-bottom: 1px solid var(--border-color);
  box-shadow: var(--shadow-sm);
  backdrop-filter: blur(10px);
}

.header-inner {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 68px;
  gap: 16px;
}

.brand-logo {
  display: flex;
  align-items: center;
  gap: 10px;
  font-weight: 800;
  font-size: 20px;
  color: var(--primary);
}

.brand-badge {
  background: var(--accent);
  color: #fff;
  font-size: 10px;
  font-weight: 700;
  padding: 2px 6px;
  border-radius: 9999px;
  text-transform: uppercase;
}

.search-box {
  flex: 1;
  max-width: 520px;
  position: relative;
  display: none;
}

@media (min-width: 768px) {
  .search-box {
    display: block;
  }
}

.search-input {
  width: 100%;
  height: 42px;
  padding: 0 16px 0 42px;
  border: 1px solid var(--border-color);
  border-radius: var(--radius);
  background: var(--bg-page);
  color: var(--text-main);
  outline: none;
  transition: all 0.2s;
}

.search-input:focus {
  border-color: var(--primary);
  box-shadow: 0 0 0 3px var(--primary-light);
}

.search-icon {
  position: absolute;
  left: 14px;
  top: 50%;
  transform: translateY(-50%);
  color: var(--text-muted);
}

.header-actions {
  display: flex;
  align-items: center;
  gap: 12px;
}

.nav-btn {
  background: transparent;
  border: none;
  cursor: pointer;
  padding: 8px;
  border-radius: var(--radius-sm);
  color: var(--text-main);
  display: flex;
  align-items: center;
  gap: 6px;
  font-weight: 600;
  font-size: 14px;
  position: relative;
  transition: background 0.2s;
}

.nav-btn:hover {
  background: var(--primary-light);
  color: var(--primary);
}

.cart-counter {
  position: absolute;
  top: 2px;
  right: 2px;
  background: var(--accent);
  color: white;
  font-size: 10px;
  font-weight: 700;
  width: 18px;
  height: 18px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* ==========================================================
   MOBILE BOTTOM BAR (App-like mobile experience)
   ========================================================== */
.mobile-bottom-bar {
  display: flex;
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  height: 64px;
  background: var(--bg-card);
  border-top: 1px solid var(--border-color);
  box-shadow: 0 -2px 10px rgba(0,0,0,0.06);
  z-index: 90;
  justify-content: space-around;
  align-items: center;
  padding: 0 8px;
}

@media (min-width: 769px) {
  .mobile-bottom-bar {
    display: none;
  }
}

.mobile-nav-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  font-size: 11px;
  font-weight: 600;
  color: var(--text-muted);
  text-decoration: none;
  position: relative;
  padding: 6px;
}

.mobile-nav-item.active,
.mobile-nav-item:hover {
  color: var(--primary);
}

.mobile-nav-item svg {
  width: 22px;
  height: 22px;
  margin-bottom: 2px;
}

/* ==========================================================
   HERO BANNER
   ========================================================== */
.hero-section {
  padding: 24px 0;
}

.hero-card {
  background: linear-gradient(135deg, var(--primary) 0%, #064e3b 100%);
  color: white;
  border-radius: var(--radius);
  padding: 40px 32px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  position: relative;
  overflow: hidden;
  box-shadow: var(--shadow-md);
}

@media (min-width: 768px) {
  .hero-card {
    padding: 60px 48px;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
  }
}

.hero-tag {
  display: inline-block;
  background: var(--accent);
  color: #fff;
  font-size: 12px;
  font-weight: 700;
  padding: 4px 12px;
  border-radius: 9999px;
  margin-bottom: 16px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.hero-title {
  font-size: 28px;
  font-weight: 800;
  line-height: 1.2;
  margin-bottom: 12px;
}

@media (min-width: 768px) {
  .hero-title {
    font-size: 42px;
  }
}

.hero-sub {
  font-size: 14px;
  opacity: 0.9;
  max-width: 480px;
  margin-bottom: 24px;
}

.hero-btn {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: white;
  color: var(--primary);
  font-weight: 700;
  font-size: 14px;
  padding: 12px 24px;
  border-radius: var(--radius);
  border: none;
  cursor: pointer;
  box-shadow: var(--shadow-md);
  transition: transform 0.2s, background 0.2s;
}

.hero-btn:hover {
  transform: translateY(-2px);
  background: #f8fafc;
}

/* ==========================================================
   CATEGORY PILLS (Touch-scrollable on mobile)
   ========================================================== */
.categories-strip {
  display: flex;
  gap: 12px;
  overflow-x: auto;
  padding: 8px 0 16px;
  scrollbar-width: none;
  -webkit-overflow-scrolling: touch;
}

.categories-strip::-webkit-scrollbar {
  display: none;
}

.cat-pill {
  flex-shrink: 0;
  background: var(--bg-card);
  border: 1px solid var(--border-color);
  border-radius: 9999px;
  padding: 8px 18px;
  font-size: 13px;
  font-weight: 600;
  color: var(--text-main);
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  transition: all 0.2s;
  box-shadow: var(--shadow-sm);
}

.cat-pill:hover,
.cat-pill.active {
  background: var(--primary);
  color: white;
  border-color: var(--primary);
}

/* ==========================================================
   FLASH SALE COUNTDOWN STRIP
   ========================================================== */
.flash-strip {
  background: #fef2f2;
  border: 1px solid #fecaca;
  border-radius: var(--radius);
  padding: 14px 20px;
  margin: 20px 0;
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}

.flash-title {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 800;
  color: #dc2626;
  font-size: 16px;
}

.timer-boxes {
  display: flex;
  gap: 6px;
  align-items: center;
  font-weight: 700;
  font-family: monospace;
}

.timer-box {
  background: #dc2626;
  color: white;
  padding: 4px 8px;
  border-radius: 6px;
  font-size: 14px;
}

/* ==========================================================
   PRODUCT GRID (Mobile Responsive: 2 cols on mobile, 4 on desktop)
   ========================================================== */
.section-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin: 28px 0 16px;
}

.section-title {
  font-size: 22px;
  font-weight: 800;
  color: var(--text-main);
}

.view-all-link {
  font-size: 13px;
  font-weight: 700;
  color: var(--primary);
  display: flex;
  align-items: center;
  gap: 4px;
}

.product-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 12px;
}

@media (min-width: 640px) {
  .product-grid {
    grid-template-columns: repeat(3, 1fr);
    gap: 16px;
  }
}

@media (min-width: 1024px) {
  .product-grid {
    grid-template-columns: repeat(4, 1fr);
    gap: 20px;
  }
}

.product-card {
  background: var(--bg-card);
  border: 1px solid var(--border-color);
  border-radius: var(--radius);
  overflow: hidden;
  box-shadow: var(--shadow-sm);
  display: flex;
  flex-direction: column;
  transition: transform 0.2s, box-shadow 0.2s, border-color 0.2s;
  position: relative;
}

.product-card:hover {
  transform: translateY(-4px);
  box-shadow: var(--shadow-lg);
  border-color: var(--primary);
}

.card-img-wrapper {
  position: relative;
  aspect-ratio: 1 / 1;
  background: #f1f5f9;
  overflow: hidden;
}

.card-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.4s;
}

.product-card:hover .card-img {
  transform: scale(1.05);
}

.discount-badge {
  position: absolute;
  top: 8px;
  left: 8px;
  background: #dc2626;
  color: white;
  font-size: 11px;
  font-weight: 800;
  padding: 3px 8px;
  border-radius: 6px;
  z-index: 2;
}

.wish-btn {
  position: absolute;
  top: 8px;
  right: 8px;
  width: 32px;
  height: 32px;
  border-radius: 50%;
  background: white;
  border: none;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: var(--shadow-sm);
  color: #94a3b8;
  transition: color 0.2s;
  z-index: 2;
}

.wish-btn:hover,
.wish-btn.active {
  color: #e11d48;
}

.card-body {
  padding: 14px;
  display: flex;
  flex-direction: column;
  flex: 1;
}

.card-category {
  font-size: 11px;
  font-weight: 600;
  color: var(--text-muted);
  text-transform: uppercase;
  margin-bottom: 4px;
}

.card-title {
  font-size: 14px;
  font-weight: 700;
  color: var(--text-main);
  line-height: 1.3;
  margin-bottom: 8px;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  height: 36px;
}

.rating-row {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 12px;
  font-weight: 700;
  color: #f59e0b;
  margin-bottom: 10px;
}

.price-row {
  display: flex;
  align-items: baseline;
  gap: 8px;
  margin-top: auto;
  margin-bottom: 12px;
}

.curr-price {
  font-size: 18px;
  font-weight: 800;
  color: var(--primary);
}

.old-price {
  font-size: 13px;
  color: var(--text-muted);
  text-decoration: line-through;
}

.add-cart-btn {
  width: 100%;
  height: 38px;
  background: var(--primary);
  color: white;
  border: none;
  border-radius: var(--radius-sm);
  font-weight: 700;
  font-size: 13px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  transition: background 0.2s, transform 0.1s;
}

.add-cart-btn:hover {
  background: var(--primary-hover);
}

.add-cart-btn:active {
  transform: scale(0.98);
}

/* ==========================================================
   SLIDE-OVER CART DRAWER
   ========================================================== */
.cart-drawer-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.5);
  backdrop-filter: blur(4px);
  z-index: 200;
  display: none;
  opacity: 0;
  transition: opacity 0.3s;
}

.cart-drawer-overlay.open {
  display: block;
  opacity: 1;
}

.cart-drawer {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  width: 100%;
  max-width: 420px;
  background: var(--bg-card);
  box-shadow: -4px 0 24px rgba(0,0,0,0.15);
  z-index: 201;
  transform: translateX(100%);
  transition: transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
  display: flex;
  flex-direction: column;
}

.cart-drawer.open {
  transform: translateX(0);
}

.cart-drawer-head {
  padding: 18px 20px;
  border-bottom: 1px solid var(--border-color);
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.cart-drawer-title {
  font-size: 18px;
  font-weight: 800;
  color: var(--text-main);
  display: flex;
  align-items: center;
  gap: 8px;
}

.close-btn {
  background: transparent;
  border: none;
  font-size: 24px;
  cursor: pointer;
  color: var(--text-muted);
  width: 36px;
  height: 36px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.close-btn:hover {
  background: var(--bg-page);
  color: var(--text-main);
}

.cart-items-list {
  flex: 1;
  overflow-y: auto;
  padding: 16px 20px;
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.cart-empty-state {
  text-align: center;
  padding: 48px 16px;
  color: var(--text-muted);
}

.cart-item-row {
  display: flex;
  gap: 12px;
  align-items: center;
  border-bottom: 1px solid var(--border-color);
  padding-bottom: 14px;
}

.cart-item-img {
  width: 64px;
  height: 64px;
  border-radius: var(--radius-sm);
  object-fit: cover;
  background: #f1f5f9;
}

.cart-item-info {
  flex: 1;
}

.cart-item-name {
  font-size: 13px;
  font-weight: 700;
  color: var(--text-main);
  margin-bottom: 4px;
}

.cart-item-price {
  font-size: 14px;
  font-weight: 800;
  color: var(--primary);
}

.qty-control {
  display: flex;
  align-items: center;
  border: 1px solid var(--border-color);
  border-radius: var(--radius-sm);
  overflow: hidden;
  height: 28px;
}

.qty-btn {
  background: var(--bg-page);
  border: none;
  width: 28px;
  height: 100%;
  font-weight: 700;
  cursor: pointer;
  color: var(--text-main);
}

.qty-display {
  padding: 0 10px;
  font-size: 12px;
  font-weight: 700;
}

.cart-drawer-foot {
  padding: 20px;
  border-top: 1px solid var(--border-color);
  background: var(--bg-page);
}

.cart-subtotal {
  display: flex;
  justify-content: space-between;
  font-size: 16px;
  font-weight: 800;
  margin-bottom: 16px;
}

.checkout-btn {
  width: 100%;
  height: 48px;
  background: var(--primary);
  color: white;
  border: none;
  border-radius: var(--radius);
  font-size: 15px;
  font-weight: 800;
  cursor: pointer;
  box-shadow: var(--shadow-md);
  transition: background 0.2s;
}

.checkout-btn:hover {
  background: var(--primary-hover);
}

/* ==========================================================
   TOAST NOTIFICATION
   ========================================================== */
.toast-container {
  position: fixed;
  bottom: 84px;
  right: 16px;
  z-index: 300;
  display: flex;
  flex-direction: column;
  gap: 8px;
  pointer-events: none;
}

@media (min-width: 769px) {
  .toast-container {
    bottom: 24px;
  }
}

.toast {
  background: #0f172a;
  color: white;
  padding: 12px 18px;
  border-radius: var(--radius-sm);
  font-size: 13px;
  font-weight: 600;
  box-shadow: var(--shadow-lg);
  display: flex;
  align-items: center;
  gap: 10px;
  animation: slideInToast 0.3s ease forwards;
  pointer-events: auto;
}

@keyframes slideInToast {
  from {
    transform: translateY(20px);
    opacity: 0;
  }
  to {
    transform: translateY(0);
    opacity: 1;
  }
}

/* ==========================================================
   FOOTER
   ========================================================== */
.site-footer {
  background: var(--bg-card);
  border-top: 1px solid var(--border-color);
  padding: 48px 0 24px;
  margin-top: 60px;
}

.footer-grid {
  display: grid;
  grid-template-columns: 1fr;
  gap: 32px;
  margin-bottom: 40px;
}

@media (min-width: 768px) {
  .footer-grid {
    grid-template-columns: 2fr 1fr 1fr 1fr;
  }
}

.footer-brand p {
  font-size: 13px;
  color: var(--text-muted);
  margin-top: 12px;
  max-width: 320px;
}

.footer-col h4 {
  font-size: 14px;
  font-weight: 800;
  margin-bottom: 16px;
  color: var(--text-main);
}

.footer-col ul {
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.footer-col a {
  font-size: 13px;
  color: var(--text-muted);
  transition: color 0.2s;
}

.footer-col a:hover {
  color: var(--primary);
}

.footer-bottom {
  border-top: 1px solid var(--border-color);
  padding-top: 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
  font-size: 12px;
  color: var(--text-muted);
  text-align: center;
}

@media (min-width: 768px) {
  .footer-bottom {
    flex-direction: row;
    justify-content: space-between;
  }
}
`;

  // 2. JAVASCRIPT (js/store.js)
  const jsContent = `/* ==========================================================
   DESHIBAZAR E-COMMERCE THEME - STORE ENGINE
   Features: Real Working Cart, Live Search, Countdown Timer,
   Mobile Drawer, Toast Notifications, Currency Toggle.
   ========================================================== */

const THEME_CONFIG = ${JSON.stringify(opts, null, 2)};

// Mock Seed Catalog
const PRODUCTS_DATA = [
  {
    id: 'prod-1',
    name: 'Pure Sundarbans Wild Honey (500g)',
    category: 'Groceries',
    price: 450,
    oldPrice: 550,
    rating: 4.9,
    reviews: 128,
    image: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=500&q=80',
    tag: '100% Organic'
  },
  {
    id: 'prod-2',
    name: 'Premium Royal Dhakai Jamdani Saree',
    category: 'Fashion',
    price: 3200,
    oldPrice: 4200,
    rating: 5.0,
    reviews: 94,
    image: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=500&q=80',
    tag: 'Heritage Deshi'
  },
  {
    id: 'prod-3',
    name: 'Fresh Padma River Hilsha Fish (1.2kg)',
    category: 'Fish & Meat',
    price: 1850,
    oldPrice: 2200,
    rating: 4.8,
    reviews: 215,
    image: 'https://images.unsplash.com/photo-1544943910-4c1dc44a0551?auto=format&fit=crop&w=500&q=80',
    tag: 'Chilled Ice Pack'
  },
  {
    id: 'prod-4',
    name: 'Traditional Tangail Hand-Woven Gamcha Pack',
    category: 'Fashion',
    price: 380,
    oldPrice: 450,
    rating: 4.7,
    reviews: 62,
    image: 'https://images.unsplash.com/photo-1606744824163-985d376605aa?auto=format&fit=crop&w=500&q=80',
    tag: 'Best Seller'
  },
  {
    id: 'prod-5',
    name: 'Aroma Premium Chinigura Rice (5kg)',
    category: 'Groceries',
    price: 680,
    oldPrice: 750,
    rating: 4.9,
    reviews: 178,
    image: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=500&q=80',
    tag: 'Polao Special'
  },
  {
    id: 'prod-6',
    name: 'Cold-Pressed Mustard Oil Ghani Bhanga (1L)',
    category: 'Groceries',
    price: 280,
    oldPrice: 320,
    rating: 4.8,
    reviews: 89,
    image: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?auto=format&fit=crop&w=500&q=80',
    tag: 'Pure Ghani'
  },
  {
    id: 'prod-7',
    name: 'Smart Bluetooth ANC Wireless Earbuds',
    category: 'Electronics',
    price: 1450,
    oldPrice: 1950,
    rating: 4.6,
    reviews: 140,
    image: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=500&q=80',
    tag: 'Gadget'
  },
  {
    id: 'prod-8',
    name: 'Handcrafted Clay Tea Pot Set (Bogra Terracotta)',
    category: 'Home & Living',
    price: 520,
    oldPrice: 650,
    rating: 4.9,
    reviews: 43,
    image: 'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?auto=format&fit=crop&w=500&q=80',
    tag: 'Artisan'
  }
];

class StoreEngine {
  constructor() {
    this.cart = this.loadCart();
    this.wishlist = this.loadWishlist();
    this.currency = THEME_CONFIG.currencySymbol || '৳';
    this.init();
  }

  init() {
    this.renderProducts();
    this.updateCartBadges();
    this.bindEvents();
    this.startCountdown();
  }

  loadCart() {
    try {
      const data = localStorage.getItem('demo_theme_cart');
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  saveCart() {
    try {
      localStorage.setItem('demo_theme_cart', JSON.stringify(this.cart));
    } catch {}
    this.updateCartBadges();
    this.renderCartDrawer();
  }

  loadWishlist() {
    try {
      const data = localStorage.getItem('demo_theme_wishlist');
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  saveWishlist() {
    try {
      localStorage.setItem('demo_theme_wishlist', JSON.stringify(this.wishlist));
    } catch {}
  }

  formatPrice(num) {
    return this.currency + Number(num).toLocaleString();
  }

  addToCart(productId, qty = 1) {
    const prod = PRODUCTS_DATA.find(p => p.id === productId);
    if (!prod) return;

    const existing = this.cart.find(item => item.id === productId);
    if (existing) {
      existing.qty += qty;
    } else {
      this.cart.push({ ...prod, qty });
    }
    this.saveCart();
    this.showToast('Added "' + prod.name + '" to cart!');
  }

  removeFromCart(productId) {
    this.cart = this.cart.filter(item => item.id !== productId);
    this.saveCart();
    this.showToast('Item removed from cart.');
  }

  updateQty(productId, delta) {
    const item = this.cart.find(i => i.id === productId);
    if (!item) return;
    item.qty += delta;
    if (item.qty <= 0) {
      this.removeFromCart(productId);
    } else {
      this.saveCart();
    }
  }

  toggleWishlist(productId) {
    const idx = this.wishlist.indexOf(productId);
    if (idx > -1) {
      this.wishlist.splice(idx, 1);
      this.showToast('Removed from wishlist');
    } else {
      this.wishlist.push(productId);
      this.showToast('Added to wishlist ❤️');
    }
    this.saveWishlist();
    this.renderProducts();
  }

  updateCartBadges() {
    const totalCount = this.cart.reduce((sum, item) => sum + item.qty, 0);
    document.querySelectorAll('.cart-counter').forEach(el => {
      el.textContent = totalCount;
      el.style.display = totalCount > 0 ? 'flex' : 'none';
    });
  }

  renderProducts(filterCategory = null, searchQuery = '') {
    const grid = document.getElementById('products-grid');
    if (!grid) return;

    let items = PRODUCTS_DATA;
    if (filterCategory && filterCategory !== 'All') {
      items = items.filter(p => p.category === filterCategory);
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      items = items.filter(p => p.name.toLowerCase().includes(q) || p.category.toLowerCase().includes(q));
    }

    if (items.length === 0) {
      grid.innerHTML = '<div style="grid-column: 1 / -1; text-align: center; padding: 40px; color: var(--text-muted); font-weight: 600;">No products match your criteria.</div>';
      return;
    }

    grid.innerHTML = items.map(product => {
      const isWished = this.wishlist.includes(product.id);
      const discount = Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100);
      return \`
        <div class="product-card" data-id="\${product.id}">
          <div class="card-img-wrapper">
            <span class="discount-badge">-\${discount}%</span>
            <button class="wish-btn \${isWished ? 'active' : ''}" onclick="window.store.toggleWishlist('\${product.id}')" title="Wishlist">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="\${isWished ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
            </button>
            <img src="\${product.image}" alt="\${product.name}" class="card-img" loading="lazy">
          </div>
          <div class="card-body">
            <span class="card-category">\${product.category}</span>
            <h3 class="card-title">\${product.name}</h3>
            <div class="rating-row">
              <span>★ \${product.rating}</span>
              <span style="color: var(--text-muted); font-size: 11px;">(\${product.reviews})</span>
            </div>
            <div class="price-row">
              <span class="curr-price">\${this.formatPrice(product.price)}</span>
              <span class="old-price">\${this.formatPrice(product.oldPrice)}</span>
            </div>
            <button class="add-cart-btn" onclick="window.store.addToCart('\${product.id}')">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>
              <span>Add to Cart</span>
            </button>
          </div>
        </div>
      \`;
    }).join('');
  }

  renderCartDrawer() {
    const list = document.getElementById('cart-items-list');
    const totalEl = document.getElementById('cart-subtotal-val');
    if (!list || !totalEl) return;

    if (this.cart.length === 0) {
      list.innerHTML = \`
        <div class="cart-empty-state">
          <svg style="margin: 0 auto 12px; opacity: 0.5;" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>
          <p style="font-weight: 700; margin-bottom: 4px;">Your cart is empty</p>
          <p style="font-size: 12px;">Discover fresh deals and add items!</p>
        </div>
      \`;
      totalEl.textContent = this.formatPrice(0);
      return;
    }

    const subtotal = this.cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
    totalEl.textContent = this.formatPrice(subtotal);

    list.innerHTML = this.cart.map(item => \`
      <div class="cart-item-row">
        <img src="\${item.image}" alt="\${item.name}" class="cart-item-img">
        <div class="cart-item-info">
          <div class="cart-item-name">\${item.name}</div>
          <div class="cart-item-price">\${this.formatPrice(item.price)}</div>
        </div>
        <div class="qty-control">
          <button class="qty-btn" onclick="window.store.updateQty('\${item.id}', -1)">-</button>
          <span class="qty-display">\${item.qty}</span>
          <button class="qty-btn" onclick="window.store.updateQty('\${item.id}', 1)">+</button>
        </div>
        <button class="close-btn" style="width:28px; height:28px; font-size:16px;" onclick="window.store.removeFromCart('\${item.id}')">✕</button>
      </div>
    \`).join('');
  }

  openCart() {
    this.renderCartDrawer();
    const overlay = document.getElementById('cart-drawer-overlay');
    const drawer = document.getElementById('cart-drawer');
    if (overlay && drawer) {
      overlay.classList.add('open');
      drawer.classList.add('open');
    }
  }

  closeCart() {
    const overlay = document.getElementById('cart-drawer-overlay');
    const drawer = document.getElementById('cart-drawer');
    if (overlay && drawer) {
      overlay.classList.remove('open');
      drawer.classList.remove('open');
    }
  }

  showToast(message) {
    let container = document.getElementById('toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'toast-container';
      container.className = 'toast-container';
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = \`
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
      <span>\${message}</span>
    \`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 2800);
  }

  startCountdown() {
    const hoursEl = document.getElementById('timer-hours');
    const minsEl = document.getElementById('timer-mins');
    const secsEl = document.getElementById('timer-secs');
    if (!hoursEl || !minsEl || !secsEl) return;

    let totalSeconds = 11 * 3600 + 45 * 60 + 20;
    setInterval(() => {
      if (totalSeconds > 0) totalSeconds--;
      const h = Math.floor(totalSeconds / 3600);
      const m = Math.floor((totalSeconds % 3600) / 60);
      const s = totalSeconds % 60;
      hoursEl.textContent = String(h).padStart(2, '0');
      minsEl.textContent = String(m).padStart(2, '0');
      secsEl.textContent = String(s).padStart(2, '0');
    }, 1000);
  }

  bindEvents() {
    // Search
    const searchInput = document.getElementById('header-search-input');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        this.renderProducts(null, e.target.value);
      });
    }

    // Category pills
    document.querySelectorAll('.cat-pill').forEach(pill => {
      pill.addEventListener('click', (e) => {
        document.querySelectorAll('.cat-pill').forEach(p => p.classList.remove('active'));
        pill.classList.add('active');
        const cat = pill.getAttribute('data-cat');
        this.renderProducts(cat);
      });
    });

    // Cart Drawer Triggers
    document.querySelectorAll('.trigger-open-cart').forEach(btn => {
      btn.addEventListener('click', () => this.openCart());
    });

    const closeCartBtn = document.getElementById('close-cart-btn');
    if (closeCartBtn) {
      closeCartBtn.addEventListener('click', () => this.closeCart());
    }

    const overlay = document.getElementById('cart-drawer-overlay');
    if (overlay) {
      overlay.addEventListener('click', () => this.closeCart());
    }
  }
}

// Bootstrap Store on DOM ready
document.addEventListener('DOMContentLoaded', () => {
  window.store = new StoreEngine();
});
`;

  // 3. HOME PAGE (index.html)
  const indexHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
  <title>${opts.storeName} - ${opts.storeTagline}</title>
  <meta name="description" content="Mobile responsive, fully functional online e-commerce marketplace powered by ${opts.themeName}.">
  <meta name="theme-color" content="${opts.primaryColor}">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/styles.css">
</head>
<body>

  <!-- Top Promotional Banner -->
  <div class="top-banner">
    ⚡ <span>Nationwide 24-48h Delivery | Free shipping on orders over ${opts.currencySymbol}1,500</span>
  </div>

  <!-- Header -->
  <header class="site-header">
    <div class="container">
      <div class="header-inner">
        <!-- Logo -->
        <a href="index.html" class="brand-logo">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="m2 7 4.41-4.41A2 2 0 0 1 7.83 2h8.34a2 2 0 0 1 1.42.59L22 7"/><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><path d="M15 22v-4a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2v4"/><path d="M2 7h20"/></svg>
          <span>${opts.storeName}</span>
          <span class="brand-badge">BD</span>
        </a>

        <!-- Desktop Search -->
        <div class="search-box">
          <svg class="search-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
          <input type="text" id="header-search-input" class="search-input" placeholder="Search rice, honey, fish, gadgets, fashion...">
        </div>

        <!-- Actions -->
        <div class="header-actions">
          <a href="shop.html" class="nav-btn" style="display:none; @media(min-width:768px){display:flex;}">
            <span>Catalogue</span>
          </a>
          <button class="nav-btn trigger-open-cart" title="Shopping Cart">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>
            <span class="cart-counter">0</span>
          </button>
        </div>
      </div>
    </div>
  </header>

  <!-- Main Content -->
  <main class="container">

    <!-- Hero Card -->
    <section class="hero-section">
      <div class="hero-card">
        <div>
          <span class="hero-tag">🌾 Authentic Deshi Collection</span>
          <h1 class="hero-title">Fresh River Catches, Pure Organic Honey & Handcrafts</h1>
          <p class="hero-sub">Directly sourced from rural Bengal artisans, farmers and verified suppliers with nationwide cold-chain delivery.</p>
          <a href="shop.html" class="hero-btn">
            <span>Shop Fresh Now</span>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
          </a>
        </div>
      </div>
    </section>

    <!-- Category Pills Strip -->
    <section>
      <div class="categories-strip">
        <button class="cat-pill active" data-cat="All">🔥 All Products</button>
        <button class="cat-pill" data-cat="Groceries">🌾 Groceries</button>
        <button class="cat-pill" data-cat="Fish & Meat">🐟 River Fish & Meat</button>
        <button class="cat-pill" data-cat="Fashion">👘 Deshi Fashion</button>
        <button class="cat-pill" data-cat="Electronics">⚡ Electronics</button>
        <button class="cat-pill" data-cat="Home & Living">🏺 Artisan Living</button>
      </div>
    </section>

    <!-- Flash Sale Countdown Strip -->
    <section>
      <div class="flash-strip">
        <div class="flash-title">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="#dc2626" stroke="#dc2626"><path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/></svg>
          <span>Today's Flash Deals (Up to 40% Off)</span>
        </div>
        <div class="timer-boxes">
          <span>Ends in:</span>
          <span class="timer-box" id="timer-hours">11</span>:
          <span class="timer-box" id="timer-mins">45</span>:
          <span class="timer-box" id="timer-secs">20</span>
        </div>
      </div>
    </section>

    <!-- Product Grid -->
    <section>
      <div class="section-head">
        <h2 class="section-title">Trending & Featured Items</h2>
        <a href="shop.html" class="view-all-link">
          <span>View Catalog</span>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
        </a>
      </div>

      <div id="products-grid" class="product-grid">
        <!-- Rendered dynamically by js/store.js -->
      </div>
    </section>

  </main>

  <!-- Cart Slide-Over Drawer -->
  <div id="cart-drawer-overlay" class="cart-drawer-overlay"></div>
  <div id="cart-drawer" class="cart-drawer">
    <div class="cart-drawer-head">
      <div class="cart-drawer-title">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>
        <span>Your Cart</span>
      </div>
      <button id="close-cart-btn" class="close-btn" title="Close Cart">✕</button>
    </div>

    <div id="cart-items-list" class="cart-items-list">
      <!-- Injected by store.js -->
    </div>

    <div class="cart-drawer-foot">
      <div class="cart-subtotal">
        <span>Estimated Subtotal:</span>
        <span id="cart-subtotal-val">${opts.currencySymbol}0</span>
      </div>
      <a href="cart.html">
        <button class="checkout-btn">Proceed to Secure Checkout →</button>
      </a>
    </div>
  </div>

  <!-- Mobile Bottom Floating Navigation Bar -->
  <nav class="mobile-bottom-bar">
    <a href="index.html" class="mobile-nav-item active">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
      <span>Home</span>
    </a>
    <a href="shop.html" class="mobile-nav-item">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect width="7" height="7" x="3" y="3" rx="1"/><rect width="7" height="7" x="14" y="3" rx="1"/><rect width="7" height="7" x="14" y="14" rx="1"/><rect width="7" height="7" x="3" y="14" rx="1"/></svg>
      <span>Shop</span>
    </a>
    <a href="javascript:void(0)" class="mobile-nav-item trigger-open-cart">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>
      <span>Cart</span>
      <span class="cart-counter" style="position: absolute; top: 0px; right: 12px;">0</span>
    </a>
    <a href="cart.html" class="mobile-nav-item">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/></svg>
      <span>Checkout</span>
    </a>
  </nav>

  <!-- Site Footer -->
  <footer class="site-footer">
    <div class="container">
      <div class="footer-grid">
        <div class="footer-brand">
          <div class="brand-logo">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="m2 7 4.41-4.41A2 2 0 0 1 7.83 2h8.34a2 2 0 0 1 1.42.59L22 7"/><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><path d="M15 22v-4a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2v4"/><path d="M2 7h20"/></svg>
            <span>${opts.storeName}</span>
          </div>
          <p>${opts.storeTagline}. Handpicked authentic items with verified source traceability.</p>
        </div>
        <div class="footer-col">
          <h4>Customer Care</h4>
          <ul>
            <li><a href="#">Order Tracking</a></li>
            <li><a href="#">Fulfillment Guidelines</a></li>
            <li><a href="#">Return & Refund Policy</a></li>
            <li><a href="#">Help & Support</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h4>Payment Methods</h4>
          <ul>
            <li><a href="#">bKash & Nagad</a></li>
            <li><a href="#">Rocket / Upay</a></li>
            <li><a href="#">Cash on Delivery (COD)</a></li>
            <li><a href="#">Credit / Debit Cards</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h4>Security & Trust</h4>
          <ul>
            <li><a href="#">100% Secure Checkout</a></li>
            <li><a href="#">Strict Quality Check</a></li>
            <li><a href="#">24/7 Hotline Support</a></li>
          </ul>
        </div>
      </div>
      <div class="footer-bottom">
        <span>© ${new Date().getFullYear()} ${opts.storeName}. All rights reserved.</span>
        <span>Theme: ${opts.themeName} (Mobile Responsive & Functional HTML5)</span>
      </div>
    </div>
  </footer>

  <script src="js/store.js"></script>
</body>
</html>
`;

  // 4. SHOP PAGE (shop.html)
  const shopHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
  <title>Shop Catalogue - ${opts.storeName}</title>
  <meta name="theme-color" content="${opts.primaryColor}">
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/styles.css">
</head>
<body>
  <!-- Top Banner -->
  <div class="top-banner">
    ⚡ <span>Full Product Catalogue | Fast nationwide delivery</span>
  </div>

  <!-- Header -->
  <header class="site-header">
    <div class="container">
      <div class="header-inner">
        <a href="index.html" class="brand-logo">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="m2 7 4.41-4.41A2 2 0 0 1 7.83 2h8.34a2 2 0 0 1 1.42.59L22 7"/><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><path d="M15 22v-4a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2v4"/><path d="M2 7h20"/></svg>
          <span>${opts.storeName}</span>
        </a>

        <div class="search-box">
          <svg class="search-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
          <input type="text" id="header-search-input" class="search-input" placeholder="Search catalog...">
        </div>

        <div class="header-actions">
          <a href="index.html" class="nav-btn">Home</a>
          <button class="nav-btn trigger-open-cart">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>
            <span class="cart-counter">0</span>
          </button>
        </div>
      </div>
    </div>
  </header>

  <main class="container" style="padding-top: 24px;">
    <!-- Filter Pills -->
    <div class="categories-strip">
      <button class="cat-pill active" data-cat="All">All Categories</button>
      <button class="cat-pill" data-cat="Groceries">Groceries</button>
      <button class="cat-pill" data-cat="Fish & Meat">Fish & Meat</button>
      <button class="cat-pill" data-cat="Fashion">Fashion</button>
      <button class="cat-pill" data-cat="Electronics">Electronics</button>
      <button class="cat-pill" data-cat="Home & Living">Home & Living</button>
    </div>

    <div class="section-head">
      <h2 class="section-title">All Products Catalogue</h2>
      <span style="font-size: 13px; color: var(--text-muted);">Verified Quality Guaranteed</span>
    </div>

    <!-- Product Grid -->
    <div id="products-grid" class="product-grid">
      <!-- Injected by js/store.js -->
    </div>
  </main>

  <!-- Mobile Bottom Bar -->
  <nav class="mobile-bottom-bar">
    <a href="index.html" class="mobile-nav-item">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
      <span>Home</span>
    </a>
    <a href="shop.html" class="mobile-nav-item active">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect width="7" height="7" x="3" y="3" rx="1"/><rect width="7" height="7" x="14" y="3" rx="1"/><rect width="7" height="7" x="14" y="14" rx="1"/><rect width="7" height="7" x="3" y="14" rx="1"/></svg>
      <span>Shop</span>
    </a>
    <a href="javascript:void(0)" class="mobile-nav-item trigger-open-cart">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>
      <span>Cart</span>
      <span class="cart-counter" style="position: absolute; top: 0; right: 12px;">0</span>
    </a>
    <a href="cart.html" class="mobile-nav-item">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/></svg>
      <span>Checkout</span>
    </a>
  </nav>

  <!-- Cart Drawer -->
  <div id="cart-drawer-overlay" class="cart-drawer-overlay"></div>
  <div id="cart-drawer" class="cart-drawer">
    <div class="cart-drawer-head">
      <div class="cart-drawer-title">Shopping Cart</div>
      <button id="close-cart-btn" class="close-btn">✕</button>
    </div>
    <div id="cart-items-list" class="cart-items-list"></div>
    <div class="cart-drawer-foot">
      <div class="cart-subtotal">
        <span>Estimated Total:</span>
        <span id="cart-subtotal-val">${opts.currencySymbol}0</span>
      </div>
      <a href="cart.html"><button class="checkout-btn">Go to Checkout →</button></a>
    </div>
  </div>

  <script src="js/store.js"></script>
</body>
</html>
`;

  // 5. CART & CHECKOUT PAGE (cart.html)
  const cartHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
  <title>Shopping Cart & Checkout - ${opts.storeName}</title>
  <meta name="theme-color" content="${opts.primaryColor}">
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/styles.css">
  <style>
    .checkout-layout {
      display: grid;
      grid-template-columns: 1fr;
      gap: 24px;
      margin: 32px 0 60px;
    }
    @media (min-width: 900px) {
      .checkout-layout {
        grid-template-columns: 1.5fr 1fr;
      }
    }
    .checkout-card {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: var(--radius);
      padding: 24px;
      box-shadow: var(--shadow-sm);
    }
    .form-group {
      margin-bottom: 16px;
    }
    .form-label {
      display: block;
      font-size: 13px;
      font-weight: 700;
      margin-bottom: 6px;
      color: var(--text-main);
    }
    .form-input {
      width: 100%;
      height: 44px;
      padding: 0 14px;
      border: 1px solid var(--border-color);
      border-radius: var(--radius-sm);
      background: var(--bg-page);
      color: var(--text-main);
    }
    .payment-radio-group {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 10px;
      margin-top: 8px;
    }
    .pay-card {
      border: 1px solid var(--border-color);
      border-radius: var(--radius-sm);
      padding: 12px;
      display: flex;
      align-items: center;
      gap: 8px;
      cursor: pointer;
      font-size: 13px;
      font-weight: 700;
    }
    .pay-card input {
      accent-color: var(--primary);
    }
  </style>
</head>
<body>
  <header class="site-header">
    <div class="container">
      <div class="header-inner">
        <a href="index.html" class="brand-logo">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="m2 7 4.41-4.41A2 2 0 0 1 7.83 2h8.34a2 2 0 0 1 1.42.59L22 7"/><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><path d="M15 22v-4a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2v4"/><path d="M2 7h20"/></svg>
          <span>${opts.storeName}</span>
        </a>
        <a href="shop.html" class="nav-btn">← Continue Shopping</a>
      </div>
    </div>
  </header>

  <main class="container">
    <h1 style="font-size: 26px; font-weight: 800; margin-top: 24px;">Checkout & Order Placement</h1>
    
    <div class="checkout-layout">
      <!-- Shipping Form -->
      <div class="checkout-card">
        <h2 style="font-size: 18px; font-weight: 800; margin-bottom: 16px;">1. Shipping & Delivery Address</h2>
        <form id="checkout-order-form" onsubmit="handlePlaceOrder(event)">
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
            <div class="form-group">
              <label class="form-label">Full Name *</label>
              <input type="text" class="form-input" required placeholder="e.g. Tanvir Ahmed">
            </div>
            <div class="form-group">
              <label class="form-label">Phone Number *</label>
              <input type="tel" class="form-input" required placeholder="017XXXXXXXX">
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Full Address *</label>
            <input type="text" class="form-input" required placeholder="House, Road, Area, City, Post code">
          </div>
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
            <div class="form-group">
              <label class="form-label">Division / City</label>
              <select class="form-input">
                <option>Dhaka</option>
                <option>Chittagong</option>
                <option>Sylhet</option>
                <option>Rajshahi</option>
                <option>Khulna</option>
                <option>Barisal</option>
                <option>Rangpur</option>
                <option>Mymensingh</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Delivery Speed</label>
              <select class="form-input">
                <option>Regular Delivery (24-48 Hours)</option>
                <option>Express Same-Day (Dhaka Only)</option>
              </select>
            </div>
          </div>

          <h2 style="font-size: 18px; font-weight: 800; margin: 24px 0 12px;">2. Payment Method</h2>
          <div class="payment-radio-group">
            <label class="pay-card">
              <input type="radio" name="paymethod" value="cod" checked>
              <span>Cash on Delivery (ক্যাশ অন ডেলিভারি)</span>
            </label>
            <label class="pay-card">
              <input type="radio" name="paymethod" value="bkash">
              <span>bKash (বিকাশ)</span>
            </label>
            <label class="pay-card">
              <input type="radio" name="paymethod" value="nagad">
              <span>Nagad (নগদ)</span>
            </label>
            <label class="pay-card">
              <input type="radio" name="paymethod" value="card">
              <span>Credit / Debit Card</span>
            </label>
          </div>

          <button type="submit" class="checkout-btn" style="margin-top: 24px;">Confirm & Place Order →</button>
        </form>
      </div>

      <!-- Order Summary Card -->
      <div class="checkout-card" style="height: fit-content;">
        <h2 style="font-size: 18px; font-weight: 800; margin-bottom: 16px;">Order Summary</h2>
        <div id="checkout-cart-summary">
          <!-- Rendered by inline script -->
        </div>
      </div>
    </div>
  </main>

  <script src="js/store.js"></script>
  <script>
    function renderCheckoutSummary() {
      const summaryBox = document.getElementById('checkout-cart-summary');
      if (!summaryBox || !window.store) return;
      const cart = window.store.cart;
      if (cart.length === 0) {
        summaryBox.innerHTML = '<p style="color: var(--text-muted); font-size: 13px;">Your cart is empty. Add products from the shop first.</p>';
        return;
      }
      const subtotal = cart.reduce((sum, i) => sum + (i.price * i.qty), 0);
      const delivery = subtotal > 1500 ? 0 : 60;
      const total = subtotal + delivery;

      summaryBox.innerHTML = \`
        <div style="display:flex; flex-direction:column; gap:10px; margin-bottom: 16px; max-height: 240px; overflow-y: auto;">
          \${cart.map(i => \`
            <div style="display:flex; justify-content:space-between; font-size:13px;">
              <span>\${i.name} (x\${i.qty})</span>
              <span style="font-weight:700;">\${window.store.formatPrice(i.price * i.qty)}</span>
            </div>
          \`).join('')}
        </div>
        <hr style="border:0; border-top:1px solid var(--border-color); margin: 12px 0;">
        <div style="display:flex; justify-content:space-between; font-size:14px; margin-bottom: 6px;">
          <span>Subtotal:</span>
          <span>\${window.store.formatPrice(subtotal)}</span>
        </div>
        <div style="display:flex; justify-content:space-between; font-size:14px; margin-bottom: 12px;">
          <span>Delivery Fee:</span>
          <span>\${delivery === 0 ? 'FREE' : window.store.formatPrice(delivery)}</span>
        </div>
        <div style="display:flex; justify-content:space-between; font-size:18px; font-weight:800; color:var(--primary);">
          <span>Total Payable:</span>
          <span>\${window.store.formatPrice(total)}</span>
        </div>
      \`;
    }

    function handlePlaceOrder(e) {
      e.preventDefault();
      if (!window.store || window.store.cart.length === 0) {
        alert('Your cart is empty! Please add some items to proceed.');
        return;
      }
      const orderNum = 'DB-' + Math.floor(100000 + Math.random() * 900000);
      alert('Order Placed Successfully! Your Order Number is: ' + orderNum + '\\nThank you for shopping with ' + '${opts.storeName}!');
      window.store.cart = [];
      window.store.saveCart();
      window.location.href = 'index.html';
    }

    document.addEventListener('DOMContentLoaded', () => {
      setTimeout(renderCheckoutSummary, 200);
    });
  </script>
</body>
</html>
`;

  // 6. README.md
  const readmeContent = `# ${opts.storeName} - E-Commerce Theme

A lightweight, mobile-responsive, production-ready, fully functional HTML5/CSS3/Vanilla JavaScript e-commerce website template.

## Highlights
- **100% Mobile Responsive**: Tested on mobile phones, tablets, and desktop displays.
- **App-like Mobile Bottom Navigation Bar**: Easy touch access to Home, Shop, Cart, and Checkout.
- **Working LocalStorage Cart**: Add items, update quantities, remove items, live count badges.
- **Slide-over Cart Drawer**: Smooth slide-in cart on both desktop and mobile.
- **Working Wishlist**: Toggle favorites with instant feedback.
- **Live Search & Category Filtering**: Instant real-time filtering with zero page reload.
- **Flash Sale Countdown Clock**: Engaging promotional timer.
- **Checkout Flow**: Complete shipping form with Bangladeshi payment simulators (bKash, Nagad, Cash on Delivery).
- **Zero Framework Dependency**: Runs directly in any browser with no build step required.

## Files Structure
\`\`\`
├── index.html          # Main storefront homepage with hero, flash sale, categories & product grid
├── shop.html           # Full catalogue view with instant category filters
├── cart.html           # Checkout & shopping cart review page
├── css/
│   └── styles.css      # Modular CSS stylesheet with configurable CSS variables
├── js/
│   └── store.js        # Complete client-side e-commerce store engine
├── theme-config.json   # Theme metadata and color palette configuration
└── README.md           # Instructions and documentation
\`\`\`

## Quick Start
1. Unzip the downloaded file.
2. Double click \`index.html\` to open it in your favorite web browser (Chrome, Safari, Firefox, Edge).
3. To customize colors, edit the CSS variables in \`css/styles.css\` or \`theme-config.json\`.
4. To connect to your backend or WooCommerce, update the \`PRODUCTS_DATA\` array in \`js/store.js\`.

Generated by DeshiBazar Theme Studio.
`;

  // 7. THEME CONFIG JSON
  const configJson = JSON.stringify(opts, null, 2);

  // Add files to ZIP
  zip.file('index.html', indexHtml);
  zip.file('shop.html', shopHtml);
  zip.file('cart.html', cartHtml);
  zip.file('css/styles.css', cssContent);
  zip.file('js/store.js', jsContent);
  zip.file('theme-config.json', configJson);
  zip.file('README.md', readmeContent);

  return zip;
}
