import React, { useState, useMemo, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { AdminBulkSmsPanel } from '../components/AdminBulkSmsPanel';
import { 
  LayoutDashboard, 
  DollarSign, 
  ShoppingBag, 
  Users, 
  Store, 
  AlertTriangle, 
  ShieldCheck, 
  CheckCircle2, 
  Plus, 
  Tag, 
  BarChart3, 
  Truck,
  Sparkles,
  ExternalLink,
  Image as ImageIcon,
  Layers,
  Settings,
  FileText,
  CreditCard,
  Search,
  Eye,
  Check,
  Receipt,
  X,
  Download,
  ChevronRight,
  ChevronLeft,
  ChevronUp,
  ChevronDown,
  ChevronsUpDown,
  PanelLeft,
  TrendingUp,
  Percent,
  Bell,
  Edit,
  Trash2,
  Palette,
  RotateCcw,
  Carrot,
  Fish,
  Wheat,
  Egg,
  Coffee,
  Shirt,
  Smartphone,
  HeartHandshake,
  Home,
  Baby,
  BookOpen,
  Sprout,
  Pill,
  Flame,
  Wrench,
  Package,
  Grid,
  List,
  Server
} from 'lucide-react';
import { BANGLADESH_COURIERS } from '../data/courierData';
import { Category } from '../types';
import { CategoryAdminModal } from '../components/CategoryAdminModal';
import { CategoryDeleteConfirmModal } from '../components/CategoryDeleteConfirmModal';
import { CustomerUIUXAdminStudio } from '../components/CustomerUIUXAdminStudio';
import { BackendAdminPanel } from '../components/BackendAdminPanel';
import { PaymentGatewayAdmin } from '../components/PaymentGatewayAdmin';

// Mock initial banners
interface PromoBanner {
  id: string;
  title: string;
  titleBn: string;
  subtitle: string;
  image: string;
  link: string;
  location: 'hero' | 'deal' | 'footer';
  active: boolean;
}

const INITIAL_BANNERS: PromoBanner[] = [
  {
    id: 'ban-1',
    title: 'Pure Organic Deshi Festival 2026',
    titleBn: 'খাঁটি দেশি পণ্যের মহা উৎসব ২০২৬',
    subtitle: 'Flat 20% OFF on all artisan items & Sundarbans honey',
    image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=1200&q=80',
    link: '/shop',
    location: 'hero',
    active: true
  },
  {
    id: 'ban-2',
    title: 'Fresh River Catch from Padma & Meghna',
    titleBn: 'পদ্মা ও মেঘনার তাজা নদীর মাছ',
    subtitle: 'Delivered in chilled ice boxes within 24 hours',
    image: 'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?auto=format&fit=crop&w=1200&q=80',
    link: '/category/fish-meat',
    location: 'hero',
    active: true
  },
  {
    id: 'ban-3',
    title: 'Eid Traditional Handloom Weaves',
    titleBn: 'ঈদের ঐতিহ্যবাহী তাঁতের শাড়ি ও পাঞ্জাবি',
    subtitle: 'Tangail & Jamdani direct from artisan handlooms',
    image: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=1200&q=80',
    link: '/category/fashion',
    location: 'deal',
    active: true
  }
];

// Mock Registered Customers
interface AdminUser {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'customer' | 'seller' | 'admin';
  totalOrders: number;
  totalSpent: number;
  joinedDate: string;
  status: 'active' | 'suspended';
}

const INITIAL_USERS: AdminUser[] = [
  {
    id: 'usr-1',
    name: 'Tanvir Hossain',
    email: 'tanvir.ctg@gmail.com',
    phone: '01819234567',
    role: 'customer',
    totalOrders: 14,
    totalSpent: 28450,
    joinedDate: '2023-11-12',
    status: 'active'
  },
  {
    id: 'usr-2',
    name: 'Nusrat Jahan',
    email: 'nusrat.j@yahoo.com',
    phone: '01711987654',
    role: 'customer',
    totalOrders: 22,
    totalSpent: 49800,
    joinedDate: '2023-04-05',
    status: 'active'
  },
  {
    id: 'usr-3',
    name: 'Dr. Shahana Akhter',
    email: 'dr.shahana@health.gov.bd',
    phone: '01912341234',
    role: 'customer',
    totalOrders: 8,
    totalSpent: 16500,
    joinedDate: '2024-01-18',
    status: 'active'
  },
  {
    id: 'usr-4',
    name: 'Kawran Agro Fresh (Merchant)',
    email: 'kawran.agro@deshibazar.com',
    phone: '01712009988',
    role: 'seller',
    totalOrders: 340,
    totalSpent: 0,
    joinedDate: '2022-08-15',
    status: 'active'
  },
  {
    id: 'usr-5',
    name: 'Imtiaz Ahmed',
    email: 'imtiaz.test@outlook.com',
    phone: '01511223344',
    role: 'customer',
    totalOrders: 1,
    totalSpent: 850,
    joinedDate: '2024-03-01',
    status: 'suspended'
  }
];

// Mock pending seller applications
interface SellerApplication {
  id: string;
  shopName: string;
  ownerName: string;
  phone: string;
  email: string;
  location: string;
  tradeLicense: string;
  category: string;
  appliedDate: string;
  status: 'pending' | 'approved' | 'rejected';
}

const INITIAL_SELLER_APPLICATIONS: SellerApplication[] = [
  {
    id: 'app-1',
    shopName: 'Kushtia Agro Pure',
    ownerName: 'Motiur Rahman',
    phone: '01718223344',
    email: 'kushtia.pure@gmail.com',
    location: 'Poradah, Kushtia',
    tradeLicense: 'TR-KUS-89421',
    category: 'Rice, Dal & Grocery',
    appliedDate: '2026-09-24',
    status: 'pending'
  },
  {
    id: 'app-2',
    shopName: 'Barishal Guava & Fish Orchards',
    ownerName: 'Subrata Roy',
    phone: '01815667788',
    email: 'barishal.fruits@gmail.com',
    location: 'Swarupkathi, Pirojpur',
    tradeLicense: 'TR-PRJ-22190',
    category: 'Fruits & Vegetables',
    appliedDate: '2026-09-26',
    status: 'pending'
  },
  {
    id: 'app-3',
    shopName: 'Comilla Khadi Shilpa',
    ownerName: 'Farhana Kabir',
    phone: '01912445566',
    email: 'farhana.khadi@gmail.com',
    location: 'Kandirpar, Comilla',
    tradeLicense: 'TR-COM-45109',
    category: 'Fashion & Handloom',
    appliedDate: '2026-09-27',
    status: 'pending'
  }
];

export const AdminDashboardView: React.FC = () => {
  const { 
    t, 
    language,
    products, 
    sellers, 
    orders, 
    updateOrderStatus, 
    showToast,
    setCurrentView,
    assignOrderCourier,
    setIsCourierModalOpen,
    setIsAddProductModalOpen,
    categories,
    addCategory,
    updateCategory,
    deleteCategory,
    resetCategoriesToDefault,
    setSelectedCategory,
    openThemeStudio,
    openEcommerceStudio,
    currentTheme,
    setThemeId,
    allThemes,
    themeCategories,
    openCashMemoModal,
    openCategoryCashMemo,
    unreadSmsCount,
    totalCustomerBakiDue,
    openSmsNotificationModal
  } = useApp();

  // Navigation tab
  const [activeTab, setActiveTab] = useState<
    'overview' | 'backend' | 'customer-ui' | 'orders' | 'products' | 'sellers' | 'categories' | 'coupons' | 
    'banners' | 'users' | 'payments' | 'delivery' | 'reports' | 'settings' | 'themes'
  >('overview');
  const [settingsSubTab, setSettingsSubTab] = useState<'bulk-sms' | 'general'>('bulk-sms');

  // Category Management State
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [categoryModalInitialTab, setCategoryModalInitialTab] = useState<'general' | 'image' | 'style' | 'tags'>('general');
  const [selectedCategoryForEdit, setSelectedCategoryForEdit] = useState<Category | null>(null);
  const [categoryToDelete, setCategoryToDelete] = useState<Category | null>(null);
  const [isDeleteConfirmModalOpen, setIsDeleteConfirmModalOpen] = useState(false);
  const [categorySearchQuery, setCategorySearchQuery] = useState('');
  const [categoryStatusFilter, setCategoryStatusFilter] = useState<'all' | 'active' | 'inactive'>('all');
  const [categorySortBy, setCategorySortBy] = useState<'default' | 'name' | 'items' | 'commission'>('default');
  const [categoryViewMode, setCategoryViewMode] = useState<'grid' | 'table'>('grid');
  const [isResetConfirmModalOpen, setIsResetConfirmModalOpen] = useState(false);

  // Time Range Filter
  const [timeRange, setTimeRange] = useState<'today' | '7days' | '30days' | 'year'>('30days');

  // Search & Filter State
  const [orderSearchQuery, setOrderSearchQuery] = useState('');
  const [orderStatusFilter, setOrderStatusFilter] = useState<string>('all');
  const [productSearchQuery, setProductSearchQuery] = useState('');
  const [productCategoryFilter, setProductCategoryFilter] = useState<string>('all');

  // Dynamic Data States
  const [usersList, setUsersList] = useState<AdminUser[]>(INITIAL_USERS);
  const [bannersList, setBannersList] = useState<PromoBanner[]>(INITIAL_BANNERS);
  const [sellerApplications, setSellerApplications] = useState<SellerApplication[]>(INITIAL_SELLER_APPLICATIONS);

  // New Banner Form State
  const [newBannerTitle, setNewBannerTitle] = useState('');
  const [newBannerSubtitle, setNewBannerSubtitle] = useState('');
  const [newBannerImage, setNewBannerImage] = useState('');
  const [newBannerLocation, setNewBannerLocation] = useState<'hero' | 'deal' | 'footer'>('hero');

  // Coupon State
  const [couponsList, setCouponsList] = useState(() => {
    try {
      const saved = localStorage.getItem('deshibazar_admin_coupons');
      return saved ? JSON.parse(saved) : [
        { code: 'WELCOME20', discountPercent: 20, minOrder: 500, maxDiscount: 300, active: true },
        { code: 'DESHI10', discountPercent: 10, minOrder: 800, maxDiscount: 200, active: true },
        { code: 'EID2026', discountPercent: 25, minOrder: 1500, maxDiscount: 500, active: true },
        { code: 'FREESHIP', discountPercent: 5, minOrder: 1000, maxDiscount: 120, active: true }
      ];
    } catch {
      return [
        { code: 'WELCOME20', discountPercent: 20, minOrder: 500, maxDiscount: 300, active: true },
        { code: 'DESHI10', discountPercent: 10, minOrder: 800, maxDiscount: 200, active: true }
      ];
    }
  });
  const [newCouponCode, setNewCouponCode] = useState('');
  const [newCouponDiscount, setNewCouponDiscount] = useState<number>(15);
  const [newCouponMinOrder, setNewCouponMinOrder] = useState<number>(600);
  const [newCouponMaxDiscount, setNewCouponMaxDiscount] = useState<number>(300);

  // Product Approval State (simulated pending vendor product submissions)
  const [pendingProducts, setPendingProducts] = useState<any[]>([
    {
      id: 'pend-1',
      name: 'Organic Wild Sundarbans Mustard Flower Honey (750g)',
      nameBn: 'সুন্দরবনের খাঁটি সরিষা ফুলের মধু (৭৫০ গ্রাম)',
      category: 'deshi-products',
      vendorName: 'Kushtia Agro Pure',
      price: 650,
      stock: 40,
      image: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=400&q=80',
      submittedDate: '2026-09-27'
    },
    {
      id: 'pend-2',
      name: 'Tangail Hand-Woven Cotton Gamcha (5-pack)',
      nameBn: 'টাঙ্গাইলের হাতে বোনা খাঁটি সুতি গামছা (৫টি)',
      category: 'fashion',
      vendorName: 'Comilla Khadi Shilpa',
      price: 450,
      stock: 60,
      image: 'https://images.unsplash.com/photo-1606744824163-985d376605aa?auto=format&fit=crop&w=400&q=80',
      submittedDate: '2026-09-28'
    }
  ]);

  // Website Settings State
  const [settings, setSettings] = useState({
    siteName: 'DeshiBazar Marketplace',
    siteNameBn: 'দেশিবাজার মার্কেটপ্লেস',
    supportPhone: '+880 1700-123456',
    supportEmail: 'support@deshibazar.com.bd',
    platformCommissionPercent: 8.5,
    freeDeliveryThreshold: 1500,
    maintenanceMode: false,
    vatTaxPercent: 5.0,
    currencySymbol: '৳',
    allowCod: true,
    allowBkash: true,
    allowNagad: true
  });

  // Calculate Key Real Metrics
  const calculatedTotalRevenue = useMemo(() => {
    return orders.reduce((sum, o) => sum + o.total, 542800);
  }, [orders]);

  const totalOrdersCount = orders.length + 1284;
  const totalCustomersCount = usersList.filter(u => u.role === 'customer').length + 3840;
  const totalSellersCount = sellers.length + sellerApplications.filter(s => s.status === 'approved').length;
  const pendingOrdersList = orders.filter(o => o.status === 'placed' || o.status === 'confirmed');
  const lowStockProductsList = products.filter(p => p.stock <= 25);

  // Tab Navigation with Up/Down and Side Buttons
  const tabsContainerRef = useRef<HTMLDivElement>(null);
  const [isSideDrawerOpen, setIsSideDrawerOpen] = useState(false);
  const [sideDrawerSearch, setSideDrawerSearch] = useState('');
  const [tabViewLayout, setTabViewLayout] = useState<'horizontal' | 'vertical'>('horizontal');

  // Master 15 Admin Sections List
  const adminTabsList = useMemo(() => [
    { id: 'overview' as const, label: t('সার্বিক চিত্র', 'Overview'), icon: LayoutDashboard },
    { id: 'backend' as const, label: t('ব্যাকএন্ড ও এপিআই', 'Backend & APIs'), icon: Server, badge: 'Live' },
    { id: 'customer-ui' as const, label: t('কাস্টমার UI/UX ডিজাইন', 'Customer UI/UX Studio'), icon: Sparkles, badge: 'Hot' },
    { id: 'orders' as const, label: t('অর্ডার ব্যবস্থাপনা', 'Orders'), icon: ShoppingBag, badge: pendingOrdersList.length ? String(pendingOrdersList.length) : undefined },
    { id: 'products' as const, label: t('পণ্য ও ইনভেন্টরি', 'Products & Stock'), icon: Tag, badge: pendingProducts.length ? String(pendingProducts.length) : undefined },
    { id: 'sellers' as const, label: t('বিক্রেতা অনুমোদন', 'Sellers & KYC'), icon: Store, badge: sellerApplications.filter(s => s.status === 'pending').length ? String(sellerApplications.filter(s => s.status === 'pending').length) : undefined },
    { id: 'categories' as const, label: t('ক্যাটাগরি সমূহ', 'Categories'), icon: Layers },
    { id: 'coupons' as const, label: t('কুপন ও ছাড়', 'Coupons'), icon: Percent },
    { id: 'banners' as const, label: t('ব্যানার ও বিজ্ঞাপন', 'Banners'), icon: ImageIcon },
    { id: 'users' as const, label: t('ব্যবহারকারী ও গ্রাহক', 'Users'), icon: Users },
    { id: 'payments' as const, label: t('পেমেন্ট ও গেটওয়ে', 'Payments'), icon: CreditCard },
    { id: 'delivery' as const, label: t('ডেলিভারি ও কুরিয়ার', 'Delivery & Logistics'), icon: Truck },
    { id: 'reports' as const, label: t('রিপোর্ট ও অ্যানালিটিক্স', 'Reports'), icon: FileText },
    { id: 'settings' as const, label: t('মার্কেটপ্লেস সেটিংস', 'Settings'), icon: Settings },
    { id: 'themes' as const, label: t('১০০+ থিম ও রূপরেখা', '100+ Themes & UI'), icon: Palette, badge: String(allThemes.length) }
  ], [t, pendingOrdersList.length, pendingProducts.length, sellerApplications, allThemes.length]);

  const currentTabIndex = adminTabsList.findIndex(item => item.id === activeTab);
  const currentTabInfo = adminTabsList[currentTabIndex >= 0 ? currentTabIndex : 0];

  // Up/Down Navigation Handlers
  const handlePrevTab = () => {
    const prevIndex = (currentTabIndex - 1 + adminTabsList.length) % adminTabsList.length;
    setActiveTab(adminTabsList[prevIndex].id);
  };

  const handleNextTab = () => {
    const nextIndex = (currentTabIndex + 1) % adminTabsList.length;
    setActiveTab(adminTabsList[nextIndex].id);
  };

  // Side Scroll Handlers
  const scrollTabs = (direction: 'left' | 'right') => {
    if (tabsContainerRef.current) {
      tabsContainerRef.current.scrollBy({
        left: direction === 'left' ? -280 : 280,
        behavior: 'smooth'
      });
    }
  };

  // Top Selling Products
  const topProducts = useMemo(() => {
    return [...products]
      .sort((a, b) => (b.reviewCount * b.price) - (a.reviewCount * a.price))
      .slice(0, 5);
  }, [products]);

  // Top Performing Sellers
  const topSellers = useMemo(() => {
    return [...sellers]
      .sort((a, b) => b.rating * b.reviewsCount - a.rating * a.reviewsCount)
      .slice(0, 5);
  }, [sellers]);

  // Handlers
  const handleApproveSeller = (appId: string) => {
    setSellerApplications(prev => prev.map(a => a.id === appId ? { ...a, status: 'approved' } : a));
    showToast(t('বিক্রেতা আবেদন অনুমোদিত ও ভেরিফাইড করা হয়েছে!', 'Seller application approved and verified!'), 'success');
  };

  const handleRejectSeller = (appId: string) => {
    setSellerApplications(prev => prev.map(a => a.id === appId ? { ...a, status: 'rejected' } : a));
    showToast(t('বিক্রেতা আবেদন বাতিল করা হয়েছে', 'Seller application rejected'), 'info');
  };

  const handleApproveProduct = (prodId: string) => {
    setPendingProducts(prev => prev.filter(p => p.id !== prodId));
    showToast(t('পণ্যটি সফলভাবে অনুমোদিত হয়ে শপে লাইভ হয়েছে!', 'Product approved and published to shop!'), 'success');
  };

  const handleRejectProduct = (prodId: string) => {
    setPendingProducts(prev => prev.filter(p => p.id !== prodId));
    showToast(t('পণ্য অনুমোদন বাতিল করা হয়েছে', 'Product submission rejected'), 'info');
  };

  const handleCreateCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCouponCode.trim()) return;

    const newCp = {
      code: newCouponCode.trim().toUpperCase(),
      discountPercent: Number(newCouponDiscount),
      minOrder: Number(newCouponMinOrder),
      maxDiscount: Number(newCouponMaxDiscount),
      active: true
    };

    const updated = [newCp, ...couponsList];
    setCouponsList(updated);
    try {
      localStorage.setItem('deshibazar_admin_coupons', JSON.stringify(updated));
    } catch {}

    showToast(t(`কুপন ${newCp.code} তৈরি হয়েছে!`, `Coupon ${newCp.code} created!`), 'success');
    setNewCouponCode('');
  };

  const handleDeleteCoupon = (code: string) => {
    const updated = couponsList.filter((c: any) => c.code !== code);
    setCouponsList(updated);
    try {
      localStorage.setItem('deshibazar_admin_coupons', JSON.stringify(updated));
    } catch {}
    showToast(t('কুপন মুছে ফেলা হয়েছে', 'Coupon removed'), 'info');
  };

  const handleToggleCoupon = (code: string) => {
    const updated = couponsList.map((c: any) => c.code === code ? { ...c, active: !c.active } : c);
    setCouponsList(updated);
    try {
      localStorage.setItem('deshibazar_admin_coupons', JSON.stringify(updated));
    } catch {}
    showToast(t('কুপনের অবস্থা পরিবর্তন করা হয়েছে', 'Coupon status updated'), 'success');
  };

  const handleAddBanner = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBannerTitle.trim() || !newBannerImage.trim()) return;

    const newBanner: PromoBanner = {
      id: `ban-${Date.now()}`,
      title: newBannerTitle.trim(),
      titleBn: newBannerTitle.trim(),
      subtitle: newBannerSubtitle.trim() || 'DeshiBazar special promo campaign',
      image: newBannerImage.trim(),
      link: '/shop',
      location: newBannerLocation,
      active: true
    };

    setBannersList([newBanner, ...bannersList]);
    setNewBannerTitle('');
    setNewBannerSubtitle('');
    setNewBannerImage('');
    showToast(t('নতুন ব্যানার সফলভাবে লাইভ হয়েছে!', 'New banner published successfully!'), 'success');
  };

  const handleToggleBanner = (id: string) => {
    setBannersList(prev => prev.map(b => b.id === id ? { ...b, active: !b.active } : b));
    showToast(t('ব্যানার স্ট্যাটাস আপডেট হয়েছে', 'Banner status updated'), 'info');
  };

  const handleDeleteBanner = (id: string) => {
    setBannersList(prev => prev.filter(b => b.id !== id));
    showToast(t('ব্যানার মুছে ফেলা হয়েছে', 'Banner deleted'), 'info');
  };

  const handleToggleUserStatus = (userId: string) => {
    setUsersList(prev => prev.map(u => {
      if (u.id === userId) {
        const nextStatus = u.status === 'active' ? 'suspended' : 'active';
        showToast(
          t(`ব্যবহারকারী ${nextStatus === 'active' ? 'পুনরায় সক্রিয়' : 'স্থগিত'} করা হয়েছে`, 
            `User ${nextStatus === 'active' ? 'activated' : 'suspended'}`), 
          'info'
        );
        return { ...u, status: nextStatus };
      }
      return u;
    }));
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      localStorage.setItem('deshibazar_site_settings', JSON.stringify(settings));
    } catch {}
    showToast(t('ওয়েবসাইটের সার্বিক সেটিংস সফলভাবে সংরক্ষিত হয়েছে!', 'Website settings updated successfully!'), 'success');
  };

  const handleExportReport = () => {
    const reportData = {
      generatedAt: new Date().toISOString(),
      totalRevenue: calculatedTotalRevenue,
      totalOrders: totalOrdersCount,
      totalCustomers: totalCustomersCount,
      totalSellers: totalSellersCount,
      ordersBreakdown: {
        delivered: Math.round(totalOrdersCount * 0.88),
        processing: Math.round(totalOrdersCount * 0.08),
        cancelled: Math.round(totalOrdersCount * 0.04)
      },
      topCategories: categories.slice(0, 5).map(c => ({ name: c.name, items: c.itemCount }))
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `DeshiBazar_Sales_Report_${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    showToast(t('রিপোর্ট সফলভাবে ডাউনলোড হয়েছে!', 'Report downloaded successfully!'), 'success');
  };

  // Filtered Orders
  const filteredOrders = useMemo(() => {
    return orders.filter(ord => {
      const matchSearch = !orderSearchQuery || 
        ord.orderNumber.toLowerCase().includes(orderSearchQuery.toLowerCase()) ||
        ord.customerName.toLowerCase().includes(orderSearchQuery.toLowerCase()) ||
        ord.customerPhone.includes(orderSearchQuery);
      const matchStatus = orderStatusFilter === 'all' || ord.status === orderStatusFilter;
      return matchSearch && matchStatus;
    });
  }, [orders, orderSearchQuery, orderStatusFilter]);

  // Filtered Products
  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      const matchSearch = !productSearchQuery || 
        p.name.toLowerCase().includes(productSearchQuery.toLowerCase()) ||
        p.nameBn.includes(productSearchQuery);
      const matchCat = productCategoryFilter === 'all' || p.category === productCategoryFilter;
      return matchSearch && matchCat;
    });
  }, [products, productSearchQuery, productCategoryFilter]);

  // Filtered & Sorted Categories for Admin Category Management
  const filteredAndSortedCategories = useMemo(() => {
    return categories
      .filter((cat) => {
        if (categorySearchQuery.trim()) {
          const q = categorySearchQuery.toLowerCase().trim();
          const matchName = cat.name.toLowerCase().includes(q);
          const matchNameBn = (cat.nameBn || '').toLowerCase().includes(q);
          const matchId = cat.id.toLowerCase().includes(q);
          const matchTags = (cat.popularItems || []).some(tag => tag.toLowerCase().includes(q));
          if (!matchName && !matchNameBn && !matchId && !matchTags) return false;
        }
        if (categoryStatusFilter === 'active' && cat.status === 'inactive') return false;
        if (categoryStatusFilter === 'inactive' && cat.status !== 'inactive') return false;
        return true;
      })
      .sort((a, b) => {
        if (categorySortBy === 'name') return a.name.localeCompare(b.name);
        if (categorySortBy === 'items') return (b.itemCount || 0) - (a.itemCount || 0);
        if (categorySortBy === 'commission') return (b.commissionRate || 8.5) - (a.commissionRate || 8.5);
        return 0;
      });
  }, [categories, categorySearchQuery, categoryStatusFilter, categorySortBy]);

  const handleOpenAddCategory = () => {
    setSelectedCategoryForEdit(null);
    setCategoryModalInitialTab('general');
    setIsCategoryModalOpen(true);
  };

  const handleOpenEditCategory = (cat: Category, tab: 'general' | 'image' | 'style' | 'tags' = 'general') => {
    setSelectedCategoryForEdit(cat);
    setCategoryModalInitialTab(tab);
    setIsCategoryModalOpen(true);
  };

  const handleOpenDeleteCategory = (cat: Category) => {
    setCategoryToDelete(cat);
    setIsDeleteConfirmModalOpen(true);
  };

  const handleSaveCategory = (catData: Partial<Category>) => {
    if (selectedCategoryForEdit) {
      updateCategory(selectedCategoryForEdit.id, catData);
    } else {
      addCategory(catData as any);
    }
  };

  const handleToggleCategoryStatus = (cat: Category, e: React.MouseEvent) => {
    e.stopPropagation();
    const newStatus = cat.status === 'inactive' ? 'active' : 'inactive';
    updateCategory(cat.id, { status: newStatus });
    showToast(
      newStatus === 'active'
        ? t(`ক্যাটাগরি "${cat.nameBn || cat.name}" সক্রিয় করা হয়েছে`, `Category "${cat.name}" marked as active`)
        : t(`ক্যাটাগরি "${cat.nameBn || cat.name}" নিষ্ক্রিয় করা হয়েছে`, `Category "${cat.name}" marked as inactive`),
      'info'
    );
  };

  const getCategoryIconElement = (cat: Category) => {
    const key = (cat.iconName || cat.id).toLowerCase();
    if (key.includes('carrot') || cat.id === 'fruits-vegetables') return <Carrot className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />;
    if (key.includes('fish') || cat.id === 'fish-meat') return <Fish className="w-4 h-4 text-blue-600 dark:text-blue-400" />;
    if (key.includes('wheat') || cat.id === 'rice-dal-grocery') return <Wheat className="w-4 h-4 text-amber-600 dark:text-amber-400" />;
    if (key.includes('egg') || cat.id === 'dairy-eggs') return <Egg className="w-4 h-4 text-orange-600 dark:text-orange-400" />;
    if (key.includes('coffee') || cat.id === 'snacks-beverages') return <Coffee className="w-4 h-4 text-rose-600 dark:text-rose-400" />;
    if (key.includes('sparkle') || cat.id === 'deshi-products') return <Sparkles className="w-4 h-4 text-amber-500 dark:text-amber-300" />;
    if (key.includes('shirt') || cat.id === 'fashion') return <Shirt className="w-4 h-4 text-purple-600 dark:text-purple-400" />;
    if (key.includes('phone') || cat.id === 'electronics') return <Smartphone className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />;
    if (key.includes('heart') || cat.id === 'beauty-personal-care') return <HeartHandshake className="w-4 h-4 text-pink-600 dark:text-pink-400" />;
    if (key.includes('home') || cat.id === 'home-kitchen') return <Home className="w-4 h-4 text-teal-600 dark:text-teal-400" />;
    if (key.includes('baby') || cat.id === 'baby-products') return <Baby className="w-4 h-4 text-sky-600 dark:text-sky-400" />;
    if (key.includes('book') || cat.id === 'stationery') return <BookOpen className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />;
    if (key.includes('sprout') || cat.id === 'agriculture-products') return <Sprout className="w-4 h-4 text-emerald-700 dark:text-emerald-300" />;
    if (key.includes('palette') || cat.id === 'handmade-products') return <Palette className="w-4 h-4 text-amber-700 dark:text-amber-400" />;
    if (key.includes('pill') || cat.id === 'madicen') return <Pill className="w-4 h-4 text-red-600 dark:text-red-400" />;
    if (key.includes('flame') || cat.id === 'masala') return <Flame className="w-4 h-4 text-orange-600 dark:text-amber-500" />;
    if (key.includes('wrench') || cat.id === 'hardware-accessories') return <Wrench className="w-4 h-4 text-slate-700 dark:text-slate-300" />;
    return <Package className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />;
  };

  return (
    <div className="py-8 bg-gray-50 dark:bg-gray-900 min-h-screen transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-6">
        
        {/* TOP COMMAND HEADER */}
        <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 border border-gray-100 dark:border-gray-700/80 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-purple-500/20 shrink-0">
              <LayoutDashboard className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black text-gray-900 dark:text-white">
                  {t('দেশিবাজার অ্যাডমিন কন্ট্রোল সেন্টার', 'DeshiBazar Admin Command Center')}
                </h1>
                <span className="px-2.5 py-0.5 rounded-full bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 text-[10px] font-black tracking-wider uppercase border border-purple-200 dark:border-purple-800">
                  Super Admin
                </span>
              </div>
              <p className="text-xs text-gray-500 mt-0.5">
                {t('মার্কেটপ্লেসের সার্বিক বিক্রয়, বিক্রেতা অনুমোদন, ইনভেন্টরি, ডেলিভারি ও রাজস্ব নিয়ন্ত্রণ', 'Complete marketplace oversight: orders, vendors, logistics, financials & settings')}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
            {/* Backend Engine & API Center Button */}
            <button
              onClick={() => setActiveTab('backend')}
              className="px-3.5 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-600/20 active:scale-95 transition-all flex items-center gap-1.5"
            >
              <Server className="w-4 h-4 text-emerald-200" />
              <span>{t('ব্যাকএন্ড ও এপিআই', 'Backend & APIs')}</span>
            </button>

            {/* Customer UI/UX Studio Button */}
            <button
              onClick={() => setActiveTab('customer-ui')}
              className="px-3.5 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white rounded-xl text-xs font-bold shadow-md shadow-purple-600/20 active:scale-95 transition-all flex items-center gap-1.5"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>{t('কাস্টমার UI/UX স্টুডিও', 'Customer UI/UX Studio')}</span>
            </button>

            {/* Quick Add Product Button */}
            <button
              onClick={() => setIsAddProductModalOpen(true)}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-600/20 active:scale-95 transition-all flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>{t('নতুন পণ্য যোগ করুন', '+ Add Product')}</span>
            </button>

            {/* Marketplace & Admin Settings Button */}
            <button
              onClick={() => setActiveTab('settings')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 active:scale-95 ${
                activeTab === 'settings'
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-600/20'
                  : 'bg-gray-100 dark:bg-gray-750 hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-800 dark:text-gray-200'
              }`}
              title={t('মার্কেটপ্লেস ও অ্যাডমিন সেটিংস', 'Marketplace & Admin Settings')}
            >
              <Settings className={`w-4 h-4 ${activeTab === 'settings' ? 'text-white' : 'text-purple-600 dark:text-purple-400'}`} />
              <span>{t('অ্যাডমিন সেটিংস (Settings)', 'Settings')}</span>
            </button>

            {/* Export Report Button */}
            <button
              onClick={handleExportReport}
              className="px-3.5 py-2 bg-gray-100 dark:bg-gray-750 hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5"
              title={t('বিক্রয় ও রাজস্ব রিপোর্ট ডাউনলোড', 'Export Sales & Revenue Report')}
            >
              <Download className="w-4 h-4 text-gray-500" />
              <span>{t('রিপোর্ট ডাউনলোড', 'Export Report')}</span>
            </button>

            {/* Time range selector */}
            <select
              value={timeRange}
              onChange={(e) => setTimeRange(e.target.value as any)}
              className="bg-gray-100 dark:bg-gray-750 border-0 rounded-xl px-3 py-2 text-xs font-bold text-gray-700 dark:text-gray-300 focus:ring-2 focus:ring-purple-500"
            >
              <option value="today">{t('আজকের হিসাব', 'Today')}</option>
              <option value="7days">{t('বিগত ৭ দিন', 'Last 7 Days')}</option>
              <option value="30days">{t('বিগত ৩০ দিন', 'Last 30 Days')}</option>
              <option value="year">{t('চলতি বছর', 'This Year')}</option>
            </select>
          </div>
        </div>

        {/* 4 PRIMARY METRIC CARDS (TOTAL SALES, TOTAL ORDERS, TOTAL CUSTOMERS, TOTAL SELLERS) */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5 sm:gap-4">
          {/* 1. Total Sales */}
          <div className="bg-white dark:bg-gray-800 p-5 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-xs relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/10 rounded-full blur-xl group-hover:bg-emerald-500/20 transition-all pointer-events-none" />
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">
                {t('মোট বিক্রয় (Total Sales)', 'Total Sales')}
              </span>
              <div className="w-8 h-8 rounded-xl bg-emerald-100 dark:bg-emerald-950 flex items-center justify-center text-emerald-600">
                <DollarSign className="w-4 h-4" />
              </div>
            </div>
            <div className="text-xl sm:text-2xl font-black text-gray-900 dark:text-white">
              ৳{calculatedTotalRevenue.toLocaleString()}
            </div>
            <div className="flex items-center gap-1.5 mt-2 text-[10px] text-emerald-600 font-bold">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>+18.4% {t('পূর্ববর্তী মাসের চেয়ে বেশি', 'vs last month')}</span>
            </div>
          </div>

          {/* 2. Total Orders */}
          <div className="bg-white dark:bg-gray-800 p-5 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-xs relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-24 h-24 bg-blue-500/10 rounded-full blur-xl group-hover:bg-blue-500/20 transition-all pointer-events-none" />
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">
                {t('মোট অর্ডার (Total Orders)', 'Total Orders')}
              </span>
              <div className="w-8 h-8 rounded-xl bg-blue-100 dark:bg-blue-950 flex items-center justify-center text-blue-600">
                <ShoppingBag className="w-4 h-4" />
              </div>
            </div>
            <div className="text-xl sm:text-2xl font-black text-gray-900 dark:text-white">
              {totalOrdersCount.toLocaleString()}
            </div>
            <div className="flex items-center justify-between mt-2 text-[10px]">
              <span className="text-blue-600 font-bold">{pendingOrdersList.length} {t('পেন্ডিং অর্ডার', 'Pending Orders')}</span>
              <span className="text-gray-400">98.2% {t('ডেলিভার্ড', 'Delivered')}</span>
            </div>
          </div>

          {/* 3. Total Customers */}
          <div className="bg-white dark:bg-gray-800 p-5 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-xs relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-24 h-24 bg-purple-500/10 rounded-full blur-xl group-hover:bg-purple-500/20 transition-all pointer-events-none" />
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">
                {t('মোট গ্রাহক (Total Customers)', 'Total Customers')}
              </span>
              <div className="w-8 h-8 rounded-xl bg-purple-100 dark:bg-purple-950 flex items-center justify-center text-purple-600">
                <Users className="w-4 h-4" />
              </div>
            </div>
            <div className="text-xl sm:text-2xl font-black text-gray-900 dark:text-white">
              {totalCustomersCount.toLocaleString()}
            </div>
            <div className="flex items-center gap-1.5 mt-2 text-[10px] text-purple-600 font-bold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>+342 {t('নতুন এই সপ্তাহে', 'new this week')}</span>
            </div>
          </div>

          {/* 4. Total Sellers */}
          <div className="bg-white dark:bg-gray-800 p-5 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-xs relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/10 rounded-full blur-xl group-hover:bg-amber-500/20 transition-all pointer-events-none" />
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">
                {t('মোট বিক্রেতা (Total Sellers)', 'Total Sellers')}
              </span>
              <div className="w-8 h-8 rounded-xl bg-amber-100 dark:bg-amber-950 flex items-center justify-center text-amber-600">
                <Store className="w-4 h-4" />
              </div>
            </div>
            <div className="text-xl sm:text-2xl font-black text-gray-900 dark:text-white">
              {totalSellersCount}
            </div>
            <div className="flex items-center justify-between mt-2 text-[10px]">
              <span className="text-amber-600 font-bold">{sellerApplications.filter(s => s.status === 'pending').length} {t('অনুমোদনের অপেক্ষায়', 'pending approval')}</span>
              <span className="text-emerald-600 font-bold">100% {t('যাচাইকৃত', 'Verified')}</span>
            </div>
          </div>
        </div>

        {/* NOTIFICATION CALLOUT: PENDING ORDERS & LOW STOCK ALERTS */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {pendingOrdersList.length > 0 && (
            <div 
              onClick={() => setActiveTab('orders')}
              className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/80 flex items-center justify-between cursor-pointer hover:bg-amber-100/60 transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-amber-500 text-white flex items-center justify-center font-bold">
                  <AlertTriangle className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-amber-900 dark:text-amber-200">
                    {t(`${pendingOrdersList.length}টি পেন্ডিং অর্ডার নিশ্চিতকরণের অপেক্ষায়`, `${pendingOrdersList.length} Pending Orders Awaiting Confirmation`)}
                  </h4>
                  <p className="text-[11px] text-amber-700 dark:text-amber-400">
                    {t('গ্রাহকের অর্ডার যাচাই করে অবিলম্বে প্রসেসিংয়ে পাঠান →', 'Review items and assign courier to ship →')}
                  </p>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-amber-600" />
            </div>
          )}

          {lowStockProductsList.length > 0 && (
            <div 
              onClick={() => setActiveTab('products')}
              className="p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/80 flex items-center justify-between cursor-pointer hover:bg-rose-100/60 transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-rose-500 text-white flex items-center justify-center font-bold">
                  <AlertTriangle className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-rose-900 dark:text-rose-200">
                    {t(`${lowStockProductsList.length}টি পণ্যের স্টক কমে গেছে (Low Stock Warning)`, `${lowStockProductsList.length} Products Running Low On Stock`)}
                  </h4>
                  <p className="text-[11px] text-rose-700 dark:text-rose-400">
                    {t('দ্রুত রি-অর্ডার করুন অথবা বিক্রেতাদের নোটিশ দিন →', 'Restock products or notify supplier →')}
                  </p>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-rose-600" />
            </div>
          )}
        </div>

        {/* NAVIGATION CONTROLS & TABS BAR (ALL 15 MASTER SECTIONS WITH UP/DOWN & SIDE BUTTONS) */}
        <div className="space-y-2">
          {/* Top Control Bar with UP/DOWN & SIDE BUTTONS */}
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-2.5 sm:p-3 border border-gray-100 dark:border-gray-700 shadow-xs flex flex-wrap items-center justify-between gap-2.5">
            {/* Left Controls: Side Button & UP/DOWN Tab Switchers */}
            <div className="flex items-center flex-wrap gap-1.5 sm:gap-2">
              {/* SIDE MENU BUTTON */}
              <button
                type="button"
                onClick={() => setIsSideDrawerOpen(true)}
                className="px-3 py-2 bg-purple-50 dark:bg-purple-950/60 hover:bg-purple-100 dark:hover:bg-purple-900/60 text-purple-700 dark:text-purple-300 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 border border-purple-200 dark:border-purple-800 shadow-xs active:scale-95"
                title={t('১৫টি সেকশন সাইড মেনু খুলুন', 'Open 15 Sections Side Menu')}
              >
                <PanelLeft className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                <span>{t('সাইড মেনু (Side Button)', 'Side Menu')}</span>
              </button>

              {/* UP BUTTON (PREVIOUS TAB) */}
              <button
                type="button"
                onClick={handlePrevTab}
                className="px-3 py-2 bg-gray-100 hover:bg-gray-200 dark:bg-gray-750 dark:hover:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 active:scale-95 border border-gray-200 dark:border-gray-700"
                title={t('পূর্ববর্তী ট্যাবে যান (UP / Prev Section)', 'Go to Previous Section (UP)')}
              >
                <ChevronUp className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                <span>{t('▲ UP (পূর্ববর্তী)', '▲ UP')}</span>
              </button>

              {/* CURRENT ACTIVE TAB BADGE */}
              <div className="px-3 py-1.5 bg-gradient-to-r from-purple-500/10 to-indigo-500/10 dark:from-purple-950/50 dark:to-indigo-950/50 border border-purple-200/80 dark:border-purple-800/80 rounded-xl text-xs font-black text-purple-700 dark:text-purple-300 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span>
                  [{currentTabIndex + 1}/15] {currentTabInfo?.label}
                </span>
              </div>

              {/* DOWN BUTTON (NEXT TAB) */}
              <button
                type="button"
                onClick={handleNextTab}
                className="px-3 py-2 bg-gray-100 hover:bg-gray-200 dark:bg-gray-750 dark:hover:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 active:scale-95 border border-gray-200 dark:border-gray-700"
                title={t('পরবর্তী ট্যাবে যান (DOWN / Next Section)', 'Go to Next Section (DOWN)')}
              >
                <span>{t('▼ DOWN (পরবর্তী)', '▼ DOWN')}</span>
                <ChevronDown className="w-4 h-4 text-purple-600 dark:text-purple-400" />
              </button>
            </div>

            {/* Right Controls: Horizontal Side Scroll Buttons & Layout Switcher */}
            <div className="flex items-center gap-1.5 sm:gap-2 ml-auto">
              {/* SIDE SCROLL LEFT BUTTON */}
              <button
                type="button"
                onClick={() => scrollTabs('left')}
                className="px-2.5 py-2 bg-gray-100 hover:bg-gray-200 dark:bg-gray-750 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-xl text-xs font-bold transition-all flex items-center gap-1 active:scale-95 border border-gray-200 dark:border-gray-700"
                title={t('বামে স্ক্রল করুন (Side Scroll Left)', 'Side Scroll Left')}
              >
                <ChevronLeft className="w-4 h-4" />
                <span className="hidden sm:inline">{t('বামে (Side Left)', 'Left')}</span>
              </button>

              {/* SIDE SCROLL RIGHT BUTTON */}
              <button
                type="button"
                onClick={() => scrollTabs('right')}
                className="px-2.5 py-2 bg-gray-100 hover:bg-gray-200 dark:bg-gray-750 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-xl text-xs font-bold transition-all flex items-center gap-1 active:scale-95 border border-gray-200 dark:border-gray-700"
                title={t('ডানে স্ক্রল করুন (Side Scroll Right)', 'Side Scroll Right')}
              >
                <span className="hidden sm:inline">{t('ডানে (Side Right)', 'Right')}</span>
                <ChevronRight className="w-4 h-4" />
              </button>

              {/* VIEW MODE TOGGLE (HORIZONTAL VS VERTICAL UP/DOWN) */}
              <button
                type="button"
                onClick={() => setTabViewLayout(prev => prev === 'horizontal' ? 'vertical' : 'horizontal')}
                className={`px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 border ${
                  tabViewLayout === 'vertical'
                    ? 'bg-purple-600 text-white border-purple-600 shadow-md shadow-purple-600/20'
                    : 'bg-gray-100 dark:bg-gray-750 hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 border-gray-200 dark:border-gray-700'
                }`}
                title={t('হরাইজন্টাল ও আপ-ডাউন ভিউ মোড পরিবর্তন', 'Toggle Horizontal or Up/Down Vertical Grid')}
              >
                <ChevronsUpDown className="w-4 h-4" />
                <span>{tabViewLayout === 'horizontal' ? t('আপ-ডাউন ভিউ (Vertical)', 'Up/Down Mode') : t('হরাইজন্টাল বার (Bar)', 'Bar Mode')}</span>
              </button>
            </div>
          </div>

          {/* MODE 1: HORIZONTAL TABS BAR WITH INTEGRATED SIDE BUTTONS */}
          {tabViewLayout === 'horizontal' && (
            <div className="relative flex items-center bg-white dark:bg-gray-800 rounded-2xl p-1.5 border border-gray-100 dark:border-gray-700 shadow-xs">
              {/* Left Side Scroll Indicator Button */}
              <button
                type="button"
                onClick={() => scrollTabs('left')}
                className="h-10 w-8 flex items-center justify-center rounded-xl bg-gray-100 hover:bg-gray-200 dark:bg-gray-750 text-gray-600 dark:text-gray-300 shrink-0 transition-colors mr-1 shadow-xs"
                title={t('বামে স্ক্রল', 'Scroll Left')}
              >
                <ChevronLeft className="w-4 h-4" />
              </button>

              {/* Scrollable Tabs Container */}
              <div 
                ref={tabsContainerRef}
                className="overflow-x-auto scrollbar-none flex gap-1.5 scroll-smooth py-1 px-0.5 flex-1"
              >
                {adminTabsList.map((tab, idx) => {
                  const Icon = tab.icon;
                  const isActive = activeTab === tab.id;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all shrink-0 relative ${
                        isActive
                          ? 'bg-purple-600 text-white shadow-md shadow-purple-600/20 scale-[1.02]'
                          : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-750'
                      }`}
                    >
                      <span className={`text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-black ${
                        isActive ? 'bg-purple-800 text-purple-100' : 'bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-400'
                      }`}>
                        {idx + 1}
                      </span>
                      <Icon className="w-4 h-4" />
                      <span>{tab.label}</span>
                      {Boolean(tab.badge) && (
                        <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-black ${
                          isActive ? 'bg-white text-purple-700' : 'bg-rose-500 text-white'
                        }`}>
                          {tab.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Right Side Scroll Indicator Button */}
              <button
                type="button"
                onClick={() => scrollTabs('right')}
                className="h-10 w-8 flex items-center justify-center rounded-xl bg-gray-100 hover:bg-gray-200 dark:bg-gray-750 text-gray-600 dark:text-gray-300 shrink-0 transition-colors ml-1 shadow-xs"
                title={t('ডানে স্ক্রল', 'Scroll Right')}
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* MODE 2: VERTICAL UP/DOWN GRID VIEW (ALL 15 TABS LISTED VERTICALLY) */}
          {tabViewLayout === 'vertical' && (
            <div className="bg-white dark:bg-gray-800 rounded-3xl p-4 sm:p-5 border border-purple-100 dark:border-purple-900/40 shadow-md">
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-gray-100 dark:border-gray-700">
                <div className="flex items-center gap-2">
                  <ChevronsUpDown className="w-5 h-5 text-purple-600" />
                  <h4 className="text-xs font-black text-gray-900 dark:text-white">
                    {t('সকল ১৫টি সেকশনের আপ-ডাউন নেভিগেশন তালিকা', 'All 15 Sections Up/Down Navigation List')}
                  </h4>
                </div>
                <div className="flex items-center gap-2 text-xs">
                  <button
                    type="button"
                    onClick={handlePrevTab}
                    className="px-2.5 py-1 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 text-gray-700 dark:text-gray-300 rounded-lg font-bold flex items-center gap-1"
                  >
                    <ChevronUp className="w-3.5 h-3.5" />
                    <span>{t('UP (আগের সেকশন)', 'UP')}</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleNextTab}
                    className="px-2.5 py-1 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 text-gray-700 dark:text-gray-300 rounded-lg font-bold flex items-center gap-1"
                  >
                    <span>{t('DOWN (পরের সেকশন)', 'DOWN')}</span>
                    <ChevronDown className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-2">
                {adminTabsList.map((tab, idx) => {
                  const Icon = tab.icon;
                  const isActive = activeTab === tab.id;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`flex items-center justify-between p-3 rounded-2xl text-xs font-bold transition-all text-left border ${
                        isActive
                          ? 'bg-purple-600 text-white border-purple-600 shadow-md shadow-purple-600/30'
                          : 'bg-gray-50 dark:bg-gray-750/70 border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:bg-purple-50 dark:hover:bg-purple-950/40 hover:border-purple-300'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 truncate">
                        <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black shrink-0 ${
                          isActive ? 'bg-white text-purple-700' : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
                        }`}>
                          {idx + 1}
                        </span>
                        <Icon className="w-4 h-4 shrink-0" />
                        <span className="truncate">{tab.label}</span>
                      </div>
                      {Boolean(tab.badge) && (
                        <span className={`ml-2 px-1.5 py-0.5 rounded-full text-[10px] font-black shrink-0 ${
                          isActive ? 'bg-white text-purple-700' : 'bg-rose-500 text-white'
                        }`}>
                          {tab.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* ======================================================== */}
        {/* TAB 1: OVERVIEW (CHARTS, TOP PRODUCTS, TOP SELLERS, LOW STOCK) */}
        {/* ======================================================== */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* CHARTS ROW: REVENUE CHART & ORDERS STATUS CHART */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* 1. Interactive Revenue Chart */}
              <div className="lg:col-span-2 bg-white dark:bg-gray-800 rounded-3xl p-6 border border-gray-100 dark:border-gray-700 shadow-xs space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <h3 className="text-sm font-black text-gray-900 dark:text-white flex items-center gap-2">
                      <BarChart3 className="w-4 h-4 text-emerald-600" />
                      <span>{t('রাজস্ব ও আয় বৃদ্ধির চার্ট (Revenue Chart)', 'Revenue & Growth Chart')}</span>
                    </h3>
                    <p className="text-xs text-gray-400">{t('দৈনিক রাজস্ব ও মোট বিক্রয়ের ট্রেন্ড অ্যানালাইসিস', 'Daily sales volume & platform commission revenue')}</p>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <span className="flex items-center gap-1 text-[11px] text-emerald-600 font-bold">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                      {t('মোট বিক্রয়', 'Gross Sales')}
                    </span>
                    <span className="flex items-center gap-1 text-[11px] text-purple-600 font-bold">
                      <span className="w-2.5 h-2.5 rounded-full bg-purple-500" />
                      {t('প্ল্যাটফর্ম ফি (৮.৫%)', 'Fee (8.5%)')}
                    </span>
                  </div>
                </div>

                {/* Simulated Visual SVG Bar Graph */}
                <div className="pt-4">
                  <div className="h-52 w-full flex items-end justify-between gap-2 sm:gap-4 px-2">
                    {[
                      { day: 'Sat (শনি)', val: 42000, height: '62%' },
                      { day: 'Sun (রবি)', val: 56000, height: '82%' },
                      { day: 'Mon (সোম)', val: 48000, height: '70%' },
                      { day: 'Tue (মঙ্গল)', val: 62000, height: '90%' },
                      { day: 'Wed (বুধ)', val: 39000, height: '55%' },
                      { day: 'Thu (বৃহস্পতি)', val: 71000, height: '100%' },
                      { day: 'Fri (শুক্র)', val: 65000, height: '92%' }
                    ].map((item, idx) => (
                      <div key={idx} className="flex-1 flex flex-col items-center gap-2 h-full justify-end group">
                        <span className="text-[10px] font-bold text-gray-400 group-hover:text-emerald-600 transition-colors opacity-0 group-hover:opacity-100">
                          ৳{(item.val / 1000).toFixed(0)}k
                        </span>
                        <div className="w-full max-w-[42px] bg-gray-100 dark:bg-gray-700 rounded-t-xl overflow-hidden relative flex flex-col justify-end h-full">
                          <div 
                            style={{ height: item.height }} 
                            className="w-full bg-gradient-to-t from-emerald-600 to-teal-400 rounded-t-xl transition-all duration-500 group-hover:from-emerald-500 group-hover:to-teal-300"
                          />
                        </div>
                        <span className="text-[10px] font-bold text-gray-500 truncate w-full text-center">
                          {item.day.split(' ')[0]}
                        </span>
                      </div>
                    ))}
                  </div>
                  <div className="pt-3 border-t border-gray-100 dark:border-gray-700/80 flex items-center justify-between text-xs text-gray-500">
                    <span>{t('গড় দৈনিক বিক্রয়: ৳৫৬,২৮৫', 'Average Daily Sales: ৳56,285')}</span>
                    <span className="font-bold text-emerald-600">{t('শীর্ষ দিন: বৃহস্পতিবার (৳৭১,০০০)', 'Peak Day: Thursday (৳71,000)')}</span>
                  </div>
                </div>
              </div>

              {/* 2. Orders Chart Breakdown */}
              <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 border border-gray-100 dark:border-gray-700 shadow-xs space-y-4">
                <div>
                  <h3 className="text-sm font-black text-gray-900 dark:text-white flex items-center gap-2">
                    <ShoppingBag className="w-4 h-4 text-blue-600" />
                    <span>{t('অর্ডার স্ট্যাটাস চার্ট (Orders Chart)', 'Orders Fulfillment Chart')}</span>
                  </h3>
                  <p className="text-xs text-gray-400">{t('ডেলিভারি প্রক্রিয়ার বিভাজন', 'Fulfillment distribution')}</p>
                </div>

                <div className="space-y-3.5 pt-2">
                  <div>
                    <div className="flex justify-between text-xs font-bold mb-1">
                      <span className="text-emerald-600">{t('ডেলিভার্ড সম্পন্ন (Delivered)', 'Delivered')}</span>
                      <span className="text-gray-900 dark:text-white font-mono">84% (1,078)</span>
                    </div>
                    <div className="w-full h-2.5 rounded-full bg-gray-100 dark:bg-gray-700 overflow-hidden">
                      <div className="h-full bg-emerald-500 rounded-full" style={{ width: '84%' }} />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-xs font-bold mb-1">
                      <span className="text-blue-600">{t('ট্রানজিট ও কুরিয়ারে (In Transit)', 'In Transit / Dispatched')}</span>
                      <span className="text-gray-900 dark:text-white font-mono">9% (116)</span>
                    </div>
                    <div className="w-full h-2.5 rounded-full bg-gray-100 dark:bg-gray-700 overflow-hidden">
                      <div className="h-full bg-blue-500 rounded-full" style={{ width: '9%' }} />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-xs font-bold mb-1">
                      <span className="text-amber-600">{t('পেন্ডিং নিশ্চিতকরণ (Pending)', 'Pending Review')}</span>
                      <span className="text-gray-900 dark:text-white font-mono">4% (51)</span>
                    </div>
                    <div className="w-full h-2.5 rounded-full bg-gray-100 dark:bg-gray-700 overflow-hidden">
                      <div className="h-full bg-amber-500 rounded-full" style={{ width: '4%' }} />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-xs font-bold mb-1">
                      <span className="text-rose-600">{t('বাতিলকৃত (Cancelled/Returned)', 'Cancelled / Return')}</span>
                      <span className="text-gray-900 dark:text-white font-mono">3% (39)</span>
                    </div>
                    <div className="w-full h-2.5 rounded-full bg-gray-100 dark:bg-gray-700 overflow-hidden">
                      <div className="h-full bg-rose-500 rounded-full" style={{ width: '3%' }} />
                    </div>
                  </div>
                </div>

                <div className="p-3 rounded-2xl bg-gray-50 dark:bg-gray-750 text-xs text-gray-500 space-y-1">
                  <div className="flex justify-between font-bold">
                    <span>{t('কুরিয়ার রিটার্ন রেট:', 'Courier Return Rate:')}</span>
                    <span className="text-emerald-600">1.8% ({t('খুবই ভালো', 'Excellent')})</span>
                  </div>
                  <div className="flex justify-between">
                    <span>{t('গড় ডেলিভারি সময়:', 'Avg Delivery Time:')}</span>
                    <span className="text-gray-900 dark:text-white">28.4 Hours</span>
                  </div>
                </div>
              </div>
            </div>

            {/* LEADERBOARDS ROW: TOP PRODUCTS & TOP SELLERS */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* TOP PRODUCTS */}
              <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 border border-gray-100 dark:border-gray-700 shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-black text-gray-900 dark:text-white flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-amber-500" />
                      <span>{t('শীর্ষ বিক্রিত পণ্যসমূহ (Top Products)', 'Top Selling Products')}</span>
                    </h3>
                    <p className="text-xs text-gray-400">{t('সর্বাধিক বিক্রয় ও আয়ের ভিত্তিতে', 'Ranked by customer demand & sales volume')}</p>
                  </div>
                  <button 
                    onClick={() => setActiveTab('products')} 
                    className="text-xs font-bold text-purple-600 hover:underline"
                  >
                    {t('সকল পণ্য →', 'View All →')}
                  </button>
                </div>

                <div className="space-y-2.5">
                  {topProducts.map((p, idx) => (
                    <div key={p.id} className="p-3 rounded-2xl bg-gray-50 dark:bg-gray-750 border border-gray-100 dark:border-gray-700/60 flex items-center justify-between text-xs">
                      <div className="flex items-center gap-3">
                        <span className="w-6 h-6 rounded-full bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 font-black text-[11px] flex items-center justify-center shrink-0">
                          #{idx + 1}
                        </span>
                        <img src={p.image} alt={p.name} className="w-10 h-10 rounded-xl object-cover shrink-0" />
                        <div className="min-w-0">
                          <span className="font-bold text-gray-900 dark:text-white block truncate">{t(p.nameBn, p.name)}</span>
                          <span className="text-[11px] text-gray-400">{p.vendorName} • ৳{p.price}</span>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <span className="font-black text-emerald-600 block">৳{(p.price * (p.reviewCount || 10)).toLocaleString()}</span>
                        <span className="text-[10px] text-gray-400">{p.reviewCount * 3} {t('বিক্রয়', 'Sold')}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* TOP SELLERS */}
              <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 border border-gray-100 dark:border-gray-700 shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-black text-gray-900 dark:text-white flex items-center gap-2">
                      <Store className="w-4 h-4 text-emerald-600" />
                      <span>{t('শীর্ষ পারফর্মিং বিক্রেতা (Top Sellers)', 'Top Merchant Partners')}</span>
                    </h3>
                    <p className="text-xs text-gray-400">{t('রেটিং, কোয়ালিটি ও পূর্ণাঙ্গ অর্ডার সংখ্যা অনুসারে', 'Ranked by customer satisfaction & volume')}</p>
                  </div>
                  <button 
                    onClick={() => setActiveTab('sellers')} 
                    className="text-xs font-bold text-purple-600 hover:underline"
                  >
                    {t('সকল বিক্রেতা →', 'View All →')}
                  </button>
                </div>

                <div className="space-y-2.5">
                  {topSellers.map((s, idx) => (
                    <div key={s.id} className="p-3 rounded-2xl bg-gray-50 dark:bg-gray-750 border border-gray-100 dark:border-gray-700/60 flex items-center justify-between text-xs">
                      <div className="flex items-center gap-3">
                        <span className="w-6 h-6 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-black text-[11px] flex items-center justify-center shrink-0">
                          #{idx + 1}
                        </span>
                        <img src={s.logo} alt={s.name} className="w-10 h-10 rounded-xl object-cover shrink-0" />
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className="font-bold text-gray-900 dark:text-white truncate">{t(s.nameBn, s.name)}</span>
                            <ShieldCheck className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                          </div>
                          <span className="text-[11px] text-gray-400">{s.location}</span>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <span className="font-black text-amber-500 block">⭐ {s.rating}</span>
                        <span className="text-[10px] text-gray-400">{s.reviewsCount} {t('রিভিউ', 'reviews')}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* LOW STOCK PRODUCTS MONITOR */}
            <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 border border-gray-100 dark:border-gray-700 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-black text-rose-600 dark:text-rose-400 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4" />
                    <span>{t('স্বল্প স্টক পণ্য তালিকা (Low-Stock Products Alert)', 'Low-Stock Products Alert')}</span>
                  </h3>
                  <p className="text-xs text-gray-400">{t('যেসব পণ্যের ইনভেন্টরি স্টক ২৫ বা তার কম রয়েছে', 'Items with stock count 25 or below')}</p>
                </div>
                <span className="px-3 py-1 rounded-full bg-rose-50 dark:bg-rose-950 text-rose-600 font-bold text-xs">
                  {lowStockProductsList.length} {t('পণ্য সতর্কতা', 'Critical Items')}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {lowStockProductsList.slice(0, 6).map((p) => (
                  <div key={p.id} className="p-3.5 rounded-2xl bg-rose-50/50 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-800/60 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-3 min-w-0">
                      <img src={p.image} alt={p.name} className="w-10 h-10 rounded-xl object-cover shrink-0" />
                      <div className="min-w-0">
                        <span className="font-bold text-gray-900 dark:text-white block truncate">{t(p.nameBn, p.name)}</span>
                        <span className="text-[10px] text-gray-400 block truncate">{p.vendorName}</span>
                      </div>
                    </div>
                    <div className="text-right shrink-0 pl-2">
                      <span className="px-2 py-0.5 rounded-lg bg-rose-100 dark:bg-rose-900 text-rose-700 dark:text-rose-200 font-black text-[11px] block">
                        {p.stock} left
                      </span>
                      <span className="text-[10px] font-bold text-emerald-600 mt-1 block">৳{p.price}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 2: ORDER MANAGEMENT & PENDING ORDERS */}
        {/* ======================================================== */}
        {activeTab === 'orders' && (
          <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 border border-gray-100 dark:border-gray-700 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-black text-gray-900 dark:text-white">
                  {t('অর্ডার ব্যবস্থাপনা ও ট্র্যাকিং কন্ট্রোল', 'Order Management & Fulfillment Queue')}
                </h3>
                <p className="text-xs text-gray-400">{t('পেন্ডিং অর্ডার অনুমোদন, কুরিয়ার নির্বাচন ও স্থিতি পরিবর্তন', 'Review pending orders, assign BD couriers, and update fulfillment')}</p>
              </div>

              {/* Filters */}
              <div className="flex flex-wrap items-center gap-2">
                <div className="relative">
                  <input
                    type="text"
                    value={orderSearchQuery}
                    onChange={(e) => setOrderSearchQuery(e.target.value)}
                    placeholder="Search by ID, Name or Phone..."
                    className="bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-650 rounded-xl px-3 py-1.5 pl-8 text-xs text-gray-900 dark:text-white focus:outline-none"
                  />
                  <Search className="w-3.5 h-3.5 text-gray-400 absolute left-2.5 top-2.5" />
                </div>

                <select
                  value={orderStatusFilter}
                  onChange={(e) => setOrderStatusFilter(e.target.value)}
                  className="bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-650 rounded-xl px-3 py-1.5 text-xs font-bold text-gray-700 dark:text-gray-300"
                >
                  <option value="all">{t('সকল অর্ডার স্ট্যাটাস', 'All Statuses')}</option>
                  <option value="placed">{t('নতুন স্থাপিত (Placed / Pending)', 'Placed')}</option>
                  <option value="confirmed">{t('নিশ্চিতকৃত (Confirmed)', 'Confirmed')}</option>
                  <option value="processing">{t('প্রসেসিং হচ্ছে (Processing)', 'Processing')}</option>
                  <option value="shipped">{t('শিপড (Shipped)', 'Shipped')}</option>
                  <option value="delivered">{t('ডেলিভার্ড (Delivered)', 'Delivered')}</option>
                  <option value="cancelled">{t('বাতিল (Cancelled)', 'Cancelled')}</option>
                </select>

                <button
                  type="button"
                  onClick={() => openCategoryCashMemo('all')}
                  className="px-3.5 py-1.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white rounded-xl text-xs font-bold shadow-xs flex items-center gap-1.5 transition-all active:scale-95"
                >
                  <Receipt className="w-3.5 h-3.5" />
                  <span>{t('ক্যাটাগরি ক্যাশ মেমো / ইনভয়েজ', 'Category Cash Memo')}</span>
                </button>
              </div>
            </div>

            {/* Orders Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-gray-200 dark:border-gray-700 text-gray-400 font-bold uppercase text-[10px]">
                    <th className="pb-3">{t('অর্ডার নম্বর ও তারিখ', 'Order ID & Date')}</th>
                    <th className="pb-3">{t('গ্রাহক ও ঠিকানা', 'Customer & Address')}</th>
                    <th className="pb-3">{t('পেমেন্ট ও মোট', 'Payment & Total')}</th>
                    <th className="pb-3">{t('নির্ধারিত কুরিয়ার', 'Assigned BD Courier')}</th>
                    <th className="pb-3">{t('স্ট্যাটাস', 'Status')}</th>
                    <th className="pb-3 text-right">{t('অ্যাকশন', 'Action')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 dark:divide-gray-700/60">
                  {filteredOrders.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-gray-400">
                        {t('কোনো অর্ডার খুঁজে পাওয়া যায়নি।', 'No orders found matching criteria.')}
                      </td>
                    </tr>
                  ) : (
                    filteredOrders.map((ord) => (
                      <tr key={ord.id} className="hover:bg-gray-50/50 dark:hover:bg-gray-750/30 transition-colors">
                        <td className="py-3.5">
                          <span className="font-mono font-bold text-purple-600 dark:text-purple-400 block">{ord.orderNumber}</span>
                          <span className="text-[10px] text-gray-400">{new Date(ord.createdAt).toLocaleDateString()}</span>
                        </td>
                        <td className="py-3.5">
                          <span className="font-bold text-gray-900 dark:text-white block">{ord.customerName}</span>
                          <span className="text-[11px] text-gray-500 block">{ord.customerPhone}</span>
                          <span className="text-[10px] text-gray-400 block truncate max-w-xs">{ord.address}, {ord.district}</span>
                        </td>
                        <td className="py-3.5">
                          <span className="font-black text-emerald-600 block">৳{ord.total}</span>
                          <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 inline-block mt-0.5">
                            {ord.paymentMethod} • {ord.paymentStatus}
                          </span>
                        </td>
                        <td className="py-3.5">
                          <select
                            value={ord.courierId || 'steadfast'}
                            onChange={(e) => assignOrderCourier(ord.id, e.target.value)}
                            className="bg-teal-50 dark:bg-teal-950/50 border border-teal-200 dark:border-teal-800 text-teal-800 dark:text-teal-200 rounded-xl px-2.5 py-1 text-[11px] font-bold focus:outline-none"
                          >
                            {BANGLADESH_COURIERS.map(c => (
                              <option key={c.id} value={c.id}>{c.name}</option>
                            ))}
                          </select>
                          <span className="font-mono text-[10px] text-gray-400 block mt-1">
                            {ord.courierTrackingCode || 'ST-AutoGenerated'}
                          </span>
                        </td>
                        <td className="py-3.5">
                          <select
                            value={ord.status}
                            onChange={(e) => updateOrderStatus(ord.id, e.target.value as any)}
                            className={`rounded-xl px-2.5 py-1 font-bold text-[11px] border focus:outline-none ${
                              ord.status === 'delivered' ? 'bg-emerald-50 text-emerald-700 border-emerald-300' :
                              ord.status === 'cancelled' ? 'bg-rose-50 text-rose-700 border-rose-300' :
                              ord.status === 'placed' ? 'bg-amber-50 text-amber-700 border-amber-300 animate-pulse' :
                              'bg-blue-50 text-blue-700 border-blue-300'
                            }`}
                          >
                            <option value="placed">Placed (নতুন)</option>
                            <option value="confirmed">Confirmed (নিশ্চিত)</option>
                            <option value="processing">Processing (প্যাকিং)</option>
                            <option value="shipped">Shipped (কুরিয়ারে)</option>
                            <option value="out_for_delivery">Out for Delivery</option>
                            <option value="delivered">Delivered (সম্পন্ন)</option>
                            <option value="cancelled">Cancelled (বাতিল)</option>
                          </select>
                        </td>
                        <td className="py-3.5 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              type="button"
                              onClick={() => openCashMemoModal(ord)}
                              className="px-2 py-1 bg-purple-50 hover:bg-purple-100 dark:bg-purple-950/40 dark:hover:bg-purple-900/40 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800 rounded-lg text-[10px] font-bold flex items-center gap-1 transition-all"
                              title={t('ক্যাশ মেমো ও ইনভয়েস ডাউনলোড (PDF/Image)', 'Download Cash Memo & Invoice (PDF/Image)')}
                            >
                              <Receipt className="w-3 h-3 text-purple-600" />
                              <span>{t('মেমো / PDF', 'Memo')}</span>
                            </button>
                            {ord.status === 'placed' && (
                              <button
                                onClick={() => updateOrderStatus(ord.id, 'confirmed')}
                                className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[10px] font-bold shadow-xs transition-all"
                              >
                                {t('অনুমোদন', 'Approve')}
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 3: PRODUCTS & PRODUCT APPROVAL */}
        {/* ======================================================== */}
        {activeTab === 'products' && (
          <div className="space-y-6">
            {/* Product Approval Section */}
            {pendingProducts.length > 0 && (
              <div className="bg-amber-50/70 dark:bg-amber-950/30 rounded-3xl p-6 border border-amber-200 dark:border-amber-800 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-black text-amber-900 dark:text-amber-200 flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-amber-600" />
                      <span>{t('বিক্রেতাদের নতুন পণ্য অনুমোদন অপেক্ষমাণ (Product Approval Queue)', 'Product Approval Queue')}</span>
                    </h3>
                    <p className="text-xs text-amber-700 dark:text-amber-400">
                      {t('বিক্রেতাদের দাখিলকৃত পণ্য পরীক্ষা করে অনুমোদন দিন বা বাতিল করুন', 'Review submitted product specifications and approve for marketplace listing')}
                    </p>
                  </div>
                  <span className="px-3 py-1 rounded-full bg-amber-500 text-white text-xs font-bold">
                    {pendingProducts.length} Pending
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {pendingProducts.map((p) => (
                    <div key={p.id} className="bg-white dark:bg-gray-800 p-4 rounded-2xl border border-amber-200 dark:border-amber-800 flex items-center justify-between gap-4">
                      <div className="flex items-center gap-3">
                        <img src={p.image} alt={p.name} className="w-14 h-14 rounded-xl object-cover shrink-0" />
                        <div>
                          <span className="font-bold text-gray-900 dark:text-white text-xs block">{p.nameBn || p.name}</span>
                          <span className="text-[11px] text-gray-400 block">{p.vendorName} • {p.category}</span>
                          <span className="text-xs font-black text-emerald-600 mt-0.5 block">৳{p.price} (Stock: {p.stock})</span>
                        </div>
                      </div>

                      <div className="flex flex-col gap-1.5 shrink-0">
                        <button
                          onClick={() => handleApproveProduct(p.id)}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-[11px] font-bold flex items-center gap-1 shadow-xs"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>{t('অনুমোদন', 'Approve')}</span>
                        </button>
                        <button
                          onClick={() => handleRejectProduct(p.id)}
                          className="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-300 rounded-xl text-[11px] font-bold"
                        >
                          <X className="w-3.5 h-3.5" />
                          <span>{t('প্রত্যাখ্যান', 'Reject')}</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Inventory Management & All Products */}
            <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 border border-gray-100 dark:border-gray-700 shadow-xs space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h3 className="text-base font-black text-gray-900 dark:text-white">
                    {t('সকল সক্রিয় পণ্য ও স্টক ইনভেন্টরি', 'Active Products & Inventory Management')}
                  </h3>
                  <p className="text-xs text-gray-400">
                    {t(`মোট ${products.length}টি পণ্য মার্কেটপ্লেসে নিবন্ধিত রয়েছে`, `Total ${products.length} items catalogued across all categories`)}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => setIsAddProductModalOpen(true)}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs flex items-center gap-1.5 transition-all"
                  >
                    <Plus className="w-4 h-4" />
                    <span>{t('নতুন পণ্য যোগ করুন', '+ Add Product')}</span>
                  </button>

                  <button
                    onClick={handleOpenAddCategory}
                    className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl text-xs font-bold shadow-xs flex items-center gap-1.5 active:scale-95 transition-all"
                    title={t('নতুন ক্যাটাগরি তৈরি করুন', 'Create New Category')}
                  >
                    <Layers className="w-4 h-4" />
                    <span>{t('নতুন ক্যাটাগরি যোগ করুন', '+ Add Category')}</span>
                  </button>

                  <div className="relative">
                    <input
                      type="text"
                      value={productSearchQuery}
                      onChange={(e) => setProductSearchQuery(e.target.value)}
                      placeholder="Search product..."
                      className="bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-650 rounded-xl px-3 py-1.5 pl-8 text-xs text-gray-900 dark:text-white focus:outline-none"
                    />
                    <Search className="w-3.5 h-3.5 text-gray-400 absolute left-2.5 top-2.5" />
                  </div>

                  <select
                    value={productCategoryFilter}
                    onChange={(e) => setProductCategoryFilter(e.target.value)}
                    className="bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-650 rounded-xl px-3 py-1.5 text-xs text-gray-700 dark:text-gray-300"
                  >
                    <option value="all">{t('সকল ক্যাটাগরি', 'All Categories')}</option>
                    {categories.map(c => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Products Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-gray-200 dark:border-gray-700 text-gray-400 font-bold uppercase text-[10px]">
                      <th className="pb-3">{t('পণ্য বিবরণ', 'Product')}</th>
                      <th className="pb-3">{t('ক্যাটাগরি', 'Category')}</th>
                      <th className="pb-3">{t('বিক্রেতা', 'Seller')}</th>
                      <th className="pb-3">{t('মূল্য ও ছাড়', 'Price & Discount')}</th>
                      <th className="pb-3">{t('স্টক সংখ্যা', 'Stock')}</th>
                      <th className="pb-3 text-right">{t('অবস্থা', 'Status')}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-gray-700/60">
                    {filteredProducts.slice(0, 15).map((p) => (
                      <tr key={p.id} className="hover:bg-gray-50/50 dark:hover:bg-gray-750/30 transition-colors">
                        <td className="py-3">
                          <div className="flex items-center gap-3">
                            <img src={p.image} alt={p.name} className="w-10 h-10 rounded-xl object-cover shrink-0" />
                            <div className="min-w-0">
                              <span className="font-bold text-gray-900 dark:text-white block truncate max-w-xs">{t(p.nameBn, p.name)}</span>
                              <span className="text-[10px] text-gray-400 font-mono">{p.id} • {p.unit}</span>
                            </div>
                          </div>
                        </td>
                        <td className="py-3">
                          <span className="px-2 py-0.5 rounded-lg bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 text-[10px] font-bold">
                            {p.category}
                          </span>
                        </td>
                        <td className="py-3 text-gray-600 dark:text-gray-300">
                          {p.vendorName}
                        </td>
                        <td className="py-3">
                          <span className="font-bold text-emerald-600">৳{p.price}</span>
                          {p.originalPrice > p.price && (
                            <span className="text-[10px] text-gray-400 line-through ml-1.5">৳{p.originalPrice}</span>
                          )}
                        </td>
                        <td className="py-3">
                          <span className={`px-2 py-0.5 rounded-lg text-[10px] font-black ${
                            p.stock <= 20 
                              ? 'bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300' 
                              : 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
                          }`}>
                            {p.stock} {p.stock <= 20 ? 'Low Stock' : 'In Stock'}
                          </span>
                        </td>
                        <td className="py-3 text-right">
                          <span className="inline-flex items-center gap-1 text-emerald-600 text-[11px] font-bold">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Live</span>
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 4: SELLERS & SELLER APPROVAL (KYC) */}
        {/* ======================================================== */}
        {activeTab === 'sellers' && (
          <div className="space-y-6">
            {/* Pending Seller Applications */}
            <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 border border-gray-100 dark:border-gray-700 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-black text-gray-900 dark:text-white flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-purple-600" />
                    <span>{t('বিক্রেতা আবেদন ও কেওয়াইসি অনুমোদন (Seller Approval & KYC)', 'Seller Approval & KYC Verification')}</span>
                  </h3>
                  <p className="text-xs text-gray-400">{t('ট্রেড লাইসেন্স ও জাতীয় পরিচয়পত্র যাচাই করে নতুন মার্চেন্ট অনুমোদন দিন', 'Verify trade licenses and merchant credentials')}</p>
                </div>
                <span className="px-3 py-1 rounded-full bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 text-xs font-bold">
                  {sellerApplications.filter(s => s.status === 'pending').length} Pending Requests
                </span>
              </div>

              <div className="divide-y divide-gray-100 dark:divide-gray-700">
                {sellerApplications.map((app) => (
                  <div key={app.id} className="py-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-xl bg-purple-100 dark:bg-purple-950 text-purple-600 flex items-center justify-center font-bold shrink-0">
                        <Store className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-bold text-gray-900 dark:text-white text-xs">{app.shopName}</h4>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            app.status === 'approved' ? 'bg-emerald-100 text-emerald-700' :
                            app.status === 'rejected' ? 'bg-rose-100 text-rose-700' :
                            'bg-amber-100 text-amber-700'
                          }`}>
                            {app.status.toUpperCase()}
                          </span>
                        </div>
                        <p className="text-[11px] text-gray-500 mt-0.5">
                          {t('মালিক:', 'Owner:')} <strong>{app.ownerName}</strong> • 📞 {app.phone} • ✉️ {app.email}
                        </p>
                        <p className="text-[11px] text-gray-400">
                          📍 {app.location} • 📜 {t('ট্রেড লাইসেন্স:', 'Trade License:')} <span className="font-mono text-purple-600 font-bold">{app.tradeLicense}</span> • {app.category}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {app.status === 'pending' ? (
                        <>
                          <button
                            onClick={() => handleApproveSeller(app.id)}
                            className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1 shadow-xs"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>{t('অনুমোদন ও ভেরিফাই', 'Approve & Verify')}</span>
                          </button>
                          <button
                            onClick={() => handleRejectSeller(app.id)}
                            className="px-3.5 py-1.5 bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-300 rounded-xl text-xs font-bold"
                          >
                            <X className="w-3.5 h-3.5" />
                            <span>{t('বাতিল', 'Reject')}</span>
                          </button>
                        </>
                      ) : (
                        <span className="text-xs text-gray-400 font-bold">
                          {app.status === 'approved' ? t('অনুমোদিত মার্চেন্ট', 'Active Merchant') : t('বাতিলকৃত', 'Rejected')}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Active Verified Sellers List */}
            <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 border border-gray-100 dark:border-gray-700 shadow-xs space-y-4">
              <h3 className="text-base font-black text-gray-900 dark:text-white">
                {t('সক্রিয় ও যাচাইকৃত বিক্রেতা তালিকা', 'Active Verified Vendors')}
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {sellers.map((s) => (
                  <div key={s.id} className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-750 border border-gray-100 dark:border-gray-700 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <img src={s.logo} alt={s.name} className="w-12 h-12 rounded-xl object-cover shrink-0" />
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold text-gray-900 dark:text-white text-xs">{t(s.nameBn, s.name)}</span>
                          <span className="px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-700 font-bold text-[9px]">Verified</span>
                        </div>
                        <span className="text-[11px] text-gray-400 block">{s.location} • Joined {s.joinedYear}</span>
                        <span className="text-[11px] text-amber-500 font-bold mt-0.5 block">⭐ {s.rating} ({s.reviewsCount} reviews) • {s.productsCount} products</span>
                      </div>
                    </div>

                    <button
                      onClick={() => showToast(t(`মার্চেন্ট ${s.name} এর প্রোফাইল খোলা হচ্ছে`, `Opening merchant profile for ${s.name}`), 'info')}
                      className="p-2 rounded-xl text-gray-400 hover:text-purple-600 hover:bg-white dark:hover:bg-gray-700"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 5: CATEGORY MANAGEMENT */}
        {/* ======================================================== */}
        {activeTab === 'categories' && (
          <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 border border-gray-100 dark:border-gray-700 shadow-xs space-y-6">
            {/* Header & Main Actions */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-gray-100 dark:border-gray-700">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-black text-gray-900 dark:text-white flex items-center gap-2">
                    <Layers className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                    <span>{t('পণ্য ক্যাটাগরি ও ইমেজ ম্যানেজমেন্ট হাব', 'Product Category, Image & Customization Hub')}</span>
                  </h3>
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold text-xs">
                    {categories.length} {t('ক্যাটাগরি', 'Categories')}
                  </span>
                </div>
                <p className="text-xs text-gray-400 mt-0.5">
                  {t(
                    'সকল ক্যাটাগরির ছবি পরিবর্তন, নতুন ক্যাটাগরি তৈরি, কালার থিম ও আইকন কাস্টমাইজেশন, কমিশন রেট এবং সক্রিয়/নিষ্ক্রিয় স্ট্যাটাস পরিচালনা করুন',
                    'Edit category cover images, customize theme palettes & icons, manage commission rates, or delete categories'
                  )}
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2.5">
                <button
                  type="button"
                  onClick={() => openCategoryCashMemo('all')}
                  className="px-3.5 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-600/20 flex items-center gap-1.5 active:scale-95 transition-all"
                >
                  <Receipt className="w-4 h-4" />
                  <span>{t('সকল ক্যাটাগরি ক্যাশ মেমো (PDF / Image)', 'All-Category Cash Memo')}</span>
                </button>

                <button
                  onClick={() => setIsResetConfirmModalOpen(true)}
                  className="px-3.5 py-2 rounded-xl border border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-750 text-xs font-bold flex items-center gap-1.5 transition-colors"
                  title={t('ডিফল্ট ক্যাটাগরিতে রিসেট করুন', 'Reset to Default Categories')}
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>{t('ডিফল্ট রিস্টোর', 'Reset Defaults')}</span>
                </button>

                <button
                  onClick={handleOpenAddCategory}
                  className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-600/20 flex items-center gap-1.5 active:scale-95 transition-all"
                >
                  <Plus className="w-4 h-4" />
                  <span>{t('নতুন ক্যাটাগরি তৈরি করুন', 'Add New Category')}</span>
                </button>
              </div>
            </div>

            {/* Quick Metrics Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
              <div className="p-4 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/40 border border-emerald-100 dark:border-emerald-800/60 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                  <Layers className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[11px] font-bold text-emerald-800 dark:text-emerald-300 block">{t('মোট ক্যাটাগরি', 'Total Categories')}</span>
                  <span className="text-xl font-black text-gray-900 dark:text-white leading-tight">{categories.length}</span>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-blue-50/70 dark:bg-blue-950/40 border border-blue-100 dark:border-blue-800/60 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[11px] font-bold text-blue-800 dark:text-blue-300 block">{t('সক্রিয় ক্যাটাগরি', 'Active Categories')}</span>
                  <span className="text-xl font-black text-gray-900 dark:text-white leading-tight">
                    {categories.filter(c => c.status !== 'inactive').length}
                  </span>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-amber-50/70 dark:bg-amber-950/40 border border-amber-100 dark:border-amber-800/60 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-xs">
                  <Eye className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[11px] font-bold text-amber-800 dark:text-amber-300 block">{t('নিষ্ক্রিয় / লুকানো', 'Inactive / Hidden')}</span>
                  <span className="text-xl font-black text-gray-900 dark:text-white leading-tight">
                    {categories.filter(c => c.status === 'inactive').length}
                  </span>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-purple-50/70 dark:bg-purple-950/40 border border-purple-100 dark:border-purple-800/60 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-purple-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                  <ShoppingBag className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[11px] font-bold text-purple-800 dark:text-purple-300 block">{t('ক্যাটালগকৃত পণ্য', 'Catalogued Items')}</span>
                  <span className="text-xl font-black text-gray-900 dark:text-white leading-tight">{products.length}</span>
                </div>
              </div>
            </div>

            {/* Filter, Search & View Controls */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 rounded-2xl bg-gray-50 dark:bg-gray-750 border border-gray-100 dark:border-gray-700">
              <div className="relative flex-1 max-w-md">
                <input
                  type="text"
                  value={categorySearchQuery}
                  onChange={(e) => setCategorySearchQuery(e.target.value)}
                  placeholder={t('নাম, আইডি বা ট্যাগ দিয়ে ক্যাটাগরি খুঁজুন...', 'Search categories by name, ID or tags...')}
                  className="w-full pl-9 pr-8 py-2 rounded-xl border border-gray-200 dark:border-gray-650 bg-white dark:bg-gray-800 text-gray-900 dark:text-white text-xs font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
                <Search className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
                {categorySearchQuery && (
                  <button
                    onClick={() => setCategorySearchQuery('')}
                    className="absolute right-2.5 top-2.5 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {/* Status Filter */}
                <select
                  value={categoryStatusFilter}
                  onChange={(e) => setCategoryStatusFilter(e.target.value as any)}
                  className="px-3 py-2 rounded-xl border border-gray-200 dark:border-gray-650 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 text-xs font-bold"
                >
                  <option value="all">{t('সকল স্ট্যাটাস', 'All Status')}</option>
                  <option value="active">{t('সক্রিয় (Active)', 'Active Only')}</option>
                  <option value="inactive">{t('নিষ্ক্রিয় (Inactive)', 'Inactive Only')}</option>
                </select>

                {/* Sort Filter */}
                <select
                  value={categorySortBy}
                  onChange={(e) => setCategorySortBy(e.target.value as any)}
                  className="px-3 py-2 rounded-xl border border-gray-200 dark:border-gray-650 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 text-xs font-bold"
                >
                  <option value="default">{t('সাজানো: ডিফল্ট', 'Sort: Default')}</option>
                  <option value="name">{t('নাম (A-Z)', 'Name (A-Z)')}</option>
                  <option value="items">{t('সর্বাধিক পণ্য', 'Most Products')}</option>
                  <option value="commission">{t('সর্বোচ্চ কমিশন', 'Highest Commission')}</option>
                </select>

                {/* View Mode Toggle */}
                <div className="flex items-center rounded-xl bg-gray-200/80 dark:bg-gray-700 p-0.5">
                  <button
                    type="button"
                    onClick={() => setCategoryViewMode('grid')}
                    className={`p-1.5 rounded-lg text-xs transition-colors ${
                      categoryViewMode === 'grid' 
                        ? 'bg-white dark:bg-gray-800 text-emerald-600 dark:text-emerald-400 shadow-xs' 
                        : 'text-gray-500 hover:text-gray-900 dark:text-gray-400'
                    }`}
                    title={t('গ্রিড ভিউ', 'Grid View')}
                  >
                    <Grid className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setCategoryViewMode('table')}
                    className={`p-1.5 rounded-lg text-xs transition-colors ${
                      categoryViewMode === 'table' 
                        ? 'bg-white dark:bg-gray-800 text-emerald-600 dark:text-emerald-400 shadow-xs' 
                        : 'text-gray-500 hover:text-gray-900 dark:text-gray-400'
                    }`}
                    title={t('টেবিল ভিউ', 'Table View')}
                  >
                    <List className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Empty State */}
            {filteredAndSortedCategories.length === 0 && (
              <div className="p-12 text-center rounded-2xl bg-gray-50 dark:bg-gray-750 border border-gray-100 dark:border-gray-700">
                <Layers className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-3" />
                <h4 className="text-sm font-bold text-gray-700 dark:text-gray-300 mb-1">
                  {t('কোনো ক্যাটাগরি পাওয়া যায়নি', 'No categories match your filter')}
                </h4>
                <p className="text-xs text-gray-400 mb-4">
                  {t('সার্চ কুয়েরি পরিবর্তন করুন অথবা নতুন ক্যাটাগরি তৈরি করুন', 'Try clearing your search term or add a new category')}
                </p>
                <div className="flex items-center justify-center gap-3">
                  <button
                    onClick={() => {
                      setCategorySearchQuery('');
                      setCategoryStatusFilter('all');
                    }}
                    className="px-4 py-2 rounded-xl bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 text-xs font-bold"
                  >
                    {t('ফিল্টার মুছুন', 'Clear Filters')}
                  </button>
                  <button
                    onClick={handleOpenAddCategory}
                    className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-bold flex items-center gap-1.5"
                  >
                    <Plus className="w-4 h-4" />
                    <span>{t('নতুন ক্যাটাগরি তৈরি করুন', 'Add New Category')}</span>
                  </button>
                </div>
              </div>
            )}

            {/* GRID VIEW */}
            {categoryViewMode === 'grid' && filteredAndSortedCategories.length > 0 && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredAndSortedCategories.map((cat) => {
                  const linkedProductsCount = products.filter(p => p.category === cat.id).length;
                  const displayItemsCount = cat.itemCount || linkedProductsCount;
                  const isActive = cat.status !== 'inactive';

                  return (
                    <div 
                      key={cat.id} 
                      className={`group rounded-3xl border transition-all duration-300 flex flex-col justify-between overflow-hidden bg-white dark:bg-gray-750 ${
                        isActive 
                          ? 'border-gray-200 dark:border-gray-700/80 hover:border-emerald-500 hover:shadow-lg' 
                          : 'border-red-200 dark:border-red-900/50 opacity-80'
                      }`}
                    >
                      {/* Top Cover Image Box */}
                      <div className="relative w-full h-40 bg-gray-100 dark:bg-gray-800 overflow-hidden">
                        <img 
                          src={cat.image} 
                          alt={cat.name} 
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />

                        {/* Top Left Icon Pill */}
                        <div className="absolute top-3 left-3 flex items-center gap-2">
                          <div className="w-8 h-8 rounded-xl bg-white/95 dark:bg-gray-800/95 backdrop-blur-md flex items-center justify-center shadow-md">
                            {getCategoryIconElement(cat)}
                          </div>
                          <span className="px-2 py-0.5 rounded-md bg-black/60 backdrop-blur-md text-white font-mono text-[10px] font-bold">
                            #{cat.id}
                          </span>
                        </div>

                        {/* Top Right Status Toggle */}
                        <button
                          type="button"
                          onClick={(e) => handleToggleCategoryStatus(cat, e)}
                          className={`absolute top-3 right-3 px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider backdrop-blur-md shadow-md transition-transform active:scale-95 flex items-center gap-1 ${
                            isActive
                              ? 'bg-emerald-600/90 text-white hover:bg-emerald-700'
                              : 'bg-red-600/90 text-white hover:bg-red-700'
                          }`}
                          title={t('স্ট্যাটাস পরিবর্তন করতে ক্লিক করুন', 'Click to toggle active/inactive')}
                        >
                          <span className={`w-1.5 h-1.5 rounded-full ${isActive ? 'bg-white' : 'bg-red-200'}`} />
                          <span>{isActive ? 'Active' : 'Inactive'}</span>
                        </button>

                        {/* Hover Overlay Button to Quickly Edit Image */}
                        <div className="absolute inset-0 bg-black/40 backdrop-blur-xs opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                          <button
                            type="button"
                            onClick={() => handleOpenEditCategory(cat, 'image')}
                            className="px-3.5 py-2 rounded-xl bg-white/90 dark:bg-gray-800/90 hover:bg-white text-gray-900 dark:text-white text-xs font-bold flex items-center gap-1.5 shadow-md active:scale-95 transition-all"
                          >
                            <ImageIcon className="w-3.5 h-3.5 text-emerald-600" />
                            <span>{t('ছবি পরিবর্তন করুন', 'Change Image')}</span>
                          </button>
                        </div>

                        {/* Bottom Overlay Title on Image */}
                        <div className="absolute bottom-2.5 left-3.5 right-3.5 flex items-end justify-between">
                          <div className="min-w-0 pr-2">
                            <h4 className="font-black text-white text-sm truncate drop-shadow-sm">
                              {cat.name}
                            </h4>
                            <span className="text-emerald-300 font-bold text-xs truncate block drop-shadow-sm">
                              {cat.nameBn || cat.name}
                            </span>
                          </div>
                          <span className="px-2 py-0.5 rounded-lg bg-emerald-500/80 text-white font-bold text-[10px] shrink-0 backdrop-blur-xs">
                            {cat.commissionRate ?? 8.5}% Comm.
                          </span>
                        </div>
                      </div>

                      {/* Card Content & Details */}
                      <div className="p-4 space-y-3 flex-1 flex flex-col justify-between">
                        <div>
                          {/* Badges / Metrics */}
                          <div className="flex items-center justify-between text-[11px] text-gray-500 dark:text-gray-400 pb-2.5 border-b border-gray-100 dark:border-gray-700/60">
                            <span className="flex items-center gap-1 font-semibold text-gray-700 dark:text-gray-300">
                              <ShoppingBag className="w-3.5 h-3.5 text-emerald-600" />
                              <span>{displayItemsCount} {t('পণ্য তালিকাভুক্ত', 'items catalogued')}</span>
                            </span>
                            <span className="text-[10px] text-gray-400">
                              {linkedProductsCount} in store
                            </span>
                          </div>

                          {/* Popular Items Pills */}
                          {cat.popularItems && cat.popularItems.length > 0 && (
                            <div className="mt-2.5">
                              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">
                                {t('জনপ্রিয় পণ্য / ট্যাগ:', 'Popular Tags:')}
                              </span>
                              <div className="flex flex-wrap gap-1.5">
                                {cat.popularItems.slice(0, 3).map((tagItem, tIdx) => (
                                  <span
                                    key={tIdx}
                                    className="px-2 py-0.5 rounded-md bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 text-[10px] font-medium"
                                  >
                                    {tagItem}
                                  </span>
                                ))}
                                {cat.popularItems.length > 3 && (
                                  <span className="px-1.5 py-0.5 rounded-md bg-gray-100 dark:bg-gray-700 text-gray-400 text-[10px]">
                                    +{cat.popularItems.length - 3}
                                  </span>
                                )}
                              </div>
                            </div>
                          )}
                        </div>

                        {/* Action Buttons Toolbar */}
                        <div className="pt-3 border-t border-gray-100 dark:border-gray-700/60 flex items-center justify-between gap-1.5">
                          <div className="flex items-center gap-1">
                            {/* Full Edit */}
                            <button
                              type="button"
                              onClick={() => handleOpenEditCategory(cat, 'general')}
                              className="p-2 rounded-xl text-gray-600 hover:text-emerald-600 dark:text-gray-300 dark:hover:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/50 transition-colors"
                              title={t('সম্পূর্ণ তথ্য সম্পাদনা করুন', 'Edit Full Category')}
                            >
                              <Edit className="w-3.5 h-3.5" />
                            </button>

                            {/* Direct Image Edit */}
                            <button
                              type="button"
                              onClick={() => handleOpenEditCategory(cat, 'image')}
                              className="p-2 rounded-xl text-gray-600 hover:text-blue-600 dark:text-gray-300 dark:hover:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/50 transition-colors"
                              title={t('ছবি ও ব্যানার পরিবর্তন করুন', 'Edit Category Image')}
                            >
                              <ImageIcon className="w-3.5 h-3.5" />
                            </button>

                            {/* Theme & Icon Customizer */}
                            <button
                              type="button"
                              onClick={() => handleOpenEditCategory(cat, 'style')}
                              className="p-2 rounded-xl text-gray-600 hover:text-purple-600 dark:text-gray-300 dark:hover:text-purple-400 hover:bg-purple-50 dark:hover:bg-purple-950/50 transition-colors"
                              title={t('আইকন ও কালার কাস্টমাইজ করুন', 'Customize Icon & Colors')}
                            >
                              <Palette className="w-3.5 h-3.5" />
                            </button>

                            {/* Category Cash Memo */}
                            <button
                              type="button"
                              onClick={() => openCategoryCashMemo(cat.id)}
                              className="p-2 rounded-xl text-gray-600 hover:text-indigo-600 dark:text-gray-300 dark:hover:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/50 transition-colors"
                              title={t('এই ক্যাটাগরির ক্যাশ মেমো / ইনভয়েজ তৈরি করুন', 'Generate Category Cash Memo / Invoice')}
                            >
                              <Receipt className="w-3.5 h-3.5" />
                            </button>

                            {/* View in Shop */}
                            <button
                              type="button"
                              onClick={() => {
                                setSelectedCategory(cat.id);
                                setCurrentView('shop');
                              }}
                              className="p-2 rounded-xl text-gray-600 hover:text-cyan-600 dark:text-gray-300 dark:hover:text-cyan-400 hover:bg-cyan-50 dark:hover:bg-cyan-950/50 transition-colors"
                              title={t('শপে এই ক্যাটাগরি দেখুন', 'View in Shop')}
                            >
                              <ExternalLink className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          {/* Delete Button */}
                          <button
                            type="button"
                            onClick={() => handleOpenDeleteCategory(cat)}
                            className="p-2 rounded-xl text-gray-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/50 transition-colors"
                            title={t('ক্যাটাগরি মুছে ফেলুন', 'Delete Category')}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* TABLE VIEW */}
            {categoryViewMode === 'table' && filteredAndSortedCategories.length > 0 && (
              <div className="overflow-x-auto rounded-2xl border border-gray-100 dark:border-gray-700">
                <table className="w-full text-left text-xs">
                  <thead className="bg-gray-50 dark:bg-gray-750 text-gray-400 font-bold uppercase tracking-wider text-[10px] border-b border-gray-100 dark:border-gray-700">
                    <tr>
                      <th className="py-3 px-4">{t('ছবি ও প্রিভিউ', 'Image')}</th>
                      <th className="py-3 px-4">{t('ক্যাটাগরির নাম', 'Category Name')}</th>
                      <th className="py-3 px-4">{t('স্ল্যাগ / আইডি', 'Slug ID')}</th>
                      <th className="py-3 px-4">{t('আইকন', 'Icon')}</th>
                      <th className="py-3 px-4">{t('পণ্য সংখ্যা', 'Products')}</th>
                      <th className="py-3 px-4">{t('কমিশন', 'Commission')}</th>
                      <th className="py-3 px-4">{t('স্ট্যাটাস', 'Status')}</th>
                      <th className="py-3 px-4 text-right">{t('অ্যাকশন', 'Actions')}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
                    {filteredAndSortedCategories.map((cat) => {
                      const isActive = cat.status !== 'inactive';
                      return (
                        <tr key={cat.id} className="hover:bg-gray-50/60 dark:hover:bg-gray-700/40 transition-colors">
                          <td className="py-3 px-4">
                            <div className="relative w-12 h-12 rounded-xl overflow-hidden bg-gray-100 dark:bg-gray-700 shrink-0 group">
                              <img src={cat.image} alt={cat.name} className="w-full h-full object-cover" />
                              <button
                                onClick={() => handleOpenEditCategory(cat, 'image')}
                                className="absolute inset-0 bg-black/50 text-white opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity"
                                title={t('ছবি বদলান', 'Change Image')}
                              >
                                <ImageIcon className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                          <td className="py-3 px-4">
                            <span className="font-bold text-gray-900 dark:text-white block">{cat.name}</span>
                            <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold block">{cat.nameBn}</span>
                          </td>
                          <td className="py-3 px-4 font-mono text-[11px] text-gray-500 dark:text-gray-400">
                            {cat.id}
                          </td>
                          <td className="py-3 px-4">
                            <div className="w-8 h-8 rounded-lg bg-gray-100 dark:bg-gray-700 flex items-center justify-center">
                              {getCategoryIconElement(cat)}
                            </div>
                          </td>
                          <td className="py-3 px-4 font-bold text-gray-900 dark:text-white">
                            {cat.itemCount || 0}
                          </td>
                          <td className="py-3 px-4 font-bold text-emerald-600 dark:text-emerald-400">
                            {cat.commissionRate ?? 8.5}%
                          </td>
                          <td className="py-3 px-4">
                            <button
                              type="button"
                              onClick={(e) => handleToggleCategoryStatus(cat, e)}
                              className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                                isActive 
                                  ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300' 
                                  : 'bg-red-100 dark:bg-red-950 text-red-700 dark:text-red-300'
                              }`}
                            >
                              {isActive ? 'Active' : 'Inactive'}
                            </button>
                          </td>
                          <td className="py-3 px-4 text-right">
                            <div className="flex items-center justify-end gap-1">
                              <button
                                onClick={() => handleOpenEditCategory(cat, 'general')}
                                className="p-1.5 rounded-lg text-gray-500 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/50"
                                title={t('সম্পাদনা', 'Edit')}
                              >
                                <Edit className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleOpenEditCategory(cat, 'image')}
                                className="p-1.5 rounded-lg text-gray-500 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950/50"
                                title={t('ছবি', 'Image')}
                              >
                                <ImageIcon className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleOpenEditCategory(cat, 'style')}
                                className="p-1.5 rounded-lg text-gray-500 hover:text-purple-600 hover:bg-purple-50 dark:hover:bg-purple-950/50"
                                title={t('স্টাইল', 'Style')}
                              >
                                <Palette className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleOpenDeleteCategory(cat)}
                                className="p-1.5 rounded-lg text-gray-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/50"
                                title={t('মুছুন', 'Delete')}
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 6: COUPON MANAGEMENT */}
        {/* ======================================================== */}
        {activeTab === 'coupons' && (
          <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 border border-gray-100 dark:border-gray-700 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-black text-gray-900 dark:text-white">
                  {t('ডিসকাউন্ট কুপন তৈরি ও পরিচালনা (Coupon Management)', 'Discount Coupon Management')}
                </h3>
                <p className="text-xs text-gray-400">{t('গ্রাহকদের বিশেষ ছাড়ের জন্য প্রোমো কোড তৈরি, সক্রিয়/নিষ্ক্রিয় ও মুছে ফেলুন', 'Create promotional discount codes and monitor usage')}</p>
              </div>
            </div>

            {/* Create Coupon Form */}
            <form onSubmit={handleCreateCoupon} className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-750 border border-gray-100 dark:border-gray-700 grid grid-cols-1 sm:grid-cols-5 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">{t('কুপন কোড *', 'Coupon Code *')}</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. FLASH30"
                  value={newCouponCode}
                  onChange={(e) => setNewCouponCode(e.target.value.toUpperCase())}
                  className="w-full bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-650 rounded-xl px-3 py-2 text-xs font-mono font-bold"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">{t('ছাড়ের শতাংশ (%)', 'Discount %')}</label>
                <input
                  type="number"
                  min="1"
                  max="90"
                  value={newCouponDiscount}
                  onChange={(e) => setNewCouponDiscount(Number(e.target.value))}
                  className="w-full bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-650 rounded-xl px-3 py-2 text-xs font-bold"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">{t('নূন্যতম অর্ডার (৳)', 'Min Order (৳)')}</label>
                <input
                  type="number"
                  value={newCouponMinOrder}
                  onChange={(e) => setNewCouponMinOrder(Number(e.target.value))}
                  className="w-full bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-650 rounded-xl px-3 py-2 text-xs"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">{t('সর্বোচ্চ ছাড় (৳)', 'Max Discount (৳)')}</label>
                <input
                  type="number"
                  value={newCouponMaxDiscount}
                  onChange={(e) => setNewCouponMaxDiscount(Number(e.target.value))}
                  className="w-full bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-650 rounded-xl px-3 py-2 text-xs"
                />
              </div>

              <div className="flex items-end">
                <button
                  type="submit"
                  className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs flex items-center justify-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>{t('কুপন তৈরি করুন', 'Create')}</span>
                </button>
              </div>
            </form>

            {/* Coupons List */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
              {couponsList.map((cp: any) => (
                <div key={cp.code} className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-750 border border-gray-100 dark:border-gray-700 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-black text-purple-600 dark:text-purple-400 text-sm tracking-wide bg-purple-50 dark:bg-purple-950 px-2 py-0.5 rounded-lg border border-purple-200 dark:border-purple-800">
                      {cp.code}
                    </span>
                    <button
                      onClick={() => handleDeleteCoupon(cp.code)}
                      className="text-gray-400 hover:text-rose-600 transition-colors p-1"
                      title="Delete Coupon"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="text-xs">
                    <span className="font-black text-gray-900 dark:text-white text-base block">{cp.discountPercent}% OFF</span>
                    <span className="text-[11px] text-gray-400 block">Min ৳{cp.minOrder} • Max ৳{cp.maxDiscount}</span>
                  </div>

                  <div className="pt-2 border-t border-gray-200 dark:border-gray-700 flex items-center justify-between text-xs">
                    <span className={`text-[10px] font-bold ${cp.active !== false ? 'text-emerald-600' : 'text-gray-400'}`}>
                      {cp.active !== false ? 'Active' : 'Disabled'}
                    </span>
                    <button
                      onClick={() => handleToggleCoupon(cp.code)}
                      className="text-[11px] font-bold text-purple-600 hover:underline"
                    >
                      {cp.active !== false ? t('নিষ্ক্রিয় করুন', 'Disable') : t('সক্রিয় করুন', 'Enable')}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 7: BANNER & PROMOTIONS MANAGEMENT */}
        {/* ======================================================== */}
        {activeTab === 'banners' && (
          <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 border border-gray-100 dark:border-gray-700 shadow-xs space-y-6">
            <div>
              <h3 className="text-base font-black text-gray-900 dark:text-white">
                {t('ব্যানার ও বিজ্ঞাপন ব্যবস্থাপনা (Banner Management)', 'Homepage Banner & Promotional Slider Management')}
              </h3>
              <p className="text-xs text-gray-400">{t('ওয়েবসাইটের হিরো ব্যানার ও উৎসব ক্যাম্পেইনের ব্যানার তৈরি ও নিয়ন্ত্রণ করুন', 'Manage promotional hero banners, campaign graphics, and links')}</p>
            </div>

            {/* Add New Banner Form */}
            <form onSubmit={handleAddBanner} className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-750 border border-gray-100 dark:border-gray-700 space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">{t('ব্যানারের শিরোনাম *', 'Banner Title *')}</label>
                  <input
                    type="text"
                    required
                    value={newBannerTitle}
                    onChange={(e) => setNewBannerTitle(e.target.value)}
                    placeholder="e.g. Boishakhi Mega Sale 2026"
                    className="w-full bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-650 rounded-xl px-3 py-2 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">{t('সাব-টাইটেল / অফার তথ্য', 'Subtitle / Promo text')}</label>
                  <input
                    type="text"
                    value={newBannerSubtitle}
                    onChange={(e) => setNewBannerSubtitle(e.target.value)}
                    placeholder="e.g. Up to 35% discount on pure honey"
                    className="w-full bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-650 rounded-xl px-3 py-2 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">{t('অবস্থান (Placement)', 'Placement')}</label>
                  <select
                    value={newBannerLocation}
                    onChange={(e) => setNewBannerLocation(e.target.value as any)}
                    className="w-full bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-650 rounded-xl px-3 py-2 text-xs"
                  >
                    <option value="hero">Hero Top Slider</option>
                    <option value="deal">Daily Deal Banner</option>
                    <option value="footer">Footer Promo Banner</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-gray-700 dark:text-gray-300 mb-1">{t('ছবির ইউআরএল (Image URL) *', 'Image URL *')}</label>
                <div className="flex gap-2">
                  <input
                    type="url"
                    required
                    value={newBannerImage}
                    onChange={(e) => setNewBannerImage(e.target.value)}
                    placeholder="https://images.unsplash.com/photo-..."
                    className="flex-1 bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-650 rounded-xl px-3 py-2 text-xs font-mono"
                  />
                  <button
                    type="submit"
                    className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs shrink-0 flex items-center gap-1.5"
                  >
                    <Plus className="w-4 h-4" />
                    <span>{t('ব্যানার যুক্ত করুন', 'Publish Banner')}</span>
                  </button>
                </div>
              </div>
            </form>

            {/* Banners Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {bannersList.map((ban) => (
                <div key={ban.id} className="rounded-2xl border border-gray-200 dark:border-gray-700 overflow-hidden bg-gray-50 dark:bg-gray-750">
                  <div className="relative h-36">
                    <img src={ban.image} alt={ban.title} className="w-full h-full object-cover" />
                    <span className={`absolute top-2 right-2 px-2 py-0.5 rounded text-[10px] font-bold ${
                      ban.active ? 'bg-emerald-600 text-white' : 'bg-gray-600 text-white'
                    }`}>
                      {ban.active ? 'Active' : 'Disabled'}
                    </span>
                    <span className="absolute bottom-2 left-2 px-2 py-0.5 rounded bg-black/60 text-white text-[10px] font-mono">
                      {ban.location.toUpperCase()}
                    </span>
                  </div>

                  <div className="p-3.5 space-y-1">
                    <h4 className="font-bold text-xs text-gray-900 dark:text-white truncate">{ban.title}</h4>
                    <p className="text-[11px] text-gray-400 truncate">{ban.subtitle}</p>

                    <div className="pt-2 flex items-center justify-between text-xs">
                      <button
                        onClick={() => handleToggleBanner(ban.id)}
                        className="text-[11px] font-bold text-purple-600 hover:underline"
                      >
                        {ban.active ? t('নিষ্ক্রিয় করুন', 'Deactivate') : t('সক্রিয় করুন', 'Activate')}
                      </button>

                      <button
                        onClick={() => handleDeleteBanner(ban.id)}
                        className="text-gray-400 hover:text-rose-600 transition-colors p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 8: USER MANAGEMENT */}
        {/* ======================================================== */}
        {activeTab === 'users' && (
          <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 border border-gray-100 dark:border-gray-700 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-black text-gray-900 dark:text-white">
                  {t('ব্যবহারকারী ও গ্রাহক ব্যবস্থাপনা (User Management)', 'Customer & User Management')}
                </h3>
                <p className="text-xs text-gray-400">{t('নিবন্ধিত গ্রাহক, বিক্রেতা ও তাদের অ্যাক্টিভিটি পর্যবেক্ষণ করুন', 'Manage registered customers, roles, and status')}</p>
              </div>
              <span className="px-3 py-1 rounded-full bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 font-bold text-xs">
                {usersList.length + 3840} Registered Accounts
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-gray-200 dark:border-gray-700 text-gray-400 font-bold uppercase text-[10px]">
                    <th className="pb-3">{t('নাম ও ইমেইল', 'User')}</th>
                    <th className="pb-3">{t('ফোন নম্বর', 'Phone')}</th>
                    <th className="pb-3">{t('ভূমিকা (Role)', 'Role')}</th>
                    <th className="pb-3">{t('মোট অর্ডার ও ব্যয়', 'Orders & Spent')}</th>
                    <th className="pb-3">{t('স্ট্যাটাস', 'Status')}</th>
                    <th className="pb-3 text-right">{t('অ্যাকশন', 'Action')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 dark:divide-gray-700/60">
                  {usersList.map((u) => (
                    <tr key={u.id} className="hover:bg-gray-50/50 dark:hover:bg-gray-750/30 transition-colors">
                      <td className="py-3">
                        <span className="font-bold text-gray-900 dark:text-white block">{u.name}</span>
                        <span className="text-[11px] text-gray-400">{u.email}</span>
                      </td>
                      <td className="py-3 font-mono text-gray-600 dark:text-gray-300">
                        {u.phone}
                      </td>
                      <td className="py-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                          u.role === 'admin' ? 'bg-purple-100 text-purple-700' :
                          u.role === 'seller' ? 'bg-amber-100 text-amber-700' :
                          'bg-blue-100 text-blue-700'
                        }`}>
                          {u.role}
                        </span>
                      </td>
                      <td className="py-3">
                        <span className="font-bold text-gray-900 dark:text-white block">{u.totalOrders} {t('অর্ডার', 'orders')}</span>
                        <span className="text-[10px] text-emerald-600 font-bold">৳{u.totalSpent.toLocaleString()}</span>
                      </td>
                      <td className="py-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          u.status === 'active' ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'
                        }`}>
                          {u.status === 'active' ? 'Active' : 'Suspended'}
                        </span>
                      </td>
                      <td className="py-3 text-right">
                        <button
                          onClick={() => handleToggleUserStatus(u.id)}
                          className={`px-3 py-1 rounded-lg text-[10px] font-bold transition-all ${
                            u.status === 'active' 
                              ? 'bg-rose-50 text-rose-600 hover:bg-rose-100' 
                              : 'bg-emerald-50 text-emerald-600 hover:bg-emerald-100'
                          }`}
                        >
                          {u.status === 'active' ? t('স্থগিত করুন', 'Suspend') : t('সক্রিয় করুন', 'Activate')}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 9: PAYMENT MANAGEMENT & BANGLADESHI BANKS */}
        {/* ======================================================== */}
        {activeTab === 'payments' && (
          <PaymentGatewayAdmin />
        )}

        {/* ======================================================== */}
        {/* TAB 10: DELIVERY & COURIER MANAGEMENT */}
        {/* ======================================================== */}
        {activeTab === 'delivery' && (
          <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 border border-gray-100 dark:border-gray-700 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-black text-gray-900 dark:text-white">
                  {t('ডেলিভারি ও বাংলাদেশি কুরিয়ার ব্যবস্থাপনা (Delivery Management)', 'Bangladeshi Courier & Delivery Partner Management')}
                </h3>
                <p className="text-xs text-gray-400">{t('বাংলাদেশের ৮টি শীর্ষ কুরিয়ারের চার্জ, হাব কভারেজ ও ট্র্যাকিং রেট নিয়ন্ত্রণ করুন', 'Manage Steadfast, Pathao, RedX, Sundarban and nationwide hub delivery logistics')}</p>
              </div>

              <button
                onClick={() => setIsCourierModalOpen(true)}
                className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-xs flex items-center gap-1.5"
              >
                <Truck className="w-4 h-4" />
                <span>{t('কুরিয়ার ডিরেক্টরি দেখুন', 'Open Courier Directory')}</span>
              </button>
            </div>

            {/* Courier partner status grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {BANGLADESH_COURIERS.map((c) => (
                <div key={c.id} className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-750 border border-gray-200 dark:border-gray-700 flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3">
                    <img src={c.logo} alt={c.name} className="w-12 h-12 rounded-xl object-cover shrink-0 border border-gray-200 dark:border-gray-600" />
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-gray-900 dark:text-white text-xs">{c.name}</h4>
                        <span className="px-2 py-0.2 rounded-full bg-emerald-100 text-emerald-700 font-bold text-[9px]">API Connected</span>
                      </div>
                      <p className="text-[11px] text-gray-500 mt-0.5">{c.coverage}</p>
                      <div className="flex items-center gap-3 mt-1.5 text-[11px] font-bold">
                        <span className="text-emerald-600">ঢাকা: ৳{c.baseRateInsideDhaka}</span>
                        <span className="text-blue-600">সারাদেশ: ৳{c.baseRateOutsideDhaka}</span>
                        <span className="text-amber-600">COD: {c.codChargePercent}%</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="text-[10px] text-gray-400 block">📞 {c.hotline}</span>
                    <button
                      onClick={() => showToast(t(`${c.name} এর রেট ও এপিআই সেটিংস সংরক্ষিত`, `Updated ${c.name} rates`), 'success')}
                      className="mt-2 px-2.5 py-1 bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg text-[10px] font-bold text-gray-700 dark:text-gray-300 hover:text-purple-600"
                    >
                      {t('কনফিগার', 'Configure')}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 11: REPORTS & ANALYTICS */}
        {/* ======================================================== */}
        {activeTab === 'reports' && (
          <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 border border-gray-100 dark:border-gray-700 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-black text-gray-900 dark:text-white">
                  {t('আর্থিক ও বিক্রয় রিপোর্ট (Reports & Financial Statements)', 'Financial & Sales Audit Reports')}
                </h3>
                <p className="text-xs text-gray-400">{t('মাসিক হিসাব, ভ্যাট ও মার্কেটপ্লেস ট্যাক্স স্টেটমেন্ট ডাউনলোড করুন', 'Download financial statements and category sales audits')}</p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleExportReport}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs flex items-center gap-1.5"
                >
                  <Download className="w-4 h-4" />
                  <span>{t('সম্পূর্ণ রিপোর্ট এক্সপোর্ট (JSON/CSV)', 'Export Report')}</span>
                </button>
              </div>
            </div>

            {/* Financial Summary Table */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-750 border border-gray-100 dark:border-gray-700 space-y-1">
                <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider block">{t('মোট গ্রস জিএমভি (GMV)', 'Gross Merchandise Value')}</span>
                <span className="text-xl font-black text-gray-900 dark:text-white block">৳{calculatedTotalRevenue.toLocaleString()}</span>
                <span className="text-[10px] text-gray-400 block">{t('চলতি অর্থবছর ২০২৬', 'FY 2026')}</span>
              </div>

              <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-750 border border-gray-100 dark:border-gray-700 space-y-1">
                <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider block">{t('প্ল্যাটফর্ম কমিশন নেট আয় (Net Revenue)', 'Marketplace Net Revenue (8.5%)')}</span>
                <span className="text-xl font-black text-purple-600 block">৳{Math.round(calculatedTotalRevenue * 0.085).toLocaleString()}</span>
                <span className="text-[10px] text-purple-500 font-bold block">+16.2% QoQ growth</span>
              </div>

              <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-750 border border-gray-100 dark:border-gray-700 space-y-1">
                <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider block">{t('প্রদেয় সরকারি ভ্যাট ও ট্যাক্স (VAT 5%)', 'Estimated Government VAT (5%)')}</span>
                <span className="text-xl font-black text-emerald-600 block">৳{Math.round(calculatedTotalRevenue * 0.05).toLocaleString()}</span>
                <span className="text-[10px] text-gray-400 block">NBR Tax Compliance</span>
              </div>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 12: WEBSITE SETTINGS + BULK SMS & BAKI RECEIPT HUB */}
        {/* ======================================================== */}
        {activeTab === 'settings' && (
          <div className="space-y-6">
            {/* Settings Sub-Header & Notification Icon Switcher */}
            <div className="bg-white dark:bg-gray-800 rounded-3xl p-4 sm:p-5 border border-gray-100 dark:border-gray-700 shadow-xs flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => setSettingsSubTab('bulk-sms')}
                  className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-all ${
                    settingsSubTab === 'bulk-sms'
                      ? 'bg-emerald-600 text-white shadow-md'
                      : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200 hover:bg-gray-200'
                  }`}
                >
                  <Bell className="w-4 h-4 text-amber-300" />
                  <span>{t('বাল্ক SMS, রসিদ নোটিফিকেশন ও বাকি পেমেন্ট', 'Bulk SMS, Receipt Notifications & Baki')}</span>
                  {unreadSmsCount > 0 && (
                    <span className="px-1.5 py-0.5 rounded-full bg-rose-500 text-white text-[10px] font-extrabold">
                      {unreadSmsCount}
                    </span>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => setSettingsSubTab('general')}
                  className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-all ${
                    settingsSubTab === 'general'
                      ? 'bg-purple-600 text-white shadow-md'
                      : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200 hover:bg-gray-200'
                  }`}
                >
                  <Settings className="w-4 h-4" />
                  <span>{t('সাধারণ মার্কেটপ্লেস সেটিংস', 'General Platform Settings')}</span>
                </button>
              </div>

              <button
                type="button"
                onClick={() => openSmsNotificationModal('notifications')}
                className="px-3.5 py-2 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-700 text-amber-800 dark:text-amber-300 text-xs font-bold flex items-center gap-2 hover:bg-amber-100"
              >
                <Bell className="w-4 h-4 text-amber-600" />
                <span>{t(`কাস্টমার রসিদ ইনবক্স (বাকি: ৳${totalCustomerBakiDue.toLocaleString()})`, `Customer Receipt Inbox (Due: ৳${totalCustomerBakiDue.toLocaleString()})`)}</span>
              </button>
            </div>

            {settingsSubTab === 'bulk-sms' && (
              <AdminBulkSmsPanel customers={usersList} />
            )}

            {settingsSubTab === 'general' && (
          <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 border border-gray-100 dark:border-gray-700 shadow-xs space-y-6">
            <div>
              <h3 className="text-base font-black text-gray-900 dark:text-white">
                {t('মার্কেটপ্লেস ও ওয়েবসাইট সেটিংস (Website Settings)', 'Marketplace Platform & General Settings')}
              </h3>
              <p className="text-xs text-gray-400">{t('প্ল্যাটফর্মের নাম, কমিশন হার, সাপোর্ট হেল্পলাইন ও ডেলিভারি পলিসি নিয়ন্ত্রণ করুন', 'Configure site branding, commission fees, and shipping policies')}</p>
            </div>

            <form onSubmit={handleSaveSettings} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">{t('ওয়েবসাইটের নাম (English)', 'Site Name (English)')}</label>
                  <input
                    type="text"
                    value={settings.siteName}
                    onChange={(e) => setSettings({ ...settings, siteName: e.target.value })}
                    className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-650 rounded-xl px-3 py-2 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">{t('ওয়েবসাইটের নাম (বাংলা)', 'Site Name (Bangla)')}</label>
                  <input
                    type="text"
                    value={settings.siteNameBn}
                    onChange={(e) => setSettings({ ...settings, siteNameBn: e.target.value })}
                    className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-650 rounded-xl px-3 py-2 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">{t('সাপোর্ট হেল্পলাইন নম্বর', 'Customer Care Hotline')}</label>
                  <input
                    type="text"
                    value={settings.supportPhone}
                    onChange={(e) => setSettings({ ...settings, supportPhone: e.target.value })}
                    className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-650 rounded-xl px-3 py-2 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">{t('সাপোর্ট ইমেইল', 'Support Email')}</label>
                  <input
                    type="email"
                    value={settings.supportEmail}
                    onChange={(e) => setSettings({ ...settings, supportEmail: e.target.value })}
                    className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-650 rounded-xl px-3 py-2 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">{t('প্ল্যাটফর্ম কমিশন (%)', 'Platform Commission (%)')}</label>
                  <input
                    type="number"
                    step="0.1"
                    value={settings.platformCommissionPercent}
                    onChange={(e) => setSettings({ ...settings, platformCommissionPercent: Number(e.target.value) })}
                    className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-650 rounded-xl px-3 py-2 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">{t('ফ্রি ডেলিভারি নূন্যতম অর্ডার (৳)', 'Free Delivery Threshold (৳)')}</label>
                  <input
                    type="number"
                    value={settings.freeDeliveryThreshold}
                    onChange={(e) => setSettings({ ...settings, freeDeliveryThreshold: Number(e.target.value) })}
                    className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-650 rounded-xl px-3 py-2 text-xs"
                  />
                </div>
              </div>

              {/* Toggles */}
              <div className="pt-2 flex flex-wrap items-center gap-6">
                <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-gray-700 dark:text-gray-300">
                  <input
                    type="checkbox"
                    checked={settings.allowCod}
                    onChange={(e) => setSettings({ ...settings, allowCod: e.target.checked })}
                    className="rounded text-purple-600"
                  />
                  <span>{t('ক্যাশ অন ডেলিভারি (COD) সক্রিয় রাখুন', 'Enable Cash on Delivery (COD)')}</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-gray-700 dark:text-gray-300">
                  <input
                    type="checkbox"
                    checked={settings.allowBkash}
                    onChange={(e) => setSettings({ ...settings, allowBkash: e.target.checked })}
                    className="rounded text-purple-600"
                  />
                  <span>{t('বিকাশ ও নগদ অনলাইন গেটওয়ে সক্রিয় রাখুন', 'Enable bKash & Nagad Gateways')}</span>
                </label>
              </div>

              <div className="pt-4 border-t border-gray-100 dark:border-gray-700">
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold shadow-md shadow-purple-600/20 active:scale-95 transition-all"
                >
                  {t('সেটিংস সংরক্ষণ করুন', 'Save Settings')}
                </button>
              </div>
            </form>
          </div>
            )}
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 13: 100+ THEMES & APP APPEARANCE */}
        {/* ======================================================== */}
        {activeTab === 'themes' && (
          <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 border border-gray-100 dark:border-gray-700 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-base sm:text-lg font-black text-gray-900 dark:text-white flex items-center gap-2">
                  <Palette className="w-5 h-5 text-purple-600 animate-pulse" />
                  <span>{t('১০০+ ওয়েবসাইট ও অ্যাপ ব্যাকগ্রাউন্ড থিম কন্ট্রোল', '100+ Background Themes & App Appearance Control')}</span>
                </h3>
                <p className="text-xs text-gray-400">
                  {t(
                    'ওয়েবসাইট এবং ডাউনলোডযোগ্য মোবাইল অ্যাপের জন্য ১১২টি প্রিমিয়াম ব্যাকগ্রাউন্ড থিম পরিচালনা করুন',
                    'Manage and switch across 112 curated background themes for the website and mobile app ecosystem'
                  )}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => openThemeStudio()}
                  className="px-4 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white rounded-xl text-xs font-bold shadow-md shadow-purple-600/20 flex items-center gap-1.5 transition-all"
                >
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>{t('সম্পূর্ণ থিম স্টুডিও খুলুন', 'Launch Theme Universe Studio')}</span>
                </button>
              </div>
            </div>

            {/* Quick Metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-4 rounded-2xl bg-purple-50 dark:bg-purple-950/40 border border-purple-100 dark:border-purple-900/50">
                <span className="text-[10px] font-bold text-purple-600 uppercase tracking-wider block mb-1">
                  {t('মোট থিম', 'Total Themes')}
                </span>
                <span className="text-xl font-black text-purple-900 dark:text-purple-200">
                  {allThemes.length}+ {t('টি', '')}
                </span>
              </div>

              <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-100 dark:border-emerald-900/50">
                <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-wider block mb-1">
                  {t('বর্তমান সক্রিয় থিম', 'Active Theme')}
                </span>
                <span className="text-sm font-black text-emerald-900 dark:text-emerald-200 truncate block">
                  {language === 'bn' ? currentTheme.nameBn : currentTheme.name}
                </span>
              </div>

              <div className="p-4 rounded-2xl bg-blue-50 dark:bg-blue-950/40 border border-blue-100 dark:border-blue-900/50">
                <span className="text-[10px] font-bold text-blue-600 uppercase tracking-wider block mb-1">
                  {t('থিম কালেকশন', 'Collections')}
                </span>
                <span className="text-xl font-black text-blue-900 dark:text-blue-200">
                  {themeCategories.length - 1} {t('ক্যাটাগরি', 'Categories')}
                </span>
              </div>

              <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-100 dark:border-amber-900/50">
                <span className="text-[10px] font-bold text-amber-600 uppercase tracking-wider block mb-1">
                  {t('অ্যাপ সিঙ্ক স্ট্যাটাস', 'App Sync')}
                </span>
                <span className="text-sm font-black text-amber-900 dark:text-amber-200 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span>100% Live Synced</span>
                </span>
              </div>
            </div>

            {/* Featured Themes Quick Grid */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-xs font-black uppercase tracking-wider text-gray-500 dark:text-gray-400">
                  {t('জনপ্রিয় প্রিমিয়াম থিমসমূহ (এক ক্লিকে সক্রিয় করুন)', 'Popular Themes (Click to activate instantly)')}
                </h4>
                <button
                  onClick={() => openThemeStudio()}
                  className="text-xs font-bold text-purple-600 hover:text-purple-700 dark:text-purple-400"
                >
                  {t('সকল ১১২টি থিম দেখুন →', 'Explore All 112 Themes →')}
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
                {allThemes.slice(0, 8).map((th) => {
                  const isActive = currentTheme.id === th.id;
                  return (
                    <div
                      key={th.id}
                      onClick={() => setThemeId(th.id)}
                      className={`p-3.5 rounded-2xl border transition-all cursor-pointer group relative overflow-hidden flex flex-col justify-between ${
                        isActive
                          ? 'ring-2 ring-purple-500 border-purple-500 shadow-md'
                          : 'border-gray-200 dark:border-gray-700 hover:border-purple-300 hover:shadow-sm'
                      }`}
                      style={{ background: th.bgGradient || th.bgColor }}
                    >
                      {isActive && (
                        <div className="absolute top-2 right-2 bg-purple-600 text-white rounded-full p-1 shadow-sm">
                          <Check className="w-3 h-3 stroke-[3]" />
                        </div>
                      )}

                      <div className="mb-2">
                        <div 
                          className="rounded-xl p-2 mb-2 shadow-xs border text-[10px]"
                          style={{
                            backgroundColor: th.surfaceColor,
                            borderColor: th.surfaceBorder,
                            color: th.textColor
                          }}
                        >
                          <div 
                            className="rounded px-1.5 py-0.5 mb-1.5 font-bold flex items-center justify-between text-[9px]"
                            style={{ backgroundColor: th.headerBg, color: th.headerText }}
                          >
                            <span>DeshiBazar</span>
                            <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: th.accentColor }} />
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="font-bold truncate max-w-[90px]">{language === 'bn' ? th.nameBn : th.name}</span>
                            <span 
                              className="px-1.5 py-0.2 rounded text-[8px] font-bold"
                              style={{ backgroundColor: th.accentColor, color: th.accentText }}
                            >
                              Demo
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold" style={{ color: th.textColor }}>
                            {language === 'bn' ? th.nameBn : th.name}
                          </span>
                          <span 
                            className="text-[9px] px-1.5 py-0.2 rounded-full font-bold uppercase"
                            style={{
                              backgroundColor: th.mode === 'dark' ? '#1e1b4b' : '#f1f5f9',
                              color: th.mode === 'dark' ? '#a5b4fc' : '#475569'
                            }}
                          >
                            {th.mode}
                          </span>
                        </div>
                      </div>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setThemeId(th.id);
                        }}
                        className={`w-full py-1 rounded-xl text-[11px] font-bold transition-all ${
                          isActive
                            ? 'bg-purple-600 text-white'
                            : 'bg-white/80 dark:bg-gray-800/80 hover:bg-white text-gray-800 dark:text-gray-100'
                        }`}
                      >
                        {isActive ? t('সক্রিয় রয়েছে', 'Active') : t('সক্রিয় করুন', 'Activate')}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* E-Commerce Theme Builder & Backend HTML ZIP Export Card */}
            <div className="p-5 rounded-3xl bg-gradient-to-r from-emerald-600 via-teal-700 to-indigo-800 text-white shadow-lg flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center backdrop-blur-xs shrink-0 border border-white/20">
                  <Palette className="w-6 h-6 text-amber-300" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-base font-black">
                      {t('মোবাইল রেসপনসিভ ই-কমার্স থিম স্টুডিও ও ব্যাকএন্ড জিপ এক্সপোর্ট', 'Mobile Responsive E-Commerce Theme Studio & Backend ZIP')}
                    </h4>
                    <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-amber-400 text-gray-950">
                      HTML ZIP
                    </span>
                  </div>
                  <p className="text-xs text-emerald-100 mt-1 max-w-xl">
                    {t(
                      'একটি সম্পূর্ণ ফাংশনাল ও রেসপনসিভ ই-কমার্স থিম তৈরি করুন, মোবাইল স্ক্রিনে টেস্ট করুন এবং ব্যাকএন্ড থেকে যেকোনো ডিভাইসে ব্যবহারের জন্য রেডিমেড HTML/CSS/JS জিপ ফাইল ডাউনলোড করুন।',
                      'Design mobile responsive e-commerce themes, preview on mobile/tablet frames, and download standalone production HTML ZIP files.'
                    )}
                  </p>
                </div>
              </div>

              <button
                onClick={() => openEcommerceStudio()}
                className="px-5 py-3 rounded-2xl bg-amber-400 hover:bg-amber-300 text-gray-950 font-black text-xs shadow-md transition-all active:scale-95 shrink-0 flex items-center gap-2"
              >
                <span>{t('থিম স্টুডিও খুলুন ও জিপ ডাউনলোড করুন →', 'Open Theme Studio & Download ZIP →')}</span>
              </button>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB: BACKEND ENGINE & REST API SUITE */}
        {/* ======================================================== */}
        {activeTab === 'backend' && (
          <BackendAdminPanel />
        )}

        {/* ======================================================== */}
        {/* TAB 14: CUSTOMER ATTRACTIVE WEB & APPS UI/UX DESIGN STUDIO */}
        {/* ======================================================== */}
        {activeTab === 'customer-ui' && (
          <CustomerUIUXAdminStudio />
        )}

        {/* ======================================================== */}
        {/* CATEGORY MANAGEMENT MODALS */}
        {/* ======================================================== */}

        {/* 1. Add / Edit / Image / Style Modal */}
        <CategoryAdminModal
          isOpen={isCategoryModalOpen}
          onClose={() => setIsCategoryModalOpen(false)}
          categoryToEdit={selectedCategoryForEdit}
          onSave={handleSaveCategory}
          initialTab={categoryModalInitialTab}
        />

        {/* 2. Category Delete Confirmation Modal */}
        <CategoryDeleteConfirmModal
          isOpen={isDeleteConfirmModalOpen}
          onClose={() => {
            setIsDeleteConfirmModalOpen(false);
            setCategoryToDelete(null);
          }}
          category={categoryToDelete}
          onConfirmDelete={(catId) => {
            deleteCategory(catId);
          }}
          associatedProductsCount={
            categoryToDelete 
              ? products.filter(p => p.category === categoryToDelete.id).length 
              : 0
          }
        />

        {/* 3. Reset Categories to Default Confirmation Modal */}
        {isResetConfirmModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
            <div 
              className="bg-white dark:bg-gray-800 rounded-3xl max-w-md w-full p-6 border border-gray-100 dark:border-gray-700 shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-2xl bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center">
                  <RotateCcw className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-black text-gray-900 dark:text-white">
                    {t('ডিফল্ট ক্যাটাগরিতে রিসেট করবেন?', 'Reset to Default Categories?')}
                  </h3>
                  <p className="text-xs text-gray-400">
                    {t('সকল ১৭টি প্রমিত ক্যাটাগরি পুনরুদ্ধার করা হবে', 'All 17 standard categories will be restored')}
                  </p>
                </div>
              </div>
              <p className="text-xs text-gray-500 dark:text-gray-400 mb-5 leading-relaxed">
                {t(
                  'আপনার তৈরি করা নতুন ক্যাটাগরি অথবা কাস্টমাইজ করা ছবিগুলো মূল ডিফল্ট সংস্করণে ফিরে যাবে। আপনি কি নিশ্চিত?',
                  'Any newly created categories or customized images will be restored to original marketplace defaults. Are you sure you want to proceed?'
                )}
              </p>
              <div className="flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsResetConfirmModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 text-xs font-bold hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                >
                  {t('বাতিল', 'Cancel')}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    resetCategoriesToDefault();
                    setIsResetConfirmModalOpen(false);
                  }}
                  className="px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold shadow-md shadow-amber-600/20 transition-all"
                >
                  {t('রিসেট নিশ্চিত করুন', 'Confirm Reset')}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* INTERACTIVE SIDE DRAWER: ALL 15 MASTER SECTIONS (UP/DOWN) */}
        {/* ======================================================== */}
        {isSideDrawerOpen && (
          <div className="fixed inset-0 z-50 flex items-stretch">
            {/* Backdrop */}
            <div 
              className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
              onClick={() => setIsSideDrawerOpen(false)}
            />

            {/* Side Drawer Panel */}
            <div 
              className="relative w-full max-w-sm sm:max-w-md bg-white dark:bg-gray-900 h-full shadow-2xl flex flex-col z-10 border-r border-gray-100 dark:border-gray-800 animate-in slide-in-from-left duration-200"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Drawer Top Header */}
              <div className="p-4 sm:p-5 border-b border-gray-100 dark:border-gray-800 flex items-center justify-between bg-gradient-to-r from-purple-50 via-white to-indigo-50 dark:from-gray-900 dark:via-gray-850 dark:to-gray-900">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-purple-600 text-white flex items-center justify-center shadow-md shadow-purple-600/30">
                    <PanelLeft className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-gray-900 dark:text-white">
                      {t('১৫টি অ্যাডমিন মাস্টার সেকশন', '15 Admin Master Sections')}
                    </h3>
                    <p className="text-[11px] text-gray-500 dark:text-gray-400">
                      {t('আপ-ডাউন স্ক্রল করুন ও পছন্দমতো সেকশনে যান', 'Scroll Up/Down to navigate sections')}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsSideDrawerOpen(false)}
                  className="p-2 text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Drawer Up/Down Quick Jumper & Filter */}
              <div className="p-3 border-b border-gray-100 dark:border-gray-800 bg-gray-50/70 dark:bg-gray-850/50 space-y-2">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handlePrevTab}
                    className="flex-1 py-2 px-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-xs font-bold text-gray-700 dark:text-gray-300 hover:bg-purple-50 dark:hover:bg-purple-950/40 flex items-center justify-center gap-1.5 transition-colors shadow-xs"
                  >
                    <ChevronUp className="w-4 h-4 text-purple-600" />
                    <span>{t('▲ UP (আগেরটি)', '▲ UP')}</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleNextTab}
                    className="flex-1 py-2 px-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-xs font-bold text-gray-700 dark:text-gray-300 hover:bg-purple-50 dark:hover:bg-purple-950/40 flex items-center justify-center gap-1.5 transition-colors shadow-xs"
                  >
                    <span>{t('▼ DOWN (পরেরটি)', '▼ DOWN')}</span>
                    <ChevronDown className="w-4 h-4 text-purple-600" />
                  </button>
                </div>

                <div className="relative">
                  <input
                    type="text"
                    value={sideDrawerSearch}
                    onChange={(e) => setSideDrawerSearch(e.target.value)}
                    placeholder={t('সেকশন খুঁজুন (১৫টি ট্যাব)...', 'Search 15 sections...')}
                    className="w-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl px-3 py-2 pl-8 text-xs focus:ring-1 focus:ring-purple-500 focus:outline-none"
                  />
                  <Search className="w-3.5 h-3.5 text-gray-400 absolute left-2.5 top-2.5" />
                </div>
              </div>

              {/* Drawer Vertical List of 15 Sections */}
              <div className="flex-1 overflow-y-auto p-3 space-y-1.5 scrollbar-thin">
                {adminTabsList
                  .filter(tab => 
                    !sideDrawerSearch || 
                    tab.label.toLowerCase().includes(sideDrawerSearch.toLowerCase()) ||
                    tab.id.toLowerCase().includes(sideDrawerSearch.toLowerCase())
                  )
                  .map((tab, idx) => {
                    const Icon = tab.icon;
                    const isActive = activeTab === tab.id;
                    return (
                      <button
                        key={tab.id}
                        type="button"
                        onClick={() => {
                          setActiveTab(tab.id);
                          setIsSideDrawerOpen(false);
                        }}
                        className={`w-full flex items-center justify-between p-3 rounded-2xl text-xs font-bold transition-all text-left ${
                          isActive
                            ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
                            : 'hover:bg-gray-100 dark:hover:bg-gray-850 text-gray-700 dark:text-gray-300'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black shrink-0 ${
                            isActive ? 'bg-purple-800 text-purple-100' : 'bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-400'
                          }`}>
                            {idx + 1}
                          </span>
                          <Icon className="w-4 h-4 shrink-0" />
                          <span>{tab.label}</span>
                        </div>
                        {Boolean(tab.badge) && (
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-black ${
                            isActive ? 'bg-white text-purple-700' : 'bg-rose-500 text-white'
                          }`}>
                            {tab.badge}
                          </span>
                        )}
                      </button>
                    );
                  })}
              </div>

              {/* Drawer Footer Actions */}
              <div className="p-3 border-t border-gray-100 dark:border-gray-800 bg-gray-50 dark:bg-gray-850 flex items-center justify-between text-xs">
                <span className="text-[11px] text-gray-400 font-semibold">
                  {t(`বর্তমান: [${currentTabIndex + 1}/15] ${currentTabInfo?.label}`, `Current: [${currentTabIndex + 1}/15]`)}
                </span>
                <button
                  type="button"
                  onClick={() => setIsSideDrawerOpen(false)}
                  className="px-3 py-1.5 bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 text-gray-800 dark:text-gray-200 rounded-xl font-bold transition-colors"
                >
                  {t('বন্ধ করুন', 'Close')}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* FLOATING QUICK DOCK: UP / DOWN & SIDE BUTTONS */}
        {/* ======================================================== */}
        <div className="fixed bottom-6 left-4 md:left-6 z-40 flex items-center gap-1.5 bg-white/95 dark:bg-gray-900/95 backdrop-blur-md p-1.5 rounded-full shadow-2xl border border-purple-200/80 dark:border-purple-800/80 animate-in fade-in duration-200">
          {/* UP Button */}
          <button
            type="button"
            onClick={handlePrevTab}
            className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-750 text-gray-700 dark:text-gray-200 flex items-center justify-center transition-all active:scale-95 shadow-xs"
            title={t('পূর্ববর্তী সেকশনে যান (▲ UP)', 'Go to Previous Section (▲ UP)')}
          >
            <ChevronUp className="w-4 h-4 text-purple-600 dark:text-purple-400" />
          </button>

          {/* Side Menu Button / Active Tab Pill */}
          <button
            type="button"
            onClick={() => setIsSideDrawerOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white rounded-full text-xs font-black shadow-md shadow-purple-600/30 transition-all active:scale-95"
            title={t('১৫টি সেকশন সাইড মেনু খুলুন (Side Menu)', 'Open 15 Sections Side Menu')}
          >
            <PanelLeft className="w-3.5 h-3.5 text-amber-300" />
            <span className="max-w-[120px] sm:max-w-[160px] truncate">
              {currentTabIndex + 1}. {currentTabInfo?.label}
            </span>
          </button>

          {/* DOWN Button */}
          <button
            type="button"
            onClick={handleNextTab}
            className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-750 text-gray-700 dark:text-gray-200 flex items-center justify-center transition-all active:scale-95 shadow-xs"
            title={t('পরবর্তী সেকশনে যান (▼ DOWN)', 'Go to Next Section (▼ DOWN)')}
          >
            <ChevronDown className="w-4 h-4 text-purple-600 dark:text-purple-400" />
          </button>
        </div>

      </div>
    </div>
  );
};
