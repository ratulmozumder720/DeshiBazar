import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  ArrowRight, 
  Grid, 
  Sparkles,
  Carrot, 
  Fish, 
  Wheat, 
  Egg, 
  Coffee, 
  Shirt, 
  Smartphone, 
  HeartHandshake, 
  Home, 
  Baby, 
  BookOpen, 
  Sprout, 
  Palette, 
  Pill, 
  Flame,
  Wrench,
  ShoppingBag,
  Plus,
  Trophy,
  Heart,
  Receipt
} from 'lucide-react';

export const CategoriesView: React.FC = () => {
  const { t, categories, setSelectedCategory, setSelectedSellerId, setCurrentView, openAddCategoryModal, openCategoryCashMemo } = useApp();

  const handleSelectCategory = (catId: string) => {
    setSelectedCategory(catId);
    setSelectedSellerId(null);
    setCurrentView('shop');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const getCategoryIcon = (id: string, iconName?: string) => {
    const key = (iconName || id).toLowerCase();
    if (key.includes('trophy') || key.includes('sport') || id === 'sports-fitness') return <Trophy className="w-5 h-5 text-teal-600 dark:text-teal-400" />;
    if (key.includes('heart') || key.includes('pet') || id === 'pet-supplies') return <Heart className="w-5 h-5 text-amber-600 dark:text-amber-400" />;
    if (key.includes('carrot') || id === 'fruits-vegetables') return <Carrot className="w-5 h-5 text-emerald-600" />;
    if (key.includes('fish') || id === 'fish-meat') return <Fish className="w-5 h-5 text-blue-600" />;
    if (key.includes('wheat') || id === 'rice-dal-grocery') return <Wheat className="w-5 h-5 text-amber-600" />;
    if (key.includes('egg') || id === 'dairy-eggs') return <Egg className="w-5 h-5 text-orange-600" />;
    if (key.includes('coffee') || id === 'snacks-beverages') return <Coffee className="w-5 h-5 text-rose-600" />;
    if (key.includes('sparkle') || id === 'deshi-products') return <Sparkles className="w-5 h-5 text-amber-500" />;
    if (key.includes('shirt') || id === 'fashion') return <Shirt className="w-5 h-5 text-purple-600" />;
    if (key.includes('phone') || id === 'electronics') return <Smartphone className="w-5 h-5 text-cyan-600" />;
    if (key.includes('beauty') || id === 'beauty-personal-care') return <HeartHandshake className="w-5 h-5 text-pink-600" />;
    if (key.includes('home') || id === 'home-kitchen') return <Home className="w-5 h-5 text-teal-600" />;
    if (key.includes('baby') || id === 'baby-products') return <Baby className="w-5 h-5 text-sky-600" />;
    if (key.includes('book') || id === 'stationery') return <BookOpen className="w-5 h-5 text-indigo-600" />;
    if (key.includes('sprout') || id === 'agriculture-products') return <Sprout className="w-5 h-5 text-emerald-700" />;
    if (key.includes('palette') || id === 'handmade-products') return <Palette className="w-5 h-5 text-amber-700" />;
    if (key.includes('pill') || id === 'madicen') return <Pill className="w-5 h-5 text-red-600" />;
    if (key.includes('flame') || id === 'masala') return <Flame className="w-5 h-5 text-orange-600" />;
    if (key.includes('wrench') || id === 'hardware-accessories') return <Wrench className="w-5 h-5 text-slate-700 dark:text-slate-300" />;
    return <ShoppingBag className="w-5 h-5 text-emerald-600" />;
  };

  return (
    <div className="py-10 bg-gray-50 dark:bg-gray-900 min-h-screen transition-colors">
      <div className="max-w-7xl mx-auto px-4">
        {/* Breadcrumb & Header */}
        <div className="mb-8">
          <div className="flex items-center gap-2 text-xs text-gray-500 mb-2">
            <button onClick={() => setCurrentView('home')} className="hover:text-emerald-600">
              {t('হোম', 'Home')}
            </button>
            <span>/</span>
            <span className="text-gray-900 dark:text-white font-semibold">{t('সকল ক্যাটাগরি', 'All Categories')}</span>
          </div>

          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-3xl font-black text-gray-900 dark:text-white tracking-tight flex items-center gap-2">
                <Grid className="w-8 h-8 text-emerald-600" />
                <span>{t('দেশিবাজার ক্যাটাগরি ডিরেক্টরি', 'DeshiBazar Category Directory')}</span>
              </h1>
              <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400 mt-1">
                {t(
                  'মুদি পণ্য, নদী ও সাগরের মাছ, খাঁটি দেশি পণ্য, ঐতিহ্যবাহী শাড়ি এবং আধুনিক ইলেকট্রনিক্স',
                  'Browse through specialized Bangladeshi departments and authentic regional supplies'
                )}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => openCategoryCashMemo('all')}
                className="px-4 py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white rounded-2xl text-xs font-bold shadow-lg shadow-indigo-600/20 flex items-center gap-2 active:scale-95 transition-all"
              >
                <Receipt className="w-4 h-4" />
                <span>{t('সকল ক্যাটাগরি ক্যাশ মেমো / ইনভয়েজ', 'All-Category Cash Memo / Invoice')}</span>
              </button>

              <button
                onClick={openAddCategoryModal}
                className="px-4 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-2xl text-xs font-bold shadow-lg shadow-emerald-600/20 flex items-center gap-2 active:scale-95 transition-all"
              >
                <Plus className="w-4 h-4" />
                <span>{t('নতুন ক্যাটাগরি যোগ করুন', '+ Add Category')}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Categories Big Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.filter(c => c.status !== 'inactive').map((cat) => (
            <div
              key={cat.id}
              onClick={() => handleSelectCategory(cat.id)}
              className="group bg-white dark:bg-gray-800 rounded-3xl p-6 border border-gray-100 dark:border-gray-700/80 hover:border-emerald-500 hover:shadow-xl transition-all duration-300 cursor-pointer flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-4 mb-4">
                  <div className="relative w-24 h-24 rounded-2xl overflow-hidden bg-gray-100 dark:bg-gray-700 shadow-inner shrink-0 group-hover:scale-105 transition-transform">
                    <img src={cat.image} alt={cat.name} className="w-full h-full object-cover" />
                    <div className="absolute top-2 left-2 w-8 h-8 rounded-lg bg-white/95 dark:bg-gray-800/95 backdrop-blur-xs flex items-center justify-center shadow-xs">
                      {getCategoryIcon(cat.id, cat.iconName)}
                    </div>
                  </div>
                  <span className="px-3 py-1 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 text-xs font-bold rounded-full border border-emerald-200 dark:border-emerald-800">
                    {cat.itemCount}+ {t('পণ্য', 'Items')}
                  </span>
                </div>

                <h3 className="text-lg font-bold text-gray-900 dark:text-white group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                  {t(cat.nameBn, cat.name)}
                </h3>
                <span className="text-xs text-gray-500 font-medium">{cat.name}</span>

                {/* Popular items pills */}
                <div className="mt-3">
                  <span className="text-[10px] uppercase font-bold text-gray-400 block mb-1.5">
                    {t('জনপ্রিয় আইটেম সমূহ:', 'Popular Items:')}
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {cat.popularItems.map((item, idx) => (
                      <span
                        key={idx}
                        className="text-xs bg-gray-50 dark:bg-gray-700/60 text-gray-700 dark:text-gray-300 px-2.5 py-1 rounded-lg border border-gray-100 dark:border-gray-600"
                      >
                        {item}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="pt-4 mt-4 border-t border-gray-100 dark:border-gray-700/60 flex items-center justify-between gap-2 text-xs font-bold">
                <span className="text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
                  <span>{t('এই বিভাগের পণ্যগুলো দেখুন', 'Explore department')}</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </span>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    openCategoryCashMemo(cat.id);
                  }}
                  className="px-2.5 py-1.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-600 hover:text-white border border-indigo-200 dark:border-indigo-800 text-[11px] font-bold flex items-center gap-1 transition-all"
                  title={t('এই ক্যাটাগরির ক্যাশ মেমো বা ইনভয়েজ তৈরি করুন', 'Create Cash Memo / Invoice for this category')}
                >
                  <Receipt className="w-3.5 h-3.5" />
                  <span>{t('ক্যাশ মেমো', 'Cash Memo')}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
