import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  CheckCircle2, 
  MapPin, 
  CreditCard, 
  Truck, 
  ShieldCheck, 
  ShoppingBag, 
  ArrowRight, 
  ArrowLeft,
  Printer,
  XCircle,
  Building2,
  Copy,
  Check,
  ChevronDown,
  ChevronUp,
  Search,
  Sliders,
  Receipt
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { BANGLADESH_DIVISIONS, DISTRICTS_BY_DIVISION } from '../data/mockData';
import { BANGLADESH_COURIERS } from '../data/courierData';
import { BANGLADESHI_BANKS } from '../data/bangladeshiBanks';
import { CancelOrderModal } from '../components/CancelOrderModal';

export const CheckoutView: React.FC = () => {
  const {
    t,
    language,
    cart,
    cartSubtotal,
    discountAmount,
    appliedCoupon,
    user,
    userProfile,
    createOrder,
    setCurrentView,
    selectedLocation,
    openCashMemoModal,
    showToast
  } = useApp();

  const [currentStep, setCurrentStep] = useState<1 | 2 | 3>(1);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Step 1: Delivery Information State
  const [customerName, setCustomerName] = useState(userProfile?.displayName || user?.displayName || '');
  const [customerPhone, setCustomerPhone] = useState(userProfile?.phone || '+88017');
  const [customerEmail, setCustomerEmail] = useState(userProfile?.email || user?.email || '');
  const [division, setDivision] = useState(selectedLocation || 'Dhaka');
  const [district, setDistrict] = useState('Dhaka');
  const [upazila, setUpazila] = useState('Gulshan');
  const [address, setAddress] = useState('House 14, Road 11, Block D');
  const [deliveryInstructions, setDeliveryInstructions] = useState('');
  const [selectedCourierId, setSelectedCourierId] = useState<string>('steadfast');

  const isDhakaOrder = division.toLowerCase().includes('dhaka');
  const selectedCourier = BANGLADESH_COURIERS.find((c: any) => c.id === selectedCourierId) || BANGLADESH_COURIERS[0];
  const dynamicDeliveryFee = isDhakaOrder ? selectedCourier.baseRateInsideDhaka : selectedCourier.baseRateOutsideDhaka;
  const calculatedGrandTotal = Math.max(0, cartSubtotal - discountAmount + dynamicDeliveryFee);

  // Step 2: Payment Method State (Including Bangladeshi Bank Gateway)
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'bkash' | 'nagad' | 'rocket' | 'card' | 'bank_transfer'>('cod');
  const [bkashNumber, setBkashNumber] = useState('017');
  const [bkashPin, setBkashPin] = useState('');

  // Bangladeshi Bank Transfer state
  const [selectedBankId, setSelectedBankId] = useState<string>('ibbl');
  const [bankTransferType, setBankTransferType] = useState<'cellfin' | 'nexus_pay' | 'internet_banking' | 'branch_deposit' | 'npsb_beftn'>('cellfin');
  const [bankSenderInfo, setBankSenderInfo] = useState<string>('');
  const [bankTxnRef, setBankTxnRef] = useState<string>('');
  const [copiedBankField, setCopiedBankField] = useState<string | null>(null);
  const [isBankDropdownOpen, setIsBankDropdownOpen] = useState(false);
  const [bankSearchQuery, setBankSearchQuery] = useState('');

  const handleCopyBankField = (text: string, fieldKey: string) => {
    navigator.clipboard.writeText(text);
    setCopiedBankField(fieldKey);
    setTimeout(() => setCopiedBankField(null), 2000);
  };

  // Step 3: Confirmed Order State
  const [confirmedOrder, setConfirmedOrder] = useState<any>(null);
  const [isCancelModalOpen, setIsCancelModalOpen] = useState(false);

  // Step 1 Validation & Proceed
  const handleProceedToPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !customerPhone || !address) {
      showToast(t('অনুগ্রহ করে সকল প্রয়োজনীয় ডেলিভারি তথ্য পূরণ করুন।', 'Please fill all required delivery details.'), 'error');
      return;
    }
    setCurrentStep(2);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Step 2 Complete Order
  const handlePlaceOrder = async () => {
    setIsSubmitting(true);

    if (paymentMethod === 'bkash' || paymentMethod === 'nagad' || paymentMethod === 'rocket' || paymentMethod === 'bank_transfer') {
      await new Promise(resolve => setTimeout(resolve, 1200));
    }

    try {
      const selectedBank = BANGLADESHI_BANKS.find((b: any) => b.id === selectedBankId) || BANGLADESHI_BANKS[0];
      const bankDetails = paymentMethod === 'bank_transfer' ? {
        bankId: selectedBank.id,
        bankName: selectedBank.name,
        accountNumber: selectedBank.accountNumber,
        senderAccountOrPhone: bankSenderInfo || customerPhone,
        bankTransactionRef: bankTxnRef || `BNK-${Math.floor(100000 + Math.random() * 900000)}`,
        paymentMethodType: bankTransferType
      } : undefined;

      const order = await createOrder({
        userId: user?.uid || 'guest',
        customerName,
        customerPhone,
        customerEmail,
        division,
        district,
        upazila,
        address,
        deliveryInstructions,
        paymentMethod,
        paymentStatus: paymentMethod === 'cod' ? 'pending' : 'paid_online',
        transactionId: paymentMethod === 'bank_transfer' 
          ? (bankTxnRef || `BNK-${Math.floor(100000 + Math.random() * 900000)}`) 
          : (paymentMethod !== 'cod' ? 'TXN-' + Math.random().toString(36).substring(2, 10).toUpperCase() : undefined),
        bankPaymentDetails: bankDetails,
        deliveryType: 'regular',
        deliveryFee: dynamicDeliveryFee,
        subtotal: cartSubtotal,
        discount: discountAmount,
        couponCode: appliedCoupon?.code,
        total: calculatedGrandTotal,
        status: 'placed',
        items: cart,
        courierId: selectedCourierId,
        courierName: selectedCourier.name
      });

      setConfirmedOrder(order);
      setCurrentStep(3);
      window.scrollTo({ top: 0, behavior: 'smooth' });

      // Celebration Confetti
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (cart.length === 0 && currentStep !== 3) {
    return (
      <div className="py-20 text-center max-w-md mx-auto px-4">
        <div className="w-16 h-16 rounded-full bg-emerald-50 dark:bg-emerald-950 flex items-center justify-center text-emerald-600 mx-auto mb-4">
          <ShoppingBag className="w-8 h-8 opacity-60" />
        </div>
        <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
          {t('আপনার ব্যাগ খালি আছে', 'Your cart is empty')}
        </h2>
        <p className="text-xs text-gray-500 mb-6">
          {t('চেকআউট করার আগে ব্যাগে কিছু পণ্য যোগ করুন।', 'Please add items to your cart before proceeding to checkout.')}
        </p>
        <button
          onClick={() => setCurrentView('shop')}
          className="px-6 py-3 bg-emerald-600 text-white font-bold rounded-xl text-xs"
        >
          {t('কেনাকাটা করুন', 'Start Shopping')}
        </button>
      </div>
    );
  }

  return (
    <div className="py-10 bg-gray-50 dark:bg-gray-900 min-h-screen transition-colors">
      <div className="max-w-4xl mx-auto px-4">
        {/* Step Indicator Header */}
        <div className="mb-8">
          <div className="flex items-center justify-center gap-2 sm:gap-6 max-w-md mx-auto">
            {/* Step 1 */}
            <div className="flex items-center gap-2">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                currentStep >= 1 ? 'bg-emerald-600 text-white' : 'bg-gray-200 text-gray-600'
              }`}>
                {currentStep > 1 ? <CheckCircle2 className="w-4 h-4" /> : '1'}
              </div>
              <span className={`text-xs font-semibold hidden sm:inline ${currentStep >= 1 ? 'text-gray-900 dark:text-white' : 'text-gray-400'}`}>
                {t('ডেলিভারি তথ্য', 'Delivery')}
              </span>
            </div>

            <div className={`h-0.5 w-10 sm:w-16 ${currentStep >= 2 ? 'bg-emerald-600' : 'bg-gray-200 dark:bg-gray-700'}`}></div>

            {/* Step 2 */}
            <div className="flex items-center gap-2">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                currentStep >= 2 ? 'bg-emerald-600 text-white' : 'bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-400'
              }`}>
                {currentStep > 2 ? <CheckCircle2 className="w-4 h-4" /> : '2'}
              </div>
              <span className={`text-xs font-semibold hidden sm:inline ${currentStep >= 2 ? 'text-gray-900 dark:text-white' : 'text-gray-400'}`}>
                {t('পেমেন্ট পদ্ধতি', 'Payment')}
              </span>
            </div>

            <div className={`h-0.5 w-10 sm:w-16 ${currentStep >= 3 ? 'bg-emerald-600' : 'bg-gray-200 dark:bg-gray-700'}`}></div>

            {/* Step 3 */}
            <div className="flex items-center gap-2">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                currentStep === 3 ? 'bg-emerald-600 text-white' : 'bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-400'
              }`}>
                3
              </div>
              <span className={`text-xs font-semibold hidden sm:inline ${currentStep === 3 ? 'text-gray-900 dark:text-white' : 'text-gray-400'}`}>
                {t('অর্ডার নিশ্চিত', 'Confirmation')}
              </span>
            </div>
          </div>
        </div>

        {/* STEP 1: Delivery Information */}
        {currentStep === 1 && (
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
            <div className="md:col-span-7 bg-white dark:bg-gray-800 rounded-3xl p-6 sm:p-8 border border-gray-100 dark:border-gray-700/80 shadow-sm">
              <div className="flex items-center gap-2 mb-6">
                <MapPin className="w-5 h-5 text-emerald-600" />
                <h2 className="text-lg font-bold text-gray-900 dark:text-white">
                  {t('ডেলিভারি ঠিকানা ও যোগাযোগের তথ্য', 'Delivery & Contact Information')}
                </h2>
              </div>

              <form onSubmit={handleProceedToPayment} className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-gray-700 dark:text-gray-300 block mb-1">
                    {t('গ্রাহকের পূর্ণ নাম *', 'Full Name *')}
                  </label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g. Tanvir Hossain"
                    className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl px-3.5 py-2.5 text-xs text-gray-900 dark:text-white focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-bold text-gray-700 dark:text-gray-300 block mb-1">
                      {t('মোবাইল নম্বর * (ডেলিভারির জন্য)', 'Mobile Phone *')}
                    </label>
                    <input
                      type="tel"
                      required
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      placeholder="+88017xxxxxxxx"
                      className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl px-3.5 py-2.5 text-xs text-gray-900 dark:text-white focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-700 dark:text-gray-300 block mb-1">
                      {t('ইমেইল (ঐচ্ছিক)', 'Email (Optional)')}
                    </label>
                    <input
                      type="email"
                      value={customerEmail}
                      onChange={(e) => setCustomerEmail(e.target.value)}
                      placeholder="name@email.com"
                      className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl px-3.5 py-2.5 text-xs text-gray-900 dark:text-white focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                    />
                  </div>
                </div>

                {/* Division, District, Upazila */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs font-bold text-gray-700 dark:text-gray-300 block mb-1">
                      {t('বিভাগ (Division) *', 'Division *')}
                    </label>
                    <select
                      value={division}
                      onChange={(e) => {
                        setDivision(e.target.value);
                        const districts = DISTRICTS_BY_DIVISION[e.target.value] || ['Dhaka'];
                        setDistrict(districts[0]);
                      }}
                      className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl px-3 py-2.5 text-xs text-gray-900 dark:text-white focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                    >
                      {BANGLADESH_DIVISIONS.map(div => (
                        <option key={div} value={div}>{div}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-700 dark:text-gray-300 block mb-1">
                      {t('জেলা (District) *', 'District *')}
                    </label>
                    <select
                      value={district}
                      onChange={(e) => setDistrict(e.target.value)}
                      className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl px-3 py-2.5 text-xs text-gray-900 dark:text-white focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                    >
                      {(DISTRICTS_BY_DIVISION[division] || [division]).map(dis => (
                        <option key={dis} value={dis}>{dis}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-700 dark:text-gray-300 block mb-1">
                      {t('উপজেলা / থানা *', 'Thana / Upazila *')}
                    </label>
                    <input
                      type="text"
                      required
                      value={upazila}
                      onChange={(e) => setUpazila(e.target.value)}
                      placeholder="e.g. Dhanmondi / Gulshan"
                      className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl px-3 py-2.5 text-xs text-gray-900 dark:text-white focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-gray-700 dark:text-gray-300 block mb-1">
                    {t('পূর্ণাঙ্গ ঠিকানা (বাসা/ফ্ল্যাট, রোড, এলাকা) *', 'Full Address (House, Road, Area) *')}
                  </label>
                  <textarea
                    required
                    rows={2}
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="e.g. House 14, Flat 4B, Road 8, Dhanmondi, Dhaka"
                    className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl px-3.5 py-2.5 text-xs text-gray-900 dark:text-white focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-gray-700 dark:text-gray-300 block mb-1">
                    {t('ডেলিভারি নির্দেশনা (ঐচ্ছিক)', 'Special Delivery Notes (Optional)')}
                  </label>
                  <input
                    type="text"
                    value={deliveryInstructions}
                    onChange={(e) => setDeliveryInstructions(e.target.value)}
                    placeholder="e.g. কল দিয়ে বেল বাজাবেন, সিকিউরিটি গার্ডের কাছে দিতে পারেন"
                    className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl px-3.5 py-2.5 text-xs text-gray-900 dark:text-white focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>

                {/* Bangladeshi Courier Service Selection */}
                <div className="pt-2">
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs font-bold text-gray-900 dark:text-white flex items-center gap-1.5">
                      <Truck className="w-4 h-4 text-emerald-600" />
                      <span>{t('পছন্দের বাংলাদেশি কুরিয়ার সার্ভিস নির্বাচন করুন *', 'Select Bangladeshi Courier Partner *')}</span>
                    </label>
                    <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950 px-2 py-0.5 rounded-full border border-emerald-200 dark:border-emerald-800">
                      {isDhakaOrder ? t('ঢাকা মেট্রো রেট', 'Inside Dhaka Rates') : t('সারা বাংলাদেশ রেট', 'Outside Dhaka Rates')}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-56 overflow-y-auto pr-1">
                    {BANGLADESH_COURIERS.map((c: any) => {
                      const isSelected = c.id === selectedCourierId;
                      const rate = isDhakaOrder ? c.baseRateInsideDhaka : c.baseRateOutsideDhaka;
                      const time = isDhakaOrder ? c.deliveryTimeInsideDhaka : c.deliveryTimeOutsideDhaka;
                      return (
                        <div
                          key={c.id}
                          onClick={() => setSelectedCourierId(c.id)}
                          className={`p-3 rounded-2xl border cursor-pointer transition-all flex items-center gap-3 ${
                            isSelected
                              ? 'bg-emerald-50/80 dark:bg-emerald-950/40 border-emerald-500 ring-2 ring-emerald-500/20 shadow-xs'
                              : 'bg-gray-50 dark:bg-gray-700/60 border-gray-200 dark:border-gray-600 hover:bg-white dark:hover:bg-gray-750'
                          }`}
                        >
                          <img 
                            src={c.logo} 
                            alt={c.name} 
                            className="w-10 h-10 rounded-xl object-cover shrink-0 border border-gray-200 dark:border-gray-600" 
                          />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-bold text-gray-900 dark:text-white truncate">
                                {t(c.nameBn, c.name)}
                              </span>
                              <span className="text-xs font-black text-emerald-600 dark:text-emerald-400 shrink-0">
                                ৳{rate}
                              </span>
                            </div>
                            <span className="text-[10px] text-gray-500 block truncate">
                              ⚡ {time} • COD {c.codChargePercent}%
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="pt-4">
                  <button
                    type="submit"
                    className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md shadow-emerald-600/30 flex items-center justify-center gap-2 active:scale-95 transition-all"
                  >
                    <span>{t('পেমেন্ট ধাপে এগিয়ে যান', 'Continue to Payment')}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </form>
            </div>

            {/* Order Summary Sidebar */}
            <div className="md:col-span-5 bg-white dark:bg-gray-800 rounded-3xl p-6 border border-gray-100 dark:border-gray-700/80 shadow-sm h-fit space-y-4">
              <h3 className="text-sm font-bold text-gray-900 dark:text-white pb-3 border-b border-gray-100 dark:border-gray-700">
                {t('অর্ডার বিবরণী', 'Order Summary')} ({cart.length} {t('আইটেম', 'items')})
              </h3>

              <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
                {cart.map((item) => (
                  <div key={item.product.id} className="flex items-center gap-3 text-xs">
                    <img src={item.product.image} alt={item.product.name} className="w-12 h-12 rounded-xl object-cover" />
                    <div className="flex-1 min-w-0">
                      <span className="font-bold text-gray-900 dark:text-white truncate block">{t(item.product.nameBn, item.product.name)}</span>
                      <span className="text-gray-400 text-[11px]">{item.quantity} x ৳{item.product.price}</span>
                    </div>
                    <span className="font-bold text-emerald-600">৳{item.quantity * item.product.price}</span>
                  </div>
                ))}
              </div>

              <div className="pt-3 border-t border-gray-100 dark:border-gray-700 space-y-2 text-xs text-gray-600 dark:text-gray-300">
                <div className="flex justify-between">
                  <span>{t('সাবটোটাল', 'Subtotal')}</span>
                  <span className="font-bold text-gray-900 dark:text-white">৳{cartSubtotal}</span>
                </div>
                <div className="flex justify-between">
                  <span>
                    {t('কুরিয়ার চার্জ', 'Courier Shipping')}
                    <span className="text-[10px] text-gray-400 block">({selectedCourier.name})</span>
                  </span>
                  <span className="font-bold text-gray-900 dark:text-white">৳{dynamicDeliveryFee}</span>
                </div>
                {discountAmount > 0 && (
                  <div className="flex justify-between text-emerald-600">
                    <span>{t('কুপন ডিসকাউন্ট', 'Discount')}</span>
                    <span>-৳{discountAmount}</span>
                  </div>
                )}
                <div className="pt-2 border-t border-gray-200 dark:border-gray-650 flex justify-between text-base font-black text-gray-900 dark:text-white">
                  <span>{t('সর্বমোট', 'Total')}</span>
                  <span className="text-emerald-600 dark:text-emerald-400">৳{calculatedGrandTotal}</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* STEP 2: Payment Method */}
        {currentStep === 2 && (
          <div className="max-w-2xl mx-auto bg-white dark:bg-gray-800 rounded-3xl p-6 sm:p-8 border border-gray-100 dark:border-gray-700/80 shadow-sm space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-gray-100 dark:border-gray-700">
              <div className="flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-emerald-600" />
                <h2 className="text-lg font-bold text-gray-900 dark:text-white">
                  {t('পেমেন্ট পদ্ধতি নির্বাচন করুন', 'Select Payment Method')}
                </h2>
              </div>
              <button
                onClick={() => setCurrentStep(1)}
                className="text-xs text-gray-500 hover:text-emerald-600 flex items-center gap-1"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>{t('ঠিকানা পরিবর্তন', 'Back')}</span>
              </button>
            </div>

            {/* Quick Payment Gateway Dropdown Selector */}
            <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-50/90 to-teal-50/90 dark:from-emerald-950/40 dark:to-teal-950/40 border-2 border-emerald-500/30 space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-gray-800 dark:text-gray-200 flex items-center gap-1.5">
                  <CreditCard className="w-4 h-4 text-emerald-600" />
                  <span>{t('পেমেন্ট গেটওয়ে ড্রপডাউন (Payment Gateway Dropdown):', 'Payment Gateway Dropdown Selector:')}</span>
                </label>
                <span className="text-[10px] text-emerald-700 dark:text-emerald-300 font-bold bg-white dark:bg-gray-800 px-2.5 py-0.5 rounded-full border border-emerald-200 dark:border-emerald-700">
                  {t('সহজ ড্রপডাউন নির্বাচন', 'Quick Dropdown')}
                </span>
              </div>
              <div className="relative">
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value as any)}
                  className="w-full bg-white dark:bg-gray-800 border-2 border-emerald-600 dark:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs font-bold text-gray-900 dark:text-white cursor-pointer shadow-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none appearance-none pr-9"
                >
                  <option value="bank_transfer">🏛️ {t('বাংলাদেশি ব্যাংক ট্রান্সফার ও ইন্টারনেট ব্যাংকিং (Bangladeshi Bank Gateway / iBanking)', 'Bangladeshi Bank Gateway & Internet Banking')}</option>
                  <option value="bkash">📱 {t('বিকাশ ইনস্ট্যান্ট পেমেন্ট গেটওয়ে (bKash Instant Gateway)', 'bKash Instant PGW')}</option>
                  <option value="nagad">🟠 {t('নগদ ডিজিটাল পেমেন্ট গেটওয়ে (Nagad Direct Gateway)', 'Nagad Direct PGW')}</option>
                  <option value="rocket">🟣 {t('রকেট ও ডিবিবিএল নেক্সাস গেটওয়ে (Rocket / DBBL Nexus)', 'Rocket / NexusPay')}</option>
                  <option value="card">💳 {t('ভিসা / মাস্টারকার্ড / এমেক্স কার্ড (Debit / Credit Cards)', 'Visa / Mastercard')}</option>
                  <option value="cod">💵 {t('ক্যাশ অন ডেলিভারি (Cash on Delivery - COD)', 'Cash on Delivery (COD)')}</option>
                </select>
                <ChevronDown className="w-4 h-4 text-emerald-600 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>

            <div className="space-y-3">
              {/* Option 1: Cash on Delivery */}
              <label className={`p-4 rounded-2xl border-2 flex items-center justify-between cursor-pointer transition-all ${
                paymentMethod === 'cod'
                  ? 'border-emerald-600 bg-emerald-50/50 dark:bg-emerald-950/30'
                  : 'border-gray-200 dark:border-gray-700 hover:border-gray-300'
              }`}>
                <div className="flex items-center gap-3">
                  <input
                    type="radio"
                    name="payment"
                    value="cod"
                    checked={paymentMethod === 'cod'}
                    onChange={() => setPaymentMethod('cod')}
                    className="accent-emerald-600"
                  />
                  <div>
                    <span className="text-sm font-bold text-gray-900 dark:text-white block">
                      {t('ক্যাশ অন ডেলিভারি (Cash on Delivery)', 'Cash on Delivery (COD)')}
                    </span>
                    <span className="text-xs text-gray-500">
                      {t('পণ্য হাতে পেয়ে চেক করে টাকা দিন। কোনো অগ্রিম পেমেন্ট নেই।', 'Pay in cash after receiving and inspecting the package.')}
                    </span>
                  </div>
                </div>
                <span className="bg-emerald-100 dark:bg-emerald-900 text-emerald-700 dark:text-emerald-300 text-[10px] font-bold px-2 py-0.5 rounded">
                  Most Popular
                </span>
              </label>

              {/* Option 2: bKash */}
              <label className={`p-4 rounded-2xl border-2 flex flex-col cursor-pointer transition-all ${
                paymentMethod === 'bkash'
                  ? 'border-[#E2136E] bg-pink-50/40 dark:bg-pink-950/20'
                  : 'border-gray-200 dark:border-gray-700 hover:border-gray-300'
              }`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <input
                      type="radio"
                      name="payment"
                      value="bkash"
                      checked={paymentMethod === 'bkash'}
                      onChange={() => setPaymentMethod('bkash')}
                      className="accent-[#E2136E]"
                    />
                    <div>
                      <span className="text-sm font-bold text-gray-900 dark:text-white block">
                        {t('বিকাশ পেমেন্ট (bKash Instant Gateway)', 'bKash Instant Gateway')}
                      </span>
                      <span className="text-xs text-gray-500">
                        {t('বিকাশ অ্যাকাউন্ট দিয়ে দ্রুত ও নিরাপদ পেমেন্ট', 'Fast & instant mobile payment')}
                      </span>
                    </div>
                  </div>
                  <span className="bg-[#E2136E] text-white text-[10px] font-black px-2.5 py-1 rounded">
                    bKash
                  </span>
                </div>

                {paymentMethod === 'bkash' && (
                  <div className="mt-4 pt-3 border-t border-pink-200 dark:border-pink-900/40 space-y-2">
                    <span className="text-xs font-semibold text-gray-700 dark:text-gray-300 block">
                      {t('আপনার বিকাশ নম্বর দিন:', 'Your bKash Account Number:')}
                    </span>
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="tel"
                        value={bkashNumber}
                        onChange={(e) => setBkashNumber(e.target.value)}
                        placeholder="017xxxxxxxx"
                        className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl p-2 text-xs"
                      />
                      <input
                        type="password"
                        value={bkashPin}
                        onChange={(e) => setBkashPin(e.target.value)}
                        placeholder="PIN (Demo: 12345)"
                        className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl p-2 text-xs"
                      />
                    </div>
                    <span className="text-[10px] text-gray-400">
                      {t('নিরাপদ বিকাশ গেটওয়ে সিমুলেশন সক্রিয়', 'Secured bKash API checkout simulator')}
                    </span>
                  </div>
                )}
              </label>

              {/* Option 3: Nagad */}
              <label className={`p-4 rounded-2xl border-2 flex items-center justify-between cursor-pointer transition-all ${
                paymentMethod === 'nagad'
                  ? 'border-[#F7931E] bg-orange-50/40 dark:bg-orange-950/20'
                  : 'border-gray-200 dark:border-gray-700 hover:border-gray-300'
              }`}>
                <div className="flex items-center gap-3">
                  <input
                    type="radio"
                    name="payment"
                    value="nagad"
                    checked={paymentMethod === 'nagad'}
                    onChange={() => setPaymentMethod('nagad')}
                    className="accent-[#F7931E]"
                  />
                  <div>
                    <span className="text-sm font-bold text-gray-900 dark:text-white block">
                      {t('নগদ পেমেন্ট (Nagad Payment)', 'Nagad Direct Pay')}
                    </span>
                    <span className="text-xs text-gray-500">
                      {t('ডাক বিভাগের ডিজিটাল লেনদেন সেবা', 'Bangladesh Post Office Digital Financial Service')}
                    </span>
                  </div>
                </div>
                <span className="bg-[#F7931E] text-white text-[10px] font-black px-2.5 py-1 rounded">
                  NAGAD
                </span>
              </label>

              {/* Option 4: Card Payment */}
              <label className={`p-4 rounded-2xl border-2 flex items-center justify-between cursor-pointer transition-all ${
                paymentMethod === 'card'
                  ? 'border-blue-600 bg-blue-50/40 dark:bg-blue-950/20'
                  : 'border-gray-200 dark:border-gray-700 hover:border-gray-300'
              }`}>
                <div className="flex items-center gap-3">
                  <input
                    type="radio"
                    name="payment"
                    value="card"
                    checked={paymentMethod === 'card'}
                    onChange={() => setPaymentMethod('card')}
                    className="accent-blue-600"
                  />
                  <div>
                    <span className="text-sm font-bold text-gray-900 dark:text-white block">
                      {t('ভিসা / মাস্টারকার্ড (Debit / Credit Card)', 'Visa / Mastercard')}
                    </span>
                    <span className="text-xs text-gray-500">
                      {t('যেকোনো বাংলাদেশি ব্যাংকের কার্ড দিয়ে তাৎক্ষণিক পেমেন্ট', 'Any Bangladeshi bank card with 3D Secure OTP')}
                    </span>
                  </div>
                </div>
                <span className="bg-[#1A1F71] text-white text-[10px] font-bold px-2 py-0.5 rounded">
                  Cards
                </span>
              </label>

              {/* Option 5: Bangladeshi Bank Gateway & Internet Banking */}
              <div className={`rounded-2xl border-2 transition-all overflow-hidden ${
                paymentMethod === 'bank_transfer'
                  ? 'border-emerald-600 bg-emerald-50/30 dark:bg-emerald-950/20'
                  : 'border-gray-200 dark:border-gray-700 hover:border-gray-300'
              }`}>
                <label className="p-4 flex items-center justify-between cursor-pointer">
                  <div className="flex items-center gap-3">
                    <input
                      type="radio"
                      name="payment"
                      value="bank_transfer"
                      checked={paymentMethod === 'bank_transfer'}
                      onChange={() => setPaymentMethod('bank_transfer')}
                      className="accent-emerald-600"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-gray-900 dark:text-white block">
                          {t('বাংলাদেশি ব্যাংক ট্রান্সফার ও ইন্টারনেট ব্যাংকিং', 'Bangladeshi Bank Gateway / Internet Banking')}
                        </span>
                        <span className="px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-900 text-emerald-700 dark:text-emerald-300 text-[10px] font-black">
                          All BD Banks
                        </span>
                      </div>
                      <span className="text-xs text-gray-500">
                        {t('CellFin, NexusPay, City Touch, Astha, NPSB Instant 24/7 বা ব্যাংক অ্যাকাউন্ট ডিপোজিট', 'CellFin, NexusPay, City Touch, Astha, NPSB Instant 24/7 & Direct Deposit')}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <span className="w-8 h-8 rounded-xl bg-emerald-100 dark:bg-emerald-900 text-emerald-700 dark:text-emerald-300 flex items-center justify-center font-bold">
                      <Building2 className="w-4 h-4" />
                    </span>
                  </div>
                </label>

                {paymentMethod === 'bank_transfer' && (
                  <div className="px-4 pb-5 pt-2 border-t border-emerald-200/80 dark:border-emerald-900/40 space-y-4">
                    {/* 1. Select Bangladeshi Bank via Drop Down Button & Selector */}
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-gray-800 dark:text-gray-200 flex items-center gap-1.5">
                          <Building2 className="w-4 h-4 text-emerald-600" />
                          <span>{t('১. ড্রপডাউন বাটন থেকে ব্যাংক নির্বাচন করুন:', '1. Select Bangladeshi Bank (Dropdown Button):')}</span>
                        </span>
                        <span className="text-[10px] font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-100 dark:bg-emerald-950 px-2 py-0.5 rounded-full">
                          {BANGLADESHI_BANKS.length} {t('টি ব্যাংক যুক্ত', 'Banks Connected')}
                        </span>
                      </div>

                      {/* Prominent Custom Drop Down Button */}
                      {(() => {
                        const currentBank = BANGLADESHI_BANKS.find((b: any) => b.id === selectedBankId) || BANGLADESHI_BANKS[0];
                        const filteredList = BANGLADESHI_BANKS.filter((b: any) => {
                          if (!bankSearchQuery.trim()) return true;
                          const q = bankSearchQuery.toLowerCase();
                          return (
                            b.name.toLowerCase().includes(q) ||
                            b.nameBn.toLowerCase().includes(q) ||
                            b.shortCode.toLowerCase().includes(q) ||
                            b.accountNumber.toLowerCase().includes(q) ||
                            b.appPlatform.toLowerCase().includes(q)
                          );
                        });

                        return (
                          <div className="relative">
                            <button
                              type="button"
                              onClick={() => setIsBankDropdownOpen(!isBankDropdownOpen)}
                              className="w-full p-3 bg-white dark:bg-gray-800 border-2 border-emerald-600 dark:border-emerald-500 rounded-2xl flex items-center justify-between text-left shadow-sm hover:border-emerald-700 transition-all active:scale-[0.99] focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                            >
                              <div className="flex items-center gap-3 min-w-0">
                                <div 
                                  className="w-9 h-9 rounded-xl flex items-center justify-center text-white text-xs font-black shadow-xs shrink-0"
                                  style={{ backgroundColor: currentBank.color }}
                                >
                                  {currentBank.id.substring(0, 2).toUpperCase()}
                                </div>
                                <div className="min-w-0">
                                  <div className="flex items-center gap-2">
                                    <span className="font-black text-xs text-gray-900 dark:text-white truncate">
                                      {language === 'bn' ? currentBank.nameBn : currentBank.name}
                                    </span>
                                    <span className="px-1.5 py-0.2 bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-300 text-[9px] font-bold rounded shrink-0">
                                      {currentBank.shortCode}
                                    </span>
                                  </div>
                                  <span className="text-[11px] text-gray-400 block truncate">
                                    {t('হিসাব:', 'A/C:')} <span className="font-mono text-gray-700 dark:text-gray-300 font-bold">{currentBank.accountNumber}</span> • {currentBank.appPlatform}
                                  </span>
                                </div>
                              </div>

                              <div className="flex items-center gap-2 shrink-0 ml-2">
                                <span className="text-[11px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/80 px-2 py-1 rounded-lg border border-emerald-200 dark:border-emerald-800 hidden sm:inline-flex items-center gap-1">
                                  {isBankDropdownOpen ? t('ড্রপডাউন বন্ধ করুন', 'Close Dropdown') : t('ড্রপডাউন খুলুন ▼', 'Open Dropdown ▼')}
                                </span>
                                <div className="w-7 h-7 rounded-lg bg-emerald-600 text-white flex items-center justify-center shadow-xs">
                                  {isBankDropdownOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                                </div>
                              </div>
                            </button>

                            {/* Drop Down Menu Box */}
                            {isBankDropdownOpen && (
                              <div className="absolute top-full left-0 right-0 mt-2 z-50 bg-white dark:bg-gray-850 rounded-2xl border-2 border-emerald-500 shadow-2xl overflow-hidden">
                                <div className="p-2.5 bg-gray-50 dark:bg-gray-800 border-b border-gray-100 dark:border-gray-700">
                                  <div className="relative">
                                    <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                                    <input
                                      type="text"
                                      autoFocus
                                      value={bankSearchQuery}
                                      onChange={(e) => setBankSearchQuery(e.target.value)}
                                      placeholder={t('ব্যাংকের নাম বা কোড খুঁজুন (e.g. IBBL, DBBL, City, BRAC, Sonali)...', 'Search bank (e.g. IBBL, DBBL, City, BRAC, Sonali)...')}
                                      className="w-full bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl pl-8 pr-3 py-2 text-xs text-gray-900 dark:text-white placeholder:text-gray-400 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                                    />
                                  </div>
                                </div>

                                <div className="max-h-60 overflow-y-auto divide-y divide-gray-100 dark:divide-gray-800 p-1.5">
                                  {filteredList.length === 0 ? (
                                    <div className="p-4 text-center text-xs text-gray-400">
                                      {t('কোনো মিল পাওয়া যায়নি', 'No matching bank found')}
                                    </div>
                                  ) : (
                                    filteredList.map((b: any) => {
                                      const isSelected = b.id === selectedBankId;
                                      return (
                                        <div
                                          key={b.id}
                                          onClick={() => {
                                            setSelectedBankId(b.id);
                                            setIsBankDropdownOpen(false);
                                            setBankSearchQuery('');
                                          }}
                                          className={`p-2.5 rounded-xl flex items-center justify-between cursor-pointer transition-colors ${
                                            isSelected
                                              ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-900 dark:text-emerald-100 font-bold border border-emerald-300 dark:border-emerald-800'
                                              : 'hover:bg-gray-50 dark:hover:bg-gray-800 text-gray-700 dark:text-gray-200'
                                          }`}
                                        >
                                          <div className="flex items-center gap-2.5 min-w-0">
                                            <div 
                                              className="w-7 h-7 rounded-lg flex items-center justify-center text-white text-[10px] font-black shrink-0"
                                              style={{ backgroundColor: b.color }}
                                            >
                                              {b.id.substring(0, 2).toUpperCase()}
                                            </div>
                                            <div className="min-w-0">
                                              <div className="flex items-center gap-1.5">
                                                <span className="text-xs font-bold truncate">
                                                  {language === 'bn' ? b.nameBn : b.name}
                                                </span>
                                                <span className="text-[9px] px-1.5 py-0.2 rounded bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 shrink-0">
                                                  {b.shortCode}
                                                </span>
                                              </div>
                                              <span className="text-[10px] text-gray-400 block truncate">
                                                {b.appPlatform} • {t('রাউটিং:', 'Routing:')} {b.routingNumber}
                                              </span>
                                            </div>
                                          </div>

                                          <div className="flex items-center gap-2 shrink-0 ml-2">
                                            {b.isPopular && (
                                              <span className="text-[9px] font-black px-1.5 py-0.5 rounded bg-emerald-100 dark:bg-emerald-900 text-emerald-700 dark:text-emerald-300 hidden sm:inline">
                                                Popular
                                              </span>
                                            )}
                                            {isSelected ? (
                                              <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                                            ) : (
                                              <span className="text-[10px] text-gray-400 hover:text-emerald-600 font-medium">{t('বাছাই করুন', 'Select')}</span>
                                            )}
                                          </div>
                                        </div>
                                      );
                                    })
                                  )}
                                </div>
                              </div>
                            )}
                          </div>
                        );
                      })()}

                      {/* Native Drop Down Select Bar for Direct Accessibility */}
                      <div className="flex flex-col sm:flex-row sm:items-center gap-2 pt-0.5">
                        <label className="text-[11px] font-bold text-gray-500 dark:text-gray-400 whitespace-nowrap flex items-center gap-1">
                          <Sliders className="w-3.5 h-3.5 text-emerald-600" />
                          <span>{t('ড্রপডাউন লিস্ট থেকে দ্রুত সিলেক্ট করুন:', 'Quick Dropdown Select:')}</span>
                        </label>
                        <select
                          value={selectedBankId}
                          onChange={(e) => {
                            setSelectedBankId(e.target.value);
                            setIsBankDropdownOpen(false);
                          }}
                          className="w-full bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-xl px-3 py-2 text-xs font-bold text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-xs cursor-pointer"
                        >
                          {BANGLADESHI_BANKS.map((b: any) => (
                            <option key={b.id} value={b.id}>
                              {b.name} ({b.shortCode}) - A/C: {b.accountNumber}
                            </option>
                          ))}
                        </select>
                      </div>

                      {/* Quick Popular Bank Pills */}
                      <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
                        <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">{t('জনপ্রিয় ব্যাংক:', 'Popular Banks:')}</span>
                        {BANGLADESHI_BANKS.slice(0, 5).map((b: any) => (
                          <button
                            key={b.id}
                            type="button"
                            onClick={() => {
                              setSelectedBankId(b.id);
                              setIsBankDropdownOpen(false);
                            }}
                            className={`px-2 py-0.5 rounded-lg text-[11px] font-bold transition-all ${
                              b.id === selectedBankId
                                ? 'bg-emerald-600 text-white shadow-2xs'
                                : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 hover:bg-gray-200'
                            }`}
                          >
                            {b.shortCode.split('/')[0].trim()}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* 2. Official Store Bank Account Details with Copy Buttons */}
                    {(() => {
                      const bank = BANGLADESHI_BANKS.find((b: any) => b.id === selectedBankId) || BANGLADESHI_BANKS[0];
                      return (
                        <div className="p-4 rounded-2xl bg-white dark:bg-gray-850 border border-emerald-200 dark:border-emerald-800/80 shadow-xs space-y-3">
                          <div className="flex items-center justify-between pb-2 border-b border-gray-100 dark:border-gray-700">
                            <div>
                              <div className="flex items-center gap-2">
                                <h4 className="text-xs font-black text-gray-900 dark:text-white">
                                  {bank.name}
                                </h4>
                                <span className="px-2 py-0.2 rounded-full text-[9px] font-bold bg-emerald-100 text-emerald-700">Verified Merchant</span>
                              </div>
                              <span className="text-[10px] text-gray-400">{bank.appPlatform}</span>
                            </div>
                            <span className="text-xs font-bold text-emerald-600">{t('সরকারি ব্যাংকিং চ্যানেল', 'Official Gateway')}</span>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                            <div className="p-2.5 rounded-xl bg-gray-50 dark:bg-gray-800">
                              <span className="text-[10px] text-gray-400 block">{t('অ্যাকাউন্টের নাম', 'Account Name')}</span>
                              <span className="font-bold text-gray-900 dark:text-white">{bank.accountName}</span>
                            </div>

                            <div className="p-2.5 rounded-xl bg-emerald-50/60 dark:bg-emerald-950/40 border border-emerald-200/60 dark:border-emerald-800/40 flex items-center justify-between">
                              <div>
                                <span className="text-[10px] text-gray-400 block">{t('অ্যাকাউন্ট নম্বর', 'Account Number')}</span>
                                <span className="font-mono font-black text-emerald-700 dark:text-emerald-300">{bank.accountNumber}</span>
                              </div>
                              <button
                                type="button"
                                onClick={() => handleCopyBankField(bank.accountNumber.replace(/-/g, ''), 'acc')}
                                className="px-2 py-1 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg text-[10px] font-bold text-gray-700 dark:text-gray-200 hover:text-emerald-600 flex items-center gap-1 active:scale-95"
                              >
                                {copiedBankField === 'acc' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                                <span>{copiedBankField === 'acc' ? 'Copied' : 'Copy'}</span>
                              </button>
                            </div>

                            <div className="p-2.5 rounded-xl bg-gray-50 dark:bg-gray-800">
                              <span className="text-[10px] text-gray-400 block">{t('শাখা (Branch)', 'Branch Name')}</span>
                              <span className="font-bold text-gray-900 dark:text-white">{bank.branchName}</span>
                            </div>

                            <div className="p-2.5 rounded-xl bg-gray-50 dark:bg-gray-800 flex items-center justify-between">
                              <div>
                                <span className="text-[10px] text-gray-400 block">{t('রাউটিং নম্বর (Routing No)', 'Routing Number')}</span>
                                <span className="font-mono font-bold text-gray-900 dark:text-white">{bank.routingNumber}</span>
                              </div>
                              <button
                                type="button"
                                onClick={() => handleCopyBankField(bank.routingNumber, 'routing')}
                                className="px-2 py-1 bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg text-[10px] font-bold text-gray-700 dark:text-gray-200 hover:text-emerald-600 flex items-center gap-1 active:scale-95"
                              >
                                {copiedBankField === 'routing' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                                <span>{copiedBankField === 'routing' ? 'Copied' : 'Copy'}</span>
                              </button>
                            </div>
                          </div>

                          <p className="text-[11px] text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/30 p-2.5 rounded-xl border border-emerald-200/60 dark:border-emerald-800/40 leading-relaxed">
                            💡 {bank.instructionsBn}
                          </p>
                        </div>
                      );
                    })()}

                    {/* 3. Customer Transfer Method & Txn ID Input */}
                    <div className="space-y-3 pt-1">
                      <div>
                        <div className="flex items-center justify-between mb-1.5">
                          <span className="text-xs font-bold text-gray-700 dark:text-gray-300">
                            {t('২. ট্রান্সফার চ্যানেল ড্রপডাউন ও মাধ্যম নির্বাচন করুন:', '2. Transfer Channel Dropdown Selector:')}
                          </span>
                          <span className="text-[10px] text-emerald-600 font-bold bg-emerald-50 dark:bg-emerald-950 px-2 py-0.5 rounded-md">
                            Channel Dropdown
                          </span>
                        </div>

                        {/* Transfer channel select dropdown */}
                        <div className="relative mb-2">
                          <select
                            value={bankTransferType}
                            onChange={(e) => setBankTransferType(e.target.value as any)}
                            className="w-full bg-white dark:bg-gray-800 border-2 border-emerald-500/60 rounded-xl px-3 py-2 text-xs font-bold text-gray-900 dark:text-white cursor-pointer shadow-xs focus:ring-1 focus:ring-emerald-500 appearance-none pr-8"
                          >
                            <option value="cellfin">📱 {t('সেলফিন বা ব্যাংক মোবাইল অ্যাপ ট্রান্সফার (CellFin / Mobile App)', 'CellFin / Mobile App')}</option>
                            <option value="nexus_pay">💳 {t('নেক্সাসপে / ডেবিট-ক্রেডিট কার্ড ট্রান্সফার (NexusPay / Card)', 'NexusPay / Card')}</option>
                            <option value="internet_banking">🌐 {t('অনলাইন ইন্টারনেট ব্যাংকিং (Internet Banking Portal)', 'Internet Banking Portal')}</option>
                            <option value="npsb_beftn">⚡ {t('এনপিএসবি ইনস্ট্যান্ট ২৪/৭ অথবা বিইএফটিএন (NPSB Instant 24/7)', 'NPSB Instant 24/7 / BEFTN')}</option>
                            <option value="branch_deposit">🏛️ {t('এটিএম / সিআরএম বুথ বা ব্রাঞ্চ ডিপোজিট (ATM / Counter Slip)', 'ATM / Branch Counter Slip')}</option>
                          </select>
                          <ChevronDown className="w-4 h-4 text-emerald-600 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                        </div>

                        {/* Quick Transfer Channel Pill Buttons */}
                        <div className="flex flex-wrap gap-1.5">
                          {[
                            { id: 'cellfin', label: '📱 CellFin / App' },
                            { id: 'nexus_pay', label: '💳 NexusPay / Card' },
                            { id: 'internet_banking', label: '🌐 iBanking' },
                            { id: 'npsb_beftn', label: '⚡ NPSB Instant' },
                            { id: 'branch_deposit', label: '🏛️ CRM / Slip' }
                          ].map(tType => (
                            <button
                              key={tType.id}
                              type="button"
                              onClick={() => setBankTransferType(tType.id as any)}
                              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                                bankTransferType === tType.id
                                  ? 'bg-emerald-600 text-white shadow-xs'
                                  : 'bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-50'
                              }`}
                            >
                              {tType.label}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        <div>
                          <label className="text-[11px] font-bold text-gray-700 dark:text-gray-300 block mb-1">
                            {t('প্রেরকের অ্যাকাউন্ট বা ফোন নম্বর *', 'Sender Account / Phone *')}
                          </label>
                          <input
                            type="text"
                            value={bankSenderInfo}
                            onChange={(e) => setBankSenderInfo(e.target.value)}
                            placeholder="017xxxxxxxx or Bank A/C"
                            className="w-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl p-2.5 text-xs text-gray-900 dark:text-white"
                          />
                        </div>

                        <div>
                          <label className="text-[11px] font-bold text-gray-700 dark:text-gray-300 block mb-1">
                            {t('ব্যাংক ট্রানজেকশন আইডি / স্লিপ রেফারেন্স *', 'Transaction Ref / Slip No *')}
                          </label>
                          <input
                            type="text"
                            value={bankTxnRef}
                            onChange={(e) => setBankTxnRef(e.target.value)}
                            placeholder="e.g. TXN-948123 / Deposit Ref"
                            className="w-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl p-2.5 text-xs text-gray-900 dark:text-white font-mono"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-750 flex items-center justify-between text-sm font-bold">
              <span>{t('পরিশোধের মোট পরিমাণ:', 'Grand Total to Pay:')}</span>
              <span className="text-lg font-black text-emerald-600">৳{calculatedGrandTotal}</span>
            </div>

            <button
              onClick={handlePlaceOrder}
              disabled={isSubmitting}
              className="w-full py-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-bold shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 active:scale-95 transition-all disabled:opacity-50"
            >
              {isSubmitting ? (
                <span>{t('অর্ডার প্রক্রিয়াকরণ হচ্ছে...', 'Processing Order...')}</span>
              ) : (
                <>
                  <ShieldCheck className="w-5 h-5 text-amber-300" />
                  <span>{t('অর্ডার নিশ্চিত করুন (Confirm Order)', 'Confirm & Place Order')}</span>
                </>
              )}
            </button>
          </div>
        )}

        {/* STEP 3: Order Confirmation & Invoice */}
        {currentStep === 3 && confirmedOrder && (
          <div className="max-w-2xl mx-auto bg-white dark:bg-gray-800 rounded-3xl p-6 sm:p-10 border border-gray-100 dark:border-gray-700/80 shadow-2xl text-center space-y-6">
            <div className="w-20 h-20 rounded-full bg-emerald-100 dark:bg-emerald-950 flex items-center justify-center text-emerald-600 mx-auto">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div>
              <span className="bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-mono font-bold text-xs px-3 py-1 rounded-full uppercase">
                {confirmedOrder.orderNumber}
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white mt-3 mb-1">
                {t('আপনার অর্ডার সফলভাবে গৃহীত হয়েছে!', 'Order Placed Successfully!')}
              </h2>
              <p className="text-xs sm:text-sm text-gray-500 max-w-md mx-auto">
                {t(
                  `ধন্যবাদ ${confirmedOrder.customerName}! আপনার অর্ডারটি নিবন্ধিত হয়েছে। খুব শীঘ্রই আমাদের কুরিয়ার টিম আপনার সাথে যোগাযোগ করবে।`,
                  `Thank you ${confirmedOrder.customerName}! We have received your order. Delivery is expected by ${confirmedOrder.estimatedDelivery}.`
                )}
              </p>
            </div>

            {/* Receipt Summary Card */}
            <div className="bg-gray-50 dark:bg-gray-750 p-6 rounded-2xl border border-gray-200 dark:border-gray-700 text-left text-xs space-y-3">
              <div className="flex justify-between pb-2 border-b border-gray-200 dark:border-gray-650">
                <span className="text-gray-500">{t('ডেলিভারি ঠিকানা:', 'Delivery Address:')}</span>
                <span className="font-bold text-gray-900 dark:text-white text-right max-w-[250px]">
                  {confirmedOrder.address}, {confirmedOrder.upazila}, {confirmedOrder.district}
                </span>
              </div>
              <div className="flex justify-between pb-2 border-b border-gray-200 dark:border-gray-650">
                <span className="text-gray-500">{t('পেমেন্ট মেথড:', 'Payment Method:')}</span>
                <span className="font-bold text-gray-900 dark:text-white">
                  {confirmedOrder.paymentMethod === 'bank_transfer'
                    ? `${confirmedOrder.bankPaymentDetails?.bankName || 'Bangladeshi Bank Transfer'}`
                    : confirmedOrder.paymentMethod.toUpperCase()}
                </span>
              </div>
              <div className="flex justify-between pb-2 border-b border-gray-200 dark:border-gray-650">
                <span className="text-gray-500">{t('সম্ভাব্য ডেলিভারি তারিখ:', 'Estimated Delivery:')}</span>
                <span className="font-bold text-emerald-600 dark:text-emerald-400">{confirmedOrder.estimatedDelivery}</span>
              </div>
              <div className="flex justify-between text-sm font-black pt-1">
                <span>{t('পরিশোধিত/পরিশোধ্য মোট:', 'Total Amount:')}</span>
                <span className="text-emerald-600">৳{confirmedOrder.total}</span>
              </div>
            </div>

            {/* Bangladeshi Bank Payment Confirmation Card */}
            {confirmedOrder.paymentMethod === 'bank_transfer' && confirmedOrder.bankPaymentDetails && (
              <div className="bg-purple-50/70 dark:bg-purple-950/40 p-5 rounded-2xl border border-purple-200 dark:border-purple-800 text-left text-xs space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-purple-600 text-white flex items-center justify-center font-bold">
                      <Building2 className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-[10px] text-gray-500 font-bold uppercase block">{t('ব্যাংক ডিপোজিট / ট্রান্সফার', 'Bank Payment Verified')}</span>
                      <span className="font-black text-gray-900 dark:text-white text-xs">{confirmedOrder.bankPaymentDetails.bankName}</span>
                    </div>
                  </div>
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-700 text-[10px] font-bold">
                    Paid Online
                  </span>
                </div>

                <div className="pt-2 border-t border-purple-200 dark:border-purple-800/60 grid grid-cols-2 gap-2 text-[11px]">
                  <div>
                    <span className="text-gray-400 block">{t('মার্কেটপ্লেস একাউন্ট:', 'Merchant A/C:')}</span>
                    <span className="font-mono font-bold text-gray-800 dark:text-gray-200">{confirmedOrder.bankPaymentDetails.accountNumber}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-gray-400 block">{t('ট্রানজেকশন আইডি / স্লিপ:', 'Transaction Ref:')}</span>
                    <span className="font-mono font-bold text-purple-700 dark:text-purple-300">{confirmedOrder.bankPaymentDetails.bankTransactionRef}</span>
                  </div>
                </div>
              </div>
            )}

            {/* Bangladeshi Courier Partner Card */}
            <div className="bg-emerald-50/70 dark:bg-emerald-950/40 p-5 rounded-2xl border border-emerald-200 dark:border-emerald-800 text-left text-xs space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold">
                    <Truck className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] text-gray-500 font-bold uppercase block">{t('নির্ধারিত ডেলিভারি কুরিয়ার', 'Assigned BD Courier')}</span>
                    <span className="font-black text-gray-900 dark:text-white text-xs">{confirmedOrder.courierName || selectedCourier.name}</span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-[10px] text-gray-500 font-bold uppercase block">{t('কন্সায়নমেন্ট ট্র্যাকিং আইডি', 'Consignment ID')}</span>
                  <span className="font-mono font-bold text-emerald-700 dark:text-emerald-300 text-xs">
                    {confirmedOrder.courierTrackingCode || 'ST-9482103'}
                  </span>
                </div>
              </div>

              <div className="pt-2 border-t border-emerald-200 dark:border-emerald-800/60 flex items-center justify-between text-[11px] text-gray-600 dark:text-gray-300">
                <span>{t('কুরিয়ার হেল্পলাইন:', 'Courier Hotline:')} <strong>{selectedCourier.hotline}</strong></span>
                <span className="text-emerald-700 dark:text-emerald-400 font-semibold">
                  ⚡ {isDhakaOrder ? selectedCourier.deliveryTimeInsideDhaka : selectedCourier.deliveryTimeOutsideDhaka}
                </span>
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
              <button
                onClick={() => setCurrentView('track-order')}
                className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md flex items-center justify-center gap-2"
              >
                <Truck className="w-4 h-4" />
                <span>{t('অর্ডার ট্র্যাক করুন (Live Tracking)', 'Track This Order')}</span>
              </button>

              <button
                onClick={() => openCashMemoModal(confirmedOrder)}
                className="px-6 py-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2 active:scale-95 transition-all"
              >
                <Receipt className="w-4 h-4 text-emerald-200" />
                <span>{t('ক্যাশ মেমো ও ইনভয়েস (PDF / Image)', 'Cash Memo & Invoice (PDF / Image)')}</span>
              </button>

              <button
                onClick={() => openCashMemoModal(confirmedOrder)}
                className="px-5 py-3 bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-xl text-xs font-bold hover:bg-gray-200 flex items-center justify-center gap-2"
              >
                <Printer className="w-4 h-4" />
                <span>{t('ইনভয়েস প্রিন্ট করুন', 'Print Invoice')}</span>
              </button>

              {confirmedOrder.status !== 'cancelled' && (
                <button
                  onClick={() => setIsCancelModalOpen(true)}
                  className="px-6 py-3 border border-rose-300 dark:border-rose-800 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
                >
                  <XCircle className="w-4 h-4" />
                  <span>{t('অর্ডার বাতিল করুন', 'Cancel Order')}</span>
                </button>
              )}

              <button
                onClick={() => setCurrentView('home')}
                className="px-6 py-3 border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 rounded-xl text-xs font-bold hover:bg-gray-50"
              >
                {t('হোমে ফিরে যান', 'Back to Home')}
              </button>
            </div>
          </div>
        )}

        {/* Cancel Order Modal */}
        <CancelOrderModal
          order={confirmedOrder}
          isOpen={isCancelModalOpen}
          onClose={() => setIsCancelModalOpen(false)}
          onCancelled={() => {
            if (confirmedOrder) {
              setConfirmedOrder({
                ...confirmedOrder,
                status: 'cancelled'
              });
            }
          }}
        />
      </div>
    </div>
  );
};
