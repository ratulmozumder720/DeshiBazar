import React from 'react';
import { useApp } from '../context/AppContext';
import { HeroSection } from '../components/HeroSection';
import { CustomerStoriesBar } from '../components/CustomerStoriesBar';
import { CategorySection } from '../components/CategorySection';
import { FlashSaleSection } from '../components/FlashSaleSection';
import { DailyDealsSection } from '../components/DailyDealsSection';
import { DeshiProductsSection } from '../components/DeshiProductsSection';
import { LocalSellersSection } from '../components/LocalSellersSection';
import { PromotionsAndNewsletter } from '../components/PromotionsAndNewsletter';

export const HomeView: React.FC = () => {
  const { customerUIConfig } = useApp();

  return (
    <div className="space-y-0">
      <HeroSection />
      {customerUIConfig.showCustomerStories && <CustomerStoriesBar />}
      {customerUIConfig.showCategoryPills && <CategorySection />}
      {customerUIConfig.showFlashSale && <FlashSaleSection />}
      {customerUIConfig.showDeshiSpotlight && <DeshiProductsSection />}
      {customerUIConfig.showDailyDeals && <DailyDealsSection />}
      {customerUIConfig.showLocalSellers && <LocalSellersSection />}
      {(customerUIConfig.showAppDownloadBanner || customerUIConfig.showNewsletter) && <PromotionsAndNewsletter />}
    </div>
  );
};
