import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ProductCard } from '../components/ProductCard';
import { 
  Star, 
  ShoppingBag, 
  Zap, 
  Heart, 
  Share2, 
  Truck, 
  ShieldCheck, 
  MapPin, 
  CheckCircle2, 
  Store, 
  Sparkles,
  MessageSquarePlus,
  ArrowRight
} from 'lucide-react';
import { BANGLADESH_DIVISIONS, DISTRICTS_BY_DIVISION } from '../data/mockData';
import { addDoc, collection } from 'firebase/firestore';
import { db } from '../firebase';

export const ProductDetailsView: React.FC = () => {
  const {
    selectedProductId,
    products,
    addToCart,
    setCurrentView,
    isInWishlist,
    toggleWishlist,
    showToast,
    user,
    userProfile,
    setSelectedSellerId,
    t
  } = useApp();

  const product = products.find(p => p.id === selectedProductId) || products[0];

  const [activeImage, setActiveImage] = useState<string>(product.image);
  const [quantity, setQuantity] = useState<number>(1);
  const [activeTab, setActiveTab] = useState<'description' | 'specifications' | 'reviews' | 'faq'>('description');

  // Delivery estimation checker
  const [deliveryDivision, setDeliveryDivision] = useState<string>('Dhaka');
  const [deliveryDistrict, setDeliveryDistrict] = useState<string>('Dhaka');

  // Review submission state
  const [newReviewRating, setNewReviewRating] = useState<number>(5);
  const [newReviewComment, setNewReviewComment] = useState<string>('');
  const [localReviews, setLocalReviews] = useState([
    {
      id: 'rev-1',
      userName: 'Md. Rafiqul Islam',
      userAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80',
      rating: 5,
      comment: 'পণ্যের মান অত্যন্ত সন্তোষজনক। প্যাকেজিং অনেক ভালো ছিল এবং ঠিক সময়ে পেয়েছি।',
      date: '2 days ago',
      verified: true
    },
    {
      id: 'rev-2',
      userName: 'Farhana Sultana',
      userAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=100&q=80',
      rating: 5,
      comment: 'Original authentic deshi quality! Very pleased with the fast customer support.',
      date: '1 week ago',
      verified: true
    }
  ]);

  const isFav = isInWishlist(product.id);
  const relatedProducts = products
    .filter(p => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  const isDhakaDelivery = deliveryDivision.toLowerCase() === 'dhaka';
  const deliveryEstimatedText = isDhakaDelivery 
    ? t('আগামীকালকের মধ্যে ডেলিভারি (২৪ ঘণ্টা)', 'Delivered by tomorrow (24 hours)')
    : t('২-৩ কার্যদিবসের মধ্যে ডেলিভারি', 'Delivered within 2-3 business days');
  const estimatedDeliveryCharge = isDhakaDelivery ? '৳৬০' : '৳১২০';

  const handleAddToCart = () => {
    addToCart(product, quantity);
  };

  const handleBuyNow = () => {
    addToCart(product, quantity);
    setCurrentView('checkout');
  };

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      showToast(t('লিংক কপি করা হয়েছে!', 'Product link copied to clipboard!'), 'success');
    }
  };

  const handleReviewSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReviewComment.trim()) return;

    const newRev = {
      id: 'rev-' + Date.now(),
      userName: userProfile?.displayName || user?.displayName || 'Deshi Buyer',
      userAvatar: userProfile?.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80',
      rating: newReviewRating,
      comment: newReviewComment,
      date: 'Just now',
      verified: true
    };

    setLocalReviews(prev => [newRev, ...prev]);

    try {
      await addDoc(collection(db, 'reviews'), {
        productId: product.id,
        rating: newReviewRating,
        comment: newReviewComment,
        userName: newRev.userName,
        createdAt: new Date().toISOString()
      });
    } catch {
      // Local fallback
    }

    setNewReviewComment('');
    showToast(t('আপনার মূল্যবান রিভিউ সফলভাবে জমা হয়েছে!', 'Your review has been submitted!'), 'success');
  };

  const allImages = [product.image, ...(product.gallery || [])];

  return (
    <div className="py-8 bg-gray-50 dark:bg-gray-900 min-h-screen transition-colors">
      <div className="max-w-7xl mx-auto px-4">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-gray-500 mb-6 flex-wrap">
          <button onClick={() => setCurrentView('home')} className="hover:text-emerald-600">
            {t('হোম', 'Home')}
          </button>
          <span>/</span>
          <button onClick={() => setCurrentView('shop')} className="hover:text-emerald-600">
            {t(product.categoryBn, product.category)}
          </button>
          <span>/</span>
          <span className="text-gray-900 dark:text-white font-bold truncate max-w-xs">
            {t(product.nameBn, product.name)}
          </span>
        </div>

        {/* Main Product Layout */}
        <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 sm:p-8 border border-gray-100 dark:border-gray-700/80 shadow-sm grid grid-cols-1 lg:grid-cols-12 gap-8 mb-12">
          {/* Left: Gallery & Zoom Preview */}
          <div className="lg:col-span-5 space-y-4">
            <div className="aspect-square rounded-3xl overflow-hidden bg-gray-50 dark:bg-gray-700/40 border border-gray-100 dark:border-gray-700 relative shadow-inner">
              <img
                src={activeImage || product.image}
                alt={product.name}
                className="w-full h-full object-cover transition-all duration-300"
              />

              {product.discountPercent > 0 && (
                <span className="absolute top-4 left-4 bg-rose-500 text-white text-xs font-black px-2.5 py-1 rounded-lg shadow-sm">
                  {product.discountPercent}% {t('ছাড়', 'OFF')}
                </span>
              )}

              {product.isDeshi && (
                <span className="absolute top-4 right-4 bg-emerald-600 text-white text-xs font-bold px-2.5 py-1 rounded-lg shadow-sm flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-amber-300" />
                  <span>{t('দেশি পণ্য', 'Deshi')}</span>
                </span>
              )}
            </div>

            {/* Thumbnail Row */}
            <div className="flex gap-3 overflow-x-auto pb-1">
              {allImages.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveImage(img)}
                  className={`w-16 h-16 rounded-2xl overflow-hidden border-2 shrink-0 transition-all ${
                    (activeImage || product.image) === img 
                      ? 'border-emerald-600 scale-105 shadow-md' 
                      : 'border-transparent opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt="Thumb" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </div>

          {/* Center/Right: Details & Actions */}
          <div className="lg:col-span-7 flex flex-col justify-between space-y-6">
            <div>
              {/* Vendor & Location Tag */}
              <div className="flex items-center justify-between gap-2 mb-2">
                <button
                  onClick={() => {
                    setSelectedSellerId(product.vendorId);
                    setCurrentView('shop');
                  }}
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-3 py-1 rounded-full border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 transition-colors"
                >
                  <Store className="w-3.5 h-3.5" />
                  <span>{product.vendorName}</span>
                </button>

                <div className="flex items-center gap-1 text-xs text-gray-500">
                  <MapPin className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{product.vendorLocation}</span>
                </div>
              </div>

              {/* Title */}
              <h1 className="text-xl sm:text-2xl lg:text-3xl font-black text-gray-900 dark:text-white leading-tight mb-3">
                {t(product.nameBn, product.name)}
              </h1>

              {/* Rating & Stock */}
              <div className="flex items-center gap-4 flex-wrap pb-4 border-b border-gray-100 dark:border-gray-700 text-xs">
                <div className="flex items-center gap-1.5 bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 px-2.5 py-1 rounded-lg font-bold">
                  <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                  <span>{product.rating}</span>
                  <span className="text-gray-400">({product.reviewCount} {t('রিভিউ', 'reviews')})</span>
                </div>

                <div className="flex items-center gap-1 text-emerald-600 font-semibold">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{product.stock > 0 ? t('স্টকে রয়েছে', 'In Stock') : t('স্টক শেষ', 'Out of Stock')}</span>
                </div>

                <span className="text-gray-400">|</span>
                <span className="text-gray-500 font-medium">{t(product.unitBn, product.unit)}</span>
              </div>

              {/* Price Display */}
              <div className="py-4 flex items-baseline gap-3">
                <span className="text-3xl sm:text-4xl font-black text-emerald-700 dark:text-emerald-400">
                  ৳{product.price}
                </span>
                {product.originalPrice > product.price && (
                  <span className="text-base text-gray-400 line-through">
                    ৳{product.originalPrice}
                  </span>
                )}
                {product.discountPercent > 0 && (
                  <span className="bg-rose-100 dark:bg-rose-950 text-rose-600 dark:text-rose-400 text-xs font-bold px-2 py-1 rounded-md">
                    {t(`আপনি বাচাঁচ্ছেন ৳${product.originalPrice - product.price}`, `Save ৳${product.originalPrice - product.price}`)}
                  </span>
                )}
              </div>

              {/* Quantity Stepper & Add to Cart / Buy Now buttons */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center gap-4">
                  <span className="text-xs font-bold text-gray-700 dark:text-gray-300">
                    {t('পরিমাণ (Quantity):', 'Quantity:')}
                  </span>
                  <div className="flex items-center border border-gray-200 dark:border-gray-700 rounded-xl overflow-hidden bg-gray-50 dark:bg-gray-800">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="px-3.5 py-2 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 font-bold"
                    >
                      -
                    </button>
                    <span className="px-4 py-1 text-sm font-bold text-gray-900 dark:text-white">
                      {quantity}
                    </span>
                    <button
                      onClick={() => setQuantity(quantity + 1)}
                      className="px-3.5 py-2 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 font-bold"
                    >
                      +
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <button
                    onClick={handleAddToCart}
                    className="py-3.5 px-6 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-600 hover:text-white font-bold rounded-2xl text-xs sm:text-sm flex items-center justify-center gap-2 border border-emerald-200 dark:border-emerald-800 shadow-sm transition-all"
                  >
                    <ShoppingBag className="w-4 h-4" />
                    <span>{t('ব্যাগে যোগ করুন', 'Add to Cart')}</span>
                  </button>

                  <button
                    onClick={handleBuyNow}
                    className="py-3.5 px-6 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-2xl text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/30 transition-all active:scale-95"
                  >
                    <Zap className="w-4 h-4 text-amber-300" />
                    <span>{t('সরাসরি এখনই কিনুন', 'Buy Now')}</span>
                  </button>
                </div>

                {/* Wishlist & Share actions */}
                <div className="flex items-center gap-4 pt-3">
                  <button
                    onClick={() => toggleWishlist(product.id)}
                    className="flex items-center gap-1.5 text-xs font-semibold text-gray-600 dark:text-gray-300 hover:text-rose-500"
                  >
                    <Heart className={`w-4 h-4 ${isFav ? 'fill-rose-500 text-rose-500' : ''}`} />
                    <span>{isFav ? t('উইশলিস্টে যুক্ত আছে', 'In Wishlist') : t('উইশলিস্টে যোগ করুন', 'Add to Wishlist')}</span>
                  </button>

                  <button
                    onClick={handleShare}
                    className="flex items-center gap-1.5 text-xs font-semibold text-gray-600 dark:text-gray-300 hover:text-emerald-600"
                  >
                    <Share2 className="w-4 h-4" />
                    <span>{t('শেয়ার করুন', 'Share Product')}</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Delivery Estimation Checker Widget */}
            <div className="bg-gray-50 dark:bg-gray-750 p-4 sm:p-5 rounded-2xl border border-gray-200 dark:border-gray-700 space-y-3">
              <div className="flex items-center gap-2 text-xs font-bold text-gray-900 dark:text-white">
                <Truck className="w-4 h-4 text-emerald-600" />
                <span>{t('ডেলিভারি এলাকা ও সম্ভাব্য সময় যাচাই করুন', 'Check Delivery to Your Area')}</span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] text-gray-400 block mb-1">{t('বিভাগ', 'Division')}</label>
                  <select
                    value={deliveryDivision}
                    onChange={(e) => {
                      setDeliveryDivision(e.target.value);
                      const districts = DISTRICTS_BY_DIVISION[e.target.value] || ['Dhaka'];
                      setDeliveryDistrict(districts[0]);
                    }}
                    className="w-full bg-white dark:bg-gray-700 text-xs p-2 rounded-xl border border-gray-200 dark:border-gray-600"
                  >
                    {BANGLADESH_DIVISIONS.map(div => (
                      <option key={div} value={div}>{div}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[10px] text-gray-400 block mb-1">{t('জেলা', 'District')}</label>
                  <select
                    value={deliveryDistrict}
                    onChange={(e) => setDeliveryDistrict(e.target.value)}
                    className="w-full bg-white dark:bg-gray-700 text-xs p-2 rounded-xl border border-gray-200 dark:border-gray-600"
                  >
                    {(DISTRICTS_BY_DIVISION[deliveryDivision] || [deliveryDivision]).map(dis => (
                      <option key={dis} value={dis}>{dis}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="pt-2 border-t border-gray-200 dark:border-gray-650 flex items-center justify-between text-xs">
                <div>
                  <span className="font-bold text-gray-800 dark:text-gray-200 block">
                    {deliveryEstimatedText}
                  </span>
                  <span className="text-[11px] text-gray-500">
                    {t('ডেলিভারি চার্জ:', 'Delivery fee:')} {estimatedDeliveryCharge} (৳১৫০০+ অর্ডারে সম্পূর্ণ ফ্রি)
                  </span>
                </div>
                <span className="bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold px-2 py-1 rounded text-[10px]">
                  COD Available
                </span>
              </div>
            </div>

            {/* Payment Method Badges */}
            <div className="flex items-center gap-2 text-xs text-gray-500 flex-wrap">
              <span className="text-gray-400">{t('পেমেন্ট সুবিধা:', 'Payment Options:')}</span>
              <span className="bg-gray-100 dark:bg-gray-700 px-2 py-0.5 rounded text-[11px] font-bold">bKash</span>
              <span className="bg-gray-100 dark:bg-gray-700 px-2 py-0.5 rounded text-[11px] font-bold">Nagad</span>
              <span className="bg-gray-100 dark:bg-gray-700 px-2 py-0.5 rounded text-[11px] font-bold">Rocket</span>
              <span className="bg-gray-100 dark:bg-gray-700 px-2 py-0.5 rounded text-[11px] font-bold">Cash on Delivery</span>
            </div>
          </div>
        </div>

        {/* Tabs: Description, Specifications, Reviews, Q&A */}
        <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 sm:p-8 border border-gray-100 dark:border-gray-700/80 shadow-sm mb-12">
          <div className="flex border-b border-gray-200 dark:border-gray-700 overflow-x-auto gap-4 sm:gap-8 mb-6">
            <button
              onClick={() => setActiveTab('description')}
              className={`pb-3 text-xs sm:text-sm font-bold border-b-2 transition-colors whitespace-nowrap ${
                activeTab === 'description'
                  ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              {t('পণ্যের বিস্তারিত বিবরণ', 'Product Description')}
            </button>

            <button
              onClick={() => setActiveTab('specifications')}
              className={`pb-3 text-xs sm:text-sm font-bold border-b-2 transition-colors whitespace-nowrap ${
                activeTab === 'specifications'
                  ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              {t('স্পেসিফিকেশন ও তথ্য', 'Specifications')}
            </button>

            <button
              onClick={() => setActiveTab('reviews')}
              className={`pb-3 text-xs sm:text-sm font-bold border-b-2 transition-colors whitespace-nowrap ${
                activeTab === 'reviews'
                  ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              {t(`গ্রাহকদের রিভিউ (${localReviews.length})`, `Reviews (${localReviews.length})`)}
            </button>

            <button
              onClick={() => setActiveTab('faq')}
              className={`pb-3 text-xs sm:text-sm font-bold border-b-2 transition-colors whitespace-nowrap ${
                activeTab === 'faq'
                  ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              {t('সাধারণ প্রশ্নোত্তর (Q&A)', 'Questions & Answers')}
            </button>
          </div>

          {/* Tab 1: Description */}
          {activeTab === 'description' && (
            <div className="prose dark:prose-invert max-w-none text-xs sm:text-sm text-gray-600 dark:text-gray-300 leading-relaxed space-y-4">
              <p>{t(product.descriptionBn, product.description)}</p>
              <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-100 dark:border-emerald-800 flex items-start gap-3">
                <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div className="text-xs text-emerald-900 dark:text-emerald-200">
                  <span className="font-bold block mb-0.5">{t('দেশিবাজার কোয়ালিটি নিশ্চয়তা', 'DeshiBazar Quality Assurance')}</span>
                  {t(
                    'আমাদের প্রতিটি ভেন্ডর ও কৃষক সরাসরি যাচাইকৃত। পণ্য হাতে পাওয়ার পর চেক করে মূল্য পরিশোধ করার সুবিধা রয়েছে।',
                    'All products are verified for safety and authentic source origin. 100% inspection guarantee on delivery.'
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Tab 2: Specifications */}
          {activeTab === 'specifications' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              {Object.entries(product.specifications || {}).map(([key, value]) => (
                <div key={key} className="flex justify-between p-3 rounded-xl bg-gray-50 dark:bg-gray-700/60 border border-gray-100 dark:border-gray-700">
                  <span className="font-semibold text-gray-500 dark:text-gray-400">{key}:</span>
                  <span className="font-bold text-gray-900 dark:text-white">{value}</span>
                </div>
              ))}
              {product.origin && (
                <div className="flex justify-between p-3 rounded-xl bg-gray-50 dark:bg-gray-700/60 border border-gray-100 dark:border-gray-700">
                  <span className="font-semibold text-gray-500 dark:text-gray-400">{t('উৎস স্থান (Origin):', 'Source Region:')}</span>
                  <span className="font-bold text-emerald-600 dark:text-emerald-400">{product.origin}</span>
                </div>
              )}
            </div>
          )}

          {/* Tab 3: Reviews */}
          {activeTab === 'reviews' && (
            <div className="space-y-6">
              {/* Write Review Form */}
              <div className="bg-gray-50 dark:bg-gray-750 p-5 rounded-2xl border border-gray-200 dark:border-gray-700">
                <h4 className="text-xs sm:text-sm font-bold text-gray-900 dark:text-white mb-2 flex items-center gap-1.5">
                  <MessageSquarePlus className="w-4 h-4 text-emerald-600" />
                  <span>{t('আপনার রিভিউ ও রেটিং দিন', 'Write a Customer Review')}</span>
                </h4>
                <form onSubmit={handleReviewSubmit} className="space-y-3">
                  <div>
                    <label className="text-[11px] text-gray-500 block mb-1">{t('রেটিং নির্বাচন করুন', 'Select Rating')}</label>
                    <div className="flex gap-1">
                      {[1, 2, 3, 4, 5].map((num) => (
                        <button
                          key={num}
                          type="button"
                          onClick={() => setNewReviewRating(num)}
                          className="p-1 hover:scale-110 transition-transform"
                        >
                          <Star className={`w-5 h-5 ${num <= newReviewRating ? 'fill-amber-400 text-amber-400' : 'text-gray-300'}`} />
                        </button>
                      ))}
                    </div>
                  </div>
                  <textarea
                    required
                    value={newReviewComment}
                    onChange={(e) => setNewReviewComment(e.target.value)}
                    placeholder={t('পণ্যটি কেমন ছিল? অভিজ্ঞতা শেয়ার করুন...', 'How was your experience with this item?')}
                    className="w-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded-xl p-3 text-xs focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                    rows={3}
                  />
                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-sm"
                  >
                    {t('রিভিউ জমা দিন', 'Submit Review')}
                  </button>
                </form>
              </div>

              {/* Reviews List */}
              <div className="space-y-4">
                {localReviews.map((rev) => (
                  <div key={rev.id} className="p-4 rounded-2xl border border-gray-100 dark:border-gray-700 bg-white dark:bg-gray-800">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2.5">
                        <img src={rev.userAvatar} alt={rev.userName} className="w-8 h-8 rounded-full object-cover" />
                        <div>
                          <span className="text-xs font-bold text-gray-900 dark:text-white block">{rev.userName}</span>
                          <span className="text-[10px] text-emerald-600 font-semibold">{t('ভেরিফাইড ক্রেতা', 'Verified Buyer')}</span>
                        </div>
                      </div>
                      <div className="flex items-center text-amber-400">
                        {[...Array(rev.rating)].map((_, i) => (
                          <Star key={i} className="w-3.5 h-3.5 fill-amber-400" />
                        ))}
                      </div>
                    </div>
                    <p className="text-xs text-gray-600 dark:text-gray-300 leading-relaxed">{rev.comment}</p>
                    <span className="text-[10px] text-gray-400 mt-2 block">{rev.date}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tab 4: FAQ */}
          {activeTab === 'faq' && (
            <div className="space-y-3 text-xs">
              <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-750">
                <h5 className="font-bold text-gray-900 dark:text-white mb-1">
                  {t('প্রশ্ন: পণ্যটি আসল ও খাঁটি হওয়ার নিশ্চয়তা কী?', 'Q: How do you guarantee freshness and authenticity?')}
                </h5>
                <p className="text-gray-600 dark:text-gray-300">
                  {t('উত্তর: দেশিবাজার সরাসরি অনুমোদিত খামারি ও ঐতিহ্যবাহী কারিগরদের থেকে পণ্য সংগ্রহ করে। কোনো মধ্যস্বত্বভোগী নেই।', 'A: We source directly from registered regional producers and artisan guilds with direct batch quality inspections.')}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-750">
                <h5 className="font-bold text-gray-900 dark:text-white mb-1">
                  {t('প্রশ্ন: পণ্য পছন্দ না হলে কি ফেরত দেওয়া যাবে?', 'Q: What is the return policy?')}
                </h5>
                <p className="text-gray-600 dark:text-gray-300">
                  {t('উত্তর: অবশ্যই! ডেলিভারির সময় পণ্য দেখে পছন্দ না হলে ডেলিভারিম্যানের সামনেই রিটার্ন করতে পারবেন কোনো চার্জ ছাড়াই।', 'A: Absolutely. Check your order at your doorstep. If unsatisfied, return it on the spot with zero charge.')}
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Related Products Section */}
        {relatedProducts.length > 0 && (
          <div className="mb-12">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl sm:text-2xl font-black text-gray-900 dark:text-white">
                {t('সম্পর্কিত অন্যান্য পণ্য', 'Related Products')}
              </h3>
              <button
                onClick={() => setCurrentView('shop')}
                className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1 hover:underline"
              >
                <span>{t('সব দেখুন', 'View All')}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-6">
              {relatedProducts.map(p => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
