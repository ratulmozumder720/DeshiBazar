import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Package, 
  ShoppingBag, 
  Plus, 
  ShieldCheck, 
  BarChart3,
  Settings,
  Star,
  Receipt
} from 'lucide-react';
import { Product } from '../types';
import { addDoc, collection } from 'firebase/firestore';
import { db } from '../firebase';

export const SellerDashboardView: React.FC = () => {
  const { t, products, addProduct, sellers, orders, updateOrderStatus, showToast, categories, openAddCategoryModal, openCashMemoModal } = useApp();

  const [activeTab, setActiveTab] = useState<'analytics' | 'products' | 'orders' | 'settings'>('analytics');
  const [isAddProductOpen, setIsAddProductOpen] = useState(false);

  // New Product Form State
  const [newProdName, setNewProdName] = useState('');
  const [newProdNameBn, setNewProdNameBn] = useState('');
  const [newProdCategory, setNewProdCategory] = useState('rice-dal-grocery');
  const [newProdPrice, setNewProdPrice] = useState<number>(350);
  const [newProdOriginalPrice, setNewProdOriginalPrice] = useState<number>(400);
  const [newProdStock, setNewProdStock] = useState<number>(50);
  const [newProdUnit] = useState('1 kg pack');
  const [newProdUnitBn, setNewProdUnitBn] = useState('১ কেজি প্যাক');
  const [newProdImage, setNewProdImage] = useState('https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80');
  const [newProdIsDeshi, setNewProdIsDeshi] = useState(true);
  const [newProdIsOrganic, setNewProdIsOrganic] = useState(false);

  // My store info (defaults to Kawran Agro Fresh demo)
  const currentSeller = sellers[0];
  const sellerProducts = products.filter(p => p.vendorId === currentSeller.id);
  const totalSellerSales = orders.reduce((sum, o) => sum + o.total, 142500);

  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProdName || !newProdNameBn) return;

    const discountPercent = Math.max(0, Math.round(((newProdOriginalPrice - newProdPrice) / newProdOriginalPrice) * 100));

    const newProduct: Product = {
      id: 'prod-' + Date.now(),
      name: newProdName,
      nameBn: newProdNameBn,
      category: newProdCategory,
      categoryBn: categories.find(c => c.id === newProdCategory)?.nameBn || 'পণ্য',
      brand: currentSeller.name,
      vendorId: currentSeller.id,
      vendorName: currentSeller.name,
      vendorLocation: currentSeller.location,
      price: Number(newProdPrice),
      originalPrice: Number(newProdOriginalPrice),
      discountPercent,
      unit: newProdUnit,
      unitBn: newProdUnitBn,
      rating: 5.0,
      reviewCount: 1,
      stock: Number(newProdStock),
      isDeshi: newProdIsDeshi,
      isOrganic: newProdIsOrganic,
      image: newProdImage,
      gallery: [newProdImage],
      description: 'Fresh quality product directly listed by verified store.',
      descriptionBn: 'ভেরিফাইড বিক্রেতার নিজস্ব স্টোর থেকে সরাসরি যুক্ত করা তাজা পণ্য।',
      specifications: {
        'Origin': currentSeller.location,
        'Packaging': 'Eco-Friendly Pack'
      }
    };

    // Save to Firestore
    try {
      await addDoc(collection(db, 'products'), newProduct);
    } catch {
      // Local fallback
    }

    // Save through centralized deduplicated state
    addProduct(newProduct);
    setIsAddProductOpen(false);
    setNewProdName('');
    setNewProdNameBn('');
  };

  return (
    <div className="py-10 bg-gray-50 dark:bg-gray-900 min-h-screen transition-colors">
      <div className="max-w-7xl mx-auto px-4">
        {/* Seller Banner Header */}
        <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 sm:p-8 border border-gray-100 dark:border-gray-700/80 shadow-xs mb-8 flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4 text-center sm:text-left">
            <img
              src={currentSeller.logo}
              alt={currentSeller.name}
              className="w-16 h-16 rounded-2xl object-cover border-2 border-emerald-500 shadow-md shrink-0"
            />
            <div>
              <div className="flex items-center gap-2 justify-center sm:justify-start">
                <h1 className="text-xl sm:text-2xl font-black text-gray-900 dark:text-white">
                  {t(currentSeller.nameBn, currentSeller.name)}
                </h1>
                <span className="bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-emerald-600" />
                  {t('অনুমোদিত মার্চেন্ট', 'Verified Seller')}
                </span>
              </div>
              <p className="text-xs text-gray-500 mt-0.5">{currentSeller.location} • {currentSeller.badge}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('settings')}
              className="px-4 py-3 bg-gray-100 hover:bg-gray-200 dark:bg-gray-750 dark:hover:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-xl text-xs font-bold transition-all flex items-center gap-2 active:scale-95 shadow-xs"
            >
              <Settings className="w-4 h-4 text-emerald-600" />
              <span>{t('শপ ও প্রোফাইল সেটিংস', 'Store Settings')}</span>
            </button>

            <button
              onClick={() => setIsAddProductOpen(true)}
              className="px-5 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-600/20 flex items-center gap-2 transition-all active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span>{t('নতুন পণ্য যোগ করুন', 'Add New Product')}</span>
            </button>
          </div>
        </div>

        {/* 4 Metric Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-white dark:bg-gray-800 p-5 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-xs">
            <span className="text-[11px] font-bold text-gray-400 block mb-1 uppercase">
              {t('মোট বিক্রি (Sales)', 'Total Sales')}
            </span>
            <div className="text-xl sm:text-2xl font-black text-emerald-600">
              ৳{totalSellerSales.toLocaleString()}
            </div>
            <span className="text-[10px] text-emerald-500 font-bold mt-1 block">
              ↑ 18.4% {t('এই মাসে বৃদ্ধি', 'from last month')}
            </span>
          </div>

          <div className="bg-white dark:bg-gray-800 p-5 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-xs">
            <span className="text-[11px] font-bold text-gray-400 block mb-1 uppercase">
              {t('মোট অর্ডার (Orders)', 'Total Orders')}
            </span>
            <div className="text-xl sm:text-2xl font-black text-gray-900 dark:text-white">
              {orders.length + 384}
            </div>
            <span className="text-[10px] text-blue-500 font-bold mt-1 block">
              98.2% {t('অন-টাইম ডেলিভারি', 'on-time fulfillment')}
            </span>
          </div>

          <div className="bg-white dark:bg-gray-800 p-5 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-xs">
            <span className="text-[11px] font-bold text-gray-400 block mb-1 uppercase">
              {t('দোকানের পণ্য সংখ্যা', 'Active Products')}
            </span>
            <div className="text-xl sm:text-2xl font-black text-gray-900 dark:text-white">
              {sellerProducts.length}
            </div>
            <span className="text-[10px] text-emerald-600 font-bold mt-1 block">
              {t('সবগুলো লাইভ রয়েছে', 'All Active')}
            </span>
          </div>

          <div className="bg-white dark:bg-gray-800 p-5 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-xs">
            <span className="text-[11px] font-bold text-gray-400 block mb-1 uppercase">
              {t('গ্রাহক রেটিং', 'Customer Rating')}
            </span>
            <div className="text-xl sm:text-2xl font-black text-amber-500 flex items-center gap-1">
              <span>{currentSeller.rating}</span>
              <Star className="w-5 h-5 fill-amber-400" />
            </div>
            <span className="text-[10px] text-gray-400 mt-1 block">
              {currentSeller.reviewsCount} {t('সন্তুষ্ট গ্রাহক', 'reviews')}
            </span>
          </div>
        </div>

        {/* Tab Switcher with Settings Icon */}
        <div className="flex gap-2 border-b border-gray-200 dark:border-gray-700 mb-6 overflow-x-auto">
          {[
            { id: 'analytics', label: t('অ্যানালিটিক্স ও সেলস গ্রাফ', 'Sales Analytics'), icon: BarChart3 },
            { id: 'products', label: t('পণ্য তালিকা ও ইনভেন্টরি', 'Manage Products & Stock'), icon: Package, badge: sellerProducts.length },
            { id: 'orders', label: t('প্রাপ্ত অর্ডারসমূহ', 'Incoming Orders'), icon: ShoppingBag, badge: orders.length },
            { id: 'settings', label: t('দোকান ও মার্চেন্ট প্রোফাইল সেটিংস', 'Store & Profile Settings'), icon: Settings, badge: 'Config' }
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`pb-3 px-3 text-xs sm:text-sm font-bold border-b-2 transition-all flex items-center gap-2 whitespace-nowrap ${
                  isActive
                    ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400'
                    : 'border-transparent text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-600 dark:text-emerald-400' : 'text-gray-400'}`} />
                <span>{tab.label}</span>
                {tab.badge && (
                  <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                    isActive ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400'
                  }`}>
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* TAB 1: Analytics */}
        {activeTab === 'analytics' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 bg-white dark:bg-gray-800 p-6 rounded-3xl border border-gray-100 dark:border-gray-700 space-y-4">
              <h3 className="text-sm font-bold text-gray-900 dark:text-white flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-emerald-600" />
                <span>{t('সাপ্তাহিক রাজস্ব চার্ট (Weekly Revenue Breakdown)', 'Weekly Sales Volume')}</span>
              </h3>
              {/* Visual simulated bar chart */}
              <div className="h-48 flex items-end justify-between gap-3 pt-6 px-4">
                {[
                  { day: 'শনিবার', val: 65, amount: '৳১৮,৫০০' },
                  { day: 'রবিবার', val: 80, amount: '৳২২,৪০০' },
                  { day: 'সোমবার', val: 55, amount: '৳১৪,২০০' },
                  { day: 'মঙ্গলবার', val: 90, amount: '৳২৮,০০০' },
                  { day: 'বুধবার', val: 75, amount: '৳২১,৬০০' },
                  { day: 'বৃহস্পতিবার', val: 95, amount: '৳৩২,৫০০' },
                  { day: 'শুক্রবার', val: 100, amount: '৳৩৫,৮০০' }
                ].map((bar, i) => (
                  <div key={i} className="flex-1 flex flex-col items-center gap-1.5 h-full justify-end group">
                    <span className="text-[10px] font-bold text-emerald-600 opacity-0 group-hover:opacity-100 transition-opacity">
                      {bar.amount}
                    </span>
                    <div
                      style={{ height: `${bar.val}%` }}
                      className="w-full bg-emerald-500 group-hover:bg-emerald-600 rounded-t-xl transition-all shadow-sm"
                    />
                    <span className="text-[10px] text-gray-400 mt-1 truncate">{bar.day}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Fast selling deshi products */}
            <div className="bg-white dark:bg-gray-800 p-6 rounded-3xl border border-gray-100 dark:border-gray-700 space-y-4">
              <h3 className="text-sm font-bold text-gray-900 dark:text-white">
                {t('শীর্ষ বিক্রিত আইটেম', 'Top Performing Products')}
              </h3>
              <div className="space-y-3">
                {sellerProducts.slice(0, 4).map((p) => (
                  <div key={p.id} className="flex items-center justify-between text-xs pb-2 border-b border-gray-100 dark:border-gray-700 last:border-0">
                    <div className="flex items-center gap-2 min-w-0">
                      <img src={p.image} alt={p.name} className="w-10 h-10 rounded-lg object-cover" />
                      <div className="truncate">
                        <span className="font-bold text-gray-900 dark:text-white truncate block">{t(p.nameBn, p.name)}</span>
                        <span className="text-[10px] text-gray-400">{p.unit}</span>
                      </div>
                    </div>
                    <span className="font-bold text-emerald-600 shrink-0">৳{p.price}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: Products & Inventory */}
        {activeTab === 'products' && (
          <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 border border-gray-100 dark:border-gray-700">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-gray-200 dark:border-gray-700 text-gray-400 uppercase text-[10px]">
                    <th className="pb-3">{t('পণ্য', 'Product')}</th>
                    <th className="pb-3">{t('ক্যাটাগরি', 'Category')}</th>
                    <th className="pb-3">{t('মূল্য', 'Price')}</th>
                    <th className="pb-3">{t('স্টক সংখ্যা', 'Stock')}</th>
                    <th className="pb-3">{t('স্ট্যাটাস', 'Status')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
                  {sellerProducts.map((p) => (
                    <tr key={p.id} className="hover:bg-gray-50 dark:hover:bg-gray-750">
                      <td className="py-3 flex items-center gap-3">
                        <img src={p.image} alt={p.name} className="w-10 h-10 rounded-xl object-cover" />
                        <div>
                          <span className="font-bold text-gray-900 dark:text-white block">{t(p.nameBn, p.name)}</span>
                          <span className="text-[10px] text-gray-400">{p.unit}</span>
                        </div>
                      </td>
                      <td className="py-3 text-gray-600 dark:text-gray-300">{p.category}</td>
                      <td className="py-3 font-bold text-emerald-600">৳{p.price}</td>
                      <td className="py-3 font-semibold">{p.stock} pcs</td>
                      <td className="py-3">
                        <span className="bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold px-2 py-0.5 rounded text-[10px]">
                          Active
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 3: Orders received */}
        {activeTab === 'orders' && (
          <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 border border-gray-100 dark:border-gray-700 space-y-4">
            <h3 className="text-sm font-bold text-gray-900 dark:text-white mb-2">
              {t('গ্রাহকদের অর্ডার নিয়ন্ত্রণ ও স্ট্যাটাস পরিবর্তন', 'Fulfill & Dispatch Orders')}
            </h3>

            {orders.length === 0 ? (
              <p className="text-xs text-gray-500 py-6 text-center">{t('কোনো নতুন অর্ডার নেই।', 'No pending orders.')}</p>
            ) : (
              <div className="space-y-4">
                {orders.map((ord) => (
                  <div key={ord.id} className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-750 border border-gray-200 dark:border-gray-700 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-emerald-600">{ord.orderNumber}</span>
                        {ord.status === 'cancelled' && (
                          <span className="bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-400 text-[10px] font-bold px-2 py-0.5 rounded">
                            Cancelled
                          </span>
                        )}
                      </div>
                      <span className="font-bold text-gray-900 dark:text-white block mt-0.5">{ord.customerName} ({ord.customerPhone})</span>
                      <p className="text-gray-400 text-[11px]">{ord.address}, {ord.district}</p>
                      {ord.cancellationReason && (
                        <p className="text-rose-500 font-semibold text-[11px] mt-1">
                          {t('বাতিল কারণ:', 'Reason:')} {ord.cancellationReason}
                        </p>
                      )}
                    </div>

                    <div className="flex items-center gap-2.5">
                      <button
                        type="button"
                        onClick={() => openCashMemoModal(ord)}
                        className="px-2.5 py-1.5 bg-purple-50 hover:bg-purple-100 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800 rounded-xl text-xs font-bold flex items-center gap-1 transition-all active:scale-95"
                        title={t('ক্যাশ মেমো ও চালান স্লিপ ডাউনলোড (PDF/Image)', 'Download Cash Memo & Packaging Slip (PDF/Image)')}
                      >
                        <Receipt className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" />
                        <span>{t('মেমো / PDF', 'Memo / PDF')}</span>
                      </button>

                      <select
                        value={ord.status}
                        onChange={(e) => updateOrderStatus(ord.id, e.target.value as any)}
                        className={`border rounded-xl px-3 py-1.5 font-bold text-xs ${
                          ord.status === 'cancelled'
                            ? 'bg-rose-50 border-rose-300 text-rose-700 dark:bg-rose-950/40 dark:border-rose-800 dark:text-rose-300'
                            : 'bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600'
                        }`}
                      >
                        <option value="placed">Placed</option>
                        <option value="confirmed">Confirmed</option>
                        <option value="processing">Processing</option>
                        <option value="packed">Packed</option>
                        <option value="shipped">Shipped</option>
                        <option value="out_for_delivery">Out for Delivery</option>
                        <option value="delivered">Delivered</option>
                        <option value="cancelled">Cancelled</option>
                      </select>

                      <span className="font-black text-sm text-emerald-600">৳{ord.total}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 4: STORE & PROFILE SETTINGS */}
        {activeTab === 'settings' && (
          <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 sm:p-8 border border-gray-100 dark:border-gray-700 shadow-xs space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-gray-100 dark:border-gray-700">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-600 flex items-center justify-center font-bold">
                  <Settings className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-gray-900 dark:text-white">
                    {t('দোকান ও মার্চেন্ট প্রোফাইল সেটিংস', 'Store Profile & Business Settings')}
                  </h3>
                  <p className="text-xs text-gray-400">
                    {t('আপনার শপের ঠিকানা, ট্রেড লাইসেন্স, পেমেন্ট ও ডেলিভারি সেটিংস পরিচালনা করুন', 'Manage store information, contact details, payouts and delivery coverage')}
                  </p>
                </div>
              </div>
              <span className="px-3 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 text-xs font-bold">
                {t('ভেরিফাইড মার্চেন্ট', 'Verified Store')}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-750 border border-gray-200 dark:border-gray-700 space-y-2">
                <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider block">
                  {t('দোকানের নাম (Store Name)', 'Store Name')}
                </span>
                <input
                  type="text"
                  defaultValue={currentSeller.name}
                  className="w-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded-xl p-2.5 font-bold text-gray-900 dark:text-white"
                />
              </div>

              <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-750 border border-gray-200 dark:border-gray-700 space-y-2">
                <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider block">
                  {t('দোকানের বাংলা নাম (Bengali Name)', 'Store Bangla Name')}
                </span>
                <input
                  type="text"
                  defaultValue={currentSeller.nameBn}
                  className="w-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded-xl p-2.5 font-bold text-gray-900 dark:text-white"
                />
              </div>

              <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-750 border border-gray-200 dark:border-gray-700 space-y-2">
                <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider block">
                  {t('অবস্থান ও এলাকা (Origin / Location)', 'Store Location')}
                </span>
                <input
                  type="text"
                  defaultValue={currentSeller.location}
                  className="w-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded-xl p-2.5 font-bold text-gray-900 dark:text-white"
                />
              </div>

              <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-750 border border-gray-200 dark:border-gray-700 space-y-2">
                <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider block">
                  {t('ট্রেড লাইসেন্স নম্বর (Trade License)', 'Trade License')}
                </span>
                <input
                  type="text"
                  defaultValue="TR-DHK-2024-8841"
                  className="w-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded-xl p-2.5 font-mono text-gray-900 dark:text-white"
                />
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={() => showToast(t('শপ সেটিংস সফলভাবে আপডেট হয়েছে!', 'Store settings updated successfully!'), 'success')}
                className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-600/20 flex items-center gap-1.5 transition-all"
              >
                <Settings className="w-4 h-4" />
                <span>{t('সেটিংস পরিবর্তন সংরক্ষণ করুন', 'Save Settings Changes')}</span>
              </button>
            </div>
          </div>
        )}

        {/* Add Product Modal */}
        {isAddProductOpen && (
          <div className="fixed inset-0 z-50 overflow-y-auto p-4 flex items-center justify-center">
            <div onClick={() => setIsAddProductOpen(false)} className="fixed inset-0 bg-black/60 backdrop-blur-xs" />
            <div className="relative bg-white dark:bg-gray-800 rounded-3xl max-w-xl w-full p-6 sm:p-8 z-10 shadow-2xl space-y-4">
              <h3 className="text-lg font-bold text-gray-900 dark:text-white">
                {t('আপনার দোকানে নতুন পণ্য যোগ করুন', 'Add Product to Store')}
              </h3>

              <form onSubmit={handleAddProduct} className="space-y-3 text-xs">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="font-bold block mb-1">{t('পণ্যের নাম (বাংলা)', 'Name (Bangla) *')}</label>
                    <input
                      type="text"
                      required
                      value={newProdNameBn}
                      onChange={(e) => setNewProdNameBn(e.target.value)}
                      placeholder="যেমন: পদ্মার রূপালী ইলিশ"
                      className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 rounded-xl p-2.5"
                    />
                  </div>
                  <div>
                    <label className="font-bold block mb-1">{t('পণ্যের নাম (English)', 'Name (English) *')}</label>
                    <input
                      type="text"
                      required
                      value={newProdName}
                      onChange={(e) => setNewProdName(e.target.value)}
                      placeholder="e.g. Fresh Padma Hilsha"
                      className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 rounded-xl p-2.5"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="font-bold block">{t('পণ্য ক্যাটাগরি (Category) *', 'Product Category *')}</label>
                    <button
                      type="button"
                      onClick={openAddCategoryModal}
                      className="text-[11px] font-bold text-emerald-600 hover:text-emerald-700 hover:underline flex items-center gap-1"
                    >
                      <Plus className="w-3 h-3" />
                      <span>{t('নতুন ক্যাটাগরি যোগ করুন', '+ Add Category')}</span>
                    </button>
                  </div>
                  <select
                    value={newProdCategory}
                    onChange={(e) => setNewProdCategory(e.target.value)}
                    className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 rounded-xl p-2.5 text-xs text-gray-900 dark:text-white"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.nameBn})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="font-bold block mb-1">{t('মূল্য (৳ BDT)', 'Price (৳) *')}</label>
                    <input
                      type="number"
                      required
                      value={newProdPrice}
                      onChange={(e) => setNewProdPrice(Number(e.target.value))}
                      className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 rounded-xl p-2.5"
                    />
                  </div>
                  <div>
                    <label className="font-bold block mb-1">{t('আসল মূল্য (Strike Price)', 'Original Price (৳)')}</label>
                    <input
                      type="number"
                      value={newProdOriginalPrice}
                      onChange={(e) => setNewProdOriginalPrice(Number(e.target.value))}
                      className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 rounded-xl p-2.5"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="font-bold block mb-1">{t('স্টক সংখ্যা (Stock)', 'Stock Qty *')}</label>
                    <input
                      type="number"
                      required
                      value={newProdStock}
                      onChange={(e) => setNewProdStock(Number(e.target.value))}
                      className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 rounded-xl p-2.5"
                    />
                  </div>
                  <div>
                    <label className="font-bold block mb-1">{t('একক (যেমন: ১ কেজি / ১ পিস)', 'Unit')}</label>
                    <input
                      type="text"
                      value={newProdUnitBn}
                      onChange={(e) => setNewProdUnitBn(e.target.value)}
                      className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 rounded-xl p-2.5"
                    />
                  </div>
                </div>

                <div>
                  <label className="font-bold block mb-1">{t('ছবির লিংক (Image URL)', 'Image URL')}</label>
                  <input
                    type="url"
                    value={newProdImage}
                    onChange={(e) => setNewProdImage(e.target.value)}
                    className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 rounded-xl p-2.5"
                  />
                </div>

                <div className="flex gap-4 pt-1">
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newProdIsDeshi}
                      onChange={(e) => setNewProdIsDeshi(e.target.checked)}
                      className="accent-emerald-600"
                    />
                    <span>{t('দেশি পণ্য ট্যাগ', 'Deshi Product')}</span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newProdIsOrganic}
                      onChange={(e) => setNewProdIsOrganic(e.target.checked)}
                      className="accent-emerald-600"
                    />
                    <span>{t('অরগানিক ট্যাগ', 'Organic Tag')}</span>
                  </label>
                </div>

                <div className="pt-3 flex gap-2">
                  <button
                    type="submit"
                    className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold"
                  >
                    {t('পণ্য পাবলিশ করুন', 'Publish Product')}
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsAddProductOpen(false)}
                    className="px-4 py-3 bg-gray-100 dark:bg-gray-700 rounded-xl font-bold"
                  >
                    {t('বাতিল', 'Cancel')}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
