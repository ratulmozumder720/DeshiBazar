import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { ProductCard } from '../components/ProductCard';
import { 
  Filter, 
  Search, 
  X, 
  SlidersHorizontal, 
  ArrowUpDown, 
  Sparkles, 
  Star, 
  Check, 
  Store
} from 'lucide-react';
import { BANGLADESH_DIVISIONS } from '../data/mockData';

export const ShopView: React.FC = () => {
  const { 
    t, 
    products, 
    categories, 
    sellers, 
    searchQuery, 
    setSearchQuery, 
    selectedCategory, 
    setSelectedCategory,
    selectedSellerId,
    setSelectedSellerId,
    setCurrentView
  } = useApp();

  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'rating' | 'discount'>('featured');
  const [priceRange, setPriceRange] = useState<number>(5000);
  const [minRating, setMinRating] = useState<number>(0);
  const [onlyInStock, setOnlyInStock] = useState<boolean>(false);
  const [onlyDeshi, setOnlyDeshi] = useState<boolean>(false);
  const [onlyOrganic, setOnlyOrganic] = useState<boolean>(false);
  const [selectedDivision, setSelectedDivision] = useState<string>('all');
  const [isFilterDrawerOpen, setIsFilterDrawerOpen] = useState<boolean>(false);

  // Filter and Sort Pipeline
  const filteredProducts = useMemo(() => {
    return products.filter((product) => {
      // Search query filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesName = product.name.toLowerCase().includes(q) || product.nameBn.includes(q);
        const matchesCategory = product.category.toLowerCase().includes(q);
        const matchesBrand = product.brand.toLowerCase().includes(q);
        const matchesDesc = product.description.toLowerCase().includes(q) || product.descriptionBn.includes(q);
        if (!matchesName && !matchesCategory && !matchesBrand && !matchesDesc) return false;
      }

      // Category filter
      if (selectedCategory && product.category !== selectedCategory) {
        return false;
      }

      // Seller filter
      if (selectedSellerId && product.vendorId !== selectedSellerId) {
        return false;
      }

      // Price filter
      if (product.price > priceRange) {
        return false;
      }

      // Rating filter
      if (minRating > 0 && product.rating < minRating) {
        return false;
      }

      // In stock
      if (onlyInStock && product.stock <= 0) {
        return false;
      }

      // Deshi filter
      if (onlyDeshi && !product.isDeshi) {
        return false;
      }

      // Organic filter
      if (onlyOrganic && !product.isOrganic) {
        return false;
      }

      // Division filter
      if (selectedDivision !== 'all') {
        const matchesLoc = product.vendorLocation.toLowerCase().includes(selectedDivision.toLowerCase()) ||
          (product.origin && product.origin.toLowerCase().includes(selectedDivision.toLowerCase()));
        if (!matchesLoc) return false;
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'rating') return b.rating - a.rating;
      if (sortBy === 'discount') return b.discountPercent - a.discountPercent;
      return 0; // 'featured'
    });
  }, [
    products, 
    searchQuery, 
    selectedCategory, 
    selectedSellerId, 
    priceRange, 
    minRating, 
    onlyInStock, 
    onlyDeshi, 
    onlyOrganic, 
    selectedDivision, 
    sortBy
  ]);

  const clearAllFilters = () => {
    setSelectedCategory(null);
    setSelectedSellerId(null);
    setSearchQuery('');
    setPriceRange(5000);
    setMinRating(0);
    setOnlyInStock(false);
    setOnlyDeshi(false);
    setOnlyOrganic(false);
    setSelectedDivision('all');
    setSortBy('featured');
  };

  const hasActiveFilters = Boolean(
    selectedCategory ||
    selectedSellerId ||
    searchQuery ||
    priceRange < 5000 ||
    minRating > 0 ||
    onlyInStock ||
    onlyDeshi ||
    onlyOrganic ||
    selectedDivision !== 'all'
  );

  const selectedCategoryObj = categories.find(c => c.id === selectedCategory);
  const selectedSellerObj = sellers.find(s => s.id === selectedSellerId);

  return (
    <div className="py-8 bg-gray-50 dark:bg-gray-900 min-h-screen transition-colors">
      <div className="max-w-7xl mx-auto px-4">
        {/* Breadcrumb & Navigation */}
        <div className="flex items-center justify-between gap-2 text-xs text-gray-500 mb-4">
          <div className="flex items-center gap-2">
            <button onClick={() => setCurrentView('home')} className="hover:text-emerald-600">
              {t('হোম', 'Home')}
            </button>
            <span>/</span>
            <span className="text-gray-900 dark:text-white font-semibold">
              {selectedCategoryObj ? t(selectedCategoryObj.nameBn, selectedCategoryObj.name) : t('সকল পণ্য (ফুল-উইডথ শপ)', 'All Products (Full View)')}
            </span>
            {selectedSellerObj && (
              <>
                <span>/</span>
                <span className="text-emerald-600 font-bold">{selectedSellerObj.name}</span>
              </>
            )}
          </div>
        </div>

        {/* Active Seller Banner if selected */}
        {selectedSellerObj && (
          <div className="mb-6 p-6 rounded-3xl bg-white dark:bg-gray-800 border border-emerald-200 dark:border-emerald-800 shadow-xs flex flex-col sm:flex-row items-center gap-5 justify-between">
            <div className="flex items-center gap-4 text-center sm:text-left">
              <img
                src={selectedSellerObj.logo}
                alt={selectedSellerObj.name}
                className="w-16 h-16 rounded-2xl object-cover border-2 border-emerald-500 shadow-md"
              />
              <div>
                <span className="text-xs font-bold text-emerald-600 uppercase tracking-wider flex items-center justify-center sm:justify-start gap-1">
                  <Store className="w-3.5 h-3.5" />
                  {t('ভেরিফাইড সেলার শপ', 'Verified Merchant Store')}
                </span>
                <h2 className="text-xl font-black text-gray-900 dark:text-white">
                  {t(selectedSellerObj.nameBn, selectedSellerObj.name)}
                </h2>
                <p className="text-xs text-gray-500">
                  {selectedSellerObj.location} • {selectedSellerObj.rating}★ ({selectedSellerObj.reviewsCount} {t('রিভিউ', 'reviews')})
                </p>
              </div>
            </div>
            <button
              onClick={() => setSelectedSellerId(null)}
              className="px-4 py-2 bg-gray-100 dark:bg-gray-700 hover:bg-rose-50 hover:text-rose-600 text-xs font-bold rounded-xl transition-colors"
            >
              {t('সেলার ফিল্টার মুছুন', 'Clear Seller Filter')}
            </button>
          </div>
        )}

        {/* 1. Header Toolbar (Full-Width, Side Removed) */}
        <div className="bg-white dark:bg-gray-800 rounded-3xl p-5 border border-gray-100 dark:border-gray-700/80 shadow-xs mb-5">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-gray-100 dark:border-gray-700">
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-gray-900 dark:text-white flex items-center gap-2">
                <span>
                  {searchQuery ? `"${searchQuery}"` : selectedCategoryObj ? t(selectedCategoryObj.nameBn, selectedCategoryObj.name) : t('সকল পণ্য ব্রাউজ করুন', 'Explore Products')}
                </span>
              </h1>
              <p className="text-xs text-gray-500 mt-0.5">
                {t(`${filteredProducts.length} টি পণ্য পাওয়া গেছে (সাইডবার মুক্ত সম্পূর্ণ ভিউ)`, `Showing ${filteredProducts.length} products in full-width presentation`)}
              </p>
            </div>

            {/* Sort & Filter Drawer Button */}
            <div className="flex flex-wrap items-center gap-2.5">
              <button
                onClick={() => setIsFilterDrawerOpen(true)}
                className="flex items-center gap-2 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs transition-transform active:scale-95"
              >
                <SlidersHorizontal className="w-4 h-4" />
                <span>{t('ফিল্টার মেনু', 'All Filters')}</span>
                {hasActiveFilters && (
                  <span className="w-2 h-2 rounded-full bg-amber-300"></span>
                )}
              </button>

              {/* Sort By Dropdown */}
              <div className="relative">
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="bg-gray-50 dark:bg-gray-700 text-gray-800 dark:text-gray-100 text-xs font-semibold py-2 px-3 pr-8 rounded-xl border border-gray-200 dark:border-gray-600 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                >
                  <option value="featured">{t('ফিচার্ড (জনপ্রিয়)', 'Featured')}</option>
                  <option value="price-asc">{t('দাম: কম থেকে বেশি', 'Price: Low to High')}</option>
                  <option value="price-desc">{t('দাম: বেশি থেকে কম', 'Price: High to Low')}</option>
                  <option value="rating">{t('সেরা রেটিং', 'Highest Rated')}</option>
                  <option value="discount">{t('সর্বোচ্চ ছাড়', 'Biggest Discount')}</option>
                </select>
                <ArrowUpDown className="w-3.5 h-3.5 text-gray-400 absolute right-2.5 top-2.5 pointer-events-none" />
              </div>

              {hasActiveFilters && (
                <button
                  onClick={clearAllFilters}
                  className="text-xs text-rose-500 hover:underline font-bold px-2 py-1"
                >
                  {t('রিসেট', 'Clear All')}
                </button>
              )}
            </div>
          </div>

          {/* 2. Top Horizontal Category Carousel Chips */}
          <div className="pt-3 flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            <button
              onClick={() => setSelectedCategory(null)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-bold shrink-0 transition-all ${
                selectedCategory === null
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
              }`}
            >
              {t('সকল বিভাগ', 'All Departments')}
            </button>

            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id === selectedCategory ? null : cat.id)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-bold shrink-0 transition-all ${
                  selectedCategory === cat.id
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                }`}
              >
                {t(cat.nameBn, cat.name)}
              </button>
            ))}
          </div>

          {/* 3. Quick Filter Toggles */}
          <div className="mt-3 pt-3 border-t border-gray-100 dark:border-gray-700 flex flex-wrap items-center gap-2 text-xs">
            <button
              onClick={() => setOnlyDeshi(!onlyDeshi)}
              className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-all ${
                onlyDeshi
                  ? 'bg-amber-500 text-white shadow-xs'
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{t('খাঁটি দেশি', 'Authentic Deshi')}</span>
            </button>

            <button
              onClick={() => setOnlyOrganic(!onlyOrganic)}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
                onlyOrganic
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
              }`}
            >
              <span>{t('১০০% অরগানিক', 'Organic')}</span>
            </button>

            <button
              onClick={() => setOnlyInStock(!onlyInStock)}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
                onlyInStock
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
              }`}
            >
              <span>{t('স্টকে থাকা পণ্য', 'In Stock')}</span>
            </button>

            {/* Division select pill */}
            <select
              value={selectedDivision}
              onChange={(e) => setSelectedDivision(e.target.value)}
              className="bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200 px-3 py-1.5 rounded-xl font-semibold border-none focus:ring-1 focus:ring-emerald-500"
            >
              <option value="all">{t('বিভাগ: সারা দেশ', 'All Regions')}</option>
              {BANGLADESH_DIVISIONS.map(div => (
                <option key={div} value={div}>{div}</option>
              ))}
            </select>

            {/* Max Price Pill */}
            <span className="ml-auto text-gray-500 dark:text-gray-400 font-medium hidden sm:inline">
              {t('সর্বোচ্চ মূল্য:', 'Max Price:')} <strong className="text-emerald-600 font-mono">৳{priceRange}</strong>
            </span>
          </div>
        </div>

        {/* 4. Full-Width Products Grid (Side Removed) */}
        <div>
          {filteredProducts.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-4 xl:grid-cols-5 gap-3.5 sm:gap-4">
              {filteredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="bg-white dark:bg-gray-800 rounded-3xl p-12 text-center border border-gray-100 dark:border-gray-700">
              <div className="w-16 h-16 rounded-full bg-emerald-50 dark:bg-emerald-950 flex items-center justify-center text-emerald-600 mx-auto mb-4">
                <Search className="w-8 h-8 opacity-60" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-1">
                {t('কোনো পণ্য খুঁজে পাওয়া যায়নি', 'No matching products found')}
              </h3>
              <p className="text-xs text-gray-500 max-w-sm mx-auto mb-5">
                {t('অনুগ্রহ করে ফিল্টার পরিবর্তন করুন বা অন্য কোনো কীওয়ার্ড দিয়ে সার্চ করুন।', 'Try adjusting your filters or search keywords.')}
              </p>
              <button
                onClick={clearAllFilters}
                className="px-5 py-2.5 bg-emerald-600 text-white rounded-xl text-xs font-bold shadow-md hover:bg-emerald-700"
              >
                {t('সকল ফিল্টার রিসেট করুন', 'Reset All Filters')}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* 5. On-Demand Slide-over Filter Drawer (Opens only when user clicks 'All Filters') */}
      {isFilterDrawerOpen && (
        <div className="fixed inset-0 z-50 flex">
          <div
            onClick={() => setIsFilterDrawerOpen(false)}
            className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
          />
          <div className="relative ml-auto w-full max-w-sm bg-white dark:bg-gray-900 h-full p-6 shadow-2xl flex flex-col justify-between overflow-y-auto z-10 animate-in slide-in-from-right duration-200">
            <div className="space-y-6">
              <div className="flex items-center justify-between pb-3 border-b border-gray-100 dark:border-gray-800">
                <div className="flex items-center gap-2">
                  <Filter className="w-4 h-4 text-emerald-600" />
                  <span className="font-bold text-sm text-gray-900 dark:text-white">
                    {t('ফিল্টার কনফিগুরেশন', 'Product Filters')}
                  </span>
                </div>
                <button 
                  onClick={() => setIsFilterDrawerOpen(false)}
                  className="w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center text-gray-500 hover:text-gray-900"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Price Range Slider */}
              <div>
                <div className="flex justify-between items-center mb-1.5">
                  <span className="text-xs font-bold text-gray-900 dark:text-white">
                    {t('সর্বোচ্চ মূল্য', 'Max Price')}
                  </span>
                  <span className="text-xs font-mono font-bold text-emerald-600">
                    ৳{priceRange}
                  </span>
                </div>
                <input
                  type="range"
                  min="100"
                  max="5000"
                  step="50"
                  value={priceRange}
                  onChange={(e) => setPriceRange(Number(e.target.value))}
                  className="w-full accent-emerald-600 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-gray-400 mt-1">
                  <span>৳১০০</span>
                  <span>৳৫০০০+</span>
                </div>
              </div>

              {/* Source Region Division */}
              <div>
                <span className="text-xs font-bold text-gray-900 dark:text-white block mb-2">
                  {t('উৎপাদন বা সরবরাহ বিভাগ', 'Source Region')}
                </span>
                <select
                  value={selectedDivision}
                  onChange={(e) => setSelectedDivision(e.target.value)}
                  className="w-full bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl px-3 py-2 text-xs text-gray-800 dark:text-gray-100 focus:outline-none"
                >
                  <option value="all">{t('সারা বাংলাদেশ (সকল বিভাগ)', 'Nationwide (All Divisions)')}</option>
                  {BANGLADESH_DIVISIONS.map(div => (
                    <option key={div} value={div}>{div}</option>
                  ))}
                </select>
              </div>

              {/* Minimum Rating */}
              <div>
                <span className="text-xs font-bold text-gray-900 dark:text-white block mb-2">
                  {t('গ্রাহক রেটিং', 'Customer Rating')}
                </span>
                <div className="space-y-1">
                  {[4, 3].map((stars) => (
                    <button
                      key={stars}
                      onClick={() => setMinRating(minRating === stars ? 0 : stars)}
                      className={`w-full text-left px-3 py-2 rounded-xl text-xs flex items-center justify-between ${
                        minRating === stars
                          ? 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 font-bold border border-amber-200 dark:border-amber-800'
                          : 'text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800'
                      }`}
                    >
                      <div className="flex items-center gap-1.5">
                        <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                        <span>{stars}★ {t('বা তার বেশি', '& above')}</span>
                      </div>
                      {minRating === stars && <Check className="w-3.5 h-3.5 text-amber-600" />}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Bottom Drawer Actions */}
            <div className="pt-4 border-t border-gray-100 dark:border-gray-800 flex items-center gap-2">
              <button
                onClick={clearAllFilters}
                className="flex-1 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 text-xs font-bold text-gray-700 dark:text-gray-300 hover:bg-gray-50"
              >
                {t('রিসেট', 'Reset')}
              </button>
              <button
                onClick={() => setIsFilterDrawerOpen(false)}
                className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md"
              >
                {t('প্রয়োগ করুন', 'Apply')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
