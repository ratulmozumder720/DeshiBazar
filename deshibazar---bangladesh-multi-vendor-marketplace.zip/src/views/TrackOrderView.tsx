import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Search, 
  Truck, 
  CheckCircle2, 
  Package, 
  MapPin, 
  Phone, 
  ExternalLink,
  Copy,
  Check,
  Navigation,
  Receipt
} from 'lucide-react';
import { Order } from '../types';
import { CancelOrderModal } from '../components/CancelOrderModal';
import { BANGLADESH_COURIERS, generateLiveCourierTrackingInfo } from '../data/courierData';

export const TrackOrderView: React.FC = () => {
  const { orders, activeOrderToTrack, setActiveOrderToTrack, setCurrentView, t, showToast, setIsCourierModalOpen, openCashMemoModal } = useApp();

  const [inputOrderNumber, setInputOrderNumber] = useState('');
  const [copiedCode, setCopiedCode] = useState(false);
  const [searchedOrder, setSearchedOrder] = useState<Order | null>(activeOrderToTrack || (orders.length > 0 ? orders[0] : null));
  const [customTrackingResult, setCustomTrackingResult] = useState<any>(null);
  const [isCancelModalOpen, setIsCancelModalOpen] = useState(false);

  const handleSearchOrder = (e: React.FormEvent) => {
    e.preventDefault();
    const query = inputOrderNumber.trim();
    if (!query) return;

    // 1. Search in user's real/saved orders
    const found = orders.find(
      o => o.orderNumber.toLowerCase() === query.toLowerCase() ||
           o.id.toLowerCase() === query.toLowerCase() ||
           (o.courierTrackingCode && o.courierTrackingCode.toLowerCase() === query.toLowerCase())
    );

    if (found) {
      setSearchedOrder(found);
      setActiveOrderToTrack(found);
      setCustomTrackingResult(null);
      showToast(t(`অর্ডার ${found.orderNumber} লোড হয়েছে`, `Order ${found.orderNumber} loaded`), 'success');
      return;
    }

    // 2. If entered a Bangladeshi courier tracking code (ST-..., PT-..., REDX-..., SC-..., etc.)
    const liveTracking = generateLiveCourierTrackingInfo(query, `DB-${Math.floor(100000 + Math.random() * 900000)}`);
    setCustomTrackingResult(liveTracking);
    setSearchedOrder(null);
    showToast(t(`${liveTracking.courier.nameBn} লাইভ কন্সায়নমেন্ট ট্র্যাকিং পাওয়া গেছে!`, `Found live ${liveTracking.courier.name} consignment tracking!`), 'success');
  };

  const handleQuickCourierDemo = (courierId: string) => {
    const prefix = courierId === 'pathao' ? 'PT' :
                   courierId === 'redx' ? 'REDX' :
                   courierId === 'paperfly' ? 'PF' :
                   courierId === 'sundarban' ? 'SC' :
                   courierId === 'ecourier' ? 'ECR' :
                   courierId === 'sa_paribahan' ? 'SAP' :
                   courierId === 'karatoa' ? 'KC' : 'ST';
    const demoCode = `${prefix}-${Math.floor(1000000 + Math.random() * 9000000)}`;
    setInputOrderNumber(demoCode);
    const liveTracking = generateLiveCourierTrackingInfo(demoCode, undefined, courierId);
    setCustomTrackingResult(liveTracking);
    setSearchedOrder(null);
  };

  const currentOrder: Order | null = searchedOrder || (customTrackingResult ? null : (activeOrderToTrack || (orders.length > 0 ? orders[0] : null)));

  // Derive courier for current order
  const activeCourier = customTrackingResult
    ? customTrackingResult.courier
    : BANGLADESH_COURIERS.find((c: any) => c.id === currentOrder?.courierId) || BANGLADESH_COURIERS[0];

  const activeTrackingCode = customTrackingResult
    ? customTrackingResult.consignmentId
    : (currentOrder?.courierTrackingCode || `ST-${Math.floor(1000000 + Math.random() * 9000000)}`);

  const liveDetails = customTrackingResult || generateLiveCourierTrackingInfo(activeTrackingCode, currentOrder?.orderNumber, activeCourier.id);

  const copyTracking = () => {
    navigator.clipboard.writeText(activeTrackingCode);
    setCopiedCode(true);
    showToast(t('ট্র্যাকিং কোড কপি করা হয়েছে', 'Tracking code copied to clipboard'), 'info');
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="py-10 bg-gray-50 dark:bg-gray-900 min-h-screen transition-colors">
      <div className="max-w-4xl mx-auto px-4">
        {/* Header & Search */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 text-xs font-bold mb-2">
            <Truck className="w-3.5 h-3.5" />
            <span>{t('বাংলাদেশের সকল কুরিয়ার রিয়েল-টাইম ট্র্যাকিং', 'All Bangladeshi Couriers Live Tracking')}</span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white">
            {t('অর্ডার ও কুরিয়ার পার্সেল ট্র্যাক করুন', 'Live Order & Courier Parcel Tracking')}
          </h1>
          <p className="text-xs sm:text-sm text-gray-500 mt-1 max-w-lg mx-auto">
            {t(
              'দেশিবাজার অর্ডার নম্বর (DB-XXXXXX) কিংবা স্টেডফাস্ট, পাঠাও, রেডএক্স, সুন্দরবন কন্সায়নমেন্ট আইডি দিয়ে সরাসরি ট্র্যাক করুন।',
              'Enter your DeshiBazar Order ID or Steadfast, Pathao, RedX, Sundarban Consignment tracking code.'
            )}
          </p>

          {/* Search Bar */}
          <form onSubmit={handleSearchOrder} className="mt-5 max-w-lg mx-auto flex gap-2">
            <div className="relative flex-1">
              <input
                type="text"
                value={inputOrderNumber}
                onChange={(e) => setInputOrderNumber(e.target.value)}
                placeholder="e.g. DB-123456 or ST-894102 / PT-552190"
                className="w-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl px-4 py-3 pl-11 text-xs text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-xs"
              />
              <Search className="w-4 h-4 text-gray-400 absolute left-4 top-3.5" />
            </div>
            <button
              type="submit"
              className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl text-xs font-bold shadow-md shadow-emerald-600/20 active:scale-95 transition-all shrink-0"
            >
              {t('ট্র্যাক করুন', 'Track Live')}
            </button>
          </form>

          {/* Bangladeshi Courier Quick Filters & Demo Buttons */}
          <div className="mt-4 flex flex-wrap items-center justify-center gap-1.5 text-xs">
            <span className="text-[11px] font-bold text-gray-400 mr-1">{t('কুরিয়ার ডেমো:', 'Quick Test:')}</span>
            {BANGLADESH_COURIERS.slice(0, 5).map((c: any) => (
              <button
                key={c.id}
                onClick={() => handleQuickCourierDemo(c.id)}
                className="px-2.5 py-1 rounded-lg bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:border-emerald-500 hover:text-emerald-600 text-[11px] font-semibold transition-all shadow-xs"
              >
                {c.name.split(' ')[0]}
              </button>
            ))}
            <button
              onClick={() => setIsCourierModalOpen(true)}
              className="px-2.5 py-1 rounded-lg bg-teal-50 dark:bg-teal-950/60 border border-teal-200 dark:border-teal-800 text-teal-700 dark:text-teal-300 text-[11px] font-bold hover:bg-teal-100"
            >
              {t('সকল ৮টি কুরিয়ার রেট →', 'All 8 Couriers →')}
            </button>
          </div>
        </div>

        {/* Tracking Card */}
        <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 sm:p-8 border border-gray-100 dark:border-gray-700/80 shadow-md space-y-6">
          {/* 1. Bangladeshi Courier Dispatch Header */}
          <div className="p-5 rounded-2xl bg-gradient-to-r from-emerald-50 via-teal-50 to-cyan-50 dark:from-emerald-950/40 dark:via-teal-950/30 dark:to-cyan-950/20 border border-emerald-200 dark:border-emerald-800/80 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="flex items-center gap-3.5">
              <img
                src={activeCourier.logo}
                alt={activeCourier.name}
                className="w-14 h-14 rounded-2xl object-cover border-2 border-emerald-500 shadow-md shrink-0"
              />
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base sm:text-lg font-black text-gray-900 dark:text-white">
                    {t(activeCourier.nameBn, activeCourier.name)}
                  </h3>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-600 text-white text-[10px] font-black uppercase">
                    Verified Courier
                  </span>
                </div>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-xs text-gray-500 font-medium">
                    {t('কন্সায়নমেন্ট আইডি:', 'Consignment ID:')}
                  </span>
                  <span className="font-mono font-black text-emerald-700 dark:text-emerald-300 text-xs bg-white dark:bg-gray-800 px-2 py-0.5 rounded-lg border border-emerald-200 dark:border-emerald-800">
                    {activeTrackingCode}
                  </span>
                  <button
                    onClick={copyTracking}
                    className="p-1 text-gray-400 hover:text-emerald-600 transition-colors"
                    title="Copy Tracking ID"
                  >
                    {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2 w-full md:w-auto justify-between md:justify-end">
              <a
                href={`tel:${activeCourier.hotline}`}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-xs font-bold text-gray-700 dark:text-gray-200 hover:text-emerald-600 shadow-xs"
              >
                <Phone className="w-3.5 h-3.5 text-emerald-600" />
                <span>{activeCourier.hotline}</span>
              </a>

              <a
                href={activeCourier.trackingUrlTemplate.replace('{tracking}', activeTrackingCode)}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs transition-all"
              >
                <span>{t('কুরিয়ার পোর্টালে দেখুন', 'Courier Portal')}</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          {/* 2. Live Transit & Rider Status */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-750 border border-gray-100 dark:border-gray-700">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">
                {t('বর্তমান অবস্থান (Live Status)', 'Current Transit Status')}
              </span>
              <span className="text-xs font-black text-emerald-600 dark:text-emerald-400 block">
                {t(liveDetails.currentStatus, liveDetails.currentStatusEn)}
              </span>
              <span className="text-[11px] text-gray-500 mt-1 block">
                {liveDetails.estimatedDelivery}
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-750 border border-gray-100 dark:border-gray-700">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">
                {t('ডেলিভারি রাইডার ও ফোন', 'Assigned Rider')}
              </span>
              <span className="text-xs font-bold text-gray-900 dark:text-white block">
                {liveDetails.riderName}
              </span>
              <a href={`tel:${liveDetails.riderPhone}`} className="text-[11px] font-bold text-blue-600 hover:underline mt-0.5 inline-block">
                📞 {liveDetails.riderPhone}
              </a>
            </div>

            <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-750 border border-gray-100 dark:border-gray-700">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">
                {t('হাব রুট ও পার্সেল বিবরণ', 'Hub Routing & COD')}
              </span>
              <span className="text-xs font-bold text-gray-900 dark:text-white block truncate">
                {liveDetails.destinationHub}
              </span>
              <span className="text-[11px] font-mono text-emerald-600 font-bold mt-1 block">
                COD: {liveDetails.codAmount} ({liveDetails.weightKg})
              </span>
            </div>
          </div>

          {/* 3. Step-by-Step Courier Live Timeline */}
          <div>
            <h3 className="text-sm font-bold text-gray-900 dark:text-white mb-6 flex items-center gap-2">
              <Navigation className="w-4 h-4 text-emerald-600" />
              <span>{t('লাইভ কুরিয়ার ট্রানজিট টাইমলাইন', 'Courier Real-Time Transit Timeline')}</span>
            </h3>

            <div className="relative pl-6 sm:pl-8 space-y-6 before:absolute before:left-3 sm:before:left-4 before:top-2 before:bottom-2 before:w-0.5 before:bg-gray-200 dark:before:bg-gray-700">
              {liveDetails.liveTimeline.map((step: any, idx: number) => (
                <div key={idx} className="relative flex items-start gap-4">
                  <div className={`absolute -left-6 sm:-left-8 w-6 sm:w-8 h-6 sm:h-8 rounded-full flex items-center justify-center text-xs font-bold border-2 transition-all ${
                    step.completed
                      ? step.activeNow
                        ? 'bg-emerald-600 border-emerald-600 text-white ring-4 ring-emerald-500/20 animate-pulse'
                        : 'bg-emerald-600 border-emerald-600 text-white shadow-md'
                      : 'bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600 text-gray-400'
                  }`}>
                    {step.completed ? <CheckCircle2 className="w-4 h-4" /> : idx + 1}
                  </div>

                  <div className="flex-1 bg-gray-50/60 dark:bg-gray-750/50 p-4 rounded-2xl border border-gray-100 dark:border-gray-700/80">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 mb-1">
                      <h4 className={`text-xs sm:text-sm font-bold ${
                        step.completed ? 'text-gray-900 dark:text-white' : 'text-gray-400'
                      }`}>
                        {step.title}
                      </h4>
                      <span className="text-[11px] font-mono text-emerald-600 dark:text-emerald-400 font-semibold">
                        {step.time}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 text-xs text-gray-500 mb-1">
                      <MapPin className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                      <span>{step.location}</span>
                    </div>

                    <p className="text-[11px] text-gray-600 dark:text-gray-300">
                      {step.desc}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 4. Customer & Delivery Address Details if Order is present */}
          {currentOrder && (
            <div className="pt-6 border-t border-gray-100 dark:border-gray-700 grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
              <div>
                <h4 className="font-bold text-gray-900 dark:text-white mb-3 flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-emerald-600" />
                  <span>{t('ডেলিভারি গন্তব্য ও গ্রাহকের তথ্য', 'Delivery Recipient Details')}</span>
                </h4>
                <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-750 space-y-1 text-gray-600 dark:text-gray-300">
                  <p className="font-bold text-gray-900 dark:text-white">{currentOrder.customerName}</p>
                  <p>{currentOrder.address}</p>
                  <p>{currentOrder.upazila}, {currentOrder.district}, {currentOrder.division}</p>
                  <p className="text-emerald-600 font-semibold pt-1">📞 {currentOrder.customerPhone}</p>
                </div>
              </div>

              <div>
                <h4 className="font-bold text-gray-900 dark:text-white mb-3 flex items-center gap-1.5">
                  <Package className="w-4 h-4 text-emerald-600" />
                  <span>{t('অর্ডারের পণ্যসমূহ', 'Package Contents')}</span>
                </h4>
                <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-750 space-y-2 max-h-36 overflow-y-auto">
                  {currentOrder.items.map((item, idx) => (
                    <div key={idx} className="flex justify-between items-center text-xs">
                      <span className="truncate pr-2">{t(item.product.nameBn, item.product.name)} x {item.quantity}</span>
                      <span className="font-bold text-gray-900 dark:text-white shrink-0">৳{item.quantity * item.product.price}</span>
                    </div>
                  ))}
                  <div className="pt-2 border-t border-gray-200 dark:border-gray-700 flex justify-between font-bold text-emerald-600">
                    <span>{t('পরিশোধিত/পরিশোধ্য মোট', 'Total Payable')}</span>
                    <span>৳{currentOrder.total} ({currentOrder.paymentMethod.toUpperCase()})</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Action buttons */}
          <div className="pt-4 border-t border-gray-100 dark:border-gray-700 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setCurrentView('shop')}
                className="px-5 py-2.5 bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-xl text-xs font-bold hover:bg-gray-200"
              >
                {t('আরও কেনাকাটা করুন', 'Continue Shopping')}
              </button>

              {currentOrder && (
                <button
                  type="button"
                  onClick={() => openCashMemoModal(currentOrder)}
                  className="px-5 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md shadow-purple-600/20 active:scale-95 transition-all"
                  title={t('ক্যাশ মেমো ও ইনভয়েস দেখুন এবং PDF/Image ডাউনলোড করুন', 'View Cash Memo and Download PDF or Image')}
                >
                  <Receipt className="w-4 h-4 text-purple-200" />
                  <span>{t('ক্যাশ মেমো ও ইনভয়েস (PDF / Image)', 'Cash Memo & Invoice (PDF / Image)')}</span>
                </button>
              )}
            </div>

            <button
              onClick={() => setIsCourierModalOpen(true)}
              className="px-5 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs"
            >
              <Truck className="w-4 h-4" />
              <span>{t('সকল ৮টি বাংলাদেশি কুরিয়ার তালিকা', 'View All BD Couriers')}</span>
            </button>
          </div>
        </div>
      </div>

      <CancelOrderModal
        isOpen={isCancelModalOpen}
        onClose={() => setIsCancelModalOpen(false)}
        order={currentOrder}
      />
    </div>
  );
};
