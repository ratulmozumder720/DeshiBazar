import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  User, 
  Package, 
  Heart, 
  MapPin, 
  Tag, 
  Bell, 
  LifeBuoy, 
  LogOut, 
  Edit3, 
  Plus, 
  Trash2, 
  Truck, 
  Phone,
  XCircle,
  AlertCircle,
  Settings,
  Receipt,
  MessageSquare,
  Wallet
} from 'lucide-react';
import { COUPONS } from '../data/mockData';
import { CancelOrderModal } from '../components/CancelOrderModal';
import { Order } from '../types';
import { DESHIBAZAR_CONTACT } from '../data/contactConfig';

export const UserDashboardView: React.FC = () => {
  const {
    t,
    user,
    userProfile,
    updateUserProfile,
    logOut,
    switchUserRole,
    setIsAuthModalOpen,
    orders,
    wishlist,
    products,
    addToCart,
    toggleWishlist,
    setActiveOrderToTrack,
    setCurrentView,
    showToast,
    openCashMemoModal,
    smsNotifications,
    bakiAccounts,
    unreadSmsCount,
    totalCustomerBakiDue,
    openSmsNotificationModal
  } = useApp();

  const [activeTab, setActiveTab] = useState<'profile' | 'orders' | 'wishlist' | 'addresses' | 'coupons' | 'support'>('orders');
  const [orderToCancel, setOrderToCancel] = useState<Order | null>(null);
  const [isCancelModalOpen, setIsCancelModalOpen] = useState(false);

  // Profile Edit State
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [displayName, setDisplayName] = useState(userProfile?.displayName || user?.displayName || 'Deshi User');
  const [phone, setPhone] = useState(userProfile?.phone || user?.phoneNumber || '+8801700000000');

  // Address State
  const [addresses, setAddresses] = useState(userProfile?.addresses || [
    {
      id: 'addr-1',
      title: 'Home (বাসা)',
      division: 'Dhaka',
      district: 'Dhaka',
      upazila: 'Gulshan',
      fullAddress: 'House 14, Road 11, Block D, Banani, Dhaka-1213',
      phone: '+8801711223344',
      isDefault: true
    }
  ]);

  // Synchronize local form states whenever userProfile or user updates
  React.useEffect(() => {
    if (userProfile) {
      if (userProfile.displayName) setDisplayName(userProfile.displayName);
      if (userProfile.phone) setPhone(userProfile.phone);
      if (userProfile.addresses && userProfile.addresses.length > 0) {
        setAddresses(userProfile.addresses);
      }
    } else if (user) {
      if (user.displayName) setDisplayName(user.displayName);
      if (user.phoneNumber) setPhone(user.phoneNumber);
    }
  }, [userProfile, user]);
  const [isAddingAddress, setIsAddingAddress] = useState(false);
  const [newAddrTitle, setNewAddrTitle] = useState('Office');
  const [newAddrFull, setNewAddrFull] = useState('');

  const wishlistProducts = products.filter(p => wishlist.includes(p.id));

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateUserProfile({ displayName, phone });
    setIsEditingProfile(false);
  };

  const handleAddNewAddress = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAddrFull.trim()) return;
    const newEntry = {
      id: 'addr-' + Date.now(),
      title: newAddrTitle,
      division: 'Dhaka',
      district: 'Dhaka',
      upazila: 'Dhanmondi',
      fullAddress: newAddrFull,
      phone: phone || '+8801700000000',
      isDefault: false
    };
    const updated = [...addresses, newEntry];
    setAddresses(updated);
    updateUserProfile({ addresses: updated });
    setIsAddingAddress(false);
    setNewAddrFull('');
  };

  return (
    <div className="py-10 bg-gray-50 dark:bg-gray-900 min-h-screen transition-colors">
      <div className="max-w-7xl mx-auto px-4">
        {/* Profile Card Header */}
        <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 sm:p-8 border border-gray-100 dark:border-gray-700/80 shadow-xs mb-8 flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4 text-center sm:text-left">
            <div className="w-20 h-20 rounded-full bg-emerald-100 dark:bg-emerald-950 flex items-center justify-center text-emerald-600 border-4 border-white dark:border-gray-700 shadow-md overflow-hidden shrink-0">
              {userProfile?.avatarUrl ? (
                <img src={userProfile.avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
              ) : (
                <User className="w-10 h-10" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2 justify-center sm:justify-start">
                <h1 className="text-xl sm:text-2xl font-black text-gray-900 dark:text-white">
                  {userProfile?.displayName || user?.displayName || (user ? 'Customer' : t('স্বাগতম অতিথি গ্রাহক', 'Welcome Guest Customer'))}
                </h1>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 uppercase">
                  {userProfile?.role || (user ? 'Customer' : 'Guest')}
                </span>
              </div>
              <p className="text-xs text-gray-500 mt-0.5">
                {userProfile?.email || user?.email || t('লগইন করা নেই • অর্ডার ও প্রোফাইল দেখতে সাইন ইন করুন', 'Not logged in • Sign in to view your profile & orders')}
              </p>
              <p className="text-xs text-gray-400 mt-0.5">
                {userProfile?.phone || user?.phoneNumber || t('মোবাইল নম্বর যুক্ত নেই', 'No phone attached')}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {(!user && !userProfile) ? (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsAuthModalOpen(true)}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-emerald-600/20 flex items-center gap-1.5"
                >
                  <User className="w-4 h-4" />
                  <Settings className="w-3.5 h-3.5" />
                  <span>{t('লগইন / সাইন আপ করুন', 'Log In / Sign Up')}</span>
                </button>
                <button
                  onClick={() => switchUserRole('customer')}
                  className="px-3.5 py-2.5 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5"
                >
                  <Settings className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{t('ডেমো প্রোফাইল', 'Demo Profile')}</span>
                </button>
                <button
                  onClick={() => openSmsNotificationModal('notifications')}
                  className="relative px-3.5 py-2.5 bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800 hover:bg-amber-100 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5"
                  title={t('রসিদ SMS নোটিফিকেশন ও বাকি টাকা পরিশোধ', 'Receipt SMS Notification & Baki Payment')}
                >
                  <Bell className="w-4 h-4 text-amber-600" />
                  <span>{t('রসিদ SMS', 'Receipt SMS')}</span>
                  {unreadSmsCount > 0 && (
                    <span className="px-1.5 py-0.5 rounded-full bg-rose-500 text-white text-[10px]">
                      {unreadSmsCount}
                    </span>
                  )}
                </button>
              </div>
            ) : (
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => openSmsNotificationModal('notifications')}
                  className="relative px-3.5 py-2 bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-800 hover:bg-amber-100 text-amber-800 dark:text-amber-300 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5"
                  title={t('সেটিংসের অধীনে রসিদ SMS ও বাকি পরিশোধ', 'Receipt SMS & Baki Payment under Settings')}
                >
                  <Bell className="w-4 h-4 text-amber-600" />
                  <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{t('রসিদ SMS নোটিফিকেশন', 'Receipt SMS')}</span>
                  {unreadSmsCount > 0 && (
                    <span className="px-1.5 py-0.5 rounded-full bg-rose-500 text-white text-[10px] font-extrabold">
                      {unreadSmsCount}
                    </span>
                  )}
                </button>

                <button
                  onClick={() => setActiveTab('profile')}
                  className="px-4 py-2 bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-650 text-gray-800 dark:text-gray-200 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5"
                >
                  <Settings className="w-4 h-4 text-emerald-600" />
                  <span>{t('প্রোফাইল সেটিংস', 'Profile Settings')}</span>
                </button>

                <button
                  onClick={() => {
                    logOut();
                    setCurrentView('home');
                  }}
                  className="px-4 py-2 bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 hover:bg-red-100 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5"
                >
                  <LogOut className="w-4 h-4" />
                  <Settings className="w-3.5 h-3.5 text-red-400" />
                  <span>{t('লগআউট', 'Log Out')}</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Dashboard Layout: Sidebar Nav & Active Content */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Sidebar Menu */}
          <div className="lg:col-span-3 bg-white dark:bg-gray-800 rounded-3xl p-4 border border-gray-100 dark:border-gray-700/80 shadow-xs space-y-1">
            <button
              onClick={() => setActiveTab('orders')}
              className={`w-full text-left px-4 py-3 rounded-2xl text-xs font-bold flex items-center gap-3 transition-colors ${
                activeTab === 'orders'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
              }`}
            >
              <Package className="w-4 h-4" />
              <span>{t('আমার অর্ডারসমূহ', 'My Orders')}</span>
              <span className="ml-auto text-[10px] bg-white/20 px-2 py-0.5 rounded-full">
                {orders.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('wishlist')}
              className={`w-full text-left px-4 py-3 rounded-2xl text-xs font-bold flex items-center gap-3 transition-colors ${
                activeTab === 'wishlist'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
              }`}
            >
              <Heart className="w-4 h-4" />
              <span>{t('উইশলিস্ট (পছন্দের তালিকা)', 'Wishlist')}</span>
              <span className="ml-auto text-[10px] bg-white/20 px-2 py-0.5 rounded-full">
                {wishlist.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('profile')}
              className={`w-full text-left px-4 py-3 rounded-2xl text-xs font-bold flex items-center justify-between transition-colors ${
                activeTab === 'profile'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
              }`}
            >
              <div className="flex items-center gap-3">
                <Settings className="w-4 h-4" />
                <span>{t('প্রোফাইল ও একাউন্ট সেটিংস', 'Profile & Account Settings')}</span>
              </div>
              <Settings className={`w-3.5 h-3.5 ${activeTab === 'profile' ? 'text-emerald-200' : 'text-gray-400'}`} />
            </button>

            {/* SMS Receipt Notification Icon nested directly under Settings */}
            <button
              onClick={() => openSmsNotificationModal('notifications')}
              className="w-full text-left pl-7 pr-4 py-2.5 rounded-2xl text-xs font-bold flex items-center justify-between transition-colors bg-amber-50/80 dark:bg-amber-950/30 text-amber-800 dark:text-amber-300 border border-amber-200/80 dark:border-amber-800/60 hover:bg-amber-100 dark:hover:bg-amber-900/40"
            >
              <div className="flex items-center gap-2.5">
                <Bell className="w-4 h-4 text-amber-600" />
                <div>
                  <span className="block">{t('রসিদ SMS নোটিফিকেশন', 'Receipt SMS Alerts')}</span>
                  {totalCustomerBakiDue > 0 && (
                    <span className="text-[10px] text-rose-600 dark:text-rose-400 font-extrabold">
                      {t(`বাকি: ৳${totalCustomerBakiDue.toLocaleString()}`, `Baki: ৳${totalCustomerBakiDue.toLocaleString()}`)}
                    </span>
                  )}
                </div>
              </div>
              {unreadSmsCount > 0 && (
                <span className="px-1.5 py-0.5 rounded-full bg-rose-500 text-white text-[10px] font-extrabold">
                  {unreadSmsCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('addresses')}
              className={`w-full text-left px-4 py-3 rounded-2xl text-xs font-bold flex items-center gap-3 transition-colors ${
                activeTab === 'addresses'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
              }`}
            >
              <MapPin className="w-4 h-4" />
              <span>{t('সংরক্ষিত ঠিকানা', 'Saved Addresses')}</span>
            </button>

            <button
              onClick={() => setActiveTab('coupons')}
              className={`w-full text-left px-4 py-3 rounded-2xl text-xs font-bold flex items-center gap-3 transition-colors ${
                activeTab === 'coupons'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
              }`}
            >
              <Tag className="w-4 h-4" />
              <span>{t('আমার ডিসকাউন্ট কুপন', 'Coupons & Vouchers')}</span>
            </button>

            <button
              onClick={() => setActiveTab('support')}
              className={`w-full text-left px-4 py-3 rounded-2xl text-xs font-bold flex items-center gap-3 transition-colors ${
                activeTab === 'support'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
              }`}
            >
              <LifeBuoy className="w-4 h-4" />
              <span>{t('গ্রাহক সহায়তা ও হেল্পলাইন', 'Support & Help')}</span>
            </button>
          </div>

          {/* Main Tab Content */}
          <div className="lg:col-span-9 bg-white dark:bg-gray-800 rounded-3xl p-6 sm:p-8 border border-gray-100 dark:border-gray-700/80 shadow-xs">
            {/* TAB: My Orders */}
            {activeTab === 'orders' && (
              <div>
                <h3 className="text-base sm:text-lg font-black text-gray-900 dark:text-white mb-6">
                  {t('আপনার সকল অর্ডার', 'All Your Orders')} ({orders.length})
                </h3>

                {orders.length === 0 ? (
                  <div className="py-12 text-center">
                    <Package className="w-12 h-12 text-gray-400 mx-auto mb-3 opacity-60" />
                    <h4 className="text-sm font-bold text-gray-900 dark:text-white mb-1">
                      {t('এখনও কোনো অর্ডার করেননি', 'No orders placed yet')}
                    </h4>
                    <p className="text-xs text-gray-500 mb-4">
                      {t('দেশিবাজার থেকে তাজা খাবার ও খাঁটি পণ্য কিনুন।', 'Order fresh grocery and traditional handmade goods.')}
                    </p>
                    <button
                      onClick={() => setCurrentView('shop')}
                      className="px-5 py-2.5 bg-emerald-600 text-white rounded-xl text-xs font-bold"
                    >
                      {t('কেনাকাটা শুরু করুন', 'Start Shopping')}
                    </button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {orders.map((ord) => (
                      <div
                        key={ord.id}
                        className="p-5 rounded-2xl border border-gray-200 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-750/50 space-y-4"
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-gray-200 dark:border-gray-700">
                          <div>
                            <span className="font-mono font-bold text-emerald-700 dark:text-emerald-400 text-sm">
                              {ord.orderNumber}
                            </span>
                            <span className="text-gray-400 text-xs ml-2">
                              {new Date(ord.createdAt).toLocaleDateString()}
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className={`font-bold px-2.5 py-1 rounded-lg text-xs uppercase ${
                              ord.status === 'cancelled'
                                ? 'bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-400'
                                : 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
                            }`}>
                              {ord.status}
                            </span>
                            <span className="text-xs font-bold text-gray-900 dark:text-white">
                              ৳{ord.total}
                            </span>
                          </div>
                        </div>

                        {/* If order is cancelled, show cancellation reason */}
                        {ord.status === 'cancelled' && (
                          <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/40 text-xs text-rose-800 dark:text-rose-300 flex items-center gap-2">
                            <AlertCircle className="w-4 h-4 text-rose-500 shrink-0" />
                            <span>
                              {t('বাতিল করার কারণ:', 'Cancellation Reason:')}{' '}
                              <strong>{ord.cancellationReason || t('গ্রাহকের অনুরোধে বাতিল', 'Customer Request')}</strong>
                            </span>
                          </div>
                        )}

                        {/* Items in this order */}
                        <div className="space-y-2">
                          {ord.items.map((it, idx) => (
                            <div key={idx} className="flex items-center justify-between text-xs text-gray-600 dark:text-gray-300">
                              <span className="truncate pr-4">
                                {t(it.product.nameBn, it.product.name)} x {it.quantity}
                              </span>
                              <span className="font-bold shrink-0">৳{it.product.price * it.quantity}</span>
                            </div>
                          ))}
                        </div>

                        <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                          <span className="text-xs text-gray-500">
                            {ord.status === 'cancelled' ? (
                              <span className="text-rose-600 font-semibold">{t('অর্ডারটি বাতিল করা হয়েছে', 'Order is Cancelled')}</span>
                            ) : (
                              <>{t('সম্ভাব্য ডেলিভারি:', 'Est. Delivery:')} <strong className="text-gray-800 dark:text-gray-200">{ord.estimatedDelivery}</strong></>
                            )}
                          </span>

                          <div className="flex items-center gap-2 self-start sm:self-auto">
                            {/* Cancel Order Button */}
                            {['placed', 'confirmed', 'processing'].includes(ord.status) && (
                              <button
                                type="button"
                                onClick={() => {
                                  setOrderToCancel(ord);
                                  setIsCancelModalOpen(true);
                                }}
                                className="px-3.5 py-2 border border-rose-300 dark:border-rose-800 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl text-xs font-bold transition-colors flex items-center gap-1"
                              >
                                <XCircle className="w-3.5 h-3.5" />
                                <span>{t('বাতিল করুন', 'Cancel Order')}</span>
                              </button>
                            )}

                            <button
                              type="button"
                              onClick={() => openCashMemoModal(ord)}
                              className="px-3.5 py-2 bg-purple-50 hover:bg-purple-100 dark:bg-purple-950/40 dark:hover:bg-purple-900/40 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all shadow-xs active:scale-95"
                              title={t('ক্যাশ মেমো / ইনভয়েস দেখুন এবং PDF বা ছবি ডাউনলোড করুন', 'View Cash Memo and Download PDF or Image')}
                            >
                              <Receipt className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" />
                              <span>{t('ক্যাশ মেমো (PDF/Image)', 'Cash Memo')}</span>
                            </button>

                            <button
                              onClick={() => {
                                setActiveOrderToTrack(ord);
                                setCurrentView('track-order');
                              }}
                              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5"
                            >
                              <Truck className="w-3.5 h-3.5" />
                              <span>{t('লাইভ ট্র্যাক করুন', 'Live Track Order')}</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB: Wishlist */}
            {activeTab === 'wishlist' && (
              <div>
                <h3 className="text-base sm:text-lg font-black text-gray-900 dark:text-white mb-6">
                  {t('আপনার পছন্দের পণ্য তালিকা', 'Wishlist Products')} ({wishlistProducts.length})
                </h3>

                {wishlistProducts.length === 0 ? (
                  <div className="py-12 text-center">
                    <Heart className="w-12 h-12 text-gray-400 mx-auto mb-3 opacity-60" />
                    <p className="text-xs text-gray-500 mb-4">
                      {t('আপনার উইশলিস্টে কোনো পণ্য নেই।', 'Your wishlist is currently empty.')}
                    </p>
                    <button
                      onClick={() => setCurrentView('shop')}
                      className="px-5 py-2.5 bg-emerald-600 text-white rounded-xl text-xs font-bold"
                    >
                      {t('পণ্য দেখুন', 'Browse Products')}
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {wishlistProducts.map((p) => (
                      <div
                        key={p.id}
                        className="p-4 rounded-2xl border border-gray-200 dark:border-gray-700 flex gap-4 items-center justify-between bg-gray-50/50 dark:bg-gray-750"
                      >
                        <img src={p.image} alt={p.name} className="w-16 h-16 rounded-xl object-cover" />
                        <div className="flex-1 min-w-0">
                          <h4 className="text-xs font-bold text-gray-900 dark:text-white truncate">
                            {t(p.nameBn, p.name)}
                          </h4>
                          <span className="text-xs font-bold text-emerald-600 block mt-1">৳{p.price}</span>
                          <button
                            onClick={() => addToCart(p, 1)}
                            className="mt-2 text-xs font-bold text-emerald-600 hover:underline"
                          >
                            + {t('ব্যাগে যোগ করুন', 'Add to Cart')}
                          </button>
                        </div>
                        <button
                          onClick={() => toggleWishlist(p.id)}
                          className="p-2 text-gray-400 hover:text-red-500"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB: Profile Details */}
            {activeTab === 'profile' && (
              <div className="max-w-lg">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-base sm:text-lg font-black text-gray-900 dark:text-white">
                    {t('প্রোফাইল তথ্য', 'Personal Information')}
                  </h3>
                  <button
                    onClick={() => setIsEditingProfile(!isEditingProfile)}
                    className="text-xs text-emerald-600 font-bold hover:underline flex items-center gap-1"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>{isEditingProfile ? t('বাতিল', 'Cancel') : t('সম্পাদনা', 'Edit Profile')}</span>
                  </button>
                </div>

                <form onSubmit={handleSaveProfile} className="space-y-4">
                  <div>
                    <label className="text-xs font-bold text-gray-700 dark:text-gray-300 block mb-1">
                      {t('আপনার নাম', 'Full Name')}
                    </label>
                    <input
                      type="text"
                      disabled={!isEditingProfile}
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl px-3 py-2.5 text-xs text-gray-900 dark:text-white disabled:opacity-70"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-700 dark:text-gray-300 block mb-1">
                      {t('ইমেইল ঠিকানা', 'Email Address')}
                    </label>
                    <input
                      type="email"
                      disabled
                      value={userProfile?.email || user?.email || ''}
                      className="w-full bg-gray-100 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl px-3 py-2.5 text-xs text-gray-500 cursor-not-allowed"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-700 dark:text-gray-300 block mb-1">
                      {t('বাংলাদেশি মোবাইল নম্বর', 'Phone Number')}
                    </label>
                    <input
                      type="tel"
                      disabled={!isEditingProfile}
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl px-3 py-2.5 text-xs text-gray-900 dark:text-white disabled:opacity-70"
                    />
                  </div>

                  {isEditingProfile && (
                    <button
                      type="submit"
                      className="px-6 py-2.5 bg-emerald-600 text-white rounded-xl text-xs font-bold shadow-md hover:bg-emerald-700"
                    >
                      {t('সংরক্ষণ করুন', 'Save Changes')}
                    </button>
                  )}
                </form>

                {/* Embedded SMS Receipt Notification & Baki Payment Card under Profile Settings */}
                <div className="mt-8 p-5 rounded-2xl bg-gradient-to-br from-amber-50 via-white to-emerald-50 dark:from-amber-950/30 dark:via-gray-900 dark:to-emerald-950/30 border border-amber-200 dark:border-amber-800 space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="relative w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-400/40 flex items-center justify-center">
                        <Bell className="w-5 h-5 text-amber-600" />
                        {unreadSmsCount > 0 && (
                          <span className="absolute -top-1.5 -right-1.5 px-1.5 py-0.5 rounded-full bg-rose-500 text-white text-[10px] font-bold">
                            {unreadSmsCount}
                          </span>
                        )}
                      </div>
                      <div>
                        <h4 className="text-sm font-black text-gray-900 dark:text-white">
                          {t('রসিদ SMS নোটিফিকেশন ও বাকি টাকা পরিশোধ', 'Receipt SMS Notifications & Baki Payment')}
                        </h4>
                        <p className="text-xs text-gray-500 dark:text-gray-400">
                          {t(
                            `অপঠিত রসিদ SMS: ${unreadSmsCount}টি • মোট বাকি টাকা: ৳${totalCustomerBakiDue.toLocaleString()}`,
                            `Unread Receipt SMS: ${unreadSmsCount} • Total Baki Due: ৳${totalCustomerBakiDue.toLocaleString()}`
                          )}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => openSmsNotificationModal('notifications')}
                      className="px-3 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm"
                    >
                      <MessageSquare className="w-4 h-4" />
                      <span>{t(`রসিদ SMS দেখুন (${smsNotifications.length})`, `Receipt SMS (${smsNotifications.length})`)}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => openSmsNotificationModal('baki-payment')}
                      className="px-3 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm"
                    >
                      <Wallet className="w-4 h-4" />
                      <span>{t(`বাকি পরিশোধ (৳${totalCustomerBakiDue})`, `Pay Baki (৳${totalCustomerBakiDue})`)}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => openSmsNotificationModal('sms-settings')}
                      className="px-3 py-2.5 rounded-xl bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 text-gray-800 dark:text-gray-200 text-xs font-bold flex items-center justify-center gap-1.5"
                    >
                      <Settings className="w-4 h-4 text-emerald-600" />
                      <span>{t('SMS অ্যালার্ট সেটিংস', 'SMS Preferences')}</span>
                    </button>
                  </div>

                  {bakiAccounts.some(b => b.bakiAmount > 0) && (
                    <div className="text-xs bg-white/80 dark:bg-gray-800/80 rounded-xl p-3 border border-amber-200/70 dark:border-amber-800/50 space-y-1.5">
                      <span className="font-bold text-amber-800 dark:text-amber-300 block">
                        {t('বকেয়া বাকি হিসাবসমূহ:', 'Active Baki Balances:')}
                      </span>
                      {bakiAccounts
                        .filter(b => b.bakiAmount > 0)
                        .slice(0, 2)
                        .map(b => (
                          <div key={b.id} className="flex items-center justify-between gap-2">
                            <span className="text-gray-700 dark:text-gray-300 truncate">
                              {b.orderNumber} — {b.customerNameBn || b.customerName}
                            </span>
                            <button
                              type="button"
                              onClick={() => openSmsNotificationModal('baki-payment', b.id)}
                              className="px-2 py-1 rounded-lg bg-amber-500 text-white font-bold text-[11px] shrink-0"
                            >
                              {t(`৳${b.bakiAmount} পরিশোধ`, `Pay ৳${b.bakiAmount}`)}
                            </button>
                          </div>
                        ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* TAB: Saved Addresses */}
            {activeTab === 'addresses' && (
              <div>
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-base sm:text-lg font-black text-gray-900 dark:text-white">
                    {t('সংরক্ষিত ডেলিভারি ঠিকানা', 'Saved Addresses')}
                  </h3>
                  <button
                    onClick={() => setIsAddingAddress(!isAddingAddress)}
                    className="px-4 py-2 bg-emerald-600 text-white rounded-xl text-xs font-bold flex items-center gap-1.5"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{t('নতুন ঠিকানা যোগ করুন', 'Add New Address')}</span>
                  </button>
                </div>

                {isAddingAddress && (
                  <form onSubmit={handleAddNewAddress} className="mb-6 p-4 rounded-2xl bg-gray-50 dark:bg-gray-750 border border-gray-200 dark:border-gray-700 space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-xs font-bold block mb-1">{t('লেবেল (বাসা/অফিস)', 'Address Label')}</label>
                        <input
                          type="text"
                          value={newAddrTitle}
                          onChange={(e) => setNewAddrTitle(e.target.value)}
                          className="w-full bg-white dark:bg-gray-700 border border-gray-200 rounded-xl p-2 text-xs"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="text-xs font-bold block mb-1">{t('পূর্ণাঙ্গ ঠিকানা', 'Full Address')}</label>
                      <textarea
                        required
                        value={newAddrFull}
                        onChange={(e) => setNewAddrFull(e.target.value)}
                        placeholder="House, Road, Area, Dhaka"
                        className="w-full bg-white dark:bg-gray-700 border border-gray-200 rounded-xl p-2 text-xs"
                        rows={2}
                      />
                    </div>
                    <button
                      type="submit"
                      className="px-4 py-2 bg-emerald-600 text-white rounded-xl text-xs font-bold"
                    >
                      {t('ঠিকানা সংরক্ষণ করুন', 'Save Address')}
                    </button>
                  </form>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {addresses.map((addr) => (
                    <div key={addr.id} className="p-4 rounded-2xl border border-gray-200 dark:border-gray-700 bg-gray-50/40 dark:bg-gray-750 space-y-1 text-xs">
                      <div className="flex items-center justify-between font-bold text-gray-900 dark:text-white">
                        <span>{addr.title}</span>
                        {addr.isDefault && (
                          <span className="text-[10px] text-emerald-600 bg-emerald-100 dark:bg-emerald-950 px-2 py-0.5 rounded">
                            Default
                          </span>
                        )}
                      </div>
                      <p className="text-gray-600 dark:text-gray-300">{addr.fullAddress}</p>
                      <p className="text-gray-400">{addr.upazila}, {addr.district}, {addr.division}</p>
                      <p className="text-gray-400">{addr.phone}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB: Coupons */}
            {activeTab === 'coupons' && (
              <div>
                <h3 className="text-base sm:text-lg font-black text-gray-900 dark:text-white mb-6">
                  {t('আপনার উপলব্ধ কুপন ও ভাউচার', 'Available Coupons')}
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {COUPONS.map((cp) => (
                    <div
                      key={cp.code}
                      className="p-5 rounded-2xl border-2 border-dashed border-emerald-500 bg-emerald-50/40 dark:bg-emerald-950/20 flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-mono font-black text-emerald-700 dark:text-emerald-400 text-base">
                            {cp.code}
                          </span>
                          <span className="bg-emerald-600 text-white text-[10px] font-bold px-2 py-0.5 rounded">
                            {cp.discountPercent}% OFF
                          </span>
                        </div>
                        <p className="text-xs text-gray-600 dark:text-gray-300 leading-relaxed">
                          {t(cp.descriptionBn, cp.description)}
                        </p>
                      </div>

                      <div className="pt-4 mt-4 border-t border-emerald-200 dark:border-emerald-800 flex justify-between items-center text-xs">
                        <span className="text-[11px] text-gray-400">
                          {t(`ন্যূনতম অর্ডার ৳${cp.minOrder}`, `Min order ৳${cp.minOrder}`)}
                        </span>
                        <button
                          onClick={() => {
                            if (navigator.clipboard) {
                              navigator.clipboard.writeText(cp.code);
                              showToast(t(`কুপন কোড ${cp.code} কপি করা হয়েছে!`, `Coupon code ${cp.code} copied!`), 'success');
                            }
                          }}
                          className="font-bold text-emerald-600 hover:underline"
                        >
                          {t('কোড কপি করুন', 'Copy Code')}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB: Support */}
            {activeTab === 'support' && (
              <div className="space-y-6">
                <h3 className="text-base sm:text-lg font-black text-gray-900 dark:text-white">
                  {t('দেশিবাজার গ্রাহক সেবা ও হেল্পলাইন', 'Customer Support & Help Center')}
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div className="p-5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800">
                    <Phone className="w-6 h-6 text-emerald-600 mb-2" />
                    <h4 className="font-bold text-sm text-gray-900 dark:text-white mb-1">
                      {t('২৪/৭ টেলিফোন সাপোর্ট', '24/7 Phone Helpline')}
                    </h4>
                    <p className="text-gray-600 dark:text-gray-300 mb-3">
                      {t('অর্ডার সংক্রান্ত যেকোনো সহায়তায় সরাসরি কল করুন:', 'Call our dedicated Bangladesh support hotline:')}
                    </p>
                    <a href={DESHIBAZAR_CONTACT.hotlineTel} className="text-sm font-black text-emerald-700 dark:text-emerald-400 underline block mb-1">
                      {DESHIBAZAR_CONTACT.hotlineDisplay}
                    </a>
                    <span className="text-[11px] text-gray-500 block">
                      {t('মোবাইল:', 'Direct:')} {DESHIBAZAR_CONTACT.phonePrimary}
                    </span>
                  </div>

                  <div className="p-5 rounded-2xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800">
                    <LifeBuoy className="w-6 h-6 text-blue-600 mb-2" />
                    <h4 className="font-bold text-sm text-gray-900 dark:text-white mb-1">
                      {t('ইমেইল ও কমপ্লেইন ডেস্ক', 'Email & Inquiries')}
                    </h4>
                    <p className="text-gray-600 dark:text-gray-300 mb-3">
                      {t('আমাদের অফিসিয়াল সাপোর্ট ডেস্কে ইমেইল পাঠান:', 'Drop an email for order issues or vendor queries:')}
                    </p>
                    <span className="text-xs font-bold text-blue-700 dark:text-blue-400">
                      support@deshibazar.bd
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Cancel Order Modal */}
      <CancelOrderModal
        order={orderToCancel}
        isOpen={isCancelModalOpen}
        onClose={() => {
          setIsCancelModalOpen(false);
          setOrderToCancel(null);
        }}
      />
    </div>
  );
};
